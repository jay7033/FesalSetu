# FasalSetu Smart Supply-Chain Intelligence Architecture

## 1. Architectural Overview

Phase 8 elevates FasalSetu from a transactional marketplace with predictive demand (Phase 6) and route optimization (Phase 7) into a **Smart Supply-Chain Intelligence Platform**. The engine coordinates supply, demand, procurement, and logistics into actionable, explainable decision-support systems for Farmers, FPOs, Consumers, and Bulk Buyers.

```
                         🌾 FASALSETU
                              │
                              ▼
                    DIRECT FARM MARKET
                              │
                 ┌────────────┴────────────┐
                 ▼                         ▼
             FARMERS/FPOs               BUYERS
                 │                         │
                 └────────────┬────────────┘
                              ▼
                         REAL ORDERS
                              │
                              ▼
                       SUPABASE BACKEND
                              │
             ┌────────────────┼────────────────┐
             ▼                ▼                ▼
         INVENTORY          ORDERS          LOCATIONS
             │                │                │
             └────────────────┼────────────────┘
                              ▼
                     🧠 AI INTELLIGENCE
                              │
       ┌──────────────────────┼──────────────────────┐
       ▼                      ▼                      ▼
 DEMAND FORECAST       SUPPLY-DEMAND          SMART MATCHING
                            GAPS
       │                      │                      │
       └──────────────────────┼──────────────────────┘
                              ▼
                    PROCUREMENT INTELLIGENCE
                              │
                              ▼
                    SURPLUS REDISTRIBUTION
                              │
                              ▼
                    🚚 LOGISTICS ENGINE
                              │
                              ▼
                    ROUTE OPTIMIZATION
                              │
                              ▼
                         PICKUP
                              │
                              ▼
                     CONSOLIDATED LOAD
                              │
                              ▼
                         DELIVERY
                              │
                              ▼
                           BUYER
```

---

## 2. Core Modules & Deterministic Logic

Phase 8 strictly extends `src/services/ai/` rather than creating a disconnected secondary AI subsystem:

### 2.1 Smart Matching Engine (`matchingService.js`)
Calculates transparent match scores (0–100) between Producer inventory and Buyer purchase requirements.
- **Centralized Prototype Weights (`MATCH_WEIGHTS`)**:
  - Quantity Compatibility: **25%**
  - Distance Proximity: **20%**
  - Quality Compatibility: **20%**
  - Price Compatibility: **15%**
  - Harvest Freshness: **10%**
  - Demand Relevance: **10%**
- **Explainability**: Outputs structured checklist factors (e.g., *"✓ Quantity fulfills 84% of buyer requirement"*, *"✓ Producer located within 32 km"*).

### 2.2 Supply-Demand Gap Engine (`supplyDemandService.js`)
Calculates:
$$\text{Potential Gap} = \text{Forecast Demand} - \text{Available Supply}$$
- **Classifications**:
  - `Potential Shortage`: Demand exceeds available local supply by $> 25\%$ or zero supply exists for positive demand.
  - `Potential Surplus`: Available local supply exceeds demand by $> 25\%$.
  - `Balanced`: Supply and demand are within $\pm 25\%$ equilibrium.
  - `Insufficient Data`: Insufficient order history or zero inventory listings.

### 2.3 Regional Surplus Redistribution (`redistributionService.js`)
Integrates Phase 7 fleet profiles and routes (`distanceService.js`, `logisticsUtils.js`).
- Identifies surplus in Region A and deficit in Region B for identical commodities.
- Checks transit distance and selects the optimal vehicle class (`Mini Truck`, `Small Truck`, `Medium Truck`, `Large Truck`).
- Cross-references active scheduled routes to identify vehicle consolidation opportunities (e.g. Nashik $\rightarrow$ Mumbai, Jewar $\rightarrow$ Noida).

### 2.4 Intelligent Bulk Procurement Engine (`procurementService.js`)
Aggregates multi-supplier sources to fulfill large institutional purchase orders.
- Evaluates candidate pools against MOQs, quality grades, and unit pricing.
- Optimizes between **Fewest Suppliers** (high-capacity FPOs) and **Shortest Corridor Distance** (hyperlocal clusters).
- Computes estimated total distance, total procurement costs, and fulfillment percentage.

### 2.5 Opportunity Scoring & Observed Price Signals (`opportunityScoreService.js`)
- **Farmer Opportunity Score (0–100)**: Considers forecast growth velocity, local supply scarcity, farmer's inventory, active buyer queries, and nearby logistics routes. Suggests listing ranges (e.g., *"Consider listing 120–180 kg"*).
- **FPO Aggregation Intelligence**: Aggregates member farm inventory vs regional forecast to identify bulk aggregation opportunities.
- **Observed Marketplace Price Trend**: Computes 30-day and recent median transaction prices. Labels trends as *"Observed marketplace price trend"* without fabricating future market predictions.

### 2.6 Supply Chain Health Scorecard (`supplyChainAnalyticsService.js`)
Evaluates system-wide composite metrics:
- **Demand Coverage %**: Listed inventory vs total projected demand.
- **Supply Availability %**: Percentage of catalogue items with active stock.
- **Fulfillment Efficiency %**: Ratio of successfully delivered/in-transit orders vs cancellations.
- **Logistics Efficiency %**: Fleet load capacity utilization across active routes.

### 2.7 AI Explanation Engine (`aiExplanationService.js`)
Converts mathematical matching, opportunity, and redistribution vectors into clear, human-readable explanations.

---

## 3. Database Architecture & Supabase Migration

Migration [`015_smart_supply_chain.sql`](file:///c:/Users/ASUS/OneDrive/Desktop/🤖🤖/NewWork/FasalSetu/supabase/migrations/015_smart_supply_chain.sql) adds 4 persistent tables:

1. **`smart_matches`**: Stores product-to-buyer matching scores, component breakdowns, and explanation checklists.
2. **`supply_demand_insights`**: Stores regional demand vs supply gap aggregates across State, District, and City.
3. **`procurement_recommendations`**: Stores multi-supplier procurement plans, aggregated sources, and estimated costs.
4. **`opportunity_scores`**: Stores actor opportunity scores and decision-support recommendations.

### Row Level Security (RLS) & Privacy
- `smart_matches`: Accessible only by the involved buyer, seller, or authorized FPO/admin.
- `procurement_recommendations`: Isolated to the owning buyer.
- `opportunity_scores`: Actor-specific isolation.
- `supply_demand_insights`: Publicly readable for regional macro statistics.
- **Zero Raw GPS Leakage**: Coordinates (`latitude`, `longitude`, `accuracy`) remain quarantined inside internal calculation helpers and are never exposed in public AI payloads.

---

## 4. UI Components & Role Dashboards

### Reusable UI Components
- `SmartMatchCard.jsx`: Product, counterparty, distance, match score (0–100), factor breakdown bars, and deterministic explanations.
- `OpportunityCard.jsx`: Opportunity score gauge, demand velocity badge, suggested listing range, and decision-support advisory.
- `ProcurementRecommendationCard.jsx`: Bulk sourcing plan, multi-supplier source breakdown, estimated distance and cost, algorithm comparison.
- `SupplyChainHealthCard.jsx`: Unified 4-pillar scorecard for system efficiency.

### Role Dashboards
- **`/ai-insights`**: Comprehensive command center with tabbed navigation:
  1. AI Demand Forecasts (Phase 6 preserved)
  2. Supply-Demand Gaps (Regional gap analysis, Shortage/Surplus classification)
  3. Smart Matches (Farmer–Buyer compatibility)
  4. Regional Surplus Redistribution (Fleet capacity integration)
  5. Printable Intelligence Report modal.
- **Farmer Dashboard**: Integrated **Smart Opportunity Center** with suggested listing volumes.
- **FPO Dashboard**: **FPO Aggregation Intelligence** comparing member pools with regional forecast demand.
- **Bulk Buyer Dashboard**: **Smart Procurement Center** featuring multi-supplier bundling.
- **Consumer Dashboard**: **Smart Recommendations** (Fresh Near You, High Availability) with privacy protection.

---

## 5. Important Limitations & Disclaimers

1. **Decision-Support Only**: AI recommendations are decision-support tools. The system never automatically buys, sells, transfers inventory, or mandates farmer planting decisions.
2. **Prototype Indicators**: Confidence scores and composite health percentages are prototype indicators based on available marketplace velocity.
3. **Price Signals**: Price trends reflect observed historical transaction medians only; they do not guarantee future market prices.
4. **Logistics Routing**: Route distances and travel times are computed using deterministic Haversine calculations and road category speed models; they do not claim live traffic awareness without external road routing APIs.
