import { calculateDistance, formatDistance } from '../src/utils/distance.js';
import { VALID_STATUS_TRANSITIONS, ORDER_LIFECYCLE_STEPS } from '../src/constants/orderStatus.js';

console.log('====================================================');
console.log('RUNNING PHASE 4 AUTOMATED BUSINESS LOGIC VALIDATION');
console.log('====================================================');

let passedTests = 0;
let totalTests = 0;

function assert(condition, testName) {
  totalTests++;
  if (condition) {
    console.log(`✅ [PASS] ${testName}`);
    passedTests++;
  } else {
    console.error(`❌ [FAIL] ${testName}`);
  }
}

// 1. Distance & Logistics Utility Verification
const noidaLat = 28.6139;
const noidaLon = 77.3592;
const dankaurLat = 28.352;
const dankaurLon = 77.550;

const dist = calculateDistance(noidaLat, noidaLon, dankaurLat, dankaurLon);
assert(typeof dist === 'number' && dist > 30 && dist < 45, `Haversine distance between Noida & Dankaur is ~35km (Calculated: ${dist} km)`);
assert(formatDistance(dist).includes('km away'), `Formatted distance string output: "${formatDistance(dist)}"`);
assert(calculateDistance(null, 77, 28, 77) === null, 'Gracefully handles null coordinates without leaking or crashing');

// 2. Strict Sequential Status Transition Rules Verification
assert(ORDER_LIFECYCLE_STEPS.length === 7, 'Lifecycle has exactly 7 sequential stages');
assert(VALID_STATUS_TRANSITIONS['Pending'].includes('Confirmed'), 'Pending can transition to Confirmed');
assert(!VALID_STATUS_TRANSITIONS['Pending'].includes('In Transit'), 'Pending CANNOT jump to In Transit');
assert(!VALID_STATUS_TRANSITIONS['Pending'].includes('Delivered'), 'Pending CANNOT jump directly to Delivered');
assert(VALID_STATUS_TRANSITIONS['Confirmed'].includes('Preparing'), 'Confirmed can transition to Preparing');
assert(VALID_STATUS_TRANSITIONS['Preparing'].includes('Ready for Pickup'), 'Preparing can transition to Ready for Pickup');
assert(VALID_STATUS_TRANSITIONS['Ready for Pickup'].includes('Picked Up'), 'Ready for Pickup can transition to Picked Up');
assert(VALID_STATUS_TRANSITIONS['Picked Up'].includes('In Transit'), 'Picked Up can transition to In Transit');
assert(VALID_STATUS_TRANSITIONS['In Transit'].includes('Delivered'), 'In Transit can transition to Delivered');
assert(VALID_STATUS_TRANSITIONS['Delivered'].length === 0, 'Delivered is terminal status and cannot transition further');

// 3. Multi-Supplier Grouping Verification
const sampleCart = [
  { id: 'p1', name: 'Desi Tomatoes', price: 45, quantity: 5, farmerId: 'farmer_1', farmerName: 'Ramesh Singh' },
  { id: 'p2', name: 'Fresh Spinach', price: 30, quantity: 2, farmerId: 'farmer_1', farmerName: 'Ramesh Singh' },
  { id: 'p3', name: 'Basmati Rice', price: 120, quantity: 10, farmerId: 'fpo_1', farmerName: 'Kisan Vikas FPO' }
];

const supplierMap = {};
sampleCart.forEach(item => {
  const supplierKey = item.farmerId || item.fpoId || 'direct_farm';
  if (!supplierMap[supplierKey]) {
    supplierMap[supplierKey] = {
      supplierId: supplierKey,
      supplierName: item.farmerName || 'Farm Producer',
      items: [],
      subtotal: 0
    };
  }
  supplierMap[supplierKey].items.push(item);
  supplierMap[supplierKey].subtotal += item.price * item.quantity;
});

const fulfillments = Object.values(supplierMap);
assert(fulfillments.length === 2, 'Multi-supplier cart correctly grouped into 2 fulfillment batches');
assert(fulfillments[0].items.length === 2, 'Farmer 1 has 2 produce line items');
assert(fulfillments[1].items.length === 1, 'FPO 1 has 1 produce line item');
assert(fulfillments[0].subtotal === (45 * 5 + 30 * 2), 'Farmer 1 subtotal calculation matches');

// 4. Inventory Reservation & Restoral Logic Verification
let mockProduct = {
  id: 'p1',
  name: 'Desi Tomatoes',
  quantity: 100,
  reservedQuantity: 0
};

// Reserve
const reserveQty = 15;
if (mockProduct.quantity >= reserveQty) {
  mockProduct.quantity -= reserveQty;
  mockProduct.reservedQuantity += reserveQty;
}
assert(mockProduct.quantity === 85 && mockProduct.reservedQuantity === 15, 'Inventory reserved: available decreased to 85, reserved is 15');

// Release on Cancellation
mockProduct.quantity += mockProduct.reservedQuantity;
mockProduct.reservedQuantity = 0;
assert(mockProduct.quantity === 100 && mockProduct.reservedQuantity === 0, 'Inventory released upon cancellation: 100 available, 0 reserved');

// 5. Bulk Procurement MOQ Rejection Check
const bulkProduct = {
  id: 'bp1',
  name: 'Kashmiri Apples Lot',
  moq: 500, // 500 kg minimum
  pricePerKg: 65
};

const requestedQtyBelowMoq = 300;
const isMoqValid = requestedQtyBelowMoq >= (bulkProduct.moq || 1);
assert(!isMoqValid, 'MOQ validation rejects orders below 500 kg minimum');

const requestedQtyAboveMoq = 1000;
const isMoqValidAbove = requestedQtyAboveMoq >= (bulkProduct.moq || 1);
assert(isMoqValidAbove, 'MOQ validation accepts orders equal to or above 500 kg');

console.log('====================================================');
console.log(`PHASE 4 VALIDATION COMPLETE: ${passedTests}/${totalTests} TESTS PASSED`);
console.log('====================================================');

if (passedTests !== totalTests) {
  process.exit(1);
}
