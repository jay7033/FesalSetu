// Automated Verification Script for Phase 9.35: Hybrid Live + Demo Data Architecture
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

import { normalizeProduct, normalizeOrder, deduplicateById } from '../src/utils/normalizers.js';
import { 
  getConnectionStatus, 
  updateConnectionStatus, 
  mergeAndDeduplicate, 
  isDemoRecord, 
  canModifyRecord, 
  getDataComposition 
} from '../src/services/hybridDataService.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const srcDir = path.join(rootDir, 'src');

console.log('====================================================');
console.log('RUNNING PHASE 9.35 HYBRID ARCHITECTURE VERIFICATION');
console.log('====================================================');

let passedTests = 0;
let totalTests = 0;

function assert(condition, testName) {
  totalTests++;
  if (condition) {
    console.log(`✅ [PASS] ${testName}`);
    passedTests++;
  } else {
    console.error(`❌ [FAIL] ${testName}`);
  }
}

function readFile(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf-8');
  } catch {
    return '';
  }
}

// ============================================================
// 1. NORMALIZATION & DEDUPLICATION UTILITIES
// ============================================================
console.log('\n--- 1. Normalization & Deduplication Logic ---');

const sampleDemoProduct = {
  id: 'prod_1',
  name: 'Organic Wheat',
  price: 32,
  unit: 'kg',
  farmer: 'Ramesh Kumar'
};

const normDemo = normalizeProduct(sampleDemoProduct, 'demo');
assert(normDemo.source === 'demo', 'normalizeProduct tags demo source');
assert(normDemo.isDemo === true, 'normalizeProduct sets isDemo to true for demo');

const sampleLiveProduct = {
  id: 'prod_1',
  name: 'Live Wheat from Farm',
  price: 30,
  unit: 'kg',
  seller_name: 'Suresh Patil',
  is_demo: false
};

const normLive = normalizeProduct(sampleLiveProduct, 'live');
assert(normLive.source === 'live', 'normalizeProduct tags live source');
assert(normLive.isDemo === false, 'normalizeProduct sets isDemo to false for live');

// Deduplication test: live must take precedence over demo with identical ID
const mergedProds = deduplicateById([normLive, normDemo]);
assert(mergedProds.length === 1, 'deduplicateById collapses duplicate IDs');
assert(mergedProds[0].source === 'live', 'deduplicateById retains first item (live wins)');
assert(mergedProds[0].name === 'Live Wheat from Farm', 'live product attributes are preserved');

// Normalizing order
const sampleOrder = {
  id: 'ord_100',
  order_number: 'FS-2026-100',
  total_amount: 1500
};
const normOrder = normalizeOrder(sampleOrder, 'live');
assert(normOrder.source === 'live', 'normalizeOrder tags live source');
assert(normOrder.orderNumber === 'FS-2026-100', 'normalizeOrder maps camelCase fields');

// ============================================================
// 2. HYBRID DATA SERVICE & ORCHESTRATION
// ============================================================
console.log('\n--- 2. Hybrid Data Service Utilities ---');

assert(typeof getConnectionStatus === 'function', 'getConnectionStatus is exported');
assert(typeof updateConnectionStatus === 'function', 'updateConnectionStatus is exported');

// Test isDemoRecord utility
assert(isDemoRecord({ isDemo: true }) === true, 'isDemoRecord recognizes isDemo: true');
assert(isDemoRecord({ is_demo: true }) === true, 'isDemoRecord recognizes is_demo: true');
assert(isDemoRecord({ source: 'demo' }) === true, 'isDemoRecord recognizes source: demo');
assert(isDemoRecord({ source: 'live', isDemo: false }) === false, 'isDemoRecord returns false for live');

// Test canModifyRecord utility (demo protection)
assert(canModifyRecord({ isDemo: true }, 'user_123') === false, 'canModifyRecord blocks mutation of demo record');
assert(canModifyRecord({ isDemo: false, source: 'live' }, 'user_123') === true, 'canModifyRecord allows mutation of live record');

// Test mergeAndDeduplicate
const combined = mergeAndDeduplicate([normLive], [normDemo]);
assert(combined.length === 1 && combined[0].source === 'live', 'mergeAndDeduplicate ensures live wins');

// Test getDataComposition
const comp = getDataComposition([normLive, normDemo, { id: 'prod_2', isDemo: true }], [normOrder]);
assert(comp.totalProducts === 3, 'getDataComposition counts total products');
assert(comp.liveProducts === 1, 'getDataComposition counts live products accurately');
assert(comp.demoProducts === 2, 'getDataComposition counts demo products accurately');
assert(comp.liveOrders === 1, 'getDataComposition counts live orders');
assert(comp.hasLiveData === true, 'getDataComposition detects presence of live data');

// ============================================================
// 3. DATABASE MIGRATIONS & SCHEMA
// ============================================================
console.log('\n--- 3. Database Schema & Migrations ---');

const migrationPath = path.join(rootDir, 'supabase', 'migrations', '016_hybrid_data.sql');
assert(fs.existsSync(migrationPath), 'Migration 016_hybrid_data.sql exists');

const migrationSql = readFile(migrationPath);
assert(migrationSql.includes('is_demo BOOLEAN DEFAULT false'), 'Migration adds is_demo boolean column');
assert(migrationSql.includes('idx_products_is_demo'), 'Migration adds index for fast hybrid querying');
assert(migrationSql.includes('idx_profiles_is_demo'), 'Migration indexes demo profiles');

const seedPath = path.join(rootDir, 'supabase', 'seed.sql');
assert(fs.existsSync(seedPath), 'Supabase seed.sql exists');
const seedSql = readFile(seedPath);
assert(seedSql.includes('is_demo'), 'Seed SQL references is_demo column');

// ============================================================
// 4. DEMO DATA BASELINE INTEGRITY
// ============================================================
console.log('\n--- 4. Demo Data Source Tagging ---');

const demoDataPath = path.join(srcDir, 'data', 'demoData.js');
const demoDataContent = readFile(demoDataPath);
assert(demoDataContent.includes("source: 'demo'") || demoDataContent.includes('isDemo: true'), 'demoData.js tags records with demo identity');
assert(demoDataContent.includes('DEMO_METADATA'), 'demoData.js exports DEMO_METADATA architecture descriptor');

// ============================================================
// 5. CONTEXT ARCHITECTURE INTEGRATION
// ============================================================
console.log('\n--- 5. Context Layer Hybrid Hardening ---');

// ProductContext
const productContextContent = readFile(path.join(srcDir, 'context', 'ProductContext.jsx'));
assert(productContextContent.includes('normalizeProduct'), 'ProductContext uses normalizers');
assert(productContextContent.includes('connectionStatus'), 'ProductContext tracks connectionStatus');
assert(productContextContent.includes('isDemoRecord'), 'ProductContext checks isDemoRecord');
assert(productContextContent.includes('resetToDefaultProducts'), 'ProductContext provides resetToDefaultProducts preserving live data');

// OrderContext
const orderContextContent = readFile(path.join(srcDir, 'context', 'OrderContext.jsx'));
assert(orderContextContent.includes('isDemoRecord'), 'OrderContext checks isDemoRecord');
assert(orderContextContent.includes('Demo orders cannot be cancelled') || orderContextContent.includes('isDemo: true'), 'OrderContext protects demo orders');
assert(orderContextContent.includes('source:'), 'OrderContext tags source');

// AuthContext
const authContextContent = readFile(path.join(srcDir, 'context', 'AuthContext.jsx'));
assert(authContextContent.includes("source: 'demo'"), 'AuthContext tags demo accounts with source demo');
assert(authContextContent.includes("source: 'live'"), 'AuthContext tags live user signups with source live');

// LocationContext
const locationContextContent = readFile(path.join(srcDir, 'context', 'LocationContext.jsx'));
assert(locationContextContent.includes('isDemo: true'), 'LocationContext flags initial demo locations');
assert(locationContextContent.includes("source: 'live'"), 'LocationContext marks new farm locations as live');

// AIContext
const aiContextContent = readFile(path.join(srcDir, 'context', 'AIContext.jsx'));
assert(aiContextContent.includes('getDataComposition'), 'AIContext integrates getDataComposition');
assert(aiContextContent.includes('dataComposition'), 'AIContext exposes dataComposition in state/value');

// BuyerContext
const buyerContextContent = readFile(path.join(srcDir, 'context', 'BuyerContext.jsx'));
assert(buyerContextContent.includes("source: 'demo'"), 'BuyerContext tags initial seed lists with source demo');
assert(buyerContextContent.includes("source: 'live'"), 'BuyerContext marks added preferred locations as live');

// ============================================================
// 6. UI PRESENTATION & INDICATORS
// ============================================================
console.log('\n--- 6. UI Components & Presentation Readiness ---');

const indicatorPath = path.join(srcDir, 'components', 'ConnectionStatusIndicator.jsx');
assert(fs.existsSync(indicatorPath), 'ConnectionStatusIndicator.jsx component exists');

const indicatorContent = readFile(indicatorPath);
assert(indicatorContent.includes('Live Sync') && indicatorContent.includes('Demo Sandbox'), 'Indicator differentiates Live Sync vs Demo Sandbox');
assert(indicatorContent.includes('Reset Demo Data'), 'Indicator provides demo data reset button');

const navbarContent = readFile(path.join(srcDir, 'components', 'Navbar.jsx'));
assert(navbarContent.includes('ConnectionStatusIndicator'), 'Navbar mounts ConnectionStatusIndicator');

const productCardContent = readFile(path.join(srcDir, 'components', 'ProductCard.jsx'));
assert(productCardContent.includes('Sample Listing') && productCardContent.includes('Live Farmer'), 'ProductCard presents tasteful Sample Listing vs Live Farmer badges');

const aiInsightsContent = readFile(path.join(srcDir, 'pages', 'AIInsights.jsx'));
assert(aiInsightsContent.includes('Hybrid Intelligence Pipeline'), 'AIInsights showcases transparent Hybrid Intelligence banner');
assert(aiInsightsContent.includes('dataComposition'), 'AIInsights renders live vs demo composition breakdown');

// ============================================================
// SUMMARY
// ============================================================
console.log('\n====================================================');
console.log(`HYBRID ARCHITECTURE VERIFICATION: ${passedTests}/${totalTests} TESTS PASSED`);
console.log('====================================================');

if (passedTests === totalTests) {
  console.log('🎉 ALL PHASE 9.35 HYBRID ARCHITECTURE VERIFICATIONS PASSED!\n');
  process.exit(0);
} else {
  console.error(`⚠️ ${totalTests - passedTests} TESTS FAILED. Check errors above.\n`);
  process.exit(1);
}
