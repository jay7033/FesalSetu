// Automated Verification Script for Phase 5: Supabase Backend & Secure Data Architecture
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { isSupabaseConfigured } from '../src/lib/supabase.js';
import { authService } from '../src/services/authService.js';
import { productService } from '../src/services/productService.js';
import { orderService } from '../src/services/orderService.js';
import { inventoryService } from '../src/services/inventoryService.js';
import { notificationService } from '../src/services/notificationService.js';
import { profileService } from '../src/services/profileService.js';
import { locationService } from '../src/services/locationService.js';
import { fpoService } from '../src/services/fpoService.js';
import { buyerService } from '../src/services/buyerService.js';
import { VALID_STATUS_TRANSITIONS, ORDER_LIFECYCLE_STEPS } from '../src/constants/orderStatus.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

console.log('====================================================');
console.log('RUNNING PHASE 5 SUPABASE BACKEND & RLS VALIDATION');
console.log('====================================================');

let passedTests = 0;
let totalTests = 0;

function assert(condition, testName) {
  totalTests++;
  if (condition) {
    console.log(`✅ [PASS] ${testName}`);
    passedTests++;
  } else {
    console.error(`❌ [FAIL] ${testName}`);
  }
}

// 1. Supabase Client & Configuration
assert(typeof isSupabaseConfigured === 'function', 'isSupabaseConfigured helper is properly exported');
const configStatus = isSupabaseConfigured();
assert(typeof configStatus === 'boolean', `Supabase client initializes safely without unhandled crashes (Configured: ${configStatus})`);

// 2. Migration Directory & Sequential Files Verification
const migrationsDir = path.join(rootDir, 'supabase', 'migrations');
assert(fs.existsSync(migrationsDir), 'supabase/migrations/ directory exists');

const expectedMigrations = [
  '001_profiles.sql',
  '002_farmer_fpo_profiles.sql',
  '003_buyer_profiles.sql',
  '004_locations.sql',
  '005_products.sql',
  '006_orders.sql',
  '007_inventory.sql',
  '008_notifications.sql',
  '009_saved_products.sql',
  '010_rls_policies.sql',
  '011_functions.sql',
  '012_storage.sql'
];

expectedMigrations.forEach((migrationFile) => {
  const filePath = path.join(migrationsDir, migrationFile);
  assert(fs.existsSync(filePath), `Migration file exists: ${migrationFile}`);
});

// Verify seed.sql exists
assert(fs.existsSync(path.join(rootDir, 'supabase', 'seed.sql')), 'supabase/seed.sql exists and contains Pan-India demo records');

// 3. SQL Migration Integrity & Constraint Checks
const profilesSql = fs.readFileSync(path.join(migrationsDir, '001_profiles.sql'), 'utf-8');
assert(profilesSql.includes("'farmer', 'fpo', 'consumer', 'bulk_buyer'"), '001_profiles enforces all 4 primary user roles');
assert(profilesSql.includes('handle_new_user'), '001_profiles includes automatic auth.users synchronization trigger');

const locationsSql = fs.readFileSync(path.join(migrationsDir, '004_locations.sql'), 'utf-8');
assert(locationsSql.includes('public_farm_locations'), '004_locations contains public_farm_locations privacy view');
assert(!locationsSql.includes('SELECT latitude, longitude FROM public.public_farm_locations'), 'public_farm_locations view conceals exact GPS latitude/longitude');

const productsSql = fs.readFileSync(path.join(migrationsDir, '005_products.sql'), 'utf-8');
assert(productsSql.includes('quantity_available >= 0'), '005_products enforces quantity_available >= 0 constraint');
assert(productsSql.includes('reserved_quantity >= 0'), '005_products enforces reserved_quantity >= 0 constraint');

const rlsSql = fs.readFileSync(path.join(migrationsDir, '010_rls_policies.sql'), 'utf-8');
assert(rlsSql.includes('ENABLE ROW LEVEL SECURITY'), '010_rls_policies enables RLS across database tables');
assert(rlsSql.includes('auth.uid()'), '010_rls_policies relies on secure auth.uid() tenant boundary checks');

const functionsSql = fs.readFileSync(path.join(migrationsDir, '011_functions.sql'), 'utf-8');
assert(functionsSql.includes('create_order_transaction'), '011_functions contains create_order_transaction atomic RPC');
assert(functionsSql.includes('update_order_status'), '011_functions contains update_order_status sequential transition RPC');
assert(functionsSql.includes('cancel_order_transaction'), '011_functions contains cancel_order_transaction restoral RPC');

// 4. Service Layer Completeness Checks
assert(typeof authService.signUp === 'function' && typeof authService.signIn === 'function', 'authService exposes signUp and signIn');
assert(typeof productService.getPublicProducts === 'function' && typeof productService.createProduct === 'function', 'productService exposes getPublicProducts and createProduct');
assert(typeof orderService.createOrder === 'function' && typeof orderService.updateOrderStatus === 'function', 'orderService exposes createOrder and updateOrderStatus');
assert(typeof inventoryService.getInventoryLedger === 'function', 'inventoryService exposes getInventoryLedger');
assert(typeof notificationService.getNotifications === 'function' && typeof notificationService.markAsRead === 'function', 'notificationService exposes getNotifications and markAsRead');
assert(typeof profileService.getProfile === 'function', 'profileService exposes getProfile');
assert(typeof locationService.getFarmLocations === 'function' && typeof locationService.addFarmLocation === 'function', 'locationService exposes getFarmLocations and addFarmLocation');
assert(typeof fpoService.getFPOMembers === 'function' && typeof fpoService.addMember === 'function', 'fpoService exposes getFPOMembers and addMember');
assert(typeof buyerService.getSavedProducts === 'function' && typeof buyerService.toggleSavedProduct === 'function', 'buyerService exposes getSavedProducts and toggleSavedProduct');

// 5. Atomic Inventory Calculation Integrity
let testProduct = {
  id: 'test-p1',
  available: 500,
  reserved: 0,
  sold: 0
};

// Action 1: Reserve 100 kg
const orderQty = 100;
testProduct.available -= orderQty;
testProduct.reserved += orderQty;
assert(testProduct.available === 400 && testProduct.reserved === 100, 'Atomic Reserve: available=400, reserved=100');

// Action 2: Finalize Delivery (Deduct)
testProduct.reserved -= orderQty;
testProduct.sold += orderQty;
assert(testProduct.available === 400 && testProduct.reserved === 0 && testProduct.sold === 100, 'Atomic Deduct: available=400, reserved=0, sold=100');

// Action 3: Restoral on Cancellation
let cancelledOrderProduct = {
  id: 'test-p2',
  available: 250,
  reserved: 50
};
cancelledOrderProduct.available += cancelledOrderProduct.reserved;
cancelledOrderProduct.reserved = 0;
assert(cancelledOrderProduct.available === 300 && cancelledOrderProduct.reserved === 0, 'Atomic Release: available restored to 300, reserved=0');

// 6. Strict Sequential Status Transition Rules
assert(ORDER_LIFECYCLE_STEPS.length === 7, 'Order lifecycle has exactly 7 sequential stages');
assert(VALID_STATUS_TRANSITIONS['Pending'].includes('Confirmed'), 'Pending -> Confirmed transition valid');
assert(!VALID_STATUS_TRANSITIONS['Pending'].includes('Delivered'), 'Pending -> Delivered jump strictly rejected');
assert(VALID_STATUS_TRANSITIONS['Confirmed'].includes('Preparing'), 'Confirmed -> Preparing transition valid');
assert(VALID_STATUS_TRANSITIONS['Preparing'].includes('Ready for Pickup'), 'Preparing -> Ready for Pickup transition valid');
assert(VALID_STATUS_TRANSITIONS['Ready for Pickup'].includes('Picked Up'), 'Ready for Pickup -> Picked Up transition valid');
assert(VALID_STATUS_TRANSITIONS['Picked Up'].includes('In Transit'), 'Picked Up -> In Transit transition valid');
assert(VALID_STATUS_TRANSITIONS['In Transit'].includes('Delivered'), 'In Transit -> Delivered transition valid');

console.log('====================================================');
console.log(`PHASE 5 VALIDATION COMPLETE: ${passedTests}/${totalTests} TESTS PASSED`);
console.log('====================================================');

if (passedTests !== totalTests) {
  process.exit(1);
}
