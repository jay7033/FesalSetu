// Automated Verification Script for Phase 7: Hyperlocal Logistics & Route Optimization
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

import { 
  calculateHaversineDistance, 
  buildDistanceMatrix,
  calculateTotalRouteDistance 
} from '../src/services/logistics/distanceService.js';

import { 
  VEHICLE_PROFILES,
  getVehicleProfile,
  canTransitionShipmentStatus,
  canTransitionPickupStatus,
  canTransitionRouteStatus,
  calculateTransportCost,
  formatDuration,
  SHIPMENT_STATUSES,
  PICKUP_STATUSES,
  ROUTE_STATUSES
} from '../src/services/logistics/logisticsUtils.js';

import { 
  optimizeRoute,
  validateCapacity,
  splitIntoRoutes,
  calculateRouteETA
} from '../src/services/logistics/routeOptimizationService.js';

import { 
  generateTrackingNumber,
  createShipmentRecord,
  advanceShipmentStatus
} from '../src/services/logistics/shipmentService.js';

import { 
  createPickupSchedule,
  advancePickupStatus
} from '../src/services/logistics/pickupService.js';

import { logisticsService } from '../src/services/logistics/logisticsService.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

console.log('====================================================');
console.log('RUNNING PHASE 7 LOGISTICS & ROUTE OPTIMIZATION TESTS');
console.log('====================================================');

let passedTests = 0;
let totalTests = 0;

function assert(condition, testName) {
  totalTests++;
  if (condition) {
    console.log(`✅ [PASS] ${testName}`);
    passedTests++;
  } else {
    console.error(`❌ [FAIL] ${testName}`);
  }
}

// ----------------------------------------------------
// 1. DISTANCE SERVICE & HAVERSINE MATHEMATICS
// ----------------------------------------------------
const p1 = { lat: 28.1285, lng: 77.5553 }; // Jewar
const p2 = { lat: 28.3512, lng: 77.5540 }; // Dankaur
const p3 = { lat: 28.6280, lng: 77.3649 }; // Noida Sec 62

const dSame = calculateHaversineDistance(p1.lat, p1.lng, p1.lat, p1.lng);
assert(dSame === 0, `Haversine distance between identical points is 0 (got: ${dSame})`);

const d12 = calculateHaversineDistance(p1.lat, p1.lng, p2.lat, p2.lng);
const d21 = calculateHaversineDistance(p2.lat, p2.lng, p1.lat, p1.lng);
assert(d12 > 0 && Math.abs(d12 - d21) < 0.001, `Distance is symmetric: Jewar -> Dankaur (${d12} km) == Dankaur -> Jewar (${d21} km)`);
assert(d12 >= 20 && d12 <= 30, `Jewar to Dankaur realistic corridor distance is ~24-26 km (got: ${d12} km)`);

const dMissing = calculateHaversineDistance(null, undefined, 28.5, 77.5);
assert(dMissing === 0, `Handles missing coordinates gracefully without throwing (got: ${dMissing})`);

const matrix = buildDistanceMatrix([
  { id: 'A', lat: p1.lat, lng: p1.lng },
  { id: 'B', lat: p2.lat, lng: p2.lng },
  { id: 'C', lat: p3.lat, lng: p3.lng }
]);
assert(matrix['A']['B'] === d12, `Distance matrix indexing holds true for stop A -> stop B`);
assert(matrix['A']['A'] === 0, `Distance matrix self-distance is 0`);

const totalDist = calculateTotalRouteDistance([p1, p2]);
assert(totalDist === d12, `calculateTotalRouteDistance returns path distance (got: ${totalDist} km)`);
assert(Array.isArray(SHIPMENT_STATUSES) && SHIPMENT_STATUSES.length >= 6, `SHIPMENT_STATUSES lifecycle steps exported`);
assert(Array.isArray(PICKUP_STATUSES) && PICKUP_STATUSES.length >= 4, `PICKUP_STATUSES lifecycle steps exported`);
assert(Array.isArray(ROUTE_STATUSES) && ROUTE_STATUSES.length >= 4, `ROUTE_STATUSES lifecycle steps exported`);

// ----------------------------------------------------
// 2. VEHICLE PROFILES & CAPACITIES
// ----------------------------------------------------
assert(Boolean(VEHICLE_PROFILES.MINI_TRUCK), `MINI_TRUCK profile is registered`);
assert(VEHICLE_PROFILES.MINI_TRUCK.capacityKg === 500, `MINI_TRUCK capacity is 500 kg`);
assert(VEHICLE_PROFILES.SMALL_TRUCK.capacityKg === 1000, `SMALL_TRUCK capacity is 1000 kg`);
assert(VEHICLE_PROFILES.MEDIUM_TRUCK.capacityKg === 2500, `MEDIUM_TRUCK capacity is 2500 kg`);
assert(VEHICLE_PROFILES.LARGE_TRUCK.capacityKg === 5000, `LARGE_TRUCK capacity is 5000 kg`);

const customProfile = getVehicleProfile('electric_mini_500');
assert(customProfile.capacityKg === 500, `getVehicleProfile resolves custom key correctly`);

// ----------------------------------------------------
// 3. LIFECYCLE TRANSITION VALIDATORS
// ----------------------------------------------------
// Shipment status transitions
assert(canTransitionShipmentStatus('CREATED', 'PICKUP_SCHEDULED') === true, `Shipment valid transition: CREATED -> PICKUP_SCHEDULED`);
assert(canTransitionShipmentStatus('PICKUP_SCHEDULED', 'PICKED_UP') === true, `Shipment valid transition: PICKUP_SCHEDULED -> PICKED_UP`);
assert(canTransitionShipmentStatus('PICKED_UP', 'IN_TRANSIT') === true, `Shipment valid transition: PICKED_UP -> IN_TRANSIT`);
assert(canTransitionShipmentStatus('IN_TRANSIT', 'OUT_FOR_DELIVERY') === true, `Shipment valid transition: IN_TRANSIT -> OUT_FOR_DELIVERY`);
assert(canTransitionShipmentStatus('OUT_FOR_DELIVERY', 'DELIVERED') === true, `Shipment valid transition: OUT_FOR_DELIVERY -> DELIVERED`);
assert(canTransitionShipmentStatus('CREATED', 'DELIVERED') === false, `Shipment invalid jump: CREATED -> DELIVERED is rejected`);
assert(canTransitionShipmentStatus('DELIVERED', 'IN_TRANSIT') === false, `Shipment terminal state: DELIVERED cannot transition back`);
assert(canTransitionShipmentStatus('CREATED', 'CANCELLED') === true, `Shipment can transition to CANCELLED`);

// Pickup status transitions
assert(canTransitionPickupStatus('SCHEDULED', 'READY') === true, `Pickup valid transition: SCHEDULED -> READY`);
assert(canTransitionPickupStatus('READY', 'PICKED_UP') === true, `Pickup valid transition: READY -> PICKED_UP`);
assert(canTransitionPickupStatus('SCHEDULED', 'PICKED_UP') === false, `Pickup invalid jump: SCHEDULED -> PICKED_UP is rejected`);
assert(canTransitionPickupStatus('SCHEDULED', 'CANCELLED') === true, `Pickup can be CANCELLED`);

// Route status transitions
assert(canTransitionRouteStatus('PLANNED', 'ASSIGNED') === true, `Route valid transition: PLANNED -> ASSIGNED`);
assert(canTransitionRouteStatus('ASSIGNED', 'IN_PROGRESS') === true, `Route valid transition: ASSIGNED -> IN_PROGRESS`);
assert(canTransitionRouteStatus('IN_PROGRESS', 'COMPLETED') === true, `Route valid transition: IN_PROGRESS -> COMPLETED`);
assert(canTransitionRouteStatus('PLANNED', 'COMPLETED') === false, `Route invalid jump: PLANNED -> COMPLETED is rejected`);

// ----------------------------------------------------
// 4. TRANSPORT COST & DURATION FORMATTING
// ----------------------------------------------------
const cost1 = calculateTransportCost({
  distanceKm: 50,
  vehicleKey: 'MINI_TRUCK',
  stopCount: 3
});
assert(cost1.totalCost > 0, `Transport cost calculates positive amount (got: ₹${cost1.totalCost})`);
assert(cost1.breakdown.baseFee === 350, `Transport cost base fee matches profile (350)`);
assert(cost1.breakdown.distanceFee === 50 * 12, `Transport cost distance fee calculated correctly`);

const durText = formatDuration(125);
assert(durText === '2h 5m', `formatDuration(125) formats to '2h 5m' (got: '${durText}')`);

// ----------------------------------------------------
// 5. ROUTE OPTIMIZATION (NEAREST-NEIGHBOR + 2-OPT)
// ----------------------------------------------------
const testStops = [
  { id: 'origin', type: 'ORIGIN', address: 'Dankaur Hub', lat: 28.3512, lng: 77.5540, loadKg: 0 },
  { id: 'stop_far', type: 'PICKUP', address: 'Jewar South', lat: 28.1285, lng: 77.5553, loadKg: 100 },
  { id: 'stop_mid', type: 'PICKUP', address: 'Yamuna Hub', lat: 28.2500, lng: 77.5545, loadKg: 150 },
  { id: 'dest', type: 'DELIVERY', address: 'Noida Sec 62', lat: 28.6280, lng: 77.3649, loadKg: 0 }
];

const optResult = optimizeRoute({
  stops: testStops,
  vehicleKey: 'SMALL_TRUCK'
});

assert(optResult.optimizedStops.length === testStops.length, `Optimized route contains all stops`);
assert(optResult.optimizedStops[0].id === 'origin', `Origin stop is preserved at index 0`);
assert(optResult.optimizedStops[optResult.optimizedStops.length - 1].id === 'dest', `Destination stop is preserved at last index`);
assert(optResult.optimizedDistanceKm <= optResult.naiveDistanceKm, `2-Opt optimized distance (${optResult.optimizedDistanceKm} km) <= naive distance (${optResult.naiveDistanceKm} km)`);
assert(optResult.algorithm === 'NEAREST_NEIGHBOR_2OPT', `Optimization algorithm reported correctly`);

// Capacity validation
const capValid = validateCapacity({ totalLoadKg: 450, vehicleKey: 'MINI_TRUCK' });
assert(capValid.isValid === true, `450 kg fits in 500 kg MINI_TRUCK`);

const capOver = validateCapacity({ totalLoadKg: 650, vehicleKey: 'MINI_TRUCK' });
assert(capOver.isValid === false, `650 kg flagged as exceeding 500 kg MINI_TRUCK`);
assert(capOver.excessKg === 150, `Excess load correctly calculated as 150 kg`);

// Multi-route splitting on excess load
const splitResults = splitIntoRoutes({
  stops: [
    { id: 'p1', loadKg: 200, lat: 28.1, lng: 77.5, type: 'PICKUP' },
    { id: 'p2', loadKg: 250, lat: 28.2, lng: 77.5, type: 'PICKUP' },
    { id: 'p3', loadKg: 300, lat: 28.3, lng: 77.5, type: 'PICKUP' },
    { id: 'p4', loadKg: 400, lat: 28.4, lng: 77.5, type: 'PICKUP' }
  ],
  vehicleKey: 'MINI_TRUCK', // 500kg max
  origin: testStops[0],
  destination: testStops[3]
});
assert(splitResults.length >= 3, `1150 kg total split across at least 3 mini-trucks (got: ${splitResults.length} routes)`);
splitResults.forEach((subRoute, i) => {
  assert(subRoute.totalLoadKg <= 500, `Sub-route ${i + 1} load (${subRoute.totalLoadKg} kg) adheres to vehicle capacity <= 500 kg`);
});

// ETA progression
const etaResult = calculateRouteETA({
  stops: optResult.optimizedStops,
  vehicleKey: 'SMALL_TRUCK'
});
assert(etaResult.stops.length === testStops.length, `ETA returned for each stop`);
for (let i = 1; i < etaResult.stops.length; i++) {
  const prevTime = new Date(etaResult.stops[i - 1].estimatedArrival).getTime();
  const currTime = new Date(etaResult.stops[i].estimatedArrival).getTime();
  assert(currTime > prevTime, `ETA timestamps monotonically increase: stop ${i} (${currTime}) > stop ${i-1} (${prevTime})`);
}

// ----------------------------------------------------
// 6. SHIPMENT SERVICE & TRACKING NUMBERS
// ----------------------------------------------------
const trackingNum = generateTrackingNumber();
assert(/^FS-SHP-\d{4}-[A-Z0-9]{4}$/.test(trackingNum), `Tracking number follows format 'FS-SHP-YYYY-XXXX' (got: '${trackingNum}')`);

const newShipment = createShipmentRecord({
  orderId: 'ORD-TEST-123',
  buyerName: 'Amit Sharma',
  deliveryAddress: 'Sector 62, Noida',
  items: [{ name: 'Desi Country Tomatoes', quantity: 100, unit: 'kg' }],
  routeId: 'RT-001'
});

assert(newShipment.status === 'CREATED', `Initial shipment status is CREATED`);
assert(newShipment.trackingNumber.startsWith('FS-SHP-'), `Created shipment has tracking number`);
assert(newShipment.timeline.length === 1, `Created shipment has 1 initial timeline entry`);

const advance1 = advanceShipmentStatus(newShipment, 'PICKUP_SCHEDULED');
assert(advance1.success === true, `Advanced shipment to PICKUP_SCHEDULED`);
assert(advance1.shipment.status === 'PICKUP_SCHEDULED', `Shipment status updated to PICKUP_SCHEDULED`);
assert(advance1.shipment.timeline.length === 2, `Timeline has 2 entries`);

const advanceInvalid = advanceShipmentStatus(advance1.shipment, 'DELIVERED');
assert(advanceInvalid.success === false, `Invalid jump from PICKUP_SCHEDULED to DELIVERED rejected with error`);

// ----------------------------------------------------
// 7. PICKUP SERVICE
// ----------------------------------------------------
const newPickup = createPickupSchedule({
  orderId: 'ORD-TEST-123',
  farmerId: 'farmer-1',
  farmerName: 'Ramesh Kumar',
  farmLocationText: 'Dankaur Farm Yard',
  cropName: 'Desi Country Tomatoes',
  quantityKg: 100
});

assert(newPickup.status === 'SCHEDULED', `Initial pickup status is SCHEDULED`);
assert(Boolean(newPickup.timeWindowFormatted), `Pickup includes formatted time window`);

const readyPickup = advancePickupStatus(newPickup, 'READY');
assert(readyPickup.success === true, `Advanced pickup to READY`);
assert(readyPickup.schedule.status === 'READY', `Pickup status is READY`);

// ----------------------------------------------------
// 8. LOGISTICS SERVICE INTEGRATION
// ----------------------------------------------------
const initialRoutes = logisticsService.getAllRoutes();
assert(initialRoutes.length >= 2, `LogisticsService loads initial demo routes (got: ${initialRoutes.length})`);

const plannedRoute = logisticsService.createRouteFromFulfillments({
  fulfillments: [
    {
      id: 'ful-1',
      orderId: 'ORD-101',
      supplierName: 'Ramesh Kumar',
      originAddress: 'Dankaur Gate 1',
      lat: 28.3512,
      lng: 77.5540,
      cropName: 'Desi Tomato',
      quantityKg: 200
    },
    {
      id: 'ful-2',
      orderId: 'ORD-101',
      supplierName: 'Balram Singh',
      originAddress: 'Jewar Yard',
      lat: 28.1285,
      lng: 77.5553,
      cropName: 'Kufri Potato',
      quantityKg: 300
    }
  ],
  destination: {
    address: 'Expressway Tower Delivery Point',
    lat: 28.6280,
    lng: 77.3649
  },
  vehicleKey: 'SMALL_TRUCK'
});

assert(plannedRoute.success === true, `Route created successfully from fulfillments`);
assert(plannedRoute.route.status === 'PLANNED', `Created route has status PLANNED`);
assert(plannedRoute.route.stops.length >= 3, `Route contains pickup stops and delivery destination`);
assert(plannedRoute.route.totalLoad === 500, `Total load calculated as 500 kg`);

// ----------------------------------------------------
// 9. PRIVACY CHECKS: ZERO RAW GPS LEAKAGE
// ----------------------------------------------------
// Test that public stop presentations never expose raw GPS accuracy/coords in untrusted text fields
const sampleStop = plannedRoute.route.stops[0];
const stopText = sampleStop.approximateAddress || sampleStop.address || '';
assert(!stopText.includes('accuracy'), `Stop address does not leak GPS sensor metadata`);
assert(!stopText.includes('lat:') && !sampleStop.name?.includes('lat:'), `Stop display label does not leak raw GPS latitude string`);

// ----------------------------------------------------
// 10. DATABASE SCHEMA MIGRATION 014 VERIFICATION
// ----------------------------------------------------
const migrationPath = path.join(rootDir, 'supabase', 'migrations', '014_logistics.sql');
assert(fs.existsSync(migrationPath), `Migration file 014_logistics.sql exists`);

const migrationSql = fs.readFileSync(migrationPath, 'utf8');
assert(migrationSql.includes('TABLE IF NOT EXISTS public.logistics_routes') || migrationSql.includes('logistics_routes'), `Migration defines logistics_routes table`);
assert(migrationSql.includes('TABLE IF NOT EXISTS public.logistics_route_stops') || migrationSql.includes('logistics_route_stops'), `Migration defines logistics_route_stops table`);
assert(migrationSql.includes('TABLE IF NOT EXISTS public.shipments') || migrationSql.includes('shipments'), `Migration defines shipments table`);
assert(migrationSql.includes('TABLE IF NOT EXISTS public.pickup_schedules') || migrationSql.includes('pickup_schedules'), `Migration defines pickup_schedules table`);
assert(migrationSql.includes('ENABLE ROW LEVEL SECURITY'), `Migration enforces Row Level Security`);
assert(migrationSql.includes('idx_logistics_routes_status'), `Migration defines indexes for query performance`);

console.log('====================================================');
console.log(`PHASE 7 VALIDATION RESULTS: ${passedTests} / ${totalTests} TESTS PASSED`);
console.log('====================================================');

if (passedTests === totalTests) {
  console.log('🎉 ALL PHASE 7 LOGISTICS & ROUTE OPTIMIZATION TESTS PASSED PERFECTLY!');
  process.exit(0);
} else {
  console.error(`⚠️ ${totalTests - passedTests} TESTS FAILED. Please review the errors above.`);
  process.exit(1);
}
