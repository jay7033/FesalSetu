// Verification script for Real Supabase Project (Phase 9 & 9.35)
// IMPORTANT: Does NOT print actual credential values.

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createClient } from '@supabase/supabase-js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

// 1. Read .env.local without exposing values
const envLocalPath = path.join(rootDir, '.env.local');
let supabaseUrl = '';
let supabaseKey = '';

if (fs.existsSync(envLocalPath)) {
  const envContent = fs.readFileSync(envLocalPath, 'utf-8');
  for (const line of envContent.split('\n')) {
    const trimmed = line.trim();
    if (trimmed.startsWith('VITE_SUPABASE_URL=')) {
      supabaseUrl = trimmed.split('=')[1]?.trim();
    }
    if (trimmed.startsWith('VITE_SUPABASE_PUBLISHABLE_KEY=') || trimmed.startsWith('VITE_SUPABASE_ANON_KEY=')) {
      if (!supabaseKey) {
        supabaseKey = trimmed.split('=')[1]?.trim();
      }
    }
  }
}

console.log('====================================================');
console.log('FASALSETU — REAL SUPABASE DATABASE VERIFICATION');
console.log('====================================================');

console.log(`Supabase URL configured: ${supabaseUrl && supabaseUrl.startsWith('https://') ? 'YES' : 'NO'}`);
console.log(`Publishable key configured: ${supabaseKey && supabaseKey.length > 20 ? 'YES' : 'NO'}`);

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Credentials missing in .env.local');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function runVerification() {
  const results = {
    connection: false,
    auth: false,
    tables: {},
    hybridColumns: {},
    rpcs: {},
    storage: {},
    seedData: {}
  };

  // 1. LIVE CONNECTION & AUTH TEST
  console.log('\n--- 1. Live Connection & Auth Test ---');
  try {
    const { error: authError } = await supabase.auth.getSession();
    if (!authError) {
      results.connection = true;
      results.auth = true;
      console.log('✅ Supabase Auth service reachable & responsive');
    } else {
      console.log('❌ Auth returned error:', authError.message);
    }
  } catch (err) {
    console.log('❌ Connection failure:', err.message);
  }

  // 2. TABLES VERIFICATION
  console.log('\n--- 2. Public Tables Verification ---');
  const targetTables = [
    'profiles',
    'farmer_profiles',
    'fpo_profiles',
    'fpo_members',
    'consumer_profiles',
    'bulk_buyer_profiles',
    'farm_locations',
    'buyer_locations',
    'products',
    'orders',
    'order_items',
    'order_fulfillments',
    'order_timeline',
    'inventory_transactions',
    'notifications',
    'saved_products',
    'demand_forecasts',
    'logistics_routes',
    'logistics_route_stops',
    'shipments',
    'pickup_schedules',
    'smart_matches',
    'supply_demand_insights',
    'procurement_recommendations',
    'opportunity_scores'
  ];

  for (const table of targetTables) {
    try {
      const { error, count } = await supabase
        .from(table)
        .select('*')
        .limit(1);

      if (error) {
        if (error.code === 'PGRST205' || error.message?.includes('Could not find the table') || error.message?.includes('schema cache')) {
          results.tables[table] = { exists: false, error: 'Table does not exist in schema cache' };
          console.log(`❌ Table missing: public.${table}`);
        } else if (error.code === '42501' || error.message?.includes('permission denied') || error.message?.includes('violates row-level security')) {
          // Table exists but blocked by RLS
          results.tables[table] = { exists: true, rlsActive: true, note: 'RLS active (permission restricted)' };
          console.log(`✅ Table exists (RLS enforced): public.${table}`);
        } else {
          results.tables[table] = { exists: false, error: error.message };
          console.log(`⚠️ Table query error for ${table}:`, error.message);
        }
      } else {
        results.tables[table] = { exists: true, count: count ?? 0 };
        console.log(`✅ Table exists: public.${table} (Rows: ${count ?? 0})`);
      }
    } catch (err) {
      results.tables[table] = { exists: false, error: err.message };
      console.log(`❌ Table exception: public.${table}:`, err.message);
    }
  }

  // 3. HYBRID SCHEMA & is_demo COLUMN
  console.log('\n--- 3. Hybrid Schema (is_demo Column) Verification ---');
  const hybridCheckTables = ['products', 'orders', 'profiles', 'farm_locations'];
  for (const tbl of hybridCheckTables) {
    if (results.tables[tbl]?.exists) {
      try {
        const { error } = await supabase
          .from(tbl)
          .select('is_demo')
          .limit(1);

        if (error) {
          results.hybridColumns[tbl] = { exists: false, error: error.message };
          console.log(`❌ is_demo column missing or inaccessible on ${tbl}: ${error.message}`);
        } else {
          results.hybridColumns[tbl] = { exists: true };
          console.log(`✅ ${tbl}.is_demo column confirmed`);
        }
      } catch (err) {
        results.hybridColumns[tbl] = { exists: false, error: err.message };
      }
    } else {
      results.hybridColumns[tbl] = { exists: false, error: 'Parent table missing' };
      console.log(`❌ ${tbl}.is_demo cannot be verified (table missing)`);
    }
  }

  // 4. RPC FUNCTIONS VERIFICATION
  console.log('\n--- 4. RPC Functions Verification ---');
  const rpcList = ['create_order_transaction', 'update_order_status', 'cancel_order_transaction'];
  for (const rpcName of rpcList) {
    try {
      // Call with empty params to verify existence (will return validation error or function not found error)
      const { error } = await supabase.rpc(rpcName, {});
      if (error) {
        if (error.code === 'PGRST202' || error.message?.includes('Could not find the function')) {
          results.rpcs[rpcName] = { exists: false, error: 'Function not found in schema' };
          console.log(`❌ RPC function missing: ${rpcName}`);
        } else {
          // Function exists and returned a business logic validation error (e.g., missing parameter)
          results.rpcs[rpcName] = { exists: true, message: error.message };
          console.log(`✅ RPC function exists: ${rpcName} (Validation response: ${error.message})`);
        }
      } else {
        results.rpcs[rpcName] = { exists: true };
        console.log(`✅ RPC function exists: ${rpcName}`);
      }
    } catch (err) {
      results.rpcs[rpcName] = { exists: false, error: err.message };
      console.log(`❌ RPC exception: ${rpcName}: ${err.message}`);
    }
  }

  // 5. STORAGE BUCKETS VERIFICATION
  console.log('\n--- 5. Storage Buckets Verification ---');
  const targetBuckets = ['product-images', 'avatars'];
  try {
    const { data: buckets, error: bucketError } = await supabase.storage.listBuckets();
    if (bucketError) {
      console.log('⚠️ Could not list buckets via anon key:', bucketError.message);
      // Try accessing each directly
      for (const b of targetBuckets) {
        const { error: fileError } = await supabase.storage.from(b).list();
        if (fileError && (fileError.message?.includes('not found') || fileError.message?.includes('Bucket not found'))) {
          results.storage[b] = { exists: false, error: fileError.message };
          console.log(`❌ Storage bucket missing: ${b}`);
        } else {
          results.storage[b] = { exists: true };
          console.log(`✅ Storage bucket accessible: ${b}`);
        }
      }
    } else {
      const bucketNames = (buckets || []).map(b => b.id || b.name);
      for (const b of targetBuckets) {
        if (bucketNames.includes(b)) {
          results.storage[b] = { exists: true };
          console.log(`✅ Storage bucket exists: ${b}`);
        } else {
          results.storage[b] = { exists: false };
          console.log(`❌ Storage bucket missing: ${b}`);
        }
      }
    }
  } catch (err) {
    console.log('❌ Storage check exception:', err.message);
  }

  // 6. SEED DATA STATUS
  console.log('\n--- 6. Seed Data Status ---');
  if (results.tables['profiles']?.exists) {
    try {
      const { data: seedProfiles } = await supabase
        .from('profiles')
        .select('id, email, role, is_demo')
        .eq('is_demo', true);
      
      const count = seedProfiles?.length ?? 0;
      results.seedData.profiles = count;
      console.log(`Demo profiles in database: ${count}`);
    } catch {
      results.seedData.profiles = 0;
    }
  } else {
    results.seedData.profiles = 0;
    console.log('Demo profiles: 0 (profiles table does not exist)');
  }

  if (results.tables['products']?.exists) {
    try {
      const { data: seedProds } = await supabase
        .from('products')
        .select('id, name, is_demo')
        .eq('is_demo', true);
      
      const count = seedProds?.length ?? 0;
      results.seedData.products = count;
      console.log(`Demo products in database: ${count}`);
    } catch {
      results.seedData.products = 0;
    }
  } else {
    results.seedData.products = 0;
    console.log('Demo products: 0 (products table does not exist)');
  }

  // Write summary JSON for downstream analysis
  fs.writeFileSync(path.join(rootDir, 'scripts', 'supabase_status.json'), JSON.stringify(results, null, 2));
  console.log('\nVerification run finished.');
}

runVerification().catch(console.error);
