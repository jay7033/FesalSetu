// Automated Verification Script for Phase 8: Advanced AI & Smart Supply-Chain Intelligence
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

import { matchingService, MATCH_WEIGHTS } from '../src/services/ai/matchingService.js';
import { supplyDemandService } from '../src/services/ai/supplyDemandService.js';
import { redistributionService } from '../src/services/ai/redistributionService.js';
import { opportunityScoreService } from '../src/services/ai/opportunityScoreService.js';
import { procurementService } from '../src/services/ai/procurementService.js';
import { supplyChainAnalyticsService } from '../src/services/ai/supplyChainAnalyticsService.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

console.log('====================================================');
console.log('RUNNING PHASE 8 SMART SUPPLY-CHAIN INTELLIGENCE TESTS');
console.log('====================================================');

let passedTests = 0;
let totalTests = 0;

function assert(condition, testName) {
  totalTests++;
  if (condition) {
    console.log(`✅ [PASS] ${testName}`);
    passedTests++;
  } else {
    console.error(`❌ [FAIL] ${testName}`);
  }
}

// ----------------------------------------------------
// 1. SMART MATCHING ENGINE & WEIGHT INTEGRITY
// ----------------------------------------------------
console.log('\n--- 1. Smart Matching & Weights ---');

const totalWeight = Object.values(MATCH_WEIGHTS).reduce((a, b) => a + b, 0);
assert(totalWeight === 100, `Prototype match weights must sum to exactly 100% (got ${totalWeight}%)`);
assert(MATCH_WEIGHTS.QUANTITY === 25, 'Quantity weight is 25%');
assert(MATCH_WEIGHTS.DISTANCE === 20, 'Distance weight is 20%');
assert(MATCH_WEIGHTS.QUALITY === 20, 'Quality weight is 20%');
assert(MATCH_WEIGHTS.PRICE === 15, 'Price weight is 15%');
assert(MATCH_WEIGHTS.FRESHNESS === 10, 'Freshness weight is 10%');
assert(MATCH_WEIGHTS.DEMAND === 10, 'Demand weight is 10%');

const sampleProduct = {
  id: 'prod-001',
  name: 'Desi Country Tomato',
  quantity: 420,
  price: 28,
  qualityGrade: 'A',
  harvestDate: new Date().toISOString(),
  location: { latitude: 28.4744, longitude: 77.5040, city: 'Greater Noida' }
};

const sampleBuyerReq = {
  id: 'req-001',
  cropName: 'Desi Tomato',
  quantity: 500,
  targetPrice: 28,
  qualityGrade: 'A',
  location: { latitude: 28.5355, longitude: 77.3910, city: 'Noida' }
};

const matchEval = matchingService.calculateMatch(sampleProduct, sampleBuyerReq);
assert(matchEval.matchScore >= 0 && matchEval.matchScore <= 100, `Match score must be bounded 0-100 (got ${matchEval.matchScore})`);
assert(matchEval.breakdown.quantity > 0, 'Quantity score calculated');
assert(matchEval.breakdown.distance > 0, 'Distance score calculated');
assert(matchEval.breakdown.quality === 100, 'Exact quality grade match gives 100');
assert(matchEval.explanationFactors.length >= 3, 'Deterministic explanation checklist generated');

// Extreme distance test
const farProduct = {
  ...sampleProduct,
  location: { latitude: 19.0760, longitude: 72.8777, city: 'Mumbai' } // ~1,100 km away
};
const farMatch = matchingService.calculateMatch(farProduct, sampleBuyerReq);
assert(farMatch.matchScore < matchEval.matchScore, 'Long distance match receives lower score');

// ----------------------------------------------------
// 2. SUPPLY-DEMAND GAP PREDICTION
// ----------------------------------------------------
console.log('\n--- 2. Supply-Demand Gap Engine ---');

// Potential Shortage case: forecast demand exceeds supply
const shortageGap = supplyDemandService.calculateGap({
  cropName: 'Desi Tomato',
  forecastDemand: 4200,
  availableSupply: 2900,
  district: 'Nashik'
});
assert(shortageGap.status === 'Potential Shortage', `Forecast > Supply yields Potential Shortage (got ${shortageGap.status})`);
assert(shortageGap.potentialGap === 1300, `Potential gap = 4200 - 2900 = 1300 (got ${shortageGap.potentialGap})`);

// Potential Surplus case: supply exceeds forecast demand
const surplusGap = supplyDemandService.calculateGap({
  cropName: 'Potato',
  forecastDemand: 1500,
  availableSupply: 2600,
  district: 'Aligarh'
});
assert(surplusGap.status === 'Potential Surplus', `Supply > Forecast yields Potential Surplus (got ${surplusGap.status})`);
assert(surplusGap.potentialGap === -1100, `Potential surplus gap is negative (-1100)`);

// Balanced case: supply and demand within 25% of each other
const balancedGap = supplyDemandService.calculateGap({
  cropName: 'Onion',
  forecastDemand: 1000,
  availableSupply: 950,
  district: 'Gautam Buddha Nagar'
});
assert(balancedGap.status === 'Balanced', `Closely matching supply and demand yields Balanced (got ${balancedGap.status})`);

// Zero supply case
const zeroSupplyGap = supplyDemandService.calculateGap({
  cropName: 'Organic Ginger',
  forecastDemand: 500,
  availableSupply: 0
});
assert(zeroSupplyGap.status === 'Potential Shortage', 'Zero supply yields Potential Shortage');

// Low data / zero activity case
const lowDataGap = supplyDemandService.calculateGap({
  cropName: 'Exotic Berry',
  forecastDemand: 0,
  availableSupply: 0
});
assert(lowDataGap.status === 'Insufficient Data', 'Zero demand and zero supply yields Insufficient Data');

// ----------------------------------------------------
// 3. REGIONAL REDISTRIBUTION & PHASE 7 LOGISTICS
// ----------------------------------------------------
console.log('\n--- 3. Redistribution & Fleet Logistics Integration ---');

const surplusRegion = {
  cropName: 'Nashik Red Onion',
  district: 'Nashik',
  state: 'Maharashtra',
  potentialGap: -1500,
  availableSupply: 3000,
  forecastDemand: 1500
};

const shortageRegion = {
  cropName: 'Nashik Red Onion',
  district: 'Mumbai',
  state: 'Maharashtra',
  potentialGap: 1100,
  availableSupply: 1000,
  forecastDemand: 2100
};

const mockRoutes = [
  {
    id: 'rt-001',
    route_number: 'FS-RT-2026-009',
    vehicle_type: 'Medium Truck',
    vehicle_capacity: 2500,
    total_load: 1300,
    start_location: { city: 'Nashik' },
    end_location: { city: 'Mumbai' }
  }
];

const redisPlan = redistributionService.evaluateRedistribution(surplusRegion, shortageRegion, mockRoutes);
assert(redisPlan !== null, 'Redistribution plan successfully evaluated for matching crop');
assert(redisPlan.transferableQuantity === 1100, `Transferable quantity is min(surplus, shortage) = 1100 (got ${redisPlan.transferableQuantity})`);
assert(redisPlan.existingRouteAvailable === true, 'Recognizes active Phase 7 route along Nashik-Mumbai corridor');
assert(redisPlan.existingRouteNumber === 'FS-RT-2026-009', 'Associates correct route number');
assert(redisPlan.explanationBullets.length >= 3, 'Includes explanatory rationale');

// ----------------------------------------------------
// 4. INTELLIGENT PROCUREMENT & MULTI-SUPPLIER BUNDLING
// ----------------------------------------------------
console.log('\n--- 4. Bulk Procurement Optimization ---');

const bulkRequirement = {
  cropName: 'Potato',
  quantity: 2000,
  targetPrice: 20,
  buyerLocation: { latitude: 28.5355, longitude: 77.3910, city: 'Noida' }
};

const supplierPool = [
  { id: 's1', name: 'Kufri Jyoti Potato', farmer: 'FPO Agra Collective', fpoId: 'fpo-1', quantity: 900, price: 19, location: { latitude: 28.4069, longitude: 77.8498 } },
  { id: 's2', name: 'Kufri Jyoti Potato', farmer: 'Ramesh Verma', quantity: 600, price: 20, location: { latitude: 28.4744, longitude: 77.5040 } },
  { id: 's3', name: 'Kufri Jyoti Potato', farmer: 'Suresh Kumar', quantity: 500, price: 21, location: { latitude: 28.3500, longitude: 77.5500 } },
  { id: 's4', name: 'Kufri Jyoti Potato', farmer: 'Devendra Singh', quantity: 300, price: 24, location: { latitude: 28.9000, longitude: 77.9000 } }
];

const procurementPlan = procurementService.generateProcurementPlan(bulkRequirement, supplierPool);
assert(procurementPlan.status === 'OPTIMIZED', 'Procurement plan generated with status OPTIMIZED');
assert(procurementPlan.recommendedQuantity === 2000, `Aggregates exactly 2000 kg (got ${procurementPlan.recommendedQuantity})`);
assert(procurementPlan.supplierCount === 3, `Optimized for fewest suppliers (expected 3: 900+600+500, got ${procurementPlan.supplierCount})`);
assert(procurementPlan.fulfillmentPercent === 100, 'Fulfillment is 100%');
assert(procurementPlan.estimatedDistanceKm > 0, 'Estimated corridor distance computed');
assert(procurementPlan.estimatedCost > 0, 'Estimated procurement cost computed');

// ----------------------------------------------------
// 5. ACTOR OPPORTUNITY SCORES & PRICE SIGNALS
// ----------------------------------------------------
console.log('\n--- 5. Opportunity Scoring & Observed Price Signal ---');

const farmerOpp = opportunityScoreService.calculateFarmerOpportunity({
  cropName: 'Desi Tomato',
  farmerInventory: 350,
  forecastDemand: 1200,
  nearbySupply: 250,
  growthPercent: 18,
  activeBuyers: 3,
  hasLogisticsNearby: true
});

assert(farmerOpp.score >= 0 && farmerOpp.score <= 100, `Farmer score bounded 0-100 (got ${farmerOpp.score})`);
assert(farmerOpp.demandLevel === 'HIGH', 'Recognizes HIGH demand level');
assert(farmerOpp.suggestedListing.includes('kg'), 'Suggested listing format is formatted with kg');
assert(farmerOpp.confidenceScore >= 70, 'Confidence score calculated');
assert(farmerOpp.explanations.length >= 2, 'Opportunity explanations provided');

// FPO aggregation intelligence
const fpoOpp = opportunityScoreService.calculateFPOOpportunity({
  cropName: 'Onion',
  memberTotalInventory: 2400,
  regionalForecastDemand: 3200,
  memberCount: 12
});
assert(fpoOpp.potentialGap === 800, `FPO potential gap = 3200 - 2400 = 800 (got ${fpoOpp.potentialGap})`);
assert(fpoOpp.opportunityTier === 'HIGH', 'Large regional gap yields HIGH opportunity tier');

// Observed Price Signal
const histPrices = [26, 27, 28, 29, 28];
const recentPrices = [30, 31, 31, 32, 31];
const priceSignal = opportunityScoreService.calculateObservedPriceSignal(histPrices, recentPrices);
assert(priceSignal.available === true, 'Price signal calculated when history is provided');
assert(priceSignal.historicalMedianPrice === 28, `Historical median price is 28 (got ${priceSignal.historicalMedianPrice})`);
assert(priceSignal.recentMedianPrice === 31, `Recent median price is 31 (got ${priceSignal.recentMedianPrice})`);
assert(priceSignal.observedChangePercent > 0, 'Positive change detected');
assert(priceSignal.trend === 'RISING', 'Trend correctly flagged as RISING');

// Insufficient price history
const emptyPriceSignal = opportunityScoreService.calculateObservedPriceSignal([], []);
assert(emptyPriceSignal.available === false, 'Returns unavailable when insufficient price history');

// ----------------------------------------------------
// 6. SUPPLY CHAIN HEALTH SCORECARD
// ----------------------------------------------------
console.log('\n--- 6. Supply Chain Health Analytics ---');

const mockOrders = [
  { id: 'o1', status: 'Delivered', items: [{ quantity: 100 }] },
  { id: 'o2', status: 'Confirmed', items: [{ quantity: 250 }] },
  { id: 'o3', status: 'Cancelled', items: [{ quantity: 50 }] }
];

const mockProducts = [
  { id: 'p1', quantity: 500 },
  { id: 'p2', quantity: 800 },
  { id: 'p3', quantity: 50 }
];

const mockLogisticsRoutes = [
  { id: 'r1', vehicle_capacity: 1000, total_load: 850 }
];

const mockForecasts = [
  { forecastDemand: 1200 },
  { forecastDemand: 800 }
];

const healthScorecard = supplyChainAnalyticsService.calculateSupplyChainHealth(
  mockOrders,
  mockProducts,
  mockLogisticsRoutes,
  mockForecasts
);

assert(healthScorecard.demandCoverage >= 0 && healthScorecard.demandCoverage <= 100, 'Demand Coverage bounded 0-100');
assert(healthScorecard.supplyAvailability >= 0 && healthScorecard.supplyAvailability <= 100, 'Supply Availability bounded 0-100');
assert(healthScorecard.fulfillmentEfficiency >= 0 && healthScorecard.fulfillmentEfficiency <= 100, 'Fulfillment Efficiency bounded 0-100');
assert(healthScorecard.logisticsEfficiency >= 0 && healthScorecard.logisticsEfficiency <= 100, 'Logistics Efficiency bounded 0-100');
assert(healthScorecard.isPrototypeIndicator === true, 'Scorecard flags metrics as prototype composite indicators');

// ----------------------------------------------------
// 7. LOCATION PRIVACY & EXACT GPS PROTECTION
// ----------------------------------------------------
console.log('\n--- 7. Location Privacy Inspection ---');

// Verify public outputs do NOT contain exact GPS
const matchKeys = Object.keys(matchEval);
assert(!matchKeys.includes('latitude') && !matchKeys.includes('longitude') && !matchKeys.includes('accuracy'), 'Smart match evaluation does not leak raw GPS coordinates');

const gapKeys = Object.keys(shortageGap);
assert(!gapKeys.includes('latitude') && !gapKeys.includes('longitude') && !gapKeys.includes('accuracy'), 'Supply demand gap does not leak raw GPS coordinates');

const redisKeys = Object.keys(redisPlan);
assert(!redisKeys.includes('latitude') && !redisKeys.includes('longitude') && !redisKeys.includes('accuracy'), 'Redistribution plan does not leak raw GPS coordinates');

const oppKeys = Object.keys(farmerOpp);
assert(!oppKeys.includes('latitude') && !oppKeys.includes('longitude') && !oppKeys.includes('accuracy'), 'Farmer opportunity score does not leak raw GPS coordinates');

// ----------------------------------------------------
// 8. DATABASE MIGRATION INTEGRITY (015_smart_supply_chain.sql)
// ----------------------------------------------------
console.log('\n--- 8. Database Migration 015 Integrity ---');

const migrationPath = path.join(rootDir, 'supabase', 'migrations', '015_smart_supply_chain.sql');
assert(fs.existsSync(migrationPath), 'Migration 015_smart_supply_chain.sql exists');

const sqlContent = fs.readFileSync(migrationPath, 'utf-8');
assert(sqlContent.includes('CREATE TABLE IF NOT EXISTS public.smart_matches'), 'Creates smart_matches table');
assert(sqlContent.includes('CREATE TABLE IF NOT EXISTS public.supply_demand_insights'), 'Creates supply_demand_insights table');
assert(sqlContent.includes('CREATE TABLE IF NOT EXISTS public.procurement_recommendations'), 'Creates procurement_recommendations table');
assert(sqlContent.includes('CREATE TABLE IF NOT EXISTS public.opportunity_scores'), 'Creates opportunity_scores table');
assert(sqlContent.includes('ENABLE ROW LEVEL SECURITY'), 'Enables Row Level Security on all Phase 8 tables');
assert(sqlContent.includes('idx_smart_matches_product_id'), 'Creates smart_matches indexes');
assert(sqlContent.includes('idx_supply_demand_crop'), 'Creates supply_demand indexes');
assert(sqlContent.includes('idx_procurement_buyer_id'), 'Creates procurement indexes');
assert(sqlContent.includes('idx_opportunity_actor'), 'Creates opportunity indexes');

// ----------------------------------------------------
// SUMMARY
// ----------------------------------------------------
console.log('\n====================================================');
console.log(`PHASE 8 TESTS COMPLETED: ${passedTests} / ${totalTests} PASSED`);
console.log('====================================================');

if (passedTests === totalTests) {
  process.exit(0);
} else {
  process.exit(1);
}
