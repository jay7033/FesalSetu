// Automated Verification Script for Phase 6: AI Demand Intelligence & Predictive Agriculture
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

import { 
  calculateGrowthPercent, 
  calculateWeightedDemand, 
  classifyDemand, 
  evaluateSupplyStatus,
  formatDemandVolume,
  DEMAND_THRESHOLDS
} from '../src/services/ai/aiUtils.js';

import { calculateConfidenceScore } from '../src/services/ai/confidenceService.js';
import { analyzeMarketplaceDemand } from '../src/services/ai/demandAnalyticsService.js';
import { aggregateRegionalDemand } from '../src/services/ai/regionalDemandService.js';
import { 
  generateFarmerRecommendations, 
  generateFPOInsights, 
  generateBulkBuyerSignals, 
  generateConsumerRecommendations 
} from '../src/services/ai/recommendationService.js';
import { demandForecastService } from '../src/services/ai/demandForecastService.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

console.log('====================================================');
console.log('RUNNING PHASE 6 AI DEMAND INTELLIGENCE VALIDATION');
console.log('====================================================');

let passedTests = 0;
let totalTests = 0;

function assert(condition, testName) {
  totalTests++;
  if (condition) {
    console.log(`✅ [PASS] ${testName}`);
    passedTests++;
  } else {
    console.error(`❌ [FAIL] ${testName}`);
  }
}

// ----------------------------------------------------
// 1. MATHEMATICAL & STATISTICAL UTILITIES (aiUtils.js)
// ----------------------------------------------------
const growth1 = calculateGrowthPercent(1180, 1000);
assert(growth1 === 18.0, `Growth calculation: 1180 vs 1000 is +18.0% (got: ${growth1}%)`);

const growthZeroPrev = calculateGrowthPercent(450, 0);
assert(growthZeroPrev === 100.0, `Growth with zero baseline is 100% (got: ${growthZeroPrev}%)`);

const growthBothZero = calculateGrowthPercent(0, 0);
assert(growthBothZero === 0.0, `Growth with both zero is 0.0% (got: ${growthBothZero}%)`);

const growthDeclining = calculateGrowthPercent(800, 1000);
assert(growthDeclining === -20.0, `Growth declining: 800 vs 1000 is -20.0% (got: ${growthDeclining}%)`);

const weightedAvg = calculateWeightedDemand(1000, 800, 600, [0.5, 0.3, 0.2]);
// (1000*0.5 + 800*0.3 + 600*0.2) = 500 + 240 + 120 = 860
assert(weightedAvg === 860, `Weighted moving average (50/30/20): got ${weightedAvg} (expected 860)`);

assert(DEMAND_THRESHOLDS.MIN_ORDERS_FOR_PREDICTION === 3, 'Centralized threshold: minimum 3 orders required for full prediction');

// ----------------------------------------------------
// 2. DEMAND CLASSIFICATION THRESHOLDS
// ----------------------------------------------------
assert(
  classifyDemand(18, 1600, 10) === 'HIGH DEMAND',
  'Demand classification: +18% growth with high volume is HIGH DEMAND'
);

assert(
  classifyDemand(18, 500, 10) === 'RISING DEMAND',
  'Demand classification: +18% growth with normal volume is RISING DEMAND'
);

assert(
  classifyDemand(2, 500, 10) === 'STABLE',
  'Demand classification: +2% change is STABLE'
);

assert(
  classifyDemand(-15, 600, 10) === 'DECLINING',
  'Demand classification: -15% change is DECLINING'
);

assert(
  classifyDemand(-15, 100, 10) === 'LOW DEMAND',
  'Demand classification: -15% change with low volume is LOW DEMAND'
);

assert(
  classifyDemand(18, 500, 2) === 'INSUFFICIENT DATA',
  'Demand classification: sample size < 3 returns INSUFFICIENT DATA'
);

// ----------------------------------------------------
// 3. SURPLUS & SHORTAGE DETECTION
// ----------------------------------------------------
assert(
  evaluateSupplyStatus(1500, 1000, 10) === 'Potential Shortage',
  'Supply status: forecast 1500kg vs supply 1000kg is Potential Shortage'
);

assert(
  evaluateSupplyStatus(800, 1500, 10) === 'Potential Surplus',
  'Supply status: supply 1500kg vs forecast 800kg is Potential Surplus'
);

assert(
  evaluateSupplyStatus(1000, 1000, 10) === 'Balanced',
  'Supply status: supply 1000kg vs forecast 1000kg is Balanced'
);

assert(
  evaluateSupplyStatus(1500, 1000, 1) === 'Insufficient Data',
  'Supply status: sample size < 3 returns Insufficient Data'
);

assert(
  formatDemandVolume(2400) === '2.4 T',
  'Volume formatting: 2400 kg formatted as 2.4 T'
);

assert(
  formatDemandVolume(350) === '350 kg',
  'Volume formatting: 350 kg formatted as 350 kg'
);

// ----------------------------------------------------
// 4. TRANSPARENT CONFIDENCE SCORE & EXPLAINABILITY
// ----------------------------------------------------
const lowDataConfidence = calculateConfidenceScore({ orderCount: 0 });
assert(
  lowDataConfidence.confidenceScore === 10 && lowDataConfidence.confidenceTier === 'Low',
  'Confidence score: 0 orders returns baseline 10% (Low tier)'
);
assert(
  lowDataConfidence.factors.some(f => f.includes('Insufficient historical data')),
  'Confidence factors: 0 orders includes Insufficient historical data warning'
);

const limitedConfidence = calculateConfidenceScore({ orderCount: 2 });
assert(
  limitedConfidence.confidenceScore === 25 && limitedConfidence.confidenceTier === 'Low',
  'Confidence score: 2 orders returns 25% (Low tier)'
);

const robustConfidence = calculateConfidenceScore({
  orderCount: 30,
  recentOrderCount: 8,
  growthPercent: 12,
  distinctBuyersCount: 6,
  availableSupply: 2000,
  forecastQuantity: 1800
});
assert(
  robustConfidence.confidenceScore >= 75 && robustConfidence.confidenceTier === 'High',
  `Confidence score: robust dataset returns ${robustConfidence.confidenceScore}% (High tier)`
);
assert(
  robustConfidence.factors.length >= 3,
  'Explainability: generated 3+ empirical factors'
);

// ----------------------------------------------------
// 5. DEMAND ANALYTICS SERVICE AGGREGATIONS
// ----------------------------------------------------
const mockOrders = [
  {
    id: 'ord-1',
    createdAt: new Date().toISOString(),
    deliveryLocation: { state: 'Uttar Pradesh', district: 'Gautam Buddha Nagar', city: 'Noida' },
    items: [{ name: 'Desi Tomato', quantity: 200, category: 'Vegetables', unit: 'kg' }]
  },
  {
    id: 'ord-2',
    createdAt: new Date().toISOString(),
    deliveryLocation: { state: 'Uttar Pradesh', district: 'Gautam Buddha Nagar', city: 'Greater Noida' },
    items: [{ name: 'Desi Tomato', quantity: 300, category: 'Vegetables', unit: 'kg' }]
  },
  {
    id: 'ord-3',
    createdAt: new Date().toISOString(),
    deliveryLocation: { state: 'Uttar Pradesh', district: 'Gautam Buddha Nagar', city: 'Dadri' },
    items: [
      { name: 'Desi Tomato', quantity: 250, category: 'Vegetables', unit: 'kg' },
      { name: 'Organic Potato', quantity: 500, category: 'Vegetables', unit: 'kg' }
    ]
  },
  {
    id: 'ord-4',
    createdAt: new Date().toISOString(),
    deliveryLocation: { state: 'Maharashtra', district: 'Pune', city: 'Pune' },
    items: [{ name: 'Organic Potato', quantity: 600, category: 'Vegetables', unit: 'kg' }]
  }
];

const mockProducts = [
  { id: 'p1', name: 'Desi Tomato', quantity: 1200, reservedQuantity: 200 },
  { id: 'p2', name: 'Organic Potato', quantity: 2000, reservedQuantity: 400 }
];

const analyticsResult = analyzeMarketplaceDemand(mockOrders, mockProducts);
assert(Array.isArray(analyticsResult), 'analyzeMarketplaceDemand returns array');
assert(analyticsResult.length === 2, `analyzeMarketplaceDemand grouped into 2 crops (got: ${analyticsResult.length})`);

const tomatoInsight = analyticsResult.find(i => i.cropName === 'Desi Tomato');
assert(tomatoInsight && tomatoInsight.totalOrders === 3, 'Tomato orders aggregated accurately to 3');
assert(tomatoInsight.recent7DaysDemand === 750, `Tomato 7-day demand is 750 kg (got: ${tomatoInsight.recent7DaysDemand})`);
assert(tomatoInsight.availableSupply === 1000, `Tomato net available supply is 1000 kg (got: ${tomatoInsight.availableSupply})`);

// ----------------------------------------------------
// 6. REGIONAL DEMAND & PRIVACY PRESERVATION
// ----------------------------------------------------
const regionalResult = aggregateRegionalDemand(mockOrders, mockProducts);
assert(Array.isArray(regionalResult.regions), 'aggregateRegionalDemand returns regions array');
assert(regionalResult.totalRegionsCount === 2, `Aggregated 2 distinct districts (got: ${regionalResult.totalRegionsCount})`);

// STRICT PRIVACY CHECK: Verify no latitude, longitude, accuracy in regional payload
const serializedRegional = JSON.stringify(regionalResult);
assert(!serializedRegional.includes('"latitude"'), 'Privacy check: zero latitude in regional demand feed');
assert(!serializedRegional.includes('"longitude"'), 'Privacy check: zero longitude in regional demand feed');
assert(!serializedRegional.includes('"accuracy"'), 'Privacy check: zero GPS accuracy in regional demand feed');

// ----------------------------------------------------
// 7. ROLE RECOMMENDATIONS
// ----------------------------------------------------
const farmerRecs = generateFarmerRecommendations(
  [{ name: 'Desi Tomato', quantity: 400 }],
  analyticsResult,
  { district: 'Gautam Buddha Nagar' }
);
assert(Array.isArray(farmerRecs) && farmerRecs.length > 0, 'generateFarmerRecommendations returns recommendations');
assert(farmerRecs[0].suggestedRangeFormatted.includes('kg'), 'Farmer recommendation includes suggested range in kg');
assert(
  !farmerRecs[0].recommendationText.includes('guaranteed profit') && 
  !farmerRecs[0].recommendationText.includes('guaranteed sales'),
  'Farmer recommendation adheres to no-guarantee rule'
);

const fpoInsights = generateFPOInsights(
  [{ id: 'f1', name: 'Ramesh' }],
  [{ crop: 'Desi Tomato', quantity: 500 }],
  analyticsResult
);
assert(Array.isArray(fpoInsights) && fpoInsights.length > 0, 'generateFPOInsights returns FPO insights');
assert(fpoInsights[0].memberSupply === 500, 'FPO insight tracks member supply accurately');

const buyerSignals = generateBulkBuyerSignals(analyticsResult, [{ city: 'Noida' }]);
assert(Array.isArray(buyerSignals) && buyerSignals.length > 0, 'generateBulkBuyerSignals returns procurement opportunities');
assert(buyerSignals[0].suggestedProcurementFormatted.includes('kg'), 'Bulk buyer signal specifies suggested procurement volume');

const consumerRecs = generateConsumerRecommendations(mockProducts, analyticsResult);
assert(Array.isArray(consumerRecs), 'generateConsumerRecommendations returns product recommendations');
assert(consumerRecs.some(p => p.demandSignal), 'Consumer products tagged with demand/freshness signals');

// ----------------------------------------------------
// 8. DATABASE MIGRATION 013 INTEGRITY CHECKS
// ----------------------------------------------------
const migrationFile = path.join(rootDir, 'supabase', 'migrations', '013_demand_forecasts.sql');
assert(fs.existsSync(migrationFile), 'Migration file 013_demand_forecasts.sql exists');

const migrationSql = fs.readFileSync(migrationFile, 'utf-8');
assert(migrationSql.includes('CREATE TABLE IF NOT EXISTS public.demand_forecasts'), '013 creates demand_forecasts table');
assert(migrationSql.includes('ENABLE ROW LEVEL SECURITY'), '013 enables Row Level Security');
assert(migrationSql.includes('RISING DEMAND'), '013 enforces demand_classification CHECK constraint');
assert(migrationSql.includes('Potential Shortage'), '013 enforces supply_status CHECK constraint');
assert(migrationSql.includes('idx_demand_forecasts_product_id'), '013 creates product_id index');
assert(migrationSql.includes('idx_demand_forecasts_crop'), '013 creates crop_name index');
assert(migrationSql.includes('idx_demand_forecasts_region'), '013 creates region index');

// ----------------------------------------------------
// 9. SECURITY & NO-SECRETS AUDIT
// ----------------------------------------------------
const clientFile = fs.readFileSync(path.join(rootDir, 'src', 'lib', 'supabase.js'), 'utf-8');
assert(!clientFile.includes('service_role'), 'Security check: No service_role key in client configuration');
assert(!clientFile.includes('SUPABASE_SERVICE_ROLE'), 'Security check: No SUPABASE_SERVICE_ROLE in frontend');

// Check demandForecastService methods
assert(typeof demandForecastService.getDemandForecasts === 'function', 'demandForecastService exposes getDemandForecasts');
assert(typeof demandForecastService.getRegionalDemand === 'function', 'demandForecastService exposes getRegionalDemand');

console.log('====================================================');
console.log(`PHASE 6 VALIDATION COMPLETE: ${passedTests}/${totalTests} TESTS PASSED`);
console.log('====================================================');

if (passedTests !== totalTests) {
  process.exit(1);
}
