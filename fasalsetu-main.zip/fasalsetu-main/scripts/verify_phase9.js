// Automated Verification Script for Phase 9: SIH Hardening, Security, Demo & Presentation Readiness
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

import { ORDER_LIFECYCLE_STEPS, VALID_STATUS_TRANSITIONS } from '../src/constants/orderStatus.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const srcDir = path.join(rootDir, 'src');

console.log('====================================================');
console.log('RUNNING PHASE 9 SIH HARDENING & DEMO READINESS TESTS');
console.log('====================================================');

let passedTests = 0;
let totalTests = 0;

function assert(condition, testName) {
  totalTests++;
  if (condition) {
    console.log(`✅ [PASS] ${testName}`);
    passedTests++;
  } else {
    console.error(`❌ [FAIL] ${testName}`);
  }
}

// Helper: recursively find all files matching extensions
function findFiles(dir, extensions, results = []) {
  if (!fs.existsSync(dir)) return results;
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name !== 'node_modules' && entry.name !== '.git' && entry.name !== 'dist') {
        findFiles(fullPath, extensions, results);
      }
    } else if (extensions.some(ext => entry.name.endsWith(ext))) {
      results.push(fullPath);
    }
  }
  return results;
}

// Helper: read file content safely
function readFile(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf-8');
  } catch {
    return '';
  }
}

// ============================================================
// 1. REQUIRED DOCUMENTATION COMPLETENESS
// ============================================================
console.log('\n--- 1. Documentation Suite Completeness ---');

const requiredDocs = [
  'SIH_DEMO_GUIDE.md',
  'SECURITY_AUDIT.md',
  'ARCHITECTURE.md',
  'JUDGE_FAQ.md',
  'PRESENTATION_NOTES.md'
];

for (const doc of requiredDocs) {
  const docPath = path.join(rootDir, doc);
  const exists = fs.existsSync(docPath);
  assert(exists, `Required document ${doc} exists`);
  if (exists) {
    const content = readFile(docPath);
    assert(content.length > 1000, `${doc} has substantial content (${content.length} bytes)`);
  }
}

// README exists
assert(fs.existsSync(path.join(rootDir, 'README.md')), 'README.md exists');

// ============================================================
// 2. SECRETS & ENVIRONMENT SECURITY
// ============================================================
console.log('\n--- 2. Secrets & Environment Security ---');

// Check .gitignore
const gitignoreContent = readFile(path.join(rootDir, '.gitignore'));
assert(gitignoreContent.includes('.env'), '.gitignore excludes .env files');
assert(gitignoreContent.includes('!.env.example'), '.gitignore preserves .env.example');

// Check .env.example exists
assert(fs.existsSync(path.join(rootDir, '.env.example')), '.env.example template exists');

// Scan source for hardcoded secrets
const sourceFiles = findFiles(srcDir, ['.js', '.jsx', '.ts', '.tsx']);

let serviceRoleFound = false;
let hardcodedSupabaseKey = false;

for (const file of sourceFiles) {
  const content = readFile(file);
  if (content.includes('service_role') || content.includes('SUPABASE_SERVICE_ROLE')) {
    serviceRoleFound = true;
  }
  // Check for hardcoded key patterns (long base64 strings that look like Supabase keys)
  if (/supabaseAnonKey\s*=\s*['"][A-Za-z0-9+/=]{40,}['"]/.test(content)) {
    hardcodedSupabaseKey = true;
  }
}

assert(!serviceRoleFound, 'No service_role references in src/ directory');
assert(!hardcodedSupabaseKey, 'No hardcoded Supabase keys in src/ directory');

// ============================================================
// 3. DEMO ACCOUNTS VALIDATION
// ============================================================
console.log('\n--- 3. Demo Accounts Configuration ---');

const authContextContent = readFile(path.join(srcDir, 'context', 'AuthContext.jsx'));
assert(authContextContent.includes('DEMO_ACCOUNTS'), 'DEMO_ACCOUNTS defined in AuthContext');

const requiredRoles = ['farmer', 'fpo', 'consumer', 'bulk_buyer'];
for (const role of requiredRoles) {
  assert(authContextContent.includes(`${role}:`), `Demo account for role "${role}" exists`);
}

// Verify demo IDs are valid UUID-like format
const demoIdPattern = /id:\s*'[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}'/g;
const demoIdMatches = authContextContent.match(demoIdPattern);
assert(demoIdMatches && demoIdMatches.length >= 4, `All 4 demo accounts have valid UUID-format IDs (found ${demoIdMatches?.length || 0})`);

// ============================================================
// 4. ROUTE PROTECTION & ROLE MATRIX
// ============================================================
console.log('\n--- 4. Route Protection & Role Enforcement ---');

const appContent = readFile(path.join(srcDir, 'App.jsx'));
const protectedRouteContent = readFile(path.join(srcDir, 'components', 'auth', 'ProtectedRoute.jsx'));

// Verify ProtectedRoute is used for all role portals
assert(appContent.includes("allowedRoles={['farmer']}"), 'Farmer routes protected with allowedRoles');
assert(appContent.includes("allowedRoles={['fpo']}"), 'FPO routes protected with allowedRoles');
assert(appContent.includes("allowedRoles={['consumer']}"), 'Consumer routes protected with allowedRoles');
assert(appContent.includes("allowedRoles={['bulk_buyer']}"), 'Bulk Buyer routes protected with allowedRoles');

// Verify ProtectedRoute handles unauthenticated redirect
assert(protectedRouteContent.includes('Navigate') && protectedRouteContent.includes('/login'), 'ProtectedRoute redirects unauthenticated users to /login');

// Verify wrong-role redirect to own dashboard
assert(protectedRouteContent.includes('getRoleDashboardPath'), 'ProtectedRoute redirects wrong-role users to their own dashboard');

// Verify catch-all route exists
assert(appContent.includes('path="*"'), 'Catch-all route configured for unknown paths');

// ============================================================
// 5. ORDER LIFECYCLE & STATE TRANSITION INTEGRITY
// ============================================================
console.log('\n--- 5. Order Lifecycle State Machine ---');

// Verify lifecycle steps are complete
assert(ORDER_LIFECYCLE_STEPS.length === 7, `Order lifecycle has 7 steps (got ${ORDER_LIFECYCLE_STEPS.length})`);
assert(ORDER_LIFECYCLE_STEPS[0] === 'Pending', 'First step is Pending');
assert(ORDER_LIFECYCLE_STEPS[6] === 'Delivered', 'Last step is Delivered');

// Verify terminal states have no valid transitions
assert(VALID_STATUS_TRANSITIONS['Delivered'].length === 0, 'Delivered is a terminal state (no outgoing transitions)');
assert(VALID_STATUS_TRANSITIONS['Cancelled'].length === 0, 'Cancelled is a terminal state (no outgoing transitions)');

// Verify invalid jumps are blocked
assert(!VALID_STATUS_TRANSITIONS['Pending'].includes('Delivered'), 'Pending → Delivered is blocked');
assert(!VALID_STATUS_TRANSITIONS['Pending'].includes('In Transit'), 'Pending → In Transit is blocked');
assert(!VALID_STATUS_TRANSITIONS['Confirmed'].includes('Delivered'), 'Confirmed → Delivered is blocked');
assert(!VALID_STATUS_TRANSITIONS['Preparing'].includes('Delivered'), 'Preparing → Delivered is blocked');

// Verify valid transitions exist
assert(VALID_STATUS_TRANSITIONS['Pending'].includes('Confirmed'), 'Pending → Confirmed is allowed');
assert(VALID_STATUS_TRANSITIONS['Pending'].includes('Cancelled'), 'Pending → Cancelled is allowed');
assert(VALID_STATUS_TRANSITIONS['Confirmed'].includes('Preparing'), 'Confirmed → Preparing is allowed');
assert(VALID_STATUS_TRANSITIONS['Confirmed'].includes('Cancelled'), 'Confirmed → Cancelled is allowed');
assert(VALID_STATUS_TRANSITIONS['In Transit'].includes('Delivered'), 'In Transit → Delivered is allowed');

// ============================================================
// 6. INVENTORY LIFECYCLE CONSISTENCY
// ============================================================
console.log('\n--- 6. Inventory Reserve / Deduct / Release ---');

const orderContextContent = readFile(path.join(srcDir, 'context', 'OrderContext.jsx'));

// Verify inventory reservation on order creation
assert(orderContextContent.includes('reserveInventory'), 'OrderContext calls reserveInventory on order creation');

// Verify inventory deduction on delivery
assert(orderContextContent.includes('deductInventory'), 'OrderContext calls deductInventory');
assert(orderContextContent.includes("'Delivered'"), 'Delivery status triggers inventory action');

// Verify inventory release on cancellation
assert(orderContextContent.includes('releaseInventory'), 'OrderContext calls releaseInventory on cancellation');
assert(orderContextContent.includes("'Cancelled'"), 'Cancellation triggers inventory release');

// SQL RPC also handles inventory
const sqlFunctionsContent = readFile(path.join(rootDir, 'supabase', 'migrations', '011_functions.sql'));
assert(sqlFunctionsContent.includes('FOR UPDATE'), 'SQL RPC uses FOR UPDATE row locks for atomicity');
assert(sqlFunctionsContent.includes('reserved_quantity'), 'SQL RPC manages reserved_quantity');
assert(sqlFunctionsContent.includes('quantity_available'), 'SQL RPC manages quantity_available');
assert(sqlFunctionsContent.includes("'reserve'"), 'SQL audit log records reserve transactions');
assert(sqlFunctionsContent.includes("'deduct'"), 'SQL audit log records deduct transactions');
assert(sqlFunctionsContent.includes("'release'"), 'SQL audit log records release transactions');

// ============================================================
// 7. GPS PRIVACY — ZERO RAW COORDINATES IN PUBLIC SURFACES
// ============================================================
console.log('\n--- 7. GPS Privacy Audit ---');

// Check marketplace page does not expose lat/lng in card props
const marketplaceContent = readFile(path.join(srcDir, 'pages', 'Marketplace.jsx'));
// Should reference approximateLocation or similar, not raw lat/lng in card display
assert(!marketplaceContent.includes('product.latitude') && !marketplaceContent.includes('product.longitude'),
  'Marketplace page does not reference product.latitude/longitude directly');

// Check product detail page
const productDetailContent = readFile(path.join(srcDir, 'pages', 'ProductDetails.jsx'));
assert(!productDetailContent.includes('.latitude') || productDetailContent.includes('approximateLocation') || productDetailContent.includes('approximate'),
  'ProductDetails uses approximate location display');

// Check farmer profile for privacy protection
const farmerProfileFiles = findFiles(path.join(srcDir, 'pages', 'farmer'), ['.jsx']);
let farmerProfileHasPrivacy = false;
for (const f of farmerProfileFiles) {
  const content = readFile(f);
  if (content.includes('approximate') || content.includes('privacy') || content.includes('Privacy') || content.includes('masked')) {
    farmerProfileHasPrivacy = true;
    break;
  }
}
assert(farmerProfileHasPrivacy, 'Farmer portal pages reference privacy/approximate location handling');

// ============================================================
// 8. RLS POLICIES & DATABASE SECURITY
// ============================================================
console.log('\n--- 8. Database RLS & Migration Integrity ---');

const rlsContent = readFile(path.join(rootDir, 'supabase', 'migrations', '010_rls_policies.sql'));
assert(rlsContent.includes('ENABLE ROW LEVEL SECURITY'), 'RLS enabled in migration 010');

// Count ENABLE RLS statements
const rlsEnableCount = (rlsContent.match(/ENABLE ROW LEVEL SECURITY/g) || []).length;
assert(rlsEnableCount >= 15, `At least 15 tables have RLS enabled (found ${rlsEnableCount})`);

// Verify critical policies exist
assert(rlsContent.includes('auth.uid()'), 'RLS policies use auth.uid() for identity checks');
assert(rlsContent.includes('buyer_profile_id = auth.uid()'), 'Orders table scoped to buyer identity');
assert(rlsContent.includes('seller_profile_id = auth.uid()'), 'Products table scoped to seller identity');
assert(rlsContent.includes('owner_profile_id = auth.uid()'), 'Farm locations scoped to owner identity');

// All 15 migrations exist
for (let i = 1; i <= 15; i++) {
  const migNum = String(i).padStart(3, '0');
  const migFiles = fs.readdirSync(path.join(rootDir, 'supabase', 'migrations'));
  const found = migFiles.some(f => f.startsWith(migNum));
  assert(found, `Migration ${migNum}_*.sql exists`);
}

// ============================================================
// 9. SUPABASE CLIENT SECURITY
// ============================================================
console.log('\n--- 9. Supabase Client Configuration ---');

const supabaseClientContent = readFile(path.join(srcDir, 'lib', 'supabase.js'));

// Verify it reads from env vars, not hardcoded
assert(supabaseClientContent.includes('VITE_SUPABASE_URL'), 'Supabase URL from environment variable');
assert(supabaseClientContent.includes('VITE_SUPABASE_ANON_KEY'), 'Supabase Anon Key from environment variable');
assert(supabaseClientContent.includes('isConfigured'), 'Exports isConfigured flag for dual-mode detection');
assert(!supabaseClientContent.includes('service_role'), 'No service_role in Supabase client');

// Verify fallback mode
assert(supabaseClientContent.includes('placeholder'), 'Creates placeholder client when not configured');

// ============================================================
// 10. AI CLAIM HONESTY
// ============================================================
console.log('\n--- 10. AI Statistical Model Honesty ---');

// Check AI insights page for honest labeling
const aiInsightsContent = readFile(path.join(srcDir, 'pages', 'AIInsights.jsx'));

// Should NOT contain overstated claims
let hasOverstatedClaims = false;
const dangerousPhrases = ['99% accuracy', '95% accuracy', 'guaranteed income', 'guaranteed savings', 'guaranteed profit'];
for (const phrase of dangerousPhrases) {
  if (aiInsightsContent.toLowerCase().includes(phrase.toLowerCase())) {
    hasOverstatedClaims = true;
    console.error(`   ⚠️ Found overstated claim: "${phrase}"`);
  }
}
assert(!hasOverstatedClaims, 'AI insights page has no overstated accuracy/guarantee claims');

// Should contain prototype/forecast/statistical indicators
const hasHonestLabeling = 
  aiInsightsContent.includes('Prototype') || 
  aiInsightsContent.includes('prototype') ||
  aiInsightsContent.includes('Forecast') ||
  aiInsightsContent.includes('Statistical') ||
  aiInsightsContent.includes('statistical') ||
  aiInsightsContent.includes('Indicator');
assert(hasHonestLabeling, 'AI insights page uses honest labeling (prototype/forecast/statistical)');

// Check farmer earnings for safe disclaimers
const earningsFiles = findFiles(path.join(srcDir, 'pages', 'farmer'), ['.jsx']);
let earningsHasDisclaimer = false;
for (const f of earningsFiles) {
  const content = readFile(f);
  if (content.includes('Earnings') || content.includes('earnings')) {
    if (content.includes('prototype') || content.includes('Prototype') || content.includes('disclaimer') || content.includes('Disclaimer') || content.includes('illustrative')) {
      earningsHasDisclaimer = true;
    }
  }
}
assert(earningsHasDisclaimer, 'Farmer earnings page includes prototype/disclaimer labeling');

// Check bulk buyer order details for safe commercial terms
const bulkBuyerFiles = findFiles(path.join(srcDir, 'pages', 'bulkBuyer'), ['.jsx']);
let hasSafeCommercialTerms = false;
for (const f of bulkBuyerFiles) {
  const content = readFile(f);
  if (content.includes('Prototype') || content.includes('statutory') || content.includes('applicable') || content.includes('To be determined')) {
    hasSafeCommercialTerms = true;
  }
}
assert(hasSafeCommercialTerms, 'Bulk buyer pages use safe prototype commercial terms');

// ============================================================
// 11. CONTEXT PROVIDER TREE INTEGRITY
// ============================================================
console.log('\n--- 11. Context Provider Architecture ---');

const mainContent = readFile(path.join(srcDir, 'main.jsx'));

const requiredProviders = [
  'AuthProvider', 'LocationProvider', 'ProductProvider', 'CartProvider',
  'NotificationProvider', 'OrderProvider', 'FPOProvider', 'BuyerProvider',
  'LogisticsProvider', 'AIProvider'
];

for (const provider of requiredProviders) {
  assert(mainContent.includes(provider), `${provider} present in context tree`);
}

// Verify BrowserRouter wraps everything
assert(mainContent.includes('BrowserRouter'), 'BrowserRouter wraps the application');
assert(mainContent.includes('StrictMode'), 'React StrictMode enabled');

// ============================================================
// 12. PREVIOUS PHASE VERIFICATION SCRIPTS EXIST
// ============================================================
console.log('\n--- 12. Phase Verification Script Suite ---');

for (let phase = 4; phase <= 8; phase++) {
  const scriptPath = path.join(rootDir, 'scripts', `verify_phase${phase}.js`);
  assert(fs.existsSync(scriptPath), `verify_phase${phase}.js exists`);
}

// ============================================================
// 13. BUILD CONFIGURATION
// ============================================================
console.log('\n--- 13. Build & Tooling Configuration ---');

const packageJson = JSON.parse(readFile(path.join(rootDir, 'package.json')));

assert(packageJson.scripts?.dev !== undefined, 'npm run dev script defined');
assert(packageJson.scripts?.build !== undefined, 'npm run build script defined');
assert(packageJson.scripts?.lint !== undefined, 'npm run lint script defined');
assert(packageJson.dependencies?.react !== undefined, 'React is a dependency');
assert(packageJson.dependencies?.['react-router-dom'] !== undefined, 'React Router is a dependency');
assert(packageJson.dependencies?.['@supabase/supabase-js'] !== undefined, 'Supabase JS is a dependency');

// ============================================================
// 14. CONSOLE LOG HYGIENE
// ============================================================
console.log('\n--- 14. Console Log Hygiene ---');

let rogueConsoleLogs = 0;
const jsxFiles = findFiles(srcDir, ['.jsx', '.js']);

for (const file of jsxFiles) {
  const content = readFile(file);
  const lines = content.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    // Allow console.error, console.warn, console.info (these are legitimate)
    // Flag bare console.log that aren't commented out
    if (line.startsWith('console.log(') && !line.startsWith('//')) {
      // Exception: info-level diagnostic in development-only paths
      rogueConsoleLogs++;
    }
  }
}

assert(rogueConsoleLogs === 0, `No rogue console.log statements in src/ (found ${rogueConsoleLogs})`);

// ============================================================
// SUMMARY
// ============================================================
console.log('\n====================================================');
console.log(`PHASE 9 TESTS COMPLETED: ${passedTests} / ${totalTests} PASSED`);
console.log('====================================================');

if (passedTests === totalTests) {
  console.log('\n🏆 SIH DEMO READY — All Phase 9 hardening checks passed!');
  process.exit(0);
} else {
  console.log(`\n⚠️ ${totalTests - passedTests} test(s) need attention before SIH demo.`);
  process.exit(1);
}
