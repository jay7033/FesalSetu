# FasalSetu — System Architecture Document
**SIH 2026 · Problem Statement 26033**  
**Version:** 9.0 (Post Phase 9 Hardening)

---

## 1. High-Level Stack Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                      USER BROWSER (React SPA)                    │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────────────────┐│
│  │  Farmer  │ │   FPO    │ │ Consumer │ │    Bulk Buyer        ││
│  │  Portal  │ │  Portal  │ │  Portal  │ │    Portal            ││
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────────────────┘│
│       │             │            │             │                  │
│  ┌────┴─────────────┴────────────┴─────────────┴───────────────┐ │
│  │              React Router v7 + ProtectedRoute               │ │
│  └────┬────────────────────────────────────────────────────────┘ │
│       │                                                          │
│  ┌────┴────────────────────────────────────────────────────────┐ │
│  │              Context Provider Tree (10 Contexts)            │ │
│  │  Auth → Location → Product → Cart → Notification → Order   │ │
│  │  → FPO → Buyer → Logistics → AI                            │ │
│  └────┬────────────────────────────────────────────────────────┘ │
│       │                                                          │
│  ┌────┴────────────────────────────────────────────────────────┐ │
│  │           Service Layer (13 AI + 6 Logistics + 7 Core)      │ │
│  └────┬────────────────────────────────────────────────────────┘ │
│       │                                                          │
│  ┌────┴──────────────────┐  ┌──────────────────────────────────┐ │
│  │  Supabase JS Client   │  │   localStorage Fallback Engine  │ │
│  │  (@supabase/supabase-js) │  │   (Demo / Offline Mode)        │ │
│  └────┬──────────────────┘  └──────────────────────────────────┘ │
└───────┼──────────────────────────────────────────────────────────┘
        │ HTTPS (Anon Key JWT)
┌───────┴──────────────────────────────────────────────────────────┐
│                    SUPABASE CLOUD PLATFORM                        │
│  ┌───────────┐  ┌───────────┐  ┌────────────┐  ┌──────────────┐ │
│  │  Auth     │  │ PostgreSQL│  │  Realtime   │  │   Storage    │ │
│  │  (JWT)    │  │  + RLS    │  │ (WebSocket) │  │  (Buckets)   │ │
│  └───────────┘  └───────────┘  └────────────┘  └──────────────┘ │
│                                                                   │
│  ┌───────────────────────────────────────────────────────────┐   │
│  │            SQL RPC Functions (SECURITY DEFINER)            │   │
│  │  • create_order_transaction  • update_order_status         │   │
│  │  • cancel_order_transaction  • generate_order_number       │   │
│  └───────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────────────────────────────────┘
```

---

## 2. Frontend Architecture

### 2.1 Technology Stack
| Component | Technology | Version |
| :--- | :--- | :--- |
| Framework | React | 19.x |
| Router | React Router | 7.x |
| Build Tool | Vite | 8.x |
| Styling | Tailwind CSS | 4.x |
| Icons | Lucide React | 1.x |
| Charts | Recharts | 3.x |
| Maps | MapLibre GL | 6.x |
| Linter | OxLint | 1.x |

### 2.2 Directory Structure
```
src/
├── App.jsx                    # Route definitions
├── main.jsx                   # Context provider tree
├── index.css                  # Global styles (Tailwind)
├── components/
│   ├── auth/
│   │   └── ProtectedRoute.jsx # Role-based route guard
│   └── ... (shared UI components)
├── constants/
│   └── orderStatus.js         # Lifecycle steps & valid transitions
├── context/
│   ├── AuthContext.jsx         # Authentication & DEMO_ACCOUNTS
│   ├── LocationContext.jsx     # GPS + reverse geocoding + privacy
│   ├── ProductContext.jsx      # Product CRUD + inventory reservation
│   ├── CartContext.jsx         # Shopping cart state
│   ├── NotificationContext.jsx # In-app notifications
│   ├── OrderContext.jsx        # Order lifecycle & fulfillment
│   ├── FPOContext.jsx          # FPO aggregation & member management
│   ├── BuyerContext.jsx        # Bulk buyer procurement
│   ├── LogisticsContext.jsx    # Logistics & route management
│   └── AIContext.jsx           # AI engine state & forecasts
├── data/
│   └── demoData.js             # Seed data for demo mode
├── layouts/
│   ├── MainLayout.jsx          # Public pages layout
│   ├── FarmerLayout.jsx        # Farmer portal layout
│   ├── FPOLayout.jsx           # FPO portal layout
│   ├── ConsumerLayout.jsx      # Consumer portal layout
│   └── BulkBuyerLayout.jsx     # Bulk buyer portal layout
├── lib/
│   └── supabase.js             # Supabase client initialization
├── pages/
│   ├── Home.jsx                # Landing page
│   ├── Marketplace.jsx         # Pan-India marketplace
│   ├── ProductDetails.jsx      # Product detail view
│   ├── Cart.jsx                # Shopping cart
│   ├── Checkout.jsx            # Multi-supplier checkout
│   ├── AIInsights.jsx          # AI demand intelligence dashboard
│   ├── Logistics.jsx           # Logistics & route optimization
│   ├── HowItWorks.jsx          # Platform explainer
│   ├── auth/                   # Login, Register
│   ├── farmer/                 # Farmer portal pages (8 pages)
│   ├── fpo/                    # FPO portal pages
│   ├── consumer/               # Consumer portal pages (3 pages)
│   └── bulkBuyer/              # Bulk buyer portal pages (3 pages)
├── services/
│   ├── ai/                     # 13 AI/ML service modules
│   ├── logistics/              # 6 logistics service modules
│   ├── authService.js          # Supabase auth wrapper
│   ├── orderService.js         # Order CRUD + RPC calls
│   ├── productService.js       # Product CRUD
│   ├── inventoryService.js     # Inventory transactions
│   ├── locationService.js      # Location CRUD
│   ├── geocoding.js            # Reverse geocoding (Nominatim)
│   ├── geolocation.js          # Browser Geolocation API
│   └── ... (profile, notification, buyer, fpo services)
└── utils/                      # Shared utility functions
```

### 2.3 Context Provider Tree (Dependency Order)
```
BrowserRouter
  └── AuthProvider                    ← Authentication state
        └── LocationProvider          ← GPS + geocoding
              └── ProductProvider     ← Product catalog + inventory
                    └── CartProvider  ← Shopping cart
                          └── NotificationProvider
                                └── OrderProvider      ← Order lifecycle
                                      └── FPOProvider  ← FPO aggregation
                                            └── BuyerProvider
                                                  └── LogisticsProvider
                                                        └── AIProvider
                                                              └── <App />
```

---

## 3. Database Architecture (Supabase PostgreSQL)

### 3.1 Migration Files (15 Sequential Migrations)
| # | File | Purpose |
| :--- | :--- | :--- |
| 001 | `profiles.sql` | Base user profiles (all roles) |
| 002 | `farmer_fpo_profiles.sql` | Extended farmer & FPO profile tables |
| 003 | `buyer_profiles.sql` | Consumer & bulk buyer profile tables |
| 004 | `locations.sql` | Farm locations & buyer locations |
| 005 | `products.sql` | Product catalog with inventory fields |
| 006 | `orders.sql` | Orders, order_items, fulfillments, timeline |
| 007 | `inventory.sql` | Inventory transaction audit log |
| 008 | `notifications.sql` | In-app notification table |
| 009 | `saved_products.sql` | Consumer wishlists |
| 010 | `rls_policies.sql` | Row Level Security (21 tables enabled) |
| 011 | `functions.sql` | Atomic RPC functions (3 stored procedures) |
| 012 | `storage.sql` | Supabase Storage bucket policies |
| 013 | `demand_forecasts.sql` | AI demand forecast tables |
| 014 | `logistics.sql` | Logistics routes, pickups, shipments |
| 015 | `smart_supply_chain.sql` | Smart matching, procurement, opportunity |

### 3.2 Core Entity Relationships
```mermaid
erDiagram
    profiles ||--o| farmer_profiles : "has"
    profiles ||--o| fpo_profiles : "has"
    profiles ||--o| consumer_profiles : "has"
    profiles ||--o| bulk_buyer_profiles : "has"
    farmer_profiles ||--o{ farm_locations : "owns"
    fpo_profiles ||--o{ fpo_members : "manages"
    profiles ||--o{ products : "sells"
    products ||--o{ order_items : "ordered_in"
    profiles ||--o{ orders : "places"
    orders ||--o{ order_items : "contains"
    orders ||--o{ order_fulfillments : "fulfilled_by"
    orders ||--o{ order_timeline : "tracked_by"
    products ||--o{ inventory_transactions : "audited_by"
```

### 3.3 Inventory Fields on `products` Table
| Column | Type | Purpose |
| :--- | :--- | :--- |
| `quantity_available` | NUMERIC | Current available-for-order stock |
| `reserved_quantity` | NUMERIC | Stock reserved by active orders (not yet delivered) |
| `total_quantity` | NUMERIC | Original total quantity listed |

---

## 4. Data Flow Architecture

### 4.1 Order Creation Flow
```
Consumer/Buyer → CartContext → Checkout Page
                                    │
                    ┌───────────────┴───────────────┐
                    │  Supabase configured?          │
                    ├── YES ─────────────────────────┤
                    │  orderService.createOrder()    │
                    │  → RPC: create_order_transaction│
                    │  → FOR UPDATE row locks         │
                    │  → Validate stock               │
                    │  → Reserve inventory            │
                    │  → Create order + items          │
                    │  → Create fulfillments           │
                    │  → Timeline entry                │
                    │  → Notifications                 │
                    │  → RETURN order JSON             │
                    ├── NO (Offline) ─────────────────┤
                    │  OrderContext.createOrder()      │
                    │  → reserveInventory() (local)    │
                    │  → Build fulfillments map        │
                    │  → Save to localStorage          │
                    │  → addNotification() (local)     │
                    └─────────────────────────────────┘
```

### 4.2 AI Demand Intelligence Flow
```
AIContext.jsx
    │
    ├── demandForecastService.js
    │   └── Weighted Moving Average (50% / 30% / 20%)
    │       × Regional Trend Multiplier (0.80–1.25)
    │       → Forecast Demand per Crop per District
    │
    ├── supplyDemandService.js
    │   └── Compare forecast vs. available supply
    │       → Potential Shortage / Surplus / Balanced / Insufficient Data
    │
    ├── opportunityScoreService.js
    │   └── Multi-factor score (demand, inventory, buyers, logistics)
    │       → Farmer Opportunity Score (0–100)
    │       → FPO Aggregation Opportunity
    │
    ├── matchingService.js
    │   └── Weighted scoring (Qty 25% + Dist 20% + Quality 20% + Price 15% + Fresh 10% + Demand 10%)
    │       → Buyer-Supplier Match Score
    │
    └── redistributionService.js
        └── Evaluates surplus→shortage corridors
            → Transferable quantity + existing route association
```

### 4.3 Logistics Route Optimization Flow
```
LogisticsContext.jsx → routeOptimizationService.js
    │
    ├── Step 1: Collect pickup points (farm locations)
    ├── Step 2: Nearest Neighbor initial route construction
    ├── Step 3: 2-Opt local search improvement
    ├── Step 4: Vehicle capacity constraint validation
    ├── Step 5: ETA calculation (40 km/h baseline + dwell)
    └── Step 6: MapLibre visualization with route polylines
```

---

## 5. Hybrid Live + Demo Data Architecture (Unified System Experience)

FasalSetu utilizes a unified **Hybrid Data Architecture** rather than splitting into separate "Demo" vs "Live" applications. Live Supabase database records operate as the authoritative source of truth, while verified pre-seeded records act as an immediate fallback and seed layer to ensure zero empty screens during evaluation.

```
                     FASALSETU UNIFIED CLIENT
                                │
         ┌──────────────────────┴──────────────────────┐
         ▼                                             ▼
  Live Data Stream                             Baseline Demo Layer
  • Real Supabase PostgreSQL                   • Pre-seeded verified records
  • User-created accounts                      • Authentic agri-benchmarks
  • Live orders & product uploads              • Always available offline
  • Priority 1 in deduplication                • source: 'demo', isDemo: true
         │                                             │
         └──────────────────────┬──────────────────────┘
                                ▼
                   Hybrid Merge & Normalizer
                     (src/utils/normalizers.js)
                                │
                 Deduplication Engine (Live Wins)
                                │
                                ▼
                      UI Presentation Layer
              (Clean Badges + Connection Indicator)
```

### 5.1 Architecture Principles
1. **Live Data Takes Priority:** When an item exists in both Supabase and demo seeds with identical identifiers, the live record supersedes.
2. **Normalized Data Contract:** Every record passing through contexts contains standardized metadata:
   - `source`: `'live'` | `'demo'`
   - `isDemo`: `true` | `false`
3. **Demo Isolation & Mutation Protection:** Core demo records are write-protected; deleting or modifying them is blocked both at the client context level and via Supabase Row-Level Security policies.
4. **Transparent AI Metrics:** The AI intelligence engine exposes transparent data composition counts (`liveProducts`, `demoProducts`, `liveOrders`, `demoOrders`) so evaluators know exactly how much live user input feeds the forecasts.
5. **Dynamic Connection Indicator:** A subtle pill in the navigation header displays `Live Sync` (green pulsing dot) when connected to Supabase or `Demo Sandbox` (amber dot) when operating in offline/demo mode, complete with detailed metrics popover.

| Component | Live Source | Seed / Demo Baseline |
| :--- | :--- | :--- |
| Products | Supabase `products` table | `MARKETPLACE_PRODUCTS` (`src/data/demoData.js`) |
| Orders | Supabase `orders` table | `SEED_ORDERS` (`OrderContext.jsx`) |
| Users | Supabase Auth + `profiles` | `DEMO_ACCOUNTS` (`AuthContext.jsx`) |
| Locations | Supabase `farm_locations` | `INITIAL_FARM_LOCATIONS` (`LocationContext.jsx`) |
| Logistics | Logistics Route Service | Pre-configured pickup routes & clusters |
| Reset Scope | Persisted in database | Resets demo caches only; preserves all live user records |

---

## 6. External Dependencies

| Dependency | Purpose | License | Network Required? |
| :--- | :--- | :--- | :--- |
| Supabase | Backend-as-a-Service | Apache 2.0 | Yes (optional) |
| MapLibre GL | Map rendering | BSD 3-Clause | Yes (tile fetching) |
| Nominatim | Reverse geocoding | ODbL | Yes |
| Recharts | Chart rendering | MIT | No |
| Lucide | Icons | ISC | No |

---

## 7. Security Layers Summary

```
Layer 1: React Router ProtectedRoute (client-side role guard)
Layer 2: Supabase Auth JWT (server-verified identity)
Layer 3: PostgreSQL RLS Policies (row-level data isolation)
Layer 4: SECURITY DEFINER RPCs (atomic transactions with server-side validation)
Layer 5: .gitignore + env isolation (secrets never committed)
Layer 6: GPS Privacy Masking (approximate-public / precise-private)
```
