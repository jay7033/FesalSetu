# FasalSetu — Supabase Backend Setup & Migration Guide

This document explains how to set up, configure, and migrate the **FasalSetu** PostgreSQL database, Supabase Auth, Row Level Security (RLS) policies, Storage buckets, and Realtime channels.

---

## 1. Create a Supabase Project

1. Navigate to [Supabase](https://supabase.com/) and sign in.
2. Click **New Project**.
3. Fill in the details:
   - **Name**: `fasalsetu-production` (or `fasalsetu-dev`)
   - **Database Password**: Generate a secure password.
   - **Region**: Select a region close to your target audience (e.g. `ap-south-1` Mumbai, India).
4. Wait for the database to be provisioned.

---

## 2. Environment Variables Configuration

In your project root, create or edit `.env` (copied from [`.env.example`](file:///.env.example)):

```env
# Supabase Project URL & Anon Key (found in Project Settings -> API)
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-public-key

# Optional: Map & Geocoding configuration
VITE_REVERSE_GEOCODE_API_URL=https://nominatim.openstreetmap.org/reverse
VITE_MAP_STYLE_URL=https://demotiles.maplibre.org/style.json
VITE_APP_ENV=development
```

> [!CAUTION]
> **Never commit your secret credentials**:
> - Never place `service_role` key into client `.env` files.
> - Only use the public `anon` key in `VITE_SUPABASE_ANON_KEY`.

---

## 3. Database Migrations

Apply the migrations in sequential order using the Supabase SQL Editor or Supabase CLI:

### Option A: Using the Supabase Dashboard SQL Editor
Copy and execute the contents of each migration file in [`supabase/migrations/`](file:///supabase/migrations/) in numerical sequence:

1. **`001_profiles.sql`**: Creates `profiles` table, role check (`farmer`, `fpo`, `consumer`, `bulk_buyer`), and `auth.users` sync trigger.
2. **`002_farmer_fpo_profiles.sql`**: Creates `farmer_profiles`, `fpo_profiles`, and `fpo_members`.
3. **`003_buyer_profiles.sql`**: Creates `consumer_profiles` and `bulk_buyer_profiles`.
4. **`004_locations.sql`**: Creates `farm_locations`, `buyer_locations`, and privacy-preserving `public_farm_locations` view.
5. **`005_products.sql`**: Creates `products` table with inventory non-negativity checks, MOQ, and `public_products` view.
6. **`006_orders.sql`**: Creates `orders`, `order_items`, `order_fulfillments`, `order_timeline`, and order number generator (`FS-YYYY-XXXXXX`).
7. **`007_inventory.sql`**: Creates `inventory_transactions` audit ledger (`reserve`, `release`, `deduct`, `adjustment`).
8. **`008_notifications.sql`**: Creates `notifications` table for real-time transaction alerts.
9. **`009_saved_products.sql`**: Creates `saved_products` table for consumer favorites.
10. **`010_rls_policies.sql`**: Enables Row Level Security on all private tables with owner-based policies.
11. **`011_functions.sql`**: Creates atomic PostgreSQL RPC functions:
    - `create_order_transaction(...)`: Atomically checks inventory & MOQ, reserves stock, creates order, sub-fulfillments, timeline, notifications, and audit ledger.
    - `update_order_status(...)`: Enforces sequential 7-stage lifecycle (`Pending` $\rightarrow$ `Confirmed` $\rightarrow$ `Preparing` $\rightarrow$ `Ready for Pickup` $\rightarrow$ `Picked Up` $\rightarrow$ `In Transit` $\rightarrow$ `Delivered`).
    - `cancel_order_transaction(...)`: Atomically restores reserved stock and marks order cancelled.
12. **`012_storage.sql`**: Configures storage buckets `product-images` and `avatars` with RLS.

### Option B: Using the Supabase CLI
```bash
supabase db push
```

---

## 4. Seed Demo Data

To populate the database with safe prototype Pan-India records (farmers, FPOs, products, locations, orders):

Execute [`supabase/seed.sql`](file:///supabase/seed.sql) in the Supabase SQL Editor.

This seeds:
- **Verified Farmers & FPOs**: Ramesh Kumar (Dankaur, UP), Kisan Samriddhi FPO (Jewar, UP), Nashik Collective (Maharashtra).
- **Crops**: Desi Vine Tomatoes, Tender Spinach, Chipsona Potatoes, Sharbati Golden Wheat, Crimson Onions.
- **Initial Transaction**: Order #FS-2026-001024.

---

## 5. Storage Configuration

1. In the Supabase dashboard, navigate to **Storage**.
2. Verify the two buckets:
   - **`product-images`**: Public bucket for agricultural produce photos.
   - **`avatars`**: Public bucket for user profile pictures.
3. If not already created by `012_storage.sql`, click **New Bucket**, name it `product-images`, and toggle **Public bucket** ON.

---

## 6. Enable Realtime Replication

1. Navigate to **Database** $\rightarrow$ **Replication**.
2. Under the `supabase_realtime` publication, enable toggle for the following tables:
   - `orders` (for live counterparty tracking)
   - `order_fulfillments` (for sub-dispatch updates)
   - `notifications` (for instant in-app alerts)

---

## 7. User Roles & Testing Credentials

FasalSetu supports 4 distinct primary roles:

| Role | Demo Email | Portal Route | Primary Features |
| :--- | :--- | :--- | :--- |
| **🌾 Farmer** | `farmer@fasalsetu.demo` | `/farmer/dashboard` | Harvest listings, inventory management, sequential order fulfillment, GPS status. |
| **🏢 FPO** | `fpo@fasalsetu.demo` | `/fpo/dashboard` | Member farmer management, multi-farm aggregation yards, bulk produce batches. |
| **🛒 Consumer** | `consumer@fasalsetu.demo` | `/consumer/dashboard` | Fresh produce discovery, 5-step checkout, real-time dispatch tracking, favorites. |
| **🚛 Bulk Buyer** | `bulkbuyer@fasalsetu.demo` | `/bulk-buyer/dashboard` | Multi-tonne procurement, MOQ validation, prototype PO generation, supplier comparison. |

---

## 8. Row Level Security (RLS) Verification

To verify that RLS is working as intended:

1. **Public Marketplace Query**:
   ```sql
   SELECT * FROM public_products;
   ```
   *Expected*: Produces active products with approximate location (`city`, `district`, `state`), with exact GPS hidden.

2. **Cross-User Modification Rejection**:
   Attempt to update a product using a non-owner user ID:
   ```sql
   -- Run as consumer authenticated user
   UPDATE public.products SET price = 1 WHERE id = '...';
   ```
   *Expected*: `0 rows updated` (rejected by RLS).

3. **Direct Order Isolation**:
   ```sql
   SELECT * FROM public.orders;
   ```
   *Expected*: Returns only orders where `buyer_profile_id = auth.uid()`.

---

## 9. Troubleshooting & FAQ

- **Q: What happens if `VITE_SUPABASE_URL` is not configured?**  
  **A**: FasalSetu detects this via `isSupabaseConfigured()` and runs in safe local prototype fallback mode using pre-seeded accounts so hackathon evaluators can test without downtime.
- **Q: Are exact coordinates ever exposed on product cards?**  
  **A**: No. The public views and API queries mask exact latitude and longitude, exposing only coarse district, city, and state information.
- **Q: Can a farmer jump from `Pending` directly to `Delivered`?**  
  **A**: No. Both the PostgreSQL `update_order_status` function and `OrderContext` reject any skip outside the 7-stage sequential progression.
