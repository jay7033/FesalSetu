-- Migration 005: Produce Catalog & Inventory Table

CREATE TABLE IF NOT EXISTS public.products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    seller_profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    seller_type TEXT NOT NULL CHECK (seller_type IN ('farmer', 'fpo')),
    farm_location_id UUID REFERENCES public.farm_locations(id) ON DELETE SET NULL,

    name TEXT NOT NULL,
    hindi_name TEXT,
    category TEXT NOT NULL CHECK (category IN ('Vegetables', 'Fruits', 'Grains', 'Pulses', 'Spices', 'Dairy', 'Other')),
    description TEXT,

    price NUMERIC(10, 2) NOT NULL CHECK (price >= 0),
    unit TEXT NOT NULL DEFAULT 'kg' CHECK (unit IN ('kg', 'quintal', 'tonne', 'dozen', 'box', 'bunch', 'crate', 'litre')),

    quantity_available NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (quantity_available >= 0),
    reserved_quantity NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (reserved_quantity >= 0),
    minimum_order_quantity NUMERIC(12, 2) NOT NULL DEFAULT 1 CHECK (minimum_order_quantity > 0),

    quality TEXT NOT NULL DEFAULT 'Grade A' CHECK (quality IN ('Grade A', 'Grade B', 'Premium Export', 'Organic Certified', 'Standard')),
    organic BOOLEAN NOT NULL DEFAULT false,
    harvest_date DATE NOT NULL DEFAULT CURRENT_DATE,

    image_url TEXT,
    is_active BOOLEAN NOT NULL DEFAULT true,

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    -- Consistency constraint: available quantity can never be negative
    CONSTRAINT chk_positive_available CHECK (quantity_available >= 0),
    CONSTRAINT chk_positive_reserved CHECK (reserved_quantity >= 0)
);

CREATE INDEX IF NOT EXISTS idx_products_seller ON public.products(seller_profile_id);
CREATE INDEX IF NOT EXISTS idx_products_category ON public.products(category);
CREATE INDEX IF NOT EXISTS idx_products_active ON public.products(is_active);
CREATE INDEX IF NOT EXISTS idx_products_farm_loc ON public.products(farm_location_id);

CREATE TRIGGER set_products_updated_at
    BEFORE UPDATE ON public.products
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

-- Safe public marketplace view combining products with approximate regional locality
CREATE OR REPLACE VIEW public.public_products AS
SELECT 
    p.id,
    p.seller_profile_id,
    p.seller_type,
    prof.full_name AS seller_name,
    p.name,
    p.hindi_name,
    p.category,
    p.description,
    p.price,
    p.unit,
    p.quantity_available,
    p.minimum_order_quantity,
    p.quality,
    p.organic,
    p.harvest_date,
    p.image_url,
    p.is_active,
    pfl.approximate_location,
    pfl.city,
    pfl.district,
    pfl.state,
    p.created_at
FROM public.products p
JOIN public.profiles prof ON p.seller_profile_id = prof.id
LEFT JOIN public.public_farm_locations pfl ON p.farm_location_id = pfl.id
WHERE p.is_active = true;
