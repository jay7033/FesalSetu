-- Migration 011: Transactional RPC Functions for Atomic Order Creation & Lifecycle

-- Function 1: Atomic Order Creation with Inventory Reservation
CREATE OR REPLACE FUNCTION public.create_order_transaction(
    p_buyer_id UUID,
    p_buyer_role TEXT,
    p_delivery_type TEXT,
    p_payment_method TEXT,
    p_delivery_address TEXT,
    p_delivery_estimate TEXT,
    p_buyer_location_id UUID DEFAULT NULL,
    p_items JSONB DEFAULT '[]'::JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_order_id UUID;
    v_order_number TEXT;
    v_subtotal NUMERIC(12, 2) := 0;
    v_delivery_fee NUMERIC(10, 2) := 0;
    v_savings NUMERIC(10, 2) := 0;
    v_total NUMERIC(12, 2) := 0;
    v_item RECORD;
    v_prod RECORD;
    v_item_qty NUMERIC(12, 2);
    v_item_subtotal NUMERIC(12, 2);
    v_sellers JSONB := '[]'::JSONB;
    v_seller_id UUID;
    v_seller_rec RECORD;
    v_res JSONB;
BEGIN
    -- 1. Validate Buyer
    IF p_buyer_id IS NULL THEN
        RAISE EXCEPTION 'Authenticated buyer profile is required.';
    END IF;

    IF jsonb_array_length(p_items) = 0 THEN
        RAISE EXCEPTION 'Cannot create an order with empty items.';
    END IF;

    -- 2. Verify all products, MOQ, and inventory availability before modifying state
    FOR v_item IN SELECT * FROM jsonb_to_recordset(p_items) AS x(
        product_id UUID,
        quantity NUMERIC
    )
    LOOP
        v_item_qty := v_item.quantity;

        SELECT * INTO v_prod FROM public.products WHERE id = v_item.product_id FOR UPDATE;

        IF NOT FOUND THEN
            RAISE EXCEPTION 'Product % not found in database.', v_item.product_id;
        END IF;

        IF NOT v_prod.is_active THEN
            RAISE EXCEPTION 'Product "%" is currently inactive and cannot be ordered.', v_prod.name;
        END IF;

        IF v_item_qty < v_prod.minimum_order_quantity THEN
            RAISE EXCEPTION 'Requested quantity (%) is below Minimum Order Quantity (%) for "%".', 
                v_item_qty, v_prod.minimum_order_quantity, v_prod.name;
        END IF;

        IF v_prod.quantity_available < v_item_qty THEN
            RAISE EXCEPTION 'Insufficient stock for "%". Available: % %, Requested: % %.',
                v_prod.name, v_prod.quantity_available, v_prod.unit, v_item_qty, v_prod.unit;
        END IF;

        -- Accumulate subtotal using current DB price snapshot (tamper-proof)
        v_item_subtotal := v_prod.price * v_item_qty;
        v_subtotal := v_subtotal + v_item_subtotal;
    END LOOP;

    -- Calculate Delivery Fee
    IF p_delivery_type = 'pickup' THEN
        v_delivery_fee := 0;
    ELSE
        -- Free delivery above ₹500 for consumers, flat ₹40 otherwise
        IF p_buyer_role = 'consumer' THEN
            IF v_subtotal >= 500 THEN
                v_delivery_fee := 0;
            ELSE
                v_delivery_fee := 40;
            END IF;
        ELSE
            -- B2B freight nominal fee
            v_delivery_fee := 750;
        END IF;
    END IF;

    v_total := v_subtotal + v_delivery_fee;
    v_order_number := public.generate_order_number();

    -- 3. Create Parent Order
    INSERT INTO public.orders (
        order_number,
        buyer_profile_id,
        buyer_role,
        subtotal,
        delivery_fee,
        savings,
        total,
        delivery_type,
        payment_method,
        payment_status,
        status,
        buyer_location_id,
        delivery_address,
        delivery_estimate
    ) VALUES (
        v_order_number,
        p_buyer_id,
        p_buyer_role,
        v_subtotal,
        v_delivery_fee,
        v_savings,
        v_total,
        p_delivery_type,
        p_payment_method,
        'pending',
        'Pending',
        p_buyer_location_id,
        p_delivery_address,
        p_delivery_estimate
    ) RETURNING id INTO v_order_id;

    -- 4. Insert Order Items, Reserve Inventory, and Record Inventory Audit
    FOR v_item IN SELECT * FROM jsonb_to_recordset(p_items) AS x(
        product_id UUID,
        quantity NUMERIC
    )
    LOOP
        v_item_qty := v_item.quantity;

        SELECT * INTO v_prod FROM public.products WHERE id = v_item.product_id;
        v_item_subtotal := v_prod.price * v_item_qty;

        -- Reserve stock in product table
        UPDATE public.products
        SET 
            quantity_available = quantity_available - v_item_qty,
            reserved_quantity = reserved_quantity + v_item_qty,
            updated_at = NOW()
        WHERE id = v_prod.id;

        -- Record item
        INSERT INTO public.order_items (
            order_id,
            product_id,
            seller_profile_id,
            seller_type,
            farm_location_id,
            product_name,
            quantity,
            unit,
            unit_price,
            subtotal
        ) VALUES (
            v_order_id,
            v_prod.id,
            v_prod.seller_profile_id,
            v_prod.seller_type,
            v_prod.farm_location_id,
            v_prod.name,
            v_item_qty,
            v_prod.unit,
            v_prod.price,
            v_item_subtotal
        );

        -- Record inventory audit transaction
        INSERT INTO public.inventory_transactions (
            product_id,
            order_id,
            type,
            quantity,
            note,
            created_by
        ) VALUES (
            v_prod.id,
            v_order_id,
            'reserve',
            v_item_qty,
            'Order ' || v_order_number || ' reservation',
            p_buyer_id
        );
    END LOOP;

    -- 5. Create Multi-Supplier Fulfillments grouped by seller
    FOR v_seller_rec IN 
        SELECT DISTINCT seller_profile_id, seller_type, farm_location_id 
        FROM public.order_items 
        WHERE order_id = v_order_id
    LOOP
        INSERT INTO public.order_fulfillments (
            order_id,
            seller_profile_id,
            seller_type,
            farm_location_id,
            status,
            delivery_location
        ) VALUES (
            v_order_id,
            v_seller_rec.seller_profile_id,
            v_seller_rec.seller_type,
            v_seller_rec.farm_location_id,
            'Pending',
            p_delivery_address
        );

        -- Send in-app notification to the seller
        INSERT INTO public.notifications (
            recipient_profile_id,
            order_id,
            type,
            title,
            message
        ) VALUES (
            v_seller_rec.seller_profile_id,
            v_order_id,
            'order_placed',
            'New Order Received: ' || v_order_number,
            'A new produce order has been placed. Please confirm availability.'
        );
    END LOOP;

    -- 6. Initial Timeline Entry
    INSERT INTO public.order_timeline (
        order_id,
        status,
        changed_by,
        note
    ) VALUES (
        v_order_id,
        'Pending',
        p_buyer_id,
        'Order placed and produce reserved.'
    );

    -- 7. Send notification to buyer
    INSERT INTO public.notifications (
        recipient_profile_id,
        order_id,
        type,
        title,
        message
    ) VALUES (
        p_buyer_id,
        v_order_id,
        'order_placed',
        'Order Placed: ' || v_order_number,
        'Your harvest order has been received and sent to local producers for fulfillment.'
    );

    -- Return JSON payload of the created order
    SELECT json_build_object(
        'id', v_order_id,
        'order_number', v_order_number,
        'subtotal', v_subtotal,
        'delivery_fee', v_delivery_fee,
        'total', v_total,
        'status', 'Pending'
    )::JSONB INTO v_res;

    RETURN v_res;
END;
$$;


-- Function 2: Sequential Order Status Transition Enforcement
CREATE OR REPLACE FUNCTION public.update_order_status(
    p_order_id UUID,
    p_new_status TEXT,
    p_user_id UUID,
    p_note TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_order RECORD;
    v_current_status TEXT;
    v_item RECORD;
BEGIN
    SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Order % not found.', p_order_id;
    END IF;

    v_current_status := v_order.status;

    -- Strict Sequential Lifecycle Validation
    IF v_current_status = 'Pending' AND p_new_status NOT IN ('Confirmed', 'Cancelled') THEN
        RAISE EXCEPTION 'Invalid transition: Pending orders can only move to Confirmed or Cancelled.';
    ELSIF v_current_status = 'Confirmed' AND p_new_status NOT IN ('Preparing', 'Cancelled') THEN
        RAISE EXCEPTION 'Invalid transition: Confirmed orders can only move to Preparing or Cancelled.';
    ELSIF v_current_status = 'Preparing' AND p_new_status != 'Ready for Pickup' THEN
        RAISE EXCEPTION 'Invalid transition: Preparing orders can only move to Ready for Pickup.';
    ELSIF v_current_status = 'Ready for Pickup' AND p_new_status NOT IN ('Picked Up', 'In Transit') THEN
        RAISE EXCEPTION 'Invalid transition: Ready for Pickup orders can only move to Picked Up or In Transit.';
    ELSIF v_current_status = 'Picked Up' AND p_new_status != 'In Transit' THEN
        RAISE EXCEPTION 'Invalid transition: Picked Up orders can only move to In Transit.';
    ELSIF v_current_status = 'In Transit' AND p_new_status != 'Delivered' THEN
        RAISE EXCEPTION 'Invalid transition: In Transit orders can only move to Delivered.';
    ELSIF v_current_status IN ('Delivered', 'Cancelled') THEN
        RAISE EXCEPTION 'Order is already in terminal status (%) and cannot transition further.', v_current_status;
    END IF;

    -- If transitioning to Delivered: permanently deduct reserved inventory
    IF p_new_status = 'Delivered' THEN
        FOR v_item IN SELECT * FROM public.order_items WHERE order_id = p_order_id
        LOOP
            UPDATE public.products
            SET 
                reserved_quantity = GREATEST(0, reserved_quantity - v_item.quantity),
                updated_at = NOW()
            WHERE id = v_item.product_id;

            INSERT INTO public.inventory_transactions (
                product_id,
                order_id,
                type,
                quantity,
                note,
                created_by
            ) VALUES (
                v_item.product_id,
                p_order_id,
                'deduct',
                v_item.quantity,
                'Order fulfilled and delivered',
                p_user_id
            );
        END LOOP;
    END IF;

    -- Update Orders & Fulfillments
    UPDATE public.orders
    SET 
        status = p_new_status,
        updated_at = NOW()
    WHERE id = p_order_id;

    UPDATE public.order_fulfillments
    SET 
        status = p_new_status,
        updated_at = NOW()
    WHERE order_id = p_order_id;

    -- Append Timeline
    INSERT INTO public.order_timeline (
        order_id,
        status,
        changed_by,
        note
    ) VALUES (
        p_order_id,
        p_new_status,
        p_user_id,
        COALESCE(p_note, 'Status transitioned to ' || p_new_status)
    );

    -- Notify Buyer
    INSERT INTO public.notifications (
        recipient_profile_id,
        order_id,
        type,
        title,
        message
    ) VALUES (
        v_order.buyer_profile_id,
        p_order_id,
        'order_update',
        'Order ' || v_order.order_number || ' is now ' || p_new_status,
        'Your order status has been updated by the producer to ' || p_new_status || '.'
    );

    RETURN json_build_object(
        'success', true,
        'order_id', p_order_id,
        'status', p_new_status
    )::JSONB;
END;
$$;


-- Function 3: Atomic Order Cancellation with Reserved Inventory Restoral
CREATE OR REPLACE FUNCTION public.cancel_order_transaction(
    p_order_id UUID,
    p_user_id UUID,
    p_reason TEXT DEFAULT 'Cancelled before dispatch'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_order RECORD;
    v_item RECORD;
BEGIN
    SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Order % not found.', p_order_id;
    END IF;

    IF v_order.status NOT IN ('Pending', 'Confirmed') THEN
        RAISE EXCEPTION 'Cannot cancel order in "%" status. Only Pending or Confirmed orders can be cancelled.', v_order.status;
    END IF;

    -- Restore reserved inventory back to available stock
    FOR v_item IN SELECT * FROM public.order_items WHERE order_id = p_order_id
    LOOP
        UPDATE public.products
        SET 
            quantity_available = quantity_available + v_item.quantity,
            reserved_quantity = GREATEST(0, reserved_quantity - v_item.quantity),
            updated_at = NOW()
        WHERE id = v_item.product_id;

        INSERT INTO public.inventory_transactions (
            product_id,
            order_id,
            type,
            quantity,
            note,
            created_by
        ) VALUES (
            v_item.product_id,
            p_order_id,
            'release',
            v_item.quantity,
            'Order cancelled: ' || p_reason,
            p_user_id
        );
    END LOOP;

    -- Update order status
    UPDATE public.orders
    SET 
        status = 'Cancelled',
        cancellation_reason = p_reason,
        updated_at = NOW()
    WHERE id = p_order_id;

    UPDATE public.order_fulfillments
    SET 
        status = 'Cancelled',
        updated_at = NOW()
    WHERE order_id = p_order_id;

    -- Append to timeline
    INSERT INTO public.order_timeline (
        order_id,
        status,
        changed_by,
        note
    ) VALUES (
        p_order_id,
        'Cancelled',
        p_user_id,
        'Order cancelled: ' || p_reason
    );

    RETURN json_build_object(
        'success', true,
        'order_id', p_order_id,
        'status', 'Cancelled'
    )::JSONB;
END;
$$;
