-- =========================================================================
-- Migration 015: Smart Supply-Chain Intelligence & Multi-Actor Optimization
-- =========================================================================

-- 1. Smart Matches Table (Farmer-Buyer Compatibility)
CREATE TABLE IF NOT EXISTS public.smart_matches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID REFERENCES public.products(id) ON DELETE CASCADE,
    buyer_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    seller_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    match_score INT NOT NULL CHECK (match_score >= 0 AND match_score <= 100),
    quantity_score INT CHECK (quantity_score >= 0 AND quantity_score <= 100),
    distance_score INT CHECK (distance_score >= 0 AND distance_score <= 100),
    quality_score INT CHECK (quality_score >= 0 AND quality_score <= 100),
    price_score INT CHECK (price_score >= 0 AND price_score <= 100),
    freshness_score INT CHECK (freshness_score >= 0 AND freshness_score <= 100),
    demand_score INT CHECK (demand_score >= 0 AND demand_score <= 100),
    explanation_factors JSONB NOT NULL DEFAULT '[]'::jsonb,
    status VARCHAR(50) NOT NULL DEFAULT 'ACTIVE' CHECK (
        status IN ('ACTIVE', 'CONTACTED', 'DISMISSED', 'EXPIRED')
    ),
    generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Supply-Demand Regional Insights Table
CREATE TABLE IF NOT EXISTS public.supply_demand_insights (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
    crop_name VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    district VARCHAR(100) NOT NULL,
    city VARCHAR(100),
    forecast_demand NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (forecast_demand >= 0),
    available_supply NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (available_supply >= 0),
    potential_gap NUMERIC(12,2) NOT NULL DEFAULT 0,
    status VARCHAR(50) NOT NULL CHECK (
        status IN ('Potential Shortage', 'Balanced', 'Potential Surplus', 'Insufficient Data')
    ),
    confidence_score INT CHECK (confidence_score >= 0 AND confidence_score <= 100),
    explanation_factors JSONB NOT NULL DEFAULT '[]'::jsonb,
    generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Bulk Buyer Procurement Recommendations Table
CREATE TABLE IF NOT EXISTS public.procurement_recommendations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    buyer_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    crop_name VARCHAR(100) NOT NULL,
    required_quantity NUMERIC(12,2) NOT NULL CHECK (required_quantity > 0),
    recommended_quantity NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (recommended_quantity >= 0),
    supplier_count INT NOT NULL DEFAULT 0 CHECK (supplier_count >= 0),
    recommended_sources JSONB NOT NULL DEFAULT '[]'::jsonb,
    estimated_distance NUMERIC(8,2) NOT NULL DEFAULT 0 CHECK (estimated_distance >= 0),
    estimated_cost NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (estimated_cost >= 0),
    match_score INT NOT NULL CHECK (match_score >= 0 AND match_score <= 100),
    explanation TEXT,
    status VARCHAR(50) NOT NULL DEFAULT 'ACTIVE' CHECK (
        status IN ('ACTIVE', 'ORDERED', 'DISMISSED')
    ),
    generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. Opportunity Scores Table (Farmers & FPOs)
CREATE TABLE IF NOT EXISTS public.opportunity_scores (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    actor_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    actor_role VARCHAR(50) NOT NULL CHECK (
        actor_role IN ('farmer', 'fpo', 'bulk_buyer', 'consumer')
    ),
    product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
    crop_name VARCHAR(100) NOT NULL,
    score INT NOT NULL CHECK (score >= 0 AND score <= 100),
    score_factors JSONB NOT NULL DEFAULT '{}'::jsonb,
    recommendation TEXT,
    confidence_score INT CHECK (confidence_score >= 0 AND confidence_score <= 100),
    generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. Performance Indexes
CREATE INDEX IF NOT EXISTS idx_smart_matches_product_id ON public.smart_matches(product_id);
CREATE INDEX IF NOT EXISTS idx_smart_matches_buyer_id ON public.smart_matches(buyer_id);
CREATE INDEX IF NOT EXISTS idx_smart_matches_seller_id ON public.smart_matches(seller_id);
CREATE INDEX IF NOT EXISTS idx_smart_matches_score ON public.smart_matches(match_score DESC);

CREATE INDEX IF NOT EXISTS idx_supply_demand_crop ON public.supply_demand_insights(crop_name);
CREATE INDEX IF NOT EXISTS idx_supply_demand_region ON public.supply_demand_insights(state, district);
CREATE INDEX IF NOT EXISTS idx_supply_demand_status ON public.supply_demand_insights(status);

CREATE INDEX IF NOT EXISTS idx_procurement_buyer_id ON public.procurement_recommendations(buyer_id);
CREATE INDEX IF NOT EXISTS idx_procurement_crop ON public.procurement_recommendations(crop_name);

CREATE INDEX IF NOT EXISTS idx_opportunity_actor ON public.opportunity_scores(actor_id, actor_role);
CREATE INDEX IF NOT EXISTS idx_opportunity_crop ON public.opportunity_scores(crop_name);

-- Triggers for updated_at
DROP TRIGGER IF EXISTS trg_smart_matches_updated_at ON public.smart_matches;
CREATE TRIGGER trg_smart_matches_updated_at
    BEFORE UPDATE ON public.smart_matches
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

DROP TRIGGER IF EXISTS trg_supply_demand_insights_updated_at ON public.supply_demand_insights;
CREATE TRIGGER trg_supply_demand_insights_updated_at
    BEFORE UPDATE ON public.supply_demand_insights
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

DROP TRIGGER IF EXISTS trg_procurement_recommendations_updated_at ON public.procurement_recommendations;
CREATE TRIGGER trg_procurement_recommendations_updated_at
    BEFORE UPDATE ON public.procurement_recommendations
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

DROP TRIGGER IF EXISTS trg_opportunity_scores_updated_at ON public.opportunity_scores;
CREATE TRIGGER trg_opportunity_scores_updated_at
    BEFORE UPDATE ON public.opportunity_scores
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

-- 6. Row Level Security (RLS) Policies
ALTER TABLE public.smart_matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.supply_demand_insights ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.procurement_recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.opportunity_scores ENABLE ROW LEVEL SECURITY;

-- smart_matches RLS
CREATE POLICY "Users can view their own smart matches"
    ON public.smart_matches FOR SELECT
    USING (
        auth.uid() = buyer_id OR 
        auth.uid() = seller_id OR
        EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('admin', 'fpo'))
    );

CREATE POLICY "System/Admin can insert and update smart matches"
    ON public.smart_matches FOR ALL
    USING (
        EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('admin', 'fpo', 'farmer', 'bulk_buyer'))
    );

-- supply_demand_insights RLS (Aggregated regional data is readable by all authenticated & public)
CREATE POLICY "Public and authenticated can read supply demand insights"
    ON public.supply_demand_insights FOR SELECT
    USING (true);

CREATE POLICY "Authorized users can manage supply demand insights"
    ON public.supply_demand_insights FOR ALL
    USING (
        EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('admin', 'fpo', 'farmer'))
    );

-- procurement_recommendations RLS
CREATE POLICY "Buyers can view their own procurement recommendations"
    ON public.procurement_recommendations FOR SELECT
    USING (
        auth.uid() = buyer_id OR
        EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
    );

CREATE POLICY "Buyers and admins can manage procurement recommendations"
    ON public.procurement_recommendations FOR ALL
    USING (
        auth.uid() = buyer_id OR
        EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
    );

-- opportunity_scores RLS
CREATE POLICY "Actors can view their own opportunity scores"
    ON public.opportunity_scores FOR SELECT
    USING (
        auth.uid() = actor_id OR
        EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('admin', 'fpo'))
    );

CREATE POLICY "Actors can manage their own opportunity scores"
    ON public.opportunity_scores FOR ALL
    USING (
        auth.uid() = actor_id OR
        EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('admin', 'fpo'))
    );
