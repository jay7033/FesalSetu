-- Migration 016: Hybrid Live + Demo Data Architecture
-- Adds is_demo flag to key tables for safe demo-data management

-- 1. Add is_demo column to products
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS is_demo BOOLEAN DEFAULT false;

-- 2. Add is_demo column to orders
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS is_demo BOOLEAN DEFAULT false;

-- 3. Add is_demo column to profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_demo BOOLEAN DEFAULT false;

-- 4. Add is_demo column to farm_locations
ALTER TABLE public.farm_locations ADD COLUMN IF NOT EXISTS is_demo BOOLEAN DEFAULT false;

-- 5. Create index for efficient demo/live filtering
CREATE INDEX IF NOT EXISTS idx_products_is_demo ON public.products (is_demo);
CREATE INDEX IF NOT EXISTS idx_orders_is_demo ON public.orders (is_demo);
CREATE INDEX IF NOT EXISTS idx_profiles_is_demo ON public.profiles (is_demo);

-- 6. Protect demo records from deletion by non-owners
-- Demo products cannot be deleted by regular users
CREATE POLICY "Demo products are immutable for non-owners"
    ON public.products FOR DELETE
    USING (
        is_demo = false
        OR seller_profile_id = auth.uid()
    );

-- Demo farm locations cannot be deleted
CREATE POLICY "Demo farm locations are immutable"
    ON public.farm_locations FOR DELETE
    USING (
        is_demo = false
        OR owner_profile_id = auth.uid()
    );

-- 7. Update existing seed records to mark as demo
UPDATE public.profiles SET is_demo = true WHERE id IN (
    'e1111111-1111-4111-8111-111111111111',
    'e2222222-2222-4222-8222-222222222222',
    'e3333333-3333-4333-8333-333333333333',
    'e4444444-4444-4444-8444-444444444444'
);

UPDATE public.products SET is_demo = true WHERE id IN (
    '11111111-1111-1111-1111-111111111111',
    '22222222-2222-2222-2222-222222222222',
    '33333333-3333-3333-3333-333333333333',
    '44444444-4444-4444-4444-444444444444',
    '55555555-5555-5555-5555-555555555555'
);

UPDATE public.farm_locations SET is_demo = true WHERE id IN (
    'f1111111-1111-1111-1111-111111111111',
    'f2222222-2222-2222-2222-222222222222',
    'f3333333-3333-3333-3333-333333333333'
);

UPDATE public.orders SET is_demo = true WHERE id = '01111111-1111-1111-1111-111111111111';
