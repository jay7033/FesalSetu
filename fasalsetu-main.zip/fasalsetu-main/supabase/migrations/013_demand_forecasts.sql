-- =========================================================================
-- Migration 013: AI Demand Forecasts & Predictive Intelligence
-- =========================================================================

-- 1. Demand Forecasts Table
CREATE TABLE IF NOT EXISTS public.demand_forecasts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
    crop_name VARCHAR(100) NOT NULL,
    category VARCHAR(100),
    region_type VARCHAR(50) DEFAULT 'district',
    state VARCHAR(100) NOT NULL,
    district VARCHAR(100) NOT NULL,
    city VARCHAR(100),
    forecast_period_start DATE NOT NULL,
    forecast_period_end DATE NOT NULL,
    historical_demand NUMERIC(12,2) DEFAULT 0 CHECK (historical_demand >= 0),
    recent_demand NUMERIC(12,2) DEFAULT 0 CHECK (recent_demand >= 0),
    forecast_quantity NUMERIC(12,2) DEFAULT 0 CHECK (forecast_quantity >= 0),
    demand_growth_percent NUMERIC(6,2) DEFAULT 0,
    demand_classification VARCHAR(50) CHECK (
        demand_classification IN (
            'HIGH DEMAND',
            'RISING DEMAND',
            'STABLE',
            'DECLINING',
            'LOW DEMAND',
            'INSUFFICIENT DATA'
        )
    ),
    supply_status VARCHAR(50) CHECK (
        supply_status IN (
            'Potential Shortage',
            'Balanced',
            'Potential Surplus',
            'Insufficient Data'
        )
    ),
    confidence_score INT CHECK (confidence_score >= 0 AND confidence_score <= 100),
    confidence_factors JSONB DEFAULT '[]'::jsonb,
    recommendation TEXT,
    model_version VARCHAR(50) DEFAULT 'v1.0-statistical',
    generated_at TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Indexes for Optimized Aggregation and Lookup
CREATE INDEX IF NOT EXISTS idx_demand_forecasts_product_id ON public.demand_forecasts(product_id);
CREATE INDEX IF NOT EXISTS idx_demand_forecasts_crop ON public.demand_forecasts(crop_name);
CREATE INDEX IF NOT EXISTS idx_demand_forecasts_region ON public.demand_forecasts(state, district);
CREATE INDEX IF NOT EXISTS idx_demand_forecasts_classification ON public.demand_forecasts(demand_classification);
CREATE INDEX IF NOT EXISTS idx_demand_forecasts_generated_at ON public.demand_forecasts(generated_at DESC);

-- Auto-update updated_at timestamp trigger
DROP TRIGGER IF EXISTS trg_demand_forecasts_updated_at ON public.demand_forecasts;
CREATE TRIGGER trg_demand_forecasts_updated_at
    BEFORE UPDATE ON public.demand_forecasts
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

-- 3. Row Level Security (RLS)
ALTER TABLE public.demand_forecasts ENABLE ROW LEVEL SECURITY;

-- Public and authenticated users can view aggregated demand forecasts
CREATE POLICY "Public and authenticated can read aggregated forecasts"
    ON public.demand_forecasts FOR SELECT
    USING (true);

-- Producers can insert/update forecasts for their products
CREATE POLICY "Producers can manage forecasts for their products"
    ON public.demand_forecasts FOR ALL
    USING (
        product_id IS NULL OR product_id IN (
            SELECT id FROM public.products WHERE seller_profile_id = auth.uid()
        )
    )
    WITH CHECK (
        product_id IS NULL OR product_id IN (
            SELECT id FROM public.products WHERE seller_profile_id = auth.uid()
        )
    );
