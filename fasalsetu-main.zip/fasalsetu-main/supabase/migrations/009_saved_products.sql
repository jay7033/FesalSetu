-- Migration 009: Consumer Saved Products (Favorites)

CREATE TABLE IF NOT EXISTS public.saved_products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    consumer_profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(consumer_profile_id, product_id)
);

CREATE INDEX IF NOT EXISTS idx_saved_products_consumer ON public.saved_products(consumer_profile_id);
CREATE INDEX IF NOT EXISTS idx_saved_products_product ON public.saved_products(product_id);
