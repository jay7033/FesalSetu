-- Migration 002: Producer & Collective Entity Extensions (Farmer & FPO Profiles)

CREATE TABLE IF NOT EXISTS public.farmer_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID NOT NULL UNIQUE REFERENCES public.profiles(id) ON DELETE CASCADE,
    farmer_type TEXT NOT NULL DEFAULT 'Individual Farmer',
    farm_name TEXT,
    description TEXT,
    verification_status TEXT NOT NULL DEFAULT 'prototype_unverified' CHECK (verification_status IN ('verified', 'pending', 'prototype_unverified')),
    total_land_acres NUMERIC(6,2),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.fpo_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID NOT NULL UNIQUE REFERENCES public.profiles(id) ON DELETE CASCADE,
    fpo_name TEXT NOT NULL,
    registration_number TEXT,
    description TEXT,
    verification_status TEXT NOT NULL DEFAULT 'prototype_unverified' CHECK (verification_status IN ('verified', 'pending', 'prototype_unverified')),
    member_count INTEGER NOT NULL DEFAULT 1 CHECK (member_count >= 1),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Member association table connecting individual farmers to cooperative FPOs
CREATE TABLE IF NOT EXISTS public.fpo_members (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    fpo_profile_id UUID NOT NULL REFERENCES public.fpo_profiles(id) ON DELETE CASCADE,
    farmer_profile_id UUID REFERENCES public.farmer_profiles(id) ON DELETE SET NULL,
    farmer_name TEXT NOT NULL,
    village TEXT,
    district TEXT,
    crop_focus TEXT,
    land_acres NUMERIC(6,2),
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'pending', 'inactive')),
    joined_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_farmer_profiles_profile_id ON public.farmer_profiles(profile_id);
CREATE INDEX IF NOT EXISTS idx_fpo_profiles_profile_id ON public.fpo_profiles(profile_id);
CREATE INDEX IF NOT EXISTS idx_fpo_members_fpo_id ON public.fpo_members(fpo_profile_id);

CREATE TRIGGER set_farmer_profiles_updated_at
    BEFORE UPDATE ON public.farmer_profiles
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER set_fpo_profiles_updated_at
    BEFORE UPDATE ON public.fpo_profiles
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();
