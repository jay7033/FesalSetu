-- Migration 003: Buyer Entity Extensions (Consumer & Bulk Buyer Profiles)

CREATE TABLE IF NOT EXISTS public.consumer_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID NOT NULL UNIQUE REFERENCES public.profiles(id) ON DELETE CASCADE,
    society TEXT,
    delivery_instructions TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.bulk_buyer_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID NOT NULL UNIQUE REFERENCES public.profiles(id) ON DELETE CASCADE,
    business_name TEXT NOT NULL,
    business_type TEXT NOT NULL DEFAULT 'Retail Chain' CHECK (business_type IN ('Retail Chain', 'Society Aggregator', 'Wholesale Processor', 'Export House', 'Other')),
    gst_number TEXT,
    description TEXT,
    verification_status TEXT NOT NULL DEFAULT 'prototype_unverified' CHECK (verification_status IN ('verified', 'pending', 'prototype_unverified')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_consumer_profiles_profile_id ON public.consumer_profiles(profile_id);
CREATE INDEX IF NOT EXISTS idx_bulk_buyer_profiles_profile_id ON public.bulk_buyer_profiles(profile_id);

CREATE TRIGGER set_consumer_profiles_updated_at
    BEFORE UPDATE ON public.consumer_profiles
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER set_bulk_buyer_profiles_updated_at
    BEFORE UPDATE ON public.bulk_buyer_profiles
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();
