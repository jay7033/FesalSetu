-- Migration 010: Row Level Security (RLS) Policies
-- Enforces strict database-level authorization for multi-tenant privacy

-- Enable RLS across all core tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.farmer_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fpo_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fpo_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.consumer_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bulk_buyer_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.farm_locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.buyer_locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_fulfillments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_timeline ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saved_products ENABLE ROW LEVEL SECURITY;

-- =========================================================================
-- 1. PROFILES RLS
-- =========================================================================
CREATE POLICY "Users can read own profile"
    ON public.profiles FOR SELECT
    USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
    ON public.profiles FOR UPDATE
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);

-- Allow reading public producer names for marketplace display
CREATE POLICY "Public can read producer profile names"
    ON public.profiles FOR SELECT
    USING (role IN ('farmer', 'fpo'));

-- =========================================================================
-- 2. FARMER & FPO PROFILES RLS
-- =========================================================================
CREATE POLICY "Farmers can read own profile"
    ON public.farmer_profiles FOR SELECT
    USING (profile_id = auth.uid());

CREATE POLICY "Farmers can update own profile"
    ON public.farmer_profiles FOR UPDATE
    USING (profile_id = auth.uid())
    WITH CHECK (profile_id = auth.uid());

CREATE POLICY "Public can read verified farm info"
    ON public.farmer_profiles FOR SELECT
    USING (true);

CREATE POLICY "FPO can read own profile"
    ON public.fpo_profiles FOR SELECT
    USING (profile_id = auth.uid());

CREATE POLICY "FPO can update own profile"
    ON public.fpo_profiles FOR UPDATE
    USING (profile_id = auth.uid())
    WITH CHECK (profile_id = auth.uid());

CREATE POLICY "Public can read basic FPO info"
    ON public.fpo_profiles FOR SELECT
    USING (true);

-- FPO Members RLS
CREATE POLICY "FPO can manage its own members"
    ON public.fpo_members FOR ALL
    USING (
        fpo_profile_id IN (
            SELECT id FROM public.fpo_profiles WHERE profile_id = auth.uid()
        )
    );

-- =========================================================================
-- 3. BUYER PROFILES RLS
-- =========================================================================
CREATE POLICY "Consumers can view and edit own profile"
    ON public.consumer_profiles FOR ALL
    USING (profile_id = auth.uid())
    WITH CHECK (profile_id = auth.uid());

CREATE POLICY "Bulk buyers can view and edit own profile"
    ON public.bulk_buyer_profiles FOR ALL
    USING (profile_id = auth.uid())
    WITH CHECK (profile_id = auth.uid());

-- =========================================================================
-- 4. LOCATIONS RLS
-- =========================================================================
CREATE POLICY "Owners can manage own farm locations"
    ON public.farm_locations FOR ALL
    USING (owner_profile_id = auth.uid())
    WITH CHECK (owner_profile_id = auth.uid());

-- Public can read farm locations only through the public_farm_locations view (no raw GPS)
CREATE POLICY "Buyers can view farm locations involved in their active orders"
    ON public.farm_locations FOR SELECT
    USING (
        id IN (
            SELECT farm_location_id FROM public.order_items oi
            JOIN public.orders o ON oi.order_id = o.id
            WHERE o.buyer_profile_id = auth.uid()
        )
    );

CREATE POLICY "Buyers can manage own buyer locations"
    ON public.buyer_locations FOR ALL
    USING (profile_id = auth.uid())
    WITH CHECK (profile_id = auth.uid());

-- =========================================================================
-- 5. PRODUCTS RLS
-- =========================================================================
CREATE POLICY "Anyone can view active products"
    ON public.products FOR SELECT
    USING (is_active = true OR seller_profile_id = auth.uid());

CREATE POLICY "Sellers can manage own products"
    ON public.products FOR ALL
    USING (seller_profile_id = auth.uid())
    WITH CHECK (seller_profile_id = auth.uid());

-- =========================================================================
-- 6. ORDERS & FULFILLMENT RLS
-- =========================================================================
CREATE POLICY "Buyers can view own orders"
    ON public.orders FOR SELECT
    USING (buyer_profile_id = auth.uid());

CREATE POLICY "Buyers can insert own orders"
    ON public.orders FOR INSERT
    WITH CHECK (buyer_profile_id = auth.uid());

CREATE POLICY "Buyers can update own orders for cancellation"
    ON public.orders FOR UPDATE
    USING (buyer_profile_id = auth.uid())
    WITH CHECK (buyer_profile_id = auth.uid());

-- Order items access
CREATE POLICY "Buyers can view items of own orders"
    ON public.order_items FOR SELECT
    USING (
        order_id IN (
            SELECT id FROM public.orders WHERE buyer_profile_id = auth.uid()
        )
    );

CREATE POLICY "Sellers can view items assigned to them"
    ON public.order_items FOR SELECT
    USING (seller_profile_id = auth.uid());

-- Fulfillments access
CREATE POLICY "Buyers can view fulfillments for their orders"
    ON public.order_fulfillments FOR SELECT
    USING (
        order_id IN (
            SELECT id FROM public.orders WHERE buyer_profile_id = auth.uid()
        )
    );

CREATE POLICY "Sellers can view and update own fulfillments"
    ON public.order_fulfillments FOR ALL
    USING (seller_profile_id = auth.uid())
    WITH CHECK (seller_profile_id = auth.uid());

-- Order timeline access
CREATE POLICY "Order participants can view timeline"
    ON public.order_timeline FOR SELECT
    USING (
        order_id IN (
            SELECT id FROM public.orders WHERE buyer_profile_id = auth.uid()
            UNION
            SELECT order_id FROM public.order_fulfillments WHERE seller_profile_id = auth.uid()
        )
    );

-- =========================================================================
-- 7. INVENTORY TRANSACTIONS RLS
-- =========================================================================
CREATE POLICY "Sellers can view inventory logs for their products"
    ON public.inventory_transactions FOR SELECT
    USING (
        product_id IN (
            SELECT id FROM public.products WHERE seller_profile_id = auth.uid()
        )
    );

-- =========================================================================
-- 8. NOTIFICATIONS RLS
-- =========================================================================
CREATE POLICY "Users can manage own notifications"
    ON public.notifications FOR ALL
    USING (recipient_profile_id = auth.uid())
    WITH CHECK (recipient_profile_id = auth.uid());

-- =========================================================================
-- 9. SAVED PRODUCTS RLS
-- =========================================================================
CREATE POLICY "Consumers can manage own saved products"
    ON public.saved_products FOR ALL
    USING (consumer_profile_id = auth.uid())
    WITH CHECK (consumer_profile_id = auth.uid());
