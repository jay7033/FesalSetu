-- Migration 012: Supabase Storage Buckets & Policies

-- Create storage buckets if they do not exist
INSERT INTO storage.buckets (id, name, public)
VALUES 
    ('product-images', 'product-images', true),
    ('avatars', 'avatars', true)
ON CONFLICT (id) DO UPDATE SET public = true;

-- Product images policy: Anyone can read, authenticated users can upload
CREATE POLICY "Public Read Product Images"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'product-images');

CREATE POLICY "Authenticated Sellers Upload Product Images"
    ON storage.objects FOR INSERT
    WITH CHECK (
        bucket_id = 'product-images' AND 
        auth.role() = 'authenticated'
    );

CREATE POLICY "Sellers Delete Own Product Images"
    ON storage.objects FOR DELETE
    USING (
        bucket_id = 'product-images' AND 
        auth.uid()::text = (storage.foldername(name))[1]
    );

-- Avatars policies
CREATE POLICY "Public Read Avatars"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'avatars');

CREATE POLICY "Users Manage Own Avatar"
    ON storage.objects FOR ALL
    USING (
        bucket_id = 'avatars' AND 
        auth.uid()::text = (storage.foldername(name))[1]
    );
