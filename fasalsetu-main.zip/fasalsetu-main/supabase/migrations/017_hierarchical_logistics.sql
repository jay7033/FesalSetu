-- =========================================================================
-- Migration 017: Hierarchical Regional Logistics Architecture
-- Regional Head -> Zone Coordinators/Assigners -> Delivery Boys -> Tasks
-- =========================================================================

-- 1. Regions Table
CREATE TABLE IF NOT EXISTS public.regions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(50) UNIQUE NOT NULL, -- e.g. 'NORTH', 'WEST', 'CENTRAL', 'EAST', 'SOUTH', 'NORTHEAST'
    name VARCHAR(100) NOT NULL,
    states TEXT[] NOT NULL DEFAULT '{}',
    corridor_name VARCHAR(255),
    head_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    boundary JSONB DEFAULT '{}'::jsonb,
    status VARCHAR(50) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'PENDING', 'INACTIVE')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Logistics Zones Table (Sub-divisions within a Region)
CREATE TABLE IF NOT EXISTS public.logistics_zones (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    region_id UUID NOT NULL REFERENCES public.regions(id) ON DELETE CASCADE,
    code VARCHAR(50) NOT NULL, -- e.g. 'ZONE_A', 'ZONE_B'
    name VARCHAR(150) NOT NULL, -- e.g. 'Zone A - Greater Noida West'
    center_lat NUMERIC(10, 7) NOT NULL,
    center_lng NUMERIC(10, 7) NOT NULL,
    radius_km NUMERIC(6, 2) NOT NULL DEFAULT 15.0,
    boundary JSONB DEFAULT '{}'::jsonb,
    assigner_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    target_team_size INT DEFAULT 15,
    max_active_deliveries INT DEFAULT 50,
    status VARCHAR(50) NOT NULL DEFAULT 'BALANCED' CHECK (
        status IN ('BALANCED', 'HIGH_WORKLOAD', 'OVERLOADED', 'INACTIVE')
    ),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (region_id, code)
);

-- 3. Logistics Members Table (Assigners and Delivery Boys)
CREATE TABLE IF NOT EXISTS public.logistics_members (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    region_id UUID NOT NULL REFERENCES public.regions(id) ON DELETE CASCADE,
    zone_id UUID REFERENCES public.logistics_zones(id) ON DELETE SET NULL,
    full_name VARCHAR(150) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(255),
    role VARCHAR(50) NOT NULL CHECK (
        role IN ('logistics_head', 'delivery_assigner', 'delivery_boy')
    ),
    vehicle_type VARCHAR(50) DEFAULT 'MOTORCYCLE' CHECK (
        vehicle_type IN ('BICYCLE', 'EV_SCOOTER', 'MOTORCYCLE', 'THREE_WHEELER', 'SMALL_TRUCK')
    ),
    vehicle_number VARCHAR(50),
    vehicle_capacity_kg NUMERIC(8, 2) DEFAULT 40.0,
    status VARCHAR(50) NOT NULL DEFAULT 'AVAILABLE' CHECK (
        status IN ('AVAILABLE', 'ON_DELIVERY', 'BREAK', 'OFFLINE', 'SUSPENDED')
    ),
    current_lat NUMERIC(10, 7),
    current_lng NUMERIC(10, 7),
    active_tasks_count INT NOT NULL DEFAULT 0 CHECK (active_tasks_count >= 0),
    completed_today INT NOT NULL DEFAULT 0 CHECK (completed_today >= 0),
    rating NUMERIC(3, 2) DEFAULT 4.85,
    last_active_at TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Delivery Tasks Table
CREATE TABLE IF NOT EXISTS public.delivery_tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE,
    fulfillment_id UUID REFERENCES public.order_fulfillments(id) ON DELETE SET NULL,
    region_id UUID NOT NULL REFERENCES public.regions(id) ON DELETE CASCADE,
    zone_id UUID NOT NULL REFERENCES public.logistics_zones(id) ON DELETE CASCADE,
    delivery_boy_id UUID REFERENCES public.logistics_members(id) ON DELETE SET NULL,
    assigned_by_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    assignment_source VARCHAR(20) NOT NULL DEFAULT 'automatic' CHECK (
        assignment_source IN ('automatic', 'manual', 'fallback')
    ),
    assignment_score NUMERIC(5, 2),
    assignment_reason TEXT,
    priority VARCHAR(20) NOT NULL DEFAULT 'NORMAL' CHECK (
        priority IN ('NORMAL', 'HIGH', 'EXPRESS')
    ),
    status VARCHAR(50) NOT NULL DEFAULT 'UNASSIGNED' CHECK (
        status IN (
            'UNASSIGNED',
            'ASSIGNED',
            'PICKUP_PENDING',
            'PICKED_UP',
            'IN_TRANSIT',
            'OUT_FOR_DELIVERY',
            'DELIVERED',
            'DELAYED',
            'FAILED',
            'CANCELLED'
        )
    ),
    pickup_location JSONB NOT NULL DEFAULT '{}'::jsonb,
    delivery_location JSONB NOT NULL DEFAULT '{}'::jsonb,
    distance_km NUMERIC(6, 2) DEFAULT 0 CHECK (distance_km >= 0),
    estimated_pickup_time TIMESTAMPTZ,
    actual_pickup_time TIMESTAMPTZ,
    estimated_delivery_time TIMESTAMPTZ,
    actual_delivery_time TIMESTAMPTZ,
    exception_reason TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Indexes
CREATE INDEX IF NOT EXISTS idx_logistics_zones_region ON public.logistics_zones(region_id);
CREATE INDEX IF NOT EXISTS idx_logistics_members_region ON public.logistics_members(region_id);
CREATE INDEX IF NOT EXISTS idx_logistics_members_zone ON public.logistics_members(zone_id);
CREATE INDEX IF NOT EXISTS idx_logistics_members_role ON public.logistics_members(role);
CREATE INDEX IF NOT EXISTS idx_logistics_members_status ON public.logistics_members(status);
CREATE INDEX IF NOT EXISTS idx_delivery_tasks_region ON public.delivery_tasks(region_id);
CREATE INDEX IF NOT EXISTS idx_delivery_tasks_zone ON public.delivery_tasks(zone_id);
CREATE INDEX IF NOT EXISTS idx_delivery_tasks_boy ON public.delivery_tasks(delivery_boy_id);
CREATE INDEX IF NOT EXISTS idx_delivery_tasks_status ON public.delivery_tasks(status);

-- 6. Row-Level Security (RLS)
ALTER TABLE public.regions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.logistics_zones ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.logistics_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.delivery_tasks ENABLE ROW LEVEL SECURITY;

-- Regions RLS: Anyone can view high-level regions
CREATE POLICY "Public can view regions"
    ON public.regions FOR SELECT
    USING (true);

-- Logistics Zones RLS: Public can view zones, managers can update
CREATE POLICY "Public can view logistics zones"
    ON public.logistics_zones FOR SELECT
    USING (true);

CREATE POLICY "Logistics Heads can manage zones"
    ON public.logistics_zones FOR ALL
    USING (
        EXISTS (
            SELECT 1 FROM public.profiles
            WHERE id = auth.uid() AND role = 'logistics_head'
        )
    );

-- Logistics Members RLS:
CREATE POLICY "Heads can view all members in region"
    ON public.logistics_members FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.profiles
            WHERE id = auth.uid() AND role = 'logistics_head'
        )
        OR (user_id = auth.uid())
        OR EXISTS (
            SELECT 1 FROM public.logistics_members lm
            WHERE lm.user_id = auth.uid() 
              AND lm.role = 'delivery_assigner'
              AND lm.zone_id = public.logistics_members.zone_id
        )
    );

-- Delivery Tasks RLS:
CREATE POLICY "Heads and Assigners can view zone tasks, Delivery Boys view own"
    ON public.delivery_tasks FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.profiles
            WHERE id = auth.uid() AND role = 'logistics_head'
        )
        OR EXISTS (
            SELECT 1 FROM public.logistics_members lm
            WHERE lm.user_id = auth.uid() 
              AND lm.role = 'delivery_assigner'
              AND lm.zone_id = public.delivery_tasks.zone_id
        )
        OR EXISTS (
            SELECT 1 FROM public.logistics_members lm
            WHERE lm.id = public.delivery_tasks.delivery_boy_id
              AND lm.user_id = auth.uid()
        )
    );

CREATE POLICY "Delivery Boys can update own tasks"
    ON public.delivery_tasks FOR UPDATE
    USING (
        EXISTS (
            SELECT 1 FROM public.logistics_members lm
            WHERE lm.id = public.delivery_tasks.delivery_boy_id
              AND lm.user_id = auth.uid()
        )
        OR EXISTS (
            SELECT 1 FROM public.profiles
            WHERE id = auth.uid() AND role IN ('logistics_head', 'delivery_assigner')
        )
    );
