-- Migration 006: Order Processing, Line Items, Multi-Supplier Fulfillments, and Audit Timeline

CREATE SEQUENCE IF NOT EXISTS public.order_number_seq START WITH 1001;

CREATE OR REPLACE FUNCTION public.generate_order_number()
RETURNS TEXT AS $$
DECLARE
    next_val BIGINT;
    year_prefix TEXT;
BEGIN
    next_val := nextval('public.order_number_seq');
    year_prefix := TO_CHAR(CURRENT_DATE, 'YYYY');
    RETURN 'FS-' || year_prefix || '-' || LPAD(next_val::TEXT, 6, '0');
END;
$$ LANGUAGE plpgsql;

-- Primary Commercial Order Table
CREATE TABLE IF NOT EXISTS public.orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_number TEXT NOT NULL UNIQUE DEFAULT generate_order_number(),
    buyer_profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
    buyer_role TEXT NOT NULL CHECK (buyer_role IN ('consumer', 'bulk_buyer')),

    subtotal NUMERIC(12, 2) NOT NULL CHECK (subtotal >= 0),
    delivery_fee NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (delivery_fee >= 0),
    savings NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (savings >= 0),
    total NUMERIC(12, 2) NOT NULL CHECK (total >= 0),

    delivery_type TEXT NOT NULL DEFAULT 'delivery' CHECK (delivery_type IN ('delivery', 'pickup')),
    payment_method TEXT NOT NULL DEFAULT 'cod' CHECK (payment_method IN ('cod', 'demo_online', 'bank_wire')),
    payment_status TEXT NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'secured_escrow', 'paid', 'refunded')),

    status TEXT NOT NULL DEFAULT 'Pending' CHECK (
        status IN (
            'Pending',
            'Confirmed',
            'Preparing',
            'Ready for Pickup',
            'Picked Up',
            'In Transit',
            'Delivered',
            'Cancelled'
        )
    ),

    buyer_location_id UUID REFERENCES public.buyer_locations(id) ON DELETE SET NULL,
    delivery_address TEXT,
    delivery_estimate TEXT,
    cancellation_reason TEXT,

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Transactional Order Items with captured price snapshot
CREATE TABLE IF NOT EXISTS public.order_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,

    seller_profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
    seller_type TEXT NOT NULL CHECK (seller_type IN ('farmer', 'fpo')),
    farm_location_id UUID REFERENCES public.farm_locations(id) ON DELETE SET NULL,

    product_name TEXT NOT NULL,
    quantity NUMERIC(12, 2) NOT NULL CHECK (quantity > 0),
    unit TEXT NOT NULL DEFAULT 'kg',
    unit_price NUMERIC(10, 2) NOT NULL CHECK (unit_price >= 0),
    subtotal NUMERIC(12, 2) NOT NULL CHECK (subtotal >= 0),

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Multi-Supplier Fulfillment Sub-Dispatches per order
CREATE TABLE IF NOT EXISTS public.order_fulfillments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    seller_profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
    seller_type TEXT NOT NULL CHECK (seller_type IN ('farmer', 'fpo')),
    farm_location_id UUID REFERENCES public.farm_locations(id) ON DELETE SET NULL,

    status TEXT NOT NULL DEFAULT 'Pending' CHECK (
        status IN (
            'Pending',
            'Confirmed',
            'Preparing',
            'Ready for Pickup',
            'Picked Up',
            'In Transit',
            'Delivered',
            'Cancelled'
        )
    ),

    pickup_location TEXT,
    delivery_location TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Immutable Order Audit Timeline Log
CREATE TABLE IF NOT EXISTS public.order_timeline (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    status TEXT NOT NULL,
    changed_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_orders_buyer ON public.orders(buyer_profile_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON public.order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_product ON public.order_items(product_id);
CREATE INDEX IF NOT EXISTS idx_order_fulfillments_order ON public.order_fulfillments(order_id);
CREATE INDEX IF NOT EXISTS idx_order_fulfillments_seller ON public.order_fulfillments(seller_profile_id);
CREATE INDEX IF NOT EXISTS idx_order_timeline_order ON public.order_timeline(order_id);

CREATE TRIGGER set_orders_updated_at
    BEFORE UPDATE ON public.orders
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER set_order_fulfillments_updated_at
    BEFORE UPDATE ON public.order_fulfillments
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();
