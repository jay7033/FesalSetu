-- Migration 004: Farm & Buyer Geographical Infrastructure with Privacy Protection

-- Farm Locations for Farmers and FPOs
CREATE TABLE IF NOT EXISTS public.farm_locations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    owner_type TEXT NOT NULL CHECK (owner_type IN ('farmer', 'fpo')),
    farm_title TEXT NOT NULL DEFAULT 'Primary Farm Plot',
    latitude NUMERIC(10, 7) NOT NULL,
    longitude NUMERIC(10, 7) NOT NULL,
    accuracy NUMERIC(8, 2),
    village TEXT,
    locality TEXT,
    city TEXT,
    district TEXT NOT NULL,
    state TEXT NOT NULL,
    state_code TEXT,
    pincode TEXT,
    country TEXT NOT NULL DEFAULT 'India',
    country_code TEXT NOT NULL DEFAULT 'IN',
    formatted_address TEXT NOT NULL,
    source TEXT NOT NULL DEFAULT 'gps' CHECK (source IN ('gps', 'manual', 'demo')),
    is_default BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Buyer Delivery & Sourcing Locations
CREATE TABLE IF NOT EXISTS public.buyer_locations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    location_type TEXT NOT NULL CHECK (location_type IN ('delivery', 'sourcing')),
    label TEXT NOT NULL DEFAULT 'Primary Address',
    latitude NUMERIC(10, 7),
    longitude NUMERIC(10, 7),
    accuracy NUMERIC(8, 2),
    village TEXT,
    locality TEXT,
    city TEXT,
    district TEXT,
    state TEXT NOT NULL,
    state_code TEXT,
    pincode TEXT,
    country TEXT NOT NULL DEFAULT 'India',
    formatted_address TEXT NOT NULL,
    is_default BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_farm_locations_owner ON public.farm_locations(owner_profile_id);
CREATE INDEX IF NOT EXISTS idx_farm_locations_state ON public.farm_locations(state);
CREATE INDEX IF NOT EXISTS idx_buyer_locations_profile ON public.buyer_locations(profile_id);

CREATE TRIGGER set_farm_locations_updated_at
    BEFORE UPDATE ON public.farm_locations
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER set_buyer_locations_updated_at
    BEFORE UPDATE ON public.buyer_locations
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

-- Privacy-Preserving View for Public Marketplace
-- Masks exact latitude, longitude, and accuracy from public marketplace queries
CREATE OR REPLACE VIEW public.public_farm_locations AS
SELECT 
    id,
    owner_profile_id,
    owner_type,
    farm_title,
    city,
    district,
    state,
    state_code,
    country,
    -- Construct friendly approximate regional label (e.g., "Near Dankaur, Gautam Buddha Nagar, Uttar Pradesh")
    CASE 
        WHEN locality IS NOT NULL AND district IS NOT NULL THEN 'Near ' || locality || ', ' || district || ', ' || state
        WHEN city IS NOT NULL THEN city || ', ' || state
        ELSE district || ', ' || state
    END AS approximate_location,
    is_default,
    created_at
FROM public.farm_locations;
