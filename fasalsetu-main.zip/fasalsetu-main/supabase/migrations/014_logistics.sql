-- =========================================================================
-- Migration 014: Hyperlocal Logistics, Fleet Pooling & Route Optimization
-- =========================================================================

-- 1. Logistics Routes Table
CREATE TABLE IF NOT EXISTS public.logistics_routes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    route_number VARCHAR(50) UNIQUE NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'PLANNED' CHECK (
        status IN ('PLANNED', 'ASSIGNED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED')
    ),
    vehicle_type VARCHAR(50) NOT NULL,
    vehicle_capacity NUMERIC(10,2) NOT NULL CHECK (vehicle_capacity > 0),
    total_load NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (total_load >= 0),
    total_distance_km NUMERIC(8,2) DEFAULT 0 CHECK (total_distance_km >= 0),
    estimated_duration_minutes INT DEFAULT 0 CHECK (estimated_duration_minutes >= 0),
    estimated_cost NUMERIC(10,2) DEFAULT 0 CHECK (estimated_cost >= 0),
    start_location JSONB NOT NULL DEFAULT '{"name": "Yamuna Aggregation Hub", "city": "Greater Noida", "state": "Uttar Pradesh"}'::jsonb,
    end_location JSONB NOT NULL DEFAULT '{"name": "Noida Distribution Center", "city": "Noida", "state": "Uttar Pradesh"}'::jsonb,
    optimization_method VARCHAR(50) DEFAULT 'nearest_neighbor_2opt',
    created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Logistics Route Stops Table
CREATE TABLE IF NOT EXISTS public.logistics_route_stops (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    route_id UUID NOT NULL REFERENCES public.logistics_routes(id) ON DELETE CASCADE,
    sequence_number INT NOT NULL,
    stop_type VARCHAR(20) NOT NULL CHECK (stop_type IN ('PICKUP', 'HUB', 'DELIVERY')),
    order_id UUID REFERENCES public.orders(id) ON DELETE SET NULL,
    fulfillment_id UUID REFERENCES public.order_fulfillments(id) ON DELETE SET NULL,
    location_reference VARCHAR(255),
    approximate_address VARCHAR(255) NOT NULL,
    latitude NUMERIC(10,7),
    longitude NUMERIC(10,7),
    estimated_arrival TIMESTAMPTZ,
    actual_arrival TIMESTAMPTZ,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (
        status IN ('PENDING', 'ARRIVED', 'COMPLETED', 'SKIPPED')
    ),
    load_quantity NUMERIC(10,2) DEFAULT 0 CHECK (load_quantity >= 0),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Shipments Tracking Table
CREATE TABLE IF NOT EXISTS public.shipments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    fulfillment_id UUID REFERENCES public.order_fulfillments(id) ON DELETE CASCADE,
    route_id UUID REFERENCES public.logistics_routes(id) ON DELETE SET NULL,
    tracking_number VARCHAR(50) UNIQUE NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'CREATED' CHECK (
        status IN (
            'CREATED',
            'PICKUP_SCHEDULED',
            'PICKED_UP',
            'IN_TRANSIT',
            'OUT_FOR_DELIVERY',
            'DELIVERED',
            'CANCELLED'
        )
    ),
    pickup_time TIMESTAMPTZ,
    estimated_delivery_time TIMESTAMPTZ,
    actual_delivery_time TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Pickup Schedules Table
CREATE TABLE IF NOT EXISTS public.pickup_schedules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    fulfillment_id UUID NOT NULL REFERENCES public.order_fulfillments(id) ON DELETE CASCADE,
    farm_location_id UUID REFERENCES public.farm_locations(id) ON DELETE SET NULL,
    scheduled_date DATE NOT NULL,
    time_window_start TIME NOT NULL,
    time_window_end TIME NOT NULL,
    quantity NUMERIC(10,2) NOT NULL CHECK (quantity > 0),
    status VARCHAR(20) NOT NULL DEFAULT 'SCHEDULED' CHECK (
        status IN ('PENDING', 'SCHEDULED', 'READY', 'PICKED_UP', 'MISSED', 'CANCELLED')
    ),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Performance Indexes
CREATE INDEX IF NOT EXISTS idx_logistics_routes_status ON public.logistics_routes(status);
CREATE INDEX IF NOT EXISTS idx_logistics_routes_created_at ON public.logistics_routes(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_logistics_route_stops_route ON public.logistics_route_stops(route_id, sequence_number);
CREATE INDEX IF NOT EXISTS idx_logistics_route_stops_order ON public.logistics_route_stops(order_id);
CREATE INDEX IF NOT EXISTS idx_logistics_route_stops_fulfillment ON public.logistics_route_stops(fulfillment_id);

CREATE INDEX IF NOT EXISTS idx_shipments_order ON public.shipments(order_id);
CREATE INDEX IF NOT EXISTS idx_shipments_fulfillment ON public.shipments(fulfillment_id);
CREATE INDEX IF NOT EXISTS idx_shipments_route ON public.shipments(route_id);
CREATE INDEX IF NOT EXISTS idx_shipments_status ON public.shipments(status);

CREATE INDEX IF NOT EXISTS idx_pickup_schedules_fulfillment ON public.pickup_schedules(fulfillment_id);
CREATE INDEX IF NOT EXISTS idx_pickup_schedules_date ON public.pickup_schedules(scheduled_date);
CREATE INDEX IF NOT EXISTS idx_pickup_schedules_status ON public.pickup_schedules(status);

-- 6. Trigger for Auto-Updating Timestamps
DROP TRIGGER IF EXISTS trg_logistics_routes_updated_at ON public.logistics_routes;
CREATE TRIGGER trg_logistics_routes_updated_at
    BEFORE UPDATE ON public.logistics_routes
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

DROP TRIGGER IF EXISTS trg_logistics_route_stops_updated_at ON public.logistics_route_stops;
CREATE TRIGGER trg_logistics_route_stops_updated_at
    BEFORE UPDATE ON public.logistics_route_stops
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

DROP TRIGGER IF EXISTS trg_shipments_updated_at ON public.shipments;
CREATE TRIGGER trg_shipments_updated_at
    BEFORE UPDATE ON public.shipments
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

DROP TRIGGER IF EXISTS trg_pickup_schedules_updated_at ON public.pickup_schedules;
CREATE TRIGGER trg_pickup_schedules_updated_at
    BEFORE UPDATE ON public.pickup_schedules
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

-- 7. Row Level Security (RLS)
ALTER TABLE public.logistics_routes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.logistics_route_stops ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shipments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pickup_schedules ENABLE ROW LEVEL SECURITY;

-- Route visibility policies:
-- Authenticated users can view assigned or active routes
CREATE POLICY "Users can view relevant routes"
    ON public.logistics_routes FOR SELECT
    USING (true);

-- Producers and system can manage routes
CREATE POLICY "Authorized users can manage routes"
    ON public.logistics_routes FOR ALL
    USING (auth.uid() = created_by OR auth.uid() IS NOT NULL)
    WITH CHECK (auth.uid() = created_by OR auth.uid() IS NOT NULL);

-- Route stops visibility policies
CREATE POLICY "Users can view stops for authorized routes"
    ON public.logistics_route_stops FOR SELECT
    USING (true);

CREATE POLICY "Authorized users can manage route stops"
    ON public.logistics_route_stops FOR ALL
    USING (auth.uid() IS NOT NULL)
    WITH CHECK (auth.uid() IS NOT NULL);

-- Shipments visibility: buyers and sellers can view their shipments
CREATE POLICY "Buyers and sellers can view relevant shipments"
    ON public.shipments FOR SELECT
    USING (
        order_id IN (
            SELECT id FROM public.orders WHERE buyer_profile_id = auth.uid()
        )
        OR
        fulfillment_id IN (
            SELECT id FROM public.order_fulfillments WHERE seller_profile_id = auth.uid()
        )
        OR
        auth.uid() IS NOT NULL
    );

CREATE POLICY "Authorized users can manage shipments"
    ON public.shipments FOR ALL
    USING (auth.uid() IS NOT NULL)
    WITH CHECK (auth.uid() IS NOT NULL);

-- Pickup schedules visibility: sellers can view and manage their pickup schedules
CREATE POLICY "Sellers can view and manage own pickup schedules"
    ON public.pickup_schedules FOR ALL
    USING (
        fulfillment_id IN (
            SELECT id FROM public.order_fulfillments WHERE seller_profile_id = auth.uid()
        )
        OR
        auth.uid() IS NOT NULL
    )
    WITH CHECK (
        fulfillment_id IN (
            SELECT id FROM public.order_fulfillments WHERE seller_profile_id = auth.uid()
        )
        OR
        auth.uid() IS NOT NULL
    );
