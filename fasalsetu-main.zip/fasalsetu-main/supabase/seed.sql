-- =========================================================================
-- FasalSetu Pan-India Prototype Seed Data (Safe Demo Records)
-- All seed records are tagged is_demo = true for hybrid data architecture.
-- Dynamically resolves native Supabase Auth profile IDs by demo email.
-- =========================================================================

DO $$
DECLARE
    v_farmer_id     UUID;
    v_fpo_id        UUID;
    v_consumer_id   UUID;
    v_bulk_buyer_id UUID;
BEGIN
    -- 1. Resolve Profile IDs from public.profiles using exact demo emails
    SELECT id INTO v_farmer_id     FROM public.profiles WHERE email = 'farmer@fasalsetu.demo';
    SELECT id INTO v_fpo_id        FROM public.profiles WHERE email = 'fpo@fasalsetu.demo';
    SELECT id INTO v_consumer_id   FROM public.profiles WHERE email = 'consumer@fasalsetu.demo';
    SELECT id INTO v_bulk_buyer_id FROM public.profiles WHERE email = 'bulkbuyer@fasalsetu.demo';

    -- 2. Validate that all four required Auth demo profiles exist
    IF v_farmer_id IS NULL THEN
        RAISE EXCEPTION 'Missing demo profile for email: farmer@fasalsetu.demo. Please create this user via Supabase Auth first.';
    END IF;

    IF v_fpo_id IS NULL THEN
        RAISE EXCEPTION 'Missing demo profile for email: fpo@fasalsetu.demo. Please create this user via Supabase Auth first.';
    END IF;

    IF v_consumer_id IS NULL THEN
        RAISE EXCEPTION 'Missing demo profile for email: consumer@fasalsetu.demo. Please create this user via Supabase Auth first.';
    END IF;

    IF v_bulk_buyer_id IS NULL THEN
        RAISE EXCEPTION 'Missing demo profile for email: bulkbuyer@fasalsetu.demo. Please create this user via Supabase Auth first.';
    END IF;

    -- 3. Update Demo Profiles with canonical attributes & tag is_demo = true
    UPDATE public.profiles
    SET 
        full_name = 'Ramesh Kumar',
        phone = COALESCE(phone, '+91 98765 43210'),
        role = 'farmer',
        avatar_url = 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=150',
        is_demo = true
    WHERE id = v_farmer_id;

    UPDATE public.profiles
    SET 
        full_name = 'Kisan Samriddhi Producer Co.',
        phone = COALESCE(phone, '+91 98111 22334'),
        role = 'fpo',
        avatar_url = 'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=150',
        is_demo = true
    WHERE id = v_fpo_id;

    UPDATE public.profiles
    SET 
        full_name = 'Priya Sharma',
        phone = COALESCE(phone, '+91 99222 33445'),
        role = 'consumer',
        avatar_url = 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
        is_demo = true
    WHERE id = v_consumer_id;

    UPDATE public.profiles
    SET 
        full_name = 'Arun Verma',
        phone = COALESCE(phone, '+91 97333 44556'),
        role = 'bulk_buyer',
        avatar_url = 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
        is_demo = true
    WHERE id = v_bulk_buyer_id;

    -- 4. Role Extension Profiles
    INSERT INTO public.farmer_profiles (profile_id, farmer_type, farm_name, description, total_land_acres)
    VALUES (v_farmer_id, 'Individual Farmer', 'Green Valley Natural Farms', 'Specializing in naturally grown desi tomatoes, organic greens, and seasonal vegetables.', 6.5)
    ON CONFLICT (profile_id) DO UPDATE SET
        farm_name = EXCLUDED.farm_name,
        description = EXCLUDED.description,
        total_land_acres = EXCLUDED.total_land_acres;

    INSERT INTO public.fpo_profiles (profile_id, fpo_name, registration_number, description, member_count)
    VALUES (v_fpo_id, 'Kisan Samriddhi Producer Co. Ltd.', 'FPO-UP-2024-8921', 'A 240-member producer collective operating aggregation yards across Jewar and Dadri clusters.', 240)
    ON CONFLICT (profile_id) DO UPDATE SET
        fpo_name = EXCLUDED.fpo_name,
        registration_number = EXCLUDED.registration_number,
        description = EXCLUDED.description,
        member_count = EXCLUDED.member_count;

    INSERT INTO public.consumer_profiles (profile_id, society, delivery_instructions)
    VALUES (v_consumer_id, 'Gaur City 2, Greater Noida West', 'Leave package at security gate if morning delivery before 8 AM.')
    ON CONFLICT (profile_id) DO UPDATE SET
        society = EXCLUDED.society,
        delivery_instructions = EXCLUDED.delivery_instructions;

    INSERT INTO public.bulk_buyer_profiles (profile_id, business_name, business_type, gst_number, description)
    VALUES (v_bulk_buyer_id, 'FreshMart Urban Supermarkets', 'Retail Chain', '09AAACH7409R1ZZ', 'Procurement desk sourcing fresh farm lots for 14 retail branches in Delhi NCR.')
    ON CONFLICT (profile_id) DO UPDATE SET
        business_name = EXCLUDED.business_name,
        business_type = EXCLUDED.business_type,
        gst_number = EXCLUDED.gst_number,
        description = EXCLUDED.description;

    -- 5. Insert Farm Locations (Pan-India & Pilot Regions)
    INSERT INTO public.farm_locations (id, owner_profile_id, owner_type, farm_title, latitude, longitude, accuracy, village, locality, city, district, state, formatted_address, source, is_default, is_demo)
    VALUES
        ('f1111111-1111-1111-1111-111111111111', v_farmer_id, 'farmer', 'Dankaur Main Orchard', 28.3520000, 77.5500000, 5.0, 'Dankaur', 'Yamuna Expressway Hub', 'Greater Noida', 'Gautam Buddha Nagar', 'Uttar Pradesh', 'Dankaur Rural Gate, Gautam Buddha Nagar, Uttar Pradesh - 203201', 'gps', true, true),
        ('f2222222-2222-2222-2222-222222222222', v_fpo_id, 'fpo', 'Jewar Cluster Yard', 28.1300000, 77.5600000, 8.0, 'Jewar', 'Airport Agricultural Zone', 'Jewar', 'Gautam Buddha Nagar', 'Uttar Pradesh', 'Jewar FPO Aggregation Yard, Gautam Buddha Nagar, Uttar Pradesh - 203135', 'gps', true, true),
        ('f3333333-3333-3333-3333-333333333333', v_fpo_id, 'fpo', 'Nashik Vineyard Center', 20.0051230, 73.7893210, 10.0, 'Pimpalgaon', 'Nashik Basin', 'Nashik', 'Nashik', 'Maharashtra', 'Pimpalgaon Baswant Yard, Nashik, Maharashtra - 422209', 'manual', false, true)
    ON CONFLICT (id) DO UPDATE SET
        owner_profile_id = EXCLUDED.owner_profile_id,
        farm_title = EXCLUDED.farm_title,
        is_demo = true;

    -- 6. Insert Demo Products
    INSERT INTO public.products (id, seller_profile_id, seller_type, farm_location_id, name, hindi_name, category, description, price, unit, quantity_available, reserved_quantity, minimum_order_quantity, quality, organic, harvest_date, image_url, is_active, is_demo)
    VALUES
        ('11111111-1111-1111-1111-111111111111', v_farmer_id, 'farmer', 'f1111111-1111-1111-1111-111111111111', 'Desi Vine Tomatoes', 'देसी टमाटर', 'Vegetables', 'Vine-ripened organic tomatoes plucked daily at dawn with high natural acidity and sweetness.', 42.00, 'kg', 850.0, 50.0, 1.0, 'Grade A', true, CURRENT_DATE, 'https://images.unsplash.com/photo-1546470427-e26264be0b11?w=500', true, true),
        ('22222222-2222-2222-2222-222222222222', v_farmer_id, 'farmer', 'f1111111-1111-1111-1111-111111111111', 'Tender Green Spinach', 'पालक', 'Vegetables', 'Crisp iron-rich spinach freshly harvested from alluvial soils along the Yamuna floodplain.', 28.00, 'kg', 320.0, 10.0, 1.0, 'Grade A', true, CURRENT_DATE, 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=500', true, true),
        ('33333333-3333-3333-3333-333333333333', v_fpo_id, 'fpo', 'f2222222-2222-2222-2222-222222222222', 'Chipsona Processing Potatoes', 'आलू चिप्सोना', 'Vegetables', 'High dry-matter potatoes ideal for chips and curries with low sugar content.', 22.00, 'kg', 8500.0, 500.0, 500.0, 'Grade A', false, CURRENT_DATE, 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=500', true, true),
        ('44444444-4444-4444-4444-444444444444', v_fpo_id, 'fpo', 'f2222222-2222-2222-2222-222222222222', 'Sharbati Golden Wheat', 'शरबती गेहूं', 'Grains', 'Heavy grain wheat harvested in Central & Western UP with high natural protein.', 36.00, 'kg', 12000.0, 1000.0, 500.0, 'Premium Export', true, CURRENT_DATE, 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=500', true, true),
        ('55555555-5555-5555-5555-555555555555', v_fpo_id, 'fpo', 'f3333333-3333-3333-3333-333333333333', 'Nashik Crimson Onions', 'लाल प्याज', 'Vegetables', 'Naturally cured red onions with tight outer skins, sharp pungency, and long shelf life.', 32.00, 'kg', 9500.0, 200.0, 500.0, 'Grade A', false, CURRENT_DATE, 'https://images.unsplash.com/photo-1508747703725-719777637510?w=500', true, true)
    ON CONFLICT (id) DO UPDATE SET
        seller_profile_id = EXCLUDED.seller_profile_id,
        farm_location_id = EXCLUDED.farm_location_id,
        price = EXCLUDED.price,
        quantity_available = EXCLUDED.quantity_available,
        is_demo = true;

    -- 7. Insert Initial Demo Order
    INSERT INTO public.orders (id, order_number, buyer_profile_id, buyer_role, subtotal, delivery_fee, savings, total, delivery_type, payment_method, payment_status, status, delivery_address, delivery_estimate, is_demo)
    VALUES
        ('01111111-1111-1111-1111-111111111111', 'FS-2026-001024', v_consumer_id, 'consumer', 840.00, 0.00, 180.00, 840.00, 'delivery', 'cod', 'pending', 'In Transit', 'Flat 402, Gaur City 2, Greater Noida West, Uttar Pradesh', 'Today 4-6 Hours', true)
    ON CONFLICT (id) DO UPDATE SET
        buyer_profile_id = EXCLUDED.buyer_profile_id,
        status = EXCLUDED.status,
        is_demo = true;

    -- 8. Order Items (Idempotent: insert if not already present)
    IF NOT EXISTS (SELECT 1 FROM public.order_items WHERE order_id = '01111111-1111-1111-1111-111111111111') THEN
        INSERT INTO public.order_items (order_id, product_id, seller_profile_id, seller_type, farm_location_id, product_name, quantity, unit, unit_price, subtotal)
        VALUES
            ('01111111-1111-1111-1111-111111111111', '11111111-1111-1111-1111-111111111111', v_farmer_id, 'farmer', 'f1111111-1111-1111-1111-111111111111', 'Desi Vine Tomatoes', 10.0, 'kg', 42.00, 420.00),
            ('01111111-1111-1111-1111-111111111111', '22222222-2222-2222-2222-222222222222', v_farmer_id, 'farmer', 'f1111111-1111-1111-1111-111111111111', 'Tender Green Spinach', 15.0, 'kg', 28.00, 420.00);
    END IF;

    -- 9. Order Fulfillments (Idempotent: insert if not already present)
    IF NOT EXISTS (SELECT 1 FROM public.order_fulfillments WHERE order_id = '01111111-1111-1111-1111-111111111111') THEN
        INSERT INTO public.order_fulfillments (order_id, seller_profile_id, seller_type, farm_location_id, status, delivery_location)
        VALUES
            ('01111111-1111-1111-1111-111111111111', v_farmer_id, 'farmer', 'f1111111-1111-1111-1111-111111111111', 'In Transit', 'Flat 402, Gaur City 2, Greater Noida West, Uttar Pradesh');
    END IF;

    -- 10. Order Timeline (Idempotent: insert if not already present)
    IF NOT EXISTS (SELECT 1 FROM public.order_timeline WHERE order_id = '01111111-1111-1111-1111-111111111111') THEN
        INSERT INTO public.order_timeline (order_id, status, changed_by, note)
        VALUES
            ('01111111-1111-1111-1111-111111111111', 'Pending', v_consumer_id, 'Order placed by consumer.'),
            ('01111111-1111-1111-1111-111111111111', 'Confirmed', v_farmer_id, 'Producer confirmed produce lot.'),
            ('01111111-1111-1111-1111-111111111111', 'Preparing', v_farmer_id, 'Harvest plucked and packed.'),
            ('01111111-1111-1111-1111-111111111111', 'In Transit', v_farmer_id, 'Dispatched via Yamuna Corridor EV Transit.');
    END IF;

END $$;
