/**
 * FasalSetu Demo & MVP Data
 * Hyperlocal Agricultural Marketplace for Noida & Greater Noida, Uttar Pradesh
 */

export const PLATFORM_INFO = {
  name: "FasalSetu",
  tagline: "Connecting Farms. Empowering Farmers.",
  hindiTagline: "फसल से बाज़ार तक, सीधे और स्मार्ट तरीके से।",
  mission: "AI-Powered Hyperlocal Agricultural Marketplace",
  geography: "Noida & Greater Noida, Uttar Pradesh",
  district: "Gautam Buddha Nagar",
  status: "Prototype Demo",
  hackathon: "Smart India Hackathon 2024 / 2025 Prototype"
};

export const DEMO_METADATA = {
  architecture: 'hybrid',
  version: '1.0',
  description: 'Verified baseline agricultural catalog for FasalSetu SIH prototype demonstration',
  defaultSource: 'demo',
  isDemo: true
};

export const STATS_DATA = [
  {
    id: "farmers",
    value: "10+",
    label: "Farmers & FPOs",
    subtext: "Verified producer collectives and progressive farmers in pilot cohort",
    change: "Network Scope",
    badgeType: "scope"
  },
  {
    id: "access",
    value: "100%",
    label: "Direct Market Access",
    subtext: "Transparent farm-gate price realization with zero hidden intermediary cuts",
    change: "Direct Model",
    badgeType: "direct"
  },
  {
    id: "ai",
    value: "92%",
    label: "AI Demand Intelligence",
    subtext: "Predictive model accuracy guiding harvest volumes and regional pricing",
    change: "Prototype Metric",
    badgeType: "ai"
  },
  {
    id: "logistics",
    value: "4-6h",
    label: "Smart Logistics",
    subtext: "Consolidated farm-to-doorstep vehicle dispatches reducing spoilage",
    change: "Prototype Metric",
    badgeType: "logistics"
  }
];

export const REGIONS_DATA = [
  {
    id: "jewar",
    name: "Jewar",
    type: "Agricultural Heartland & Origin",
    role: "Primary Harvest & Grain Hub",
    details: "High-yield wheat, seasonal gourds, mustard seed and organic pulses.",
    badge: "Origin Cluster",
    distanceFromHub: "45 km to Noida Hub",
    order: 1
  },
  {
    id: "dankaur",
    name: "Dankaur",
    type: "Peri-urban Aggregation Center",
    role: "Primary FPO Sorting & Weighing",
    details: "Daily vegetable collections, leafy greens, tomatoes and fresh dairy.",
    badge: "Collection Hub",
    distanceFromHub: "28 km to Noida Hub",
    order: 2
  },
  {
    id: "greater-noida",
    name: "Greater Noida",
    type: "Distribution & Cold Transit Hub",
    role: "Pari Chowk & Alpha/Beta Staging",
    details: "Bulk consolidation, quality grade check and dispatch clustering.",
    badge: "Consolidation Hub",
    distanceFromHub: "18 km to Noida Hub",
    order: 3
  },
  {
    id: "noida",
    name: "Noida",
    type: "Urban Consumer & Retail Destination",
    role: "End-consumer & Society Delivery",
    details: "Sectors 50, 62, 78, 137, 150 apartment clusters & commercial kitchens.",
    badge: "Demand Center",
    distanceFromHub: "Destination Corridor",
    order: 4
  },
  {
    id: "dadri",
    name: "Dadri",
    type: "Eastern Aggregation Belt",
    role: "Paddy & Co-op Farmers Association",
    details: "Direct connection with eastern Gautam Buddha Nagar farmer cooperatives.",
    badge: "Co-op Partner",
    distanceFromHub: "22 km to Greater Noida",
    order: 5
  },
  {
    id: "yamuna-expressway",
    name: "Yamuna Expressway",
    type: "High-Speed Logistics Artery",
    role: "Zero-traffic Transit Corridor",
    details: "Rapid morning dispatch corridor enabling 4-hour farm-to-kitchen turnaround.",
    badge: "Green Corridor",
    distanceFromHub: "Express Arterial",
    order: 6
  }
];

export const HOW_IT_WORKS_STEPS = [
  {
    number: "01",
    step: "Step 01",
    title: "Farmer Lists Produce",
    description: "Farmers and FPOs list harvest quantity, expected availability, and transparent farm-gate pricing in simple Hindi or English with zero tech friction.",
    role: "Producer Gate",
    tag: "Direct Farm Gate"
  },
  {
    number: "02",
    step: "Step 02",
    title: "AI Understands Demand",
    description: "FasalSetu's intelligence engine analyzes historical procurement, seasonality, and regional consumption trends to forecast optimal pricing and match volumes.",
    role: "Demand Intelligence",
    tag: "Predictive Analytics"
  },
  {
    number: "03",
    step: "Step 03",
    title: "Buyers Discover & Match",
    description: "Consumers, housing societies, retailers, and bulk buyers discover verified fresh harvest directly, placing orders at fair, transparent rates.",
    role: "Marketplace Match",
    tag: "Fair Exchange"
  },
  {
    number: "04",
    step: "Step 04",
    title: "Smart Logistics Plans Delivery",
    description: "Dynamic routing clusters nearby farm pickups and consolidated vehicle corridors, moving harvest efficiently to minimize travel time and food waste.",
    role: "Route Optimization",
    tag: "Fast Turnaround"
  },
  {
    number: "05",
    step: "Step 05",
    title: "Farmer Gets Direct Market Access",
    description: "Producers receive prompt, secure escrow settlement directly to their bank accounts, retaining up to 25-30% more value compared to conventional mandis.",
    role: "Direct Realization",
    tag: "Guaranteed Payout"
  }
];

export const VALUE_PROPOSITIONS = [
  {
    id: "farmers",
    target: "FOR FARMERS & FPOs",
    title: "Better Price Realization",
    subtitle: "Sell directly to buyers and reduce unnecessary intermediaries.",
    description: "Traditional mandi supply chains strip 35-50% of value through multi-tiered intermediaries. FasalSetu ensures farmers receive true market value directly into their accounts.",
    points: [
      "Zero commission middlemen deductions",
      "Direct farm-gate pickup scheduling",
      "Assured digital payments without long delays",
      "AI harvesting advisories based on local demand"
    ],
    accent: "emerald",
    stat: "+35%",
    statLabel: "Average income realization"
  },
  {
    id: "buyers",
    target: "FOR BUYERS & RESIDENTS",
    title: "Fair & Transparent Prices",
    subtitle: "Discover locally sourced produce directly from farmers.",
    description: "Noida consumers receive produce harvested within 12 hours from farms less than 40 km away in Jewar and Dankaur, ensuring peak freshness, higher nutrient density, and clear origin traceability.",
    points: [
      "Harvest-to-home within 4 to 6 hours",
      "Full traceability back to the specific farmer or FPO",
      "Lower retail prices by cutting out mandi brokerage",
      "Bulk group buying for societies & restaurants"
    ],
    accent: "amber",
    stat: "100%",
    statLabel: "Local traceability"
  },
  {
    id: "logistics",
    target: "FOR LOCAL LOGISTICS",
    title: "Smarter Delivery",
    subtitle: "AI-assisted demand and route optimization.",
    description: "Our routing engine pools multi-farm pickups into consolidated local clusters along the Yamuna Expressway, cutting transportation emissions and maximizing local fleet utilization.",
    points: [
      "Dynamic multi-stop collection along Yamuna Expressway",
      "Pre-aggregated cluster delivery for high-density societies",
      "Lower fuel consumption and reduced empty return trips",
      "Support for local EV cargo three-wheelers"
    ],
    accent: "blue",
    stat: "40%",
    statLabel: "Reduced logistics miles"
  }
];

export const MARKETPLACE_PRODUCTS = [
  {
    id: "p1",
    name: "Desi Country Tomatoes (देसी टमाटर)",
    hindiName: "देसी टमाटर",
    category: "Vegetables",
    farmer: "Dankaur Growers",
    farmerType: "Farmer Producer Org (FPO)",
    location: "Dankaur",
    price: 26,
    typicalRetailPrice: 38,
    unit: "kg",
    quantityAvailable: 420,
    harvestDate: "Today, 5:30 AM",
    quality: "Premium",
    organic: true,
    distance: "24 km from Central Noida",
    image: "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=600&q=80",
    description: "Naturally ripened vine tomatoes picked at dawn from the Dankaur peri-urban farm belt. High in lycopene with sweet-tangy flavour ideal for curries and salads."
  },
  {
    id: "p2",
    name: "Kufri Jyoti Potatoes (कुफरी आलू)",
    hindiName: "कुफरी आलू",
    category: "Vegetables",
    farmer: "Dadri Kisan Group",
    farmerType: "Cooperative Society",
    location: "Dadri",
    price: 18,
    typicalRetailPrice: 28,
    unit: "kg",
    quantityAvailable: 850,
    harvestDate: "Yesterday",
    quality: "Standard",
    organic: false,
    distance: "21 km from Central Noida",
    image: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=600&q=80",
    description: "Direct harvest medium-large soil-dusted potatoes with firm skin and low sugar content, harvested from Dadri's alluvial loam belt."
  },
  {
    id: "p3",
    name: "Red Nashik-Jewar Onions (लाल प्याज)",
    hindiName: "लाल प्याज",
    category: "Vegetables",
    farmer: "Jewar Agri Producers",
    farmerType: "FPO Cluster",
    location: "Jewar",
    price: 24,
    typicalRetailPrice: 36,
    unit: "kg",
    quantityAvailable: 650,
    harvestDate: "2 days ago",
    quality: "Standard",
    organic: false,
    distance: "44 km from Central Noida",
    image: "https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?auto=format&fit=crop&w=600&q=80",
    description: "Properly dried and cured red onions with tight outer scales, low moisture loss, and sharp pungent aroma suitable for long household storage."
  },
  {
    id: "p4",
    name: "Sharbati Golden Wheat (शरबती गेहूँ)",
    hindiName: "शरबती गेहूँ",
    category: "Grains",
    farmer: "Yamuna Farmers Group",
    farmerType: "Certified Farmer Group",
    location: "Yamuna Expressway",
    price: 34,
    typicalRetailPrice: 48,
    unit: "kg",
    quantityAvailable: 1200,
    harvestDate: "Current Season",
    quality: "Premium",
    organic: true,
    distance: "32 km from Central Noida",
    image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=600&q=80",
    description: "Lustrous amber-golden Sharbati wheat grains from the fertile Yamuna basin. Stone-milling creates exceptionally soft, naturally sweet rotis."
  },
  {
    id: "p5",
    name: "Fresh Crisp Red Carrots (देसी गाजर)",
    hindiName: "देसी लाल गाजर",
    category: "Vegetables",
    farmer: "Green Valley FPO",
    farmerType: "FPO Cluster",
    location: "Greater Noida",
    price: 22,
    typicalRetailPrice: 35,
    unit: "kg",
    quantityAvailable: 310,
    harvestDate: "Today, 6:00 AM",
    quality: "Premium",
    organic: true,
    distance: "16 km from Central Noida",
    image: "https://images.unsplash.com/photo-1598170845058-32b9d6a5c317?auto=format&fit=crop&w=600&q=80",
    description: "Sweet, crunchy winter/spring red carrots grown using vermicompost along Greater Noida rural farms. Excellent for juicing and traditional gajar halwa."
  },
  {
    id: "p6",
    name: "Tender Green Spinach (देसी पालक)",
    hindiName: "देसी पालक",
    category: "Vegetables",
    farmer: "Dankaur Growers",
    farmerType: "Farmer Producer Org (FPO)",
    location: "Dankaur",
    price: 16,
    typicalRetailPrice: 28,
    unit: "kg",
    quantityAvailable: 35,
    harvestDate: "Today, 5:00 AM",
    quality: "Premium",
    organic: true,
    distance: "25 km from Central Noida",
    image: "https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&w=600&q=80",
    description: "Zero-chemical broad leaf desi spinach harvested at first morning light. Washed in clean tube-well water with roots intact for extended freshness."
  },
  {
    id: "p7",
    name: "Snowball Cauliflower (ताज़ा फूलगोभी)",
    hindiName: "ताज़ा फूलगोभी",
    category: "Vegetables",
    farmer: "Noida Agro FPO",
    farmerType: "Regional Collective",
    location: "Noida",
    price: 28,
    typicalRetailPrice: 42,
    unit: "kg",
    quantityAvailable: 180,
    harvestDate: "Today, 6:30 AM",
    quality: "Premium",
    organic: false,
    distance: "9 km from Central Noida",
    image: "https://images.unsplash.com/photo-1568584711075-3d021a7c3ca3?auto=format&fit=crop&w=600&q=80",
    description: "Firm, tightly packed milky white curds harvested straight from Sector 150 peri-urban green belt farms. Clean and free from blemishes."
  },
  {
    id: "p8",
    name: "Crisp Green Cabbage (पत्ता गोभी)",
    hindiName: "पत्ता गोभी",
    category: "Vegetables",
    farmer: "Greater Noida Farmer Collective",
    farmerType: "Cooperative",
    location: "Greater Noida",
    price: 19,
    typicalRetailPrice: 30,
    unit: "kg",
    quantityAvailable: 240,
    harvestDate: "Yesterday",
    quality: "Standard",
    organic: false,
    distance: "17 km from Central Noida",
    image: "https://images.unsplash.com/photo-1611105637969-959c9e830e2f?auto=format&fit=crop&w=600&q=80",
    description: "Solid, heavy heads of fresh cabbage harvested with crisp outer wrapper leaves to retain internal moisture during morning transit."
  },
  {
    id: "p9",
    name: "Sweet Garden Green Peas (मीठी हरी मटर)",
    hindiName: "हरी मटर",
    category: "Vegetables",
    farmer: "Yamuna Fresh Farms",
    farmerType: "Progressive Farmer Group",
    location: "Yamuna Expressway",
    price: 42,
    typicalRetailPrice: 65,
    unit: "kg",
    quantityAvailable: 95,
    harvestDate: "Today, 5:45 AM",
    quality: "Premium",
    organic: true,
    distance: "29 km from Central Noida",
    image: "https://images.unsplash.com/photo-1592394533824-9440e5d68530?auto=format&fit=crop&w=600&q=80",
    description: "Plump green pods bursting with sweet tender peas. Harvested cold in early morning to prevent starch conversion and preserve natural sugar content."
  },
  {
    id: "p10",
    name: "1121 Traditional Basmati Paddy Rice (बासमती चावल)",
    hindiName: "बासमती चावल",
    category: "Grains",
    farmer: "Dadri Kisan Group",
    farmerType: "Cooperative Society",
    location: "Dadri",
    price: 78,
    typicalRetailPrice: 110,
    unit: "kg",
    quantityAvailable: 900,
    harvestDate: "Aged 1 Year",
    quality: "Organic",
    organic: true,
    distance: "22 km from Central Noida",
    image: "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80",
    description: "Aged long-grain 1121 Basmati harvested along Dadri's canal irrigation belt. Retains delicate floral aroma and doubles in elongation when cooked."
  },
  {
    id: "p11",
    name: "Pure Yellow Mustard Seed (पीली सरसों)",
    hindiName: "पीली सरसों",
    category: "Grains",
    farmer: "Jewar Agri Producers",
    farmerType: "FPO Cluster",
    location: "Jewar",
    price: 68,
    typicalRetailPrice: 92,
    unit: "kg",
    quantityAvailable: 450,
    harvestDate: "Current Harvest",
    quality: "Premium",
    organic: true,
    distance: "46 km from Central Noida",
    image: "https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=600&q=80",
    description: "High oil-yield yellow mustard seeds grown with canal water in Jewar. Cleaned of chaf and foreign grains, ready for home oil expelling or spice tempering."
  },
  {
    id: "p12",
    name: "Sweet Corn Golden Maize (स्वीट कॉर्न)",
    hindiName: "मीठा भुट्टा / मक्का",
    category: "Grains",
    farmer: "Yamuna Expressway FPO",
    farmerType: "FPO Collective",
    location: "Yamuna Expressway",
    price: 25,
    typicalRetailPrice: 40,
    unit: "kg",
    quantityAvailable: 320,
    harvestDate: "Today, 6:00 AM",
    quality: "Standard",
    organic: false,
    distance: "34 km from Central Noida",
    image: "https://images.unsplash.com/photo-1551754655-cd27e38d2076?auto=format&fit=crop&w=600&q=80",
    description: "Freshly picked golden sweet corn cobs in natural green husks. Tender milky kernels ideal for boiling, roasting, and corn salads."
  },
  {
    id: "p13",
    name: "Allahabad Safeda Guavas (इलाहाबादी सफेदा अमरूद)",
    hindiName: "सफेदा अमरूद",
    category: "Fruits",
    farmer: "Dankaur Growers",
    farmerType: "Orchard Cooperative",
    location: "Dankaur",
    price: 45,
    typicalRetailPrice: 70,
    unit: "kg",
    quantityAvailable: 150,
    harvestDate: "Today, 6:15 AM",
    quality: "Premium",
    organic: true,
    distance: "26 km from Central Noida",
    image: "https://images.unsplash.com/photo-1536511135899-7a0e36098715?auto=format&fit=crop&w=600&q=80",
    description: "Tree-ripened white pulp Safeda guavas from established Dankaur riverine orchards. Smooth skin, mild seeds, and rich tropical fragrance."
  },
  {
    id: "p14",
    name: "Red Lady Farm Papaya (रेड लेडी पपीता)",
    hindiName: "पका पपीता",
    category: "Fruits",
    farmer: "Yamuna Fresh Farms",
    farmerType: "Progressive Farmer Group",
    location: "Yamuna Expressway",
    price: 32,
    typicalRetailPrice: 50,
    unit: "kg",
    quantityAvailable: 280,
    harvestDate: "Yesterday",
    quality: "Premium",
    organic: true,
    distance: "31 km from Central Noida",
    image: "https://images.unsplash.com/photo-1526318897912-3c8112a14925?auto=format&fit=crop&w=600&q=80",
    description: "High-brix deep orange-red flesh papayas harvested from drip-irrigated farms along Yamuna Expressway. Rich in digestive enzymes and vitamins."
  },
  {
    id: "p15",
    name: "Tender Green Bottle Gourd (ताज़ा लौकी)",
    hindiName: "हरी लौकी",
    category: "Vegetables",
    farmer: "Kisan FPO",
    farmerType: "Smallholder FPO",
    location: "Greater Noida",
    price: 20,
    typicalRetailPrice: 32,
    unit: "kg",
    quantityAvailable: 190,
    harvestDate: "Today, 5:30 AM",
    quality: "Standard",
    organic: false,
    distance: "15 km from Central Noida",
    image: "https://images.unsplash.com/photo-1603048588665-791ca8aea617?auto=format&fit=crop&w=600&q=80",
    description: "Straight, tender light-green bottle gourds grown on bamboo trellises near Hindon-Yamuna catchment. Thin soft skin with minimum seeds."
  },
  {
    id: "p16",
    name: "Crisp Green Okra / Ladyfinger (ताज़ा भिंडी)",
    hindiName: "हरी भिंडी",
    category: "Vegetables",
    farmer: "Noida Agro FPO",
    farmerType: "Regional Collective",
    location: "Noida",
    price: 36,
    typicalRetailPrice: 55,
    unit: "kg",
    quantityAvailable: 28,
    harvestDate: "Today, 6:00 AM",
    quality: "Premium",
    organic: true,
    distance: "8 km from Central Noida",
    image: "https://images.unsplash.com/photo-1628088062854-d1870b4553da?auto=format&fit=crop&w=600&q=80",
    description: "Tender small-to-medium green okra snapped by hand from Sector 168 village farms. Snaps easily at tips without fibrous strings."
  },
  {
    id: "p17",
    name: "Desi Whole Green Moong Dal (सबूत हरी मूंग)",
    hindiName: "सबूत हरी मूंग",
    category: "Pulses",
    farmer: "Jewar Agri Producers",
    farmerType: "FPO Cluster",
    location: "Jewar",
    price: 92,
    typicalRetailPrice: 130,
    unit: "kg",
    quantityAvailable: 340,
    harvestDate: "Current Season",
    quality: "Organic",
    organic: true,
    distance: "45 km from Central Noida",
    image: "https://images.unsplash.com/photo-1585994192701-f1a505c817ea?auto=format&fit=crop&w=600&q=80",
    description: "Unpolished whole green gram directly harvested and sun-dried in Jewar. High germination rate makes it perfect for healthy morning sprouts."
  },
  {
    id: "p18",
    name: "Desi Brown Chickpeas (देसी काला चना)",
    hindiName: "देसी काला चना",
    category: "Pulses",
    farmer: "Dadri Kisan Group",
    farmerType: "Cooperative Society",
    location: "Dadri",
    price: 74,
    typicalRetailPrice: 105,
    unit: "kg",
    quantityAvailable: 410,
    harvestDate: "Current Season",
    quality: "Standard",
    organic: true,
    distance: "23 km from Central Noida",
    image: "https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?auto=format&fit=crop&w=600&q=80",
    description: "Nutritious small-grain desi kala chana grown in rotation with wheat in Dadri. Excellent texture, high protein content and rustic flavor."
  },
  {
    id: "p19",
    name: "A2 Farm Fresh Desi Cow Milk (ताज़ा देशी गाय का दूध)",
    hindiName: "देशी गाय का दूध",
    category: "Dairy",
    farmer: "Yamuna Farmers Group",
    farmerType: "Dairy Cooperative",
    location: "Yamuna Expressway",
    price: 65,
    typicalRetailPrice: 85,
    unit: "L",
    quantityAvailable: 110,
    harvestDate: "Today, 5:00 AM",
    quality: "Organic",
    organic: true,
    distance: "28 km from Central Noida",
    image: "https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=600&q=80",
    description: "Raw unadulterated Gir & Sahiwal cow milk from Yamuna grazing pastures. Tested for fat & SNF, delivered chilled within hours of morning milking."
  },
  {
    id: "p20",
    name: "Fresh Malai Paneer (ताज़ा मलाई पनीर)",
    hindiName: "मलाई पनीर",
    category: "Dairy",
    farmer: "Green Valley FPO",
    farmerType: "Cooperative Dairy Unit",
    location: "Greater Noida",
    price: 310,
    typicalRetailPrice: 420,
    unit: "kg",
    quantityAvailable: 45,
    harvestDate: "Today, 6:00 AM",
    quality: "Premium",
    organic: true,
    distance: "14 km from Central Noida",
    image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=600&q=80",
    description: "Soft, spongy artisan paneer made exclusively from morning whole milk curdled with natural lemon. Free from vegetable oils, starch, or preservatives."
  },
  {
    id: "p21",
    name: "Kachi Ghani Cold-Pressed Mustard Oil (कच्ची घानी सरसों तेल)",
    hindiName: "कच्ची घानी सरसों तेल",
    category: "Grains",
    farmer: "Yamuna Expressway FPO",
    farmerType: "FPO Collective",
    location: "Yamuna Expressway",
    price: 165,
    typicalRetailPrice: 215,
    unit: "L",
    quantityAvailable: 210,
    harvestDate: "Fresh Cold Pressed",
    quality: "Organic",
    organic: true,
    distance: "33 km from Central Noida",
    image: "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=600&q=80",
    description: "Wood-pressed traditional cold extraction preserving natural pungency, dark golden tint, and essential omega fatty acids from local Jewar-Yamuna seeds."
  },
  {
    id: "p22",
    name: "Fresh Fragrant Green Coriander & Mint (धनिया व पुदीना)",
    hindiName: "हरा धनिया",
    category: "Vegetables",
    farmer: "Noida Agro FPO",
    farmerType: "Regional Collective",
    location: "Noida",
    price: 15,
    typicalRetailPrice: 25,
    unit: "bunch",
    quantityAvailable: 80,
    harvestDate: "Today, 6:15 AM",
    quality: "Standard",
    organic: true,
    distance: "7 km from Central Noida",
    image: "https://images.unsplash.com/photo-1589927986089-35812388d1f4?auto=format&fit=crop&w=600&q=80",
    description: "Bright green coriander with delicate tender stems and high aromatic essential oils, picked this morning from Noida green belt riverbank nursery."
  },
  {
    id: "p23",
    name: "Firm Hybrid Salad Tomatoes (सलाद टमाटर)",
    hindiName: "सलाद टमाटर",
    category: "Vegetables",
    farmer: "Yamuna Fresh Farms",
    farmerType: "Progressive Farmer Group",
    location: "Yamuna Expressway",
    price: 28,
    typicalRetailPrice: 40,
    unit: "kg",
    quantityAvailable: 380,
    harvestDate: "Today, 5:45 AM",
    quality: "Premium",
    organic: false,
    distance: "30 km from Central Noida",
    image: "https://images.unsplash.com/photo-1546470427-e26264be0b11?auto=format&fit=crop&w=600&q=80",
    description: "Uniform, juicy hybrid tomatoes with thick walls and high shelf life, harvested cold along the Yamuna Expressway farming corridor."
  },
  {
    id: "p24",
    name: "Polyhouse Organic Cherry Tomatoes (चेरी टमाटर)",
    hindiName: "चेरी टमाटर",
    category: "Vegetables",
    farmer: "Noida Agro FPO",
    farmerType: "Regional Collective",
    location: "Noida",
    state: "Uttar Pradesh",
    district: "Gautam Buddha Nagar",
    approximateLocation: "Near Sector 150, Noida",
    latitude: 28.4550,
    longitude: 77.4800,
    price: 45,
    typicalRetailPrice: 72,
    unit: "kg",
    quantityAvailable: 60,
    harvestDate: "Today, 6:30 AM",
    quality: "Organic",
    organic: true,
    distance: "8 km from Central Noida",
    image: "https://images.unsplash.com/photo-1561136594-7f68413baa99?auto=format&fit=crop&w=600&q=80",
    description: "Bite-sized sweet red cluster cherry tomatoes grown in controlled climate polyhouses near Noida Sector 150. Intense natural sweetness.",
    source: "demo"
  },
  {
    id: "p25",
    name: "Nashik Red Export Onions (नासिक लाल प्याज)",
    hindiName: "नासिक लाल प्याज",
    category: "Vegetables",
    farmer: "Sahyadri Farmers Producer Co.",
    farmerType: "FPO",
    location: "Nashik",
    state: "Maharashtra",
    district: "Nashik",
    approximateLocation: "Near Niphad, Nashik, Maharashtra",
    latitude: 20.0750,
    longitude: 74.1100,
    price: 22,
    typicalRetailPrice: 34,
    unit: "kg",
    quantityAvailable: 1500,
    harvestDate: "Current Season",
    quality: "Premium",
    organic: false,
    distance: "Pan-India Agri Corridor",
    image: "https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?auto=format&fit=crop&w=600&q=80",
    description: "Geographically Indicated (GI) Nashik red onions celebrated for pungent aroma, multi-layer skin, and long shelf stability. Direct farm gate aggregation.",
    source: "demo"
  },
  {
    id: "p26",
    name: "Nagpur Sweet Mandarin Oranges (नागपुरी संतरा)",
    hindiName: "नागपुरी संतरा",
    category: "Fruits",
    farmer: "Vidarbha Citrus Growers FPO",
    farmerType: "FPO",
    location: "Nagpur",
    state: "Maharashtra",
    district: "Nagpur",
    approximateLocation: "Near Katol, Nagpur, Maharashtra",
    latitude: 21.2700,
    longitude: 78.5800,
    price: 52,
    typicalRetailPrice: 85,
    unit: "kg",
    quantityAvailable: 850,
    harvestDate: "Yesterday",
    quality: "Premium",
    organic: true,
    distance: "Pan-India Agri Corridor",
    image: "https://images.unsplash.com/photo-1611080626919-7cf5a9dbab5b?auto=format&fit=crop&w=600&q=80",
    description: "Authentic Nagpur mandarins with thin loose skin and high juice concentration. Direct orchard harvest by Katol farmer cluster.",
    source: "demo"
  },
  {
    id: "p27",
    name: "Punjab Sharbati Wheat Flour Grain (पंजाब शरबती गेहूँ)",
    hindiName: "पंजाब शरबती गेहूँ",
    category: "Grains",
    farmer: "Doaba Kisan Collective",
    farmerType: "Farmer Cooperative",
    location: "Ludhiana",
    state: "Punjab",
    district: "Ludhiana",
    approximateLocation: "Near Samrala, Ludhiana, Punjab",
    latitude: 30.8300,
    longitude: 76.1900,
    price: 36,
    typicalRetailPrice: 52,
    unit: "kg",
    quantityAvailable: 2200,
    harvestDate: "Current Season",
    quality: "Premium",
    organic: true,
    distance: "Pan-India Agri Corridor",
    image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=600&q=80",
    description: "High-gluten, stone-milled whole grain wheat harvested from fertile canal-fed fields of Ludhiana. Produces exceptionally soft rotis.",
    source: "demo"
  },
  {
    id: "p28",
    name: "Lucknow Malihabadi Dussehri Mangoes (मलीहाबादी दशहरी)",
    hindiName: "दशहरी आम",
    category: "Fruits",
    farmer: "Malihabad Mango Growers Group",
    farmerType: "Farmer Group",
    location: "Lucknow",
    state: "Uttar Pradesh",
    district: "Lucknow",
    approximateLocation: "Near Malihabad, Lucknow, Uttar Pradesh",
    latitude: 26.9200,
    longitude: 80.7100,
    price: 65,
    typicalRetailPrice: 110,
    unit: "kg",
    quantityAvailable: 600,
    harvestDate: "Orchard Harvest",
    quality: "Organic",
    organic: true,
    distance: "Pan-India Agri Corridor",
    image: "https://images.unsplash.com/photo-1553279768-865429fa0078?auto=format&fit=crop&w=600&q=80",
    description: "GI-tagged Malihabadi Dussehri mangoes renowned for paper-thin skin, fiberless aromatic pulp, and heavenly natural sweetness.",
    source: "demo"
  },
  {
    id: "p29",
    name: "Coorg Hill Malabar Black Pepper (कूर्ग काली मिर्च)",
    hindiName: "कूर्ग काली मिर्च",
    category: "Grains",
    farmer: "Western Ghats Spices FPO",
    farmerType: "FPO",
    location: "Kodagu",
    state: "Karnataka",
    district: "Kodagu",
    approximateLocation: "Near Madikeri, Kodagu, Karnataka",
    latitude: 12.4200,
    longitude: 75.7300,
    price: 490,
    typicalRetailPrice: 650,
    unit: "kg",
    quantityAvailable: 280,
    harvestDate: "Sun-Dried Current Batch",
    quality: "Organic",
    organic: true,
    distance: "Pan-India Agri Corridor",
    image: "https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=600&q=80",
    description: "Shade-grown bold black peppercorns from coffee estate canopies in Coorg. High piperine content with sharp spicy bite.",
    source: "demo"
  },
  {
    id: "p30",
    name: "Pollachi Farm Fresh Tender Coconuts (पोलाची नारियल)",
    hindiName: "पोलाची डाभ नारियल",
    category: "Fruits",
    farmer: "Anamalai Coconut FPO",
    farmerType: "FPO",
    location: "Coimbatore",
    state: "Tamil Nadu",
    district: "Coimbatore",
    approximateLocation: "Near Pollachi, Coimbatore, Tamil Nadu",
    latitude: 10.6600,
    longitude: 77.0000,
    price: 42,
    typicalRetailPrice: 65,
    unit: "piece",
    quantityAvailable: 450,
    harvestDate: "Harvested Yesterday",
    quality: "Premium",
    organic: true,
    distance: "Pan-India Agri Corridor",
    image: "https://images.unsplash.com/photo-1526318897912-3c8112a14925?auto=format&fit=crop&w=600&q=80",
    description: "GI-recognized Pollachi tender green coconuts containing 450-550ml sweet natural electrolyte water and rich tender cream.",
    source: "demo"
  },
  {
    id: "p31",
    name: "Bardhaman Aromatic Gobindobhog Rice (गोबिंदोभोग चावल)",
    hindiName: "गोबिंदोभोग चावल",
    category: "Grains",
    farmer: "Damodar Valley Rice Producers",
    farmerType: "Cooperative Society",
    location: "Purba Bardhaman",
    state: "West Bengal",
    district: "Purba Bardhaman",
    approximateLocation: "Near Memari, Purba Bardhaman, West Bengal",
    latitude: 23.1800,
    longitude: 88.1100,
    price: 88,
    typicalRetailPrice: 125,
    unit: "kg",
    quantityAvailable: 950,
    harvestDate: "Aged 6 Months",
    quality: "Organic",
    organic: true,
    distance: "Pan-India Agri Corridor",
    image: "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80",
    description: "Short-grain fragrant heritage rice from the rice bowl of Bengal. Imparts irresistible buttery aroma ideal for payasam and khichdi.",
    source: "demo"
  },
  {
    id: "p32",
    name: "Guntur S4 Sanam Red Hot Chillies (गुंटूर लाल मिर्च)",
    hindiName: "गुंटूर तीखी मिर्च",
    category: "Vegetables",
    farmer: "Krishna Delta Spices Co-op",
    farmerType: "Farmer Cooperative",
    location: "Guntur",
    state: "Andhra Pradesh",
    district: "Guntur",
    approximateLocation: "Near Tenali, Guntur, Andhra Pradesh",
    latitude: 16.2400,
    longitude: 80.6400,
    price: 185,
    typicalRetailPrice: 260,
    unit: "kg",
    quantityAvailable: 700,
    harvestDate: "Sun-cured",
    quality: "Standard",
    organic: false,
    distance: "Pan-India Agri Corridor",
    image: "https://images.unsplash.com/photo-1589927986089-35812388d1f4?auto=format&fit=crop&w=600&q=80",
    description: "Famous deep-red Guntur S4 chillies with robust pungency (35,000-40,000 SHU) and intense natural red color extraction.",
    source: "demo"
  },
  {
    id: "p33",
    name: "Nagaur Fragrant Kasuri Methi (नागौर कसूरी मेथी)",
    hindiName: "कसूरी मेथी",
    category: "Vegetables",
    farmer: "Marwar Desert Agri Collective",
    farmerType: "FPO",
    location: "Nagaur",
    state: "Rajasthan",
    district: "Nagaur",
    approximateLocation: "Near Nagaur, Rajasthan",
    latitude: 27.2000,
    longitude: 73.7400,
    price: 240,
    typicalRetailPrice: 350,
    unit: "kg",
    quantityAvailable: 310,
    harvestDate: "Shade-Dried",
    quality: "Organic",
    organic: true,
    distance: "Pan-India Agri Corridor",
    image: "https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&w=600&q=80",
    description: "Celebrated Nagaur pan-methi dried in cool shade to lock in essential fragrance and bitter-sweet undertone for gravies and parathas.",
    source: "demo"
  },
  {
    id: "p34",
    name: "Gir Cow A2 Bilona Cultured Ghee (गीर गाय का बिलोना घी)",
    hindiName: "शुद्ध बिलोना घी",
    category: "Dairy",
    farmer: "Saurashtra Desi Gaushala Co-op",
    farmerType: "Dairy Cooperative",
    location: "Junagadh",
    state: "Gujarat",
    district: "Junagadh",
    approximateLocation: "Near Gir Sanctuary, Junagadh, Gujarat",
    latitude: 21.5200,
    longitude: 70.4500,
    price: 850,
    typicalRetailPrice: 1200,
    unit: "L",
    quantityAvailable: 120,
    harvestDate: "Fresh Batch This Week",
    quality: "Organic",
    organic: true,
    distance: "Pan-India Agri Corridor",
    image: "https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=600&q=80",
    description: "Prepared via Vedic Bilona method (curd churned with wooden bilona) from free-grazing indigenous Gir cows. Granular texture and nutty aroma.",
    source: "demo"
  }
].map(p => ({ ...p, source: p.source || 'demo', isDemo: true }));

export const SAMPLE_PRODUCTS = MARKETPLACE_PRODUCTS.slice(0, 4);

export const CATEGORIES = [
  'All',
  'Vegetables',
  'Fruits',
  'Grains',
  'Pulses',
  'Dairy'
];

export const INDIAN_STATES = [
  'All India',
  'Uttar Pradesh',
  'Maharashtra',
  'Punjab',
  'Karnataka',
  'Tamil Nadu',
  'West Bengal',
  'Madhya Pradesh',
  'Rajasthan',
  'Gujarat',
  'Andhra Pradesh',
  'Haryana',
  'Delhi'
];

export const LOCATIONS = [
  'All Locations',
  'Noida',
  'Greater Noida',
  'Dadri',
  'Dankaur',
  'Jewar',
  'Yamuna Expressway',
  'Nashik',
  'Nagpur',
  'Ludhiana',
  'Lucknow',
  'Kodagu',
  'Coimbatore',
  'Purba Bardhaman',
  'Guntur',
  'Nagaur',
  'Junagadh'
];

export const DISTANCE_OPTIONS = [
  { id: 'all', label: 'All India' },
  { id: '10', label: 'Within 10 km' },
  { id: '25', label: 'Within 25 km' },
  { id: '50', label: 'Within 50 km' },
  { id: '100', label: 'Within 100 km' }
];

export const PRICE_RANGES = [
  { id: 'all', label: 'All' },
  { id: 'under-25', label: 'Under ₹25' },
  { id: '25-50', label: '₹25–₹50' },
  { id: 'above-50', label: '₹50+' }
];

export const AVAILABILITY_OPTIONS = [
  { id: 'all', label: 'All' },
  { id: 'in-stock', label: 'In Stock' },
  { id: 'low-stock', label: 'Low Stock (<50kg)' }
];

export const QUALITY_OPTIONS = [
  'All',
  'Standard',
  'Premium',
  'Organic'
];

export const SORT_OPTIONS = [
  { id: 'recommended', label: 'Recommended' },
  { id: 'nearest', label: 'Nearest (Distance)' },
  { id: 'price-asc', label: 'Price: Low to High' },
  { id: 'price-desc', label: 'Price: High to Low' },
  { id: 'newest', label: 'Newest Harvest' }
];

// Initial Demo Farmer Profile (Green Valley FPO)
export const INITIAL_DEMO_FARMER = {
  isDemo: true,
  source: 'demo',
  id: "farmer-gv-01",
  name: "Green Valley FPO",
  farmerType: "FPO",
  contactName: "Rameshwar Singh (Director)",
  phone: "+91 98765 43210",
  email: "greenvalley.fpo@fasalsetu.demo",
  farmName: "Green Valley FPO Cooperative Cluster",
  farmSize: "450 Acres (38 Associated Smallholder Farms)",
  primaryCrops: "Tomato, Potato, Cauliflower, Spinach, Desi Grains",
  memberCount: 38,
  registrationNumber: "UP-FPO-GBN-2023-882",
  memberSince: "November 2023",
  rating: 4.9,
  description: "A registered Farmer Producer Organization (FPO) uniting smallholder vegetable growers along the Yamuna & Dankaur belt. Specializing in daily morning cold-harvest distribution.",
  location: {
    id: "loc-dankaur-01",
    village: "Dankaur Rural",
    locality: "Yamuna Khadar Cluster",
    city: "Greater Noida",
    district: "Gautam Buddha Nagar",
    state: "Uttar Pradesh",
    stateCode: "UP",
    pincode: "203201",
    country: "India",
    countryCode: "IN",
    latitude: 28.3512,
    longitude: 77.5510,
    accuracy: 35,
    formattedAddress: "Dankaur Rural, Gautam Buddha Nagar, Uttar Pradesh - 203201",
    approximateLocation: "Near Dankaur, Greater Noida, Uttar Pradesh",
    source: "demo",
    confirmed: true
  }
};

// Initial Demo Orders for Farmer Dashboard (all tagged isDemo for hybrid architecture)
export const INITIAL_DEMO_ORDERS = [
  {
    id: "FS1024",
    product: "Desi Country Tomatoes",
    quantity: 100,
    unit: "kg",
    buyer: "Greater Noida Retailer & Society Group",
    location: "Pari Chowk, Greater Noida",
    amount: 2600,
    status: "Confirmed",
    date: "Today, 07:30 AM",
    paymentStatus: "Escrow Secured"
  },
  {
    id: "FS1023",
    product: "Kufri Jyoti Potatoes",
    quantity: 250,
    unit: "kg",
    buyer: "Noida Sector 78 Apartment Kitchen",
    location: "Noida Sector 78",
    amount: 4500,
    status: "Preparing",
    date: "Today, 06:15 AM",
    paymentStatus: "Escrow Secured"
  },
  {
    id: "FS1022",
    product: "Tender Green Spinach",
    quantity: 35,
    unit: "kg",
    buyer: "FreshMart Urban Kitchens",
    location: "Noida Sector 62",
    amount: 560,
    status: "Ready for Pickup",
    date: "Today, 05:45 AM",
    paymentStatus: "Escrow Secured"
  },
  {
    id: "FS1021",
    product: "Fresh Crisp Red Carrots",
    quantity: 150,
    unit: "kg",
    buyer: "Express Greens Co-op",
    location: "Noida Sector 137",
    amount: 3300,
    status: "Delivered",
    date: "Yesterday",
    paymentStatus: "Paid to Bank"
  },
  {
    id: "FS1020",
    product: "Sharbati Golden Wheat",
    quantity: 400,
    unit: "kg",
    buyer: "Yamuna Flour Mills Collective",
    location: "Dadri Mandi",
    amount: 13600,
    status: "Delivered",
    date: "2 days ago",
    paymentStatus: "Paid to Bank"
  },
  {
    id: "FS1019",
    product: "Snowball Cauliflower",
    quantity: 80,
    unit: "kg",
    buyer: "Pari Chowk Wholesaler",
    location: "Greater Noida",
    amount: 2240,
    status: "Delivered",
    date: "3 days ago",
    paymentStatus: "Paid to Bank"
  }
].map(o => ({ ...o, source: 'demo', isDemo: true }));

export const SALES_7_DAYS = [
  { day: 'Mon', sales: 4800, volume: 180 },
  { day: 'Tue', sales: 6200, volume: 220 },
  { day: 'Wed', sales: 5400, volume: 195 },
  { day: 'Thu', sales: 7900, volume: 310 },
  { day: 'Fri', sales: 8600, volume: 340 },
  { day: 'Sat', sales: 9800, volume: 420 },
  { day: 'Sun', sales: 5800, volume: 240 }
];

export const PRODUCT_EARNINGS = [
  { product: 'Tomato', amount: 18400, fill: '#10B981' },
  { product: 'Potato', amount: 12200, fill: '#059669' },
  { product: 'Onion', amount: 7600, fill: '#F59E0B' },
  { product: 'Carrot', amount: 4100, fill: '#34D399' }
];

export const PAN_INDIA_NETWORK_ZONES = {
  north: {
    id: 'north',
    badge: 'NORTH',
    name: 'North India',
    states: ['Punjab', 'Haryana', 'Uttar Pradesh'],
    focus: 'Food grains, vegetables and dairy',
    role: 'Production & Supply',
    corridor: 'Northern Farm-to-Market Network',
    icon: '🌾',
    crops: 'Wheat, Basmati Rice, Mustard, Potato, Dairy',
    description: 'High-volume agricultural production corridor supplying Northern population centers.',
    hasActiveRoutes: true,
    statusLabel: 'Live Logistics Data'
  },
  west: {
    id: 'west',
    badge: 'WEST',
    name: 'West India',
    states: ['Maharashtra', 'Gujarat', 'Rajasthan'],
    focus: 'Horticulture, pulses and diversified crops',
    role: 'Production & Distribution',
    corridor: 'Western Agricultural Corridor',
    icon: '🚜',
    crops: 'Onion, Cotton, Groundnut, Citrus, Pomegranate',
    description: 'Commercial crop aggregation and horticulture linking western farming clusters with consumer centers.',
    hasActiveRoutes: false,
    statusLabel: 'Regional Data Pending'
  },
  central: {
    id: 'central',
    badge: 'CENTRAL',
    name: 'Central India',
    states: ['Madhya Pradesh', 'Chhattisgarh'],
    focus: 'Pulses, grains and large-scale crops',
    role: 'Aggregation Hub',
    corridor: 'Central Supply Corridor',
    icon: '🌱',
    crops: 'Soybean, Chickpea, Wheat, Rice, Lentils',
    description: 'National pulse and oilseed aggregation crossroads connecting interstate transit and bulk buyers.',
    hasActiveRoutes: false,
    statusLabel: 'Regional Data Pending'
  },
  east: {
    id: 'east',
    badge: 'EAST',
    name: 'East India',
    states: ['Bihar', 'Jharkhand', 'West Bengal'],
    focus: 'Rice, vegetables and fresh produce',
    role: 'Supply Network',
    corridor: 'Eastern Produce Corridor',
    icon: '🥬',
    crops: 'Paddy, Maize, Jute, Seasonal Vegetables',
    description: 'Riverine agricultural plains with abundant seasonal vegetables and staple food supply lines.',
    hasActiveRoutes: false,
    statusLabel: 'Regional Data Pending'
  },
  south: {
    id: 'south',
    badge: 'SOUTH',
    name: 'South India',
    states: ['Karnataka', 'Tamil Nadu', 'Telangana'],
    focus: 'Horticulture, spices and high-value crops',
    role: 'Producer Network',
    corridor: 'Southern Agri Corridor',
    icon: '🥭',
    crops: 'Tomato, Chili, Spices, Coffee, Millets',
    description: 'High-yield horticulture and specialized spices directly accessible for urban retail and bulk buyers.',
    hasActiveRoutes: false,
    statusLabel: 'Regional Data Pending'
  },
  northeast: {
    id: 'northeast',
    badge: 'NORTHEAST',
    name: 'Northeast India',
    states: ['Assam', 'Meghalaya', 'Tripura'],
    focus: 'Fresh produce, horticulture and emerging farm networks',
    role: 'Emerging Zone',
    corridor: 'Northeast Farm Network',
    icon: '🌿',
    crops: 'Tea, Ginger, Turmeric, Organic Fruits',
    description: 'Specialty organic crops and producer collectives connecting remote hill farms to digital buyers across India.',
    hasActiveRoutes: false,
    statusLabel: 'Regional Data Pending'
  }
};

// =========================================================================
// HIERARCHICAL REGIONAL LOGISTICS SYSTEM DEMO DATA
// Regional Logistics Head -> Multiple Zone Assigners -> 100 Delivery Boys -> Tasks
// =========================================================================

export const NORTH_REGION_LOGISTICS_HEAD = {
  id: 'usr-head-north-01',
  name: 'Vikramaditya Singhania',
  role: 'logistics_head',
  regionId: 'north',
  regionName: 'North India Logistics Command',
  email: 'head@fasalsetu.demo',
  phone: '+91 98100 11223',
  title: 'Chief Regional Logistics Officer (North)',
  headquarters: 'Regional Command Center, Expressway Tower, Noida',
  isDemo: true,
  source: 'demo'
};

export const NORTH_REGION_ZONES = [
  {
    id: 'zone-north-a',
    code: 'ZONE_A',
    name: 'Zone A - Greater Noida West',
    regionId: 'north',
    centerLat: 28.58,
    centerLng: 77.45,
    radiusKm: 12,
    assigner: {
      id: 'usr-assigner-north-a',
      name: 'Raj Kumar',
      email: 'assigner.north.a@fasalsetu.demo',
      phone: '+91 98110 22331',
      role: 'delivery_assigner',
      zoneId: 'zone-north-a',
      zoneName: 'Zone A - Greater Noida West'
    },
    teamSize: 18,
    maxActiveDeliveries: 45,
    currentWorkload: 'HIGH',
    status: 'HIGH_WORKLOAD',
    description: 'High-density urban residential societies, Gaur City clusters, and retail hypermarkets.'
  },
  {
    id: 'zone-north-b',
    code: 'ZONE_B',
    name: 'Zone B - Noida Central Sector 62',
    regionId: 'north',
    centerLat: 28.62,
    centerLng: 77.37,
    radiusKm: 10,
    assigner: {
      id: 'usr-assigner-north-b',
      name: 'Sunita Rao',
      email: 'assigner.north.b@fasalsetu.demo',
      phone: '+91 98110 22332',
      role: 'delivery_assigner',
      zoneId: 'zone-north-b',
      zoneName: 'Zone B - Noida Central Sector 62'
    },
    teamSize: 17,
    maxActiveDeliveries: 50,
    currentWorkload: 'BALANCED',
    status: 'BALANCED',
    description: 'Commercial corporate parks, cloud kitchens, and institutional buyer hubs.'
  },
  {
    id: 'zone-north-c',
    code: 'ZONE_C',
    name: 'Zone C - Jewar Agricultural Cluster',
    regionId: 'north',
    centerLat: 28.18,
    centerLng: 77.55,
    radiusKm: 18,
    assigner: {
      id: 'usr-assigner-north-c',
      name: 'Mahendra Yadav',
      email: 'assigner.north.c@fasalsetu.demo',
      phone: '+91 98110 22333',
      role: 'delivery_assigner',
      zoneId: 'zone-north-c',
      zoneName: 'Zone C - Jewar Agricultural Cluster'
    },
    teamSize: 16,
    maxActiveDeliveries: 40,
    currentWorkload: 'BALANCED',
    status: 'BALANCED',
    description: 'Primary farm-gate pickup corridor, FPO aggregation centers, and cold transit routes.'
  },
  {
    id: 'zone-north-d',
    code: 'ZONE_D',
    name: 'Zone D - Dankaur Rural & Dairy Hub',
    regionId: 'north',
    centerLat: 28.35,
    centerLng: 77.53,
    radiusKm: 15,
    assigner: {
      id: 'usr-assigner-north-d',
      name: 'Amit Chauhan',
      email: 'assigner.north.d@fasalsetu.demo',
      phone: '+91 98110 22334',
      role: 'delivery_assigner',
      zoneId: 'zone-north-d',
      zoneName: 'Zone D - Dankaur Rural & Dairy Hub'
    },
    teamSize: 17,
    maxActiveDeliveries: 45,
    currentWorkload: 'BALANCED',
    status: 'BALANCED',
    description: 'Green Valley producer cooperatives, perishable dairy milk-run dispatches.'
  },
  {
    id: 'zone-north-e',
    code: 'ZONE_E',
    name: 'Zone E - Dadri Bio & Grain Cluster',
    regionId: 'north',
    centerLat: 28.55,
    centerLng: 77.55,
    radiusKm: 14,
    assigner: {
      id: 'usr-assigner-north-e',
      name: 'Harish Rawat',
      email: 'assigner.north.e@fasalsetu.demo',
      phone: '+91 98110 22335',
      role: 'delivery_assigner',
      zoneId: 'zone-north-e',
      zoneName: 'Zone E - Dadri Bio & Grain Cluster'
    },
    teamSize: 16,
    maxActiveDeliveries: 40,
    currentWorkload: 'BALANCED',
    status: 'BALANCED',
    description: 'Bulk grain warehouses, mustard seed processing yards, and railway logistics freight.'
  },
  {
    id: 'zone-north-f',
    code: 'ZONE_F',
    name: 'Zone F - Ghaziabad Interstate Transit',
    regionId: 'north',
    centerLat: 28.66,
    centerLng: 77.45,
    radiusKm: 16,
    assigner: {
      id: 'usr-assigner-north-f',
      name: 'Pradeep Joshi',
      email: 'assigner.north.f@fasalsetu.demo',
      phone: '+91 98110 22336',
      role: 'delivery_assigner',
      zoneId: 'zone-north-f',
      zoneName: 'Zone F - Ghaziabad Interstate Transit'
    },
    teamSize: 16,
    maxActiveDeliveries: 40,
    currentWorkload: 'BALANCED',
    status: 'BALANCED',
    description: 'Interstate Mandi cross-docking terminal and northern trunk arterial delivery nodes.'
  }
];

// Delivery Boys Generation Helper: Generates exactly 100 realistic Delivery Boys
const FIRST_NAMES = [
  'Ravi', 'Sanjay', 'Manoj', 'Deepak', 'Arjun', 'Suresh', 'Rahul', 'Vikas', 'Pankaj', 'Aman',
  'Rohit', 'Vijay', 'Naveen', 'Ankit', 'Sachin', 'Sonu', 'Dinesh', 'Ajay', 'Gaurav', 'Mukesh',
  'Mohit', 'Kunal', 'Ashok', 'Neeraj', 'Sunil', 'Santosh', 'Rajesh', 'Vinod', 'Anil', 'Pradeep',
  'Hemant', 'Satish', 'Tarun', 'Lalit', 'Praveen', 'Suraj', 'Manish', 'Kishore', 'Babu', 'Yogesh'
];

const LAST_NAMES = [
  'Kumar', 'Singh', 'Sharma', 'Verma', 'Yadav', 'Patel', 'Chauhan', 'Gupta', 'Maurya', 'Rawat',
  'Mishra', 'Pandey', 'Shukla', 'Tiwari', 'Nagar', 'Gurjar', 'Bhati', 'Tomar', 'Rana', 'Saini'
];

const VEHICLE_SPECS = [
  { type: 'EV_SCOOTER', capacityKg: 35, icon: '⚡' },
  { type: 'MOTORCYCLE', capacityKg: 45, icon: '🏍️' },
  { type: 'THREE_WHEELER', capacityKg: 350, icon: '🛺' },
  { type: 'SMALL_TRUCK', capacityKg: 950, icon: '🚚' }
];

export const NORTH_REGION_DELIVERY_BOYS = (() => {
  const boys = [];
  const zoneAllocations = [
    { zoneId: 'zone-north-a', count: 18, centerLat: 28.58, centerLng: 77.45 },
    { zoneId: 'zone-north-b', count: 17, centerLat: 28.62, centerLng: 77.37 },
    { zoneId: 'zone-north-c', count: 16, centerLat: 28.18, centerLng: 77.55 },
    { zoneId: 'zone-north-d', count: 17, centerLat: 28.35, centerLng: 77.53 },
    { zoneId: 'zone-north-e', count: 16, centerLat: 28.55, centerLng: 77.55 },
    { zoneId: 'zone-north-f', count: 16, centerLat: 28.66, centerLng: 77.45 }
  ];

  let boyIdx = 1;
  zoneAllocations.forEach((alloc) => {
    for (let i = 0; i < alloc.count; i++) {
      const fn = FIRST_NAMES[(boyIdx * 3 + i) % FIRST_NAMES.length];
      const ln = LAST_NAMES[(boyIdx * 7 + i) % LAST_NAMES.length];
      const vSpec = VEHICLE_SPECS[(boyIdx + i) % VEHICLE_SPECS.length];
      
      // Determine status realistic distribution: ~65% Available, ~25% On Delivery, ~10% Offline/Break
      const statusRand = (boyIdx * 17 + i) % 100;
      let status = 'AVAILABLE';
      let activeTasksCount = 0;
      if (statusRand < 25) {
        status = 'ON_DELIVERY';
        activeTasksCount = 1 + (boyIdx % 2);
      } else if (statusRand >= 90) {
        status = 'OFFLINE';
      }

      // Special deterministic primary test delivery boy (Ravi Kumar in Zone A)
      const isPrimaryTestBoy = boyIdx === 1;
      const finalName = isPrimaryTestBoy ? 'Ravi Kumar' : `${fn} ${ln}`;
      const finalEmail = isPrimaryTestBoy ? 'delivery.ravi@fasalsetu.demo' : `db.${alloc.zoneId.slice(-1)}.${boyIdx}@fasalsetu.demo`;

      // Coordinate jitter around zone center
      const latOffset = ((boyIdx * 13) % 40 - 20) * 0.002;
      const lngOffset = ((boyIdx * 19) % 40 - 20) * 0.002;

      boys.push({
        id: `db-north-${String(boyIdx).padStart(3, '0')}`,
        name: finalName,
        email: finalEmail,
        phone: `+91 98${String(70000000 + boyIdx).slice(0, 8)}`,
        role: 'delivery_boy',
        regionId: 'north',
        zoneId: alloc.zoneId,
        vehicleType: vSpec.type,
        vehicleCapacityKg: vSpec.capacityKg,
        vehicleNumber: `UP-16-FS-${String(1000 + boyIdx).slice(1)}`,
        status,
        currentLat: Number((alloc.centerLat + latOffset).toFixed(5)),
        currentLng: Number((alloc.centerLng + lngOffset).toFixed(5)),
        rating: Number((4.6 + ((boyIdx % 5) * 0.08)).toFixed(2)),
        activeTasksCount,
        completedToday: 4 + (boyIdx % 7),
        isDemo: true,
        source: 'demo'
      });
      boyIdx++;
    }
  });

  return boys;
})();

export const NORTH_REGION_DELIVERY_TASKS = [
  {
    id: 'dt-1001',
    orderId: 'FS1025',
    orderNumber: 'FS-1025',
    regionId: 'north',
    zoneId: 'zone-north-a',
    deliveryBoyId: 'db-north-001', // Ravi Kumar
    deliveryBoyName: 'Ravi Kumar',
    pickupLocation: {
      name: 'Yamuna Green Harvest Farm Yard',
      address: 'Dankaur Link Road, Plot 14',
      city: 'Greater Noida',
      contactPerson: 'Ramesh Kumar',
      phone: '+91 98765 43210',
      lat: 28.35,
      lng: 77.53
    },
    deliveryLocation: {
      name: 'Gaur City 2 - Tower G',
      address: 'Sector 16C, Greater Noida West',
      city: 'Greater Noida',
      contactPerson: 'Priya Sharma',
      phone: '+91 99222 33445',
      lat: 28.58,
      lng: 77.45
    },
    items: [
      { cropName: 'Desi Tomato', quantityKg: 30, pricePerKg: 28 }
    ],
    totalWeightKg: 30,
    priority: 'HIGH',
    status: 'IN_TRANSIT',
    assignmentSource: 'automatic',
    assignmentScore: 94.5,
    assignmentReason: 'Assigned automatically to Ravi Kumar because he is available, has compatible EV Scooter capacity (35kg), is 3.1 km from pickup, and has 0 pending tasks in Zone A.',
    assignedAt: new Date(Date.now() - 45 * 60000).toISOString(),
    estimatedPickupTime: '09:30 AM',
    estimatedDeliveryTime: '11:15 AM',
    distanceKm: 24.5,
    isDemo: true,
    source: 'demo'
  },
  {
    id: 'dt-1002',
    orderId: 'FS1026',
    orderNumber: 'FS-1026',
    regionId: 'north',
    zoneId: 'zone-north-b',
    deliveryBoyId: 'db-north-020',
    deliveryBoyName: 'Sanjay Singh',
    pickupLocation: {
      name: 'Kisan Samriddhi Center, Jewar',
      address: 'Jewar Multi-Farm Collection Depot',
      city: 'Jewar',
      contactPerson: 'Kisan Samriddhi FPO',
      phone: '+91 98111 22334',
      lat: 28.18,
      lng: 77.55
    },
    deliveryLocation: {
      name: 'FreshMart Institutional Depot',
      address: 'Sector 62, Commercial Hub',
      city: 'Noida',
      contactPerson: 'Arun Verma',
      phone: '+91 97333 44556',
      lat: 28.62,
      lng: 77.36
    },
    items: [
      { cropName: 'Organic Potato', quantityKg: 250, pricePerKg: 22 }
    ],
    totalWeightKg: 250,
    priority: 'EXPRESS',
    status: 'PICKUP_PENDING',
    assignmentSource: 'automatic',
    assignmentScore: 91.2,
    assignmentReason: 'Assigned automatically to Sanjay Singh because he operates a Three-Wheeler (350kg capacity), was idle in Zone B, and was on the direct transit heading.',
    assignedAt: new Date(Date.now() - 25 * 60000).toISOString(),
    estimatedPickupTime: '10:00 AM',
    estimatedDeliveryTime: '12:30 PM',
    distanceKm: 48.0,
    isDemo: true,
    source: 'demo'
  },
  {
    id: 'dt-1003',
    orderId: 'FS1027',
    orderNumber: 'FS-1027',
    regionId: 'north',
    zoneId: 'zone-north-a',
    deliveryBoyId: null,
    deliveryBoyName: null,
    pickupLocation: {
      name: 'Dadri Bio Cluster Farm',
      address: 'Dadri Railway Station Road',
      city: 'Dadri',
      contactPerson: 'Balram Singh',
      phone: '+91 98110 55441',
      lat: 28.55,
      lng: 77.55
    },
    deliveryLocation: {
      name: 'Supertech Eco Village 1',
      address: 'Greater Noida West',
      city: 'Greater Noida',
      contactPerson: 'Resident Association',
      phone: '+91 98100 44321',
      lat: 28.59,
      lng: 77.44
    },
    items: [
      { cropName: 'Fresh Cauliflower', quantityKg: 80, pricePerKg: 35 }
    ],
    totalWeightKg: 80,
    priority: 'HIGH',
    status: 'UNASSIGNED',
    assignmentSource: 'fallback',
    assignmentScore: null,
    assignmentReason: 'High delivery load in Zone A. Immediate automatic assignment was queued for Coordinator review or cross-zone fallback.',
    assignedAt: null,
    estimatedPickupTime: '11:00 AM',
    estimatedDeliveryTime: '01:00 PM',
    distanceKm: 18.2,
    isDemo: true,
    source: 'demo'
  },
  {
    id: 'dt-1004',
    orderId: 'FS1028',
    orderNumber: 'FS-1028',
    regionId: 'north',
    zoneId: 'zone-north-d',
    deliveryBoyId: 'db-north-052',
    deliveryBoyName: 'Deepak Sharma',
    pickupLocation: {
      name: 'Dankaur Vegetable Nursery',
      address: 'Village Dankaur',
      city: 'Greater Noida',
      contactPerson: 'Sita Ram',
      phone: '+91 98777 66554',
      lat: 28.36,
      lng: 77.52
    },
    deliveryLocation: {
      name: 'Pari Chowk Local Produce Stall',
      address: 'Pari Chowk Terminal',
      city: 'Greater Noida',
      contactPerson: 'City Vendor Group',
      phone: '+91 98666 55443',
      lat: 28.47,
      lng: 77.50
    },
    items: [
      { cropName: 'Desi Spinach', quantityKg: 40, pricePerKg: 30 }
    ],
    totalWeightKg: 40,
    priority: 'NORMAL',
    status: 'DELIVERED',
    assignmentSource: 'automatic',
    assignmentScore: 89.0,
    assignmentReason: 'Assigned automatically based on optimal milk-run route proximity (1.8 km to pickup).',
    assignedAt: new Date(Date.now() - 180 * 60000).toISOString(),
    estimatedPickupTime: '08:00 AM',
    actualPickupTime: new Date(Date.now() - 120 * 60000).toISOString(),
    estimatedDeliveryTime: '09:30 AM',
    actualDeliveryTime: new Date(Date.now() - 40 * 60000).toISOString(),
    distanceKm: 14.5,
    isDemo: true,
    source: 'demo'
  }
];




