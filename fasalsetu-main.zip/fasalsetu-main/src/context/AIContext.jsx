/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { useOrders } from './OrderContext';
import { useProducts } from './ProductContext';
import { useLogistics } from './LogisticsContext';
import { demandForecastService } from '../services/ai/demandForecastService';
import { matchingService } from '../services/ai/matchingService';
import { supplyDemandService } from '../services/ai/supplyDemandService';
import { redistributionService } from '../services/ai/redistributionService';
import { opportunityScoreService } from '../services/ai/opportunityScoreService';
import { procurementService } from '../services/ai/procurementService';
import { supplyChainAnalyticsService } from '../services/ai/supplyChainAnalyticsService';
import { getDataComposition } from '../services/hybridDataService';

const AIContext = createContext(null);

export function AIProvider({ children }) {
  const { orders } = useOrders();
  const { products } = useProducts();
  const { routes } = useLogistics();

  const [forecasts, setForecasts] = useState([]);
  const [regionalDemand, setRegionalDemand] = useState({ regions: [], totalRegionsCount: 0, topRegion: null });
  const [supplyDemandGaps, setSupplyDemandGaps] = useState([]);
  const [smartMatches, setSmartMatches] = useState([]);
  const [redistributionOpportunities, setRedistributionOpportunities] = useState([]);
  const [supplyChainHealth, setSupplyChainHealth] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [error, setError] = useState(null);
  const [dataComposition, setDataComposition] = useState(null);

  // Compute or refresh forecasts and smart supply chain intelligence
  const loadForecasts = useCallback(async (force = false) => {
    try {
      if (force) {
        setRefreshing(true);
      }
      setError(null);

      const result = await demandForecastService.getDemandForecasts(orders, products, force);
      const regional = demandForecastService.getRegionalDemand(orders, products);
      const forecastList = result.forecasts || [];

      // 1. Supply-Demand Gaps
      const gaps = supplyDemandService.aggregateRegionalGaps(products, forecastList);

      // 2. Regional Surplus Redistribution (consuming logistics fleet routes)
      const redis = redistributionService.generateRedistributionRecommendations(gaps, routes || []);

      // 3. Smart Farmer-Buyer Matches for key active commodities
      const sampleBuyerRequirements = [
        { id: 'req-1', cropName: 'Desi Tomato', quantity: 500, targetPrice: 28, qualityGrade: 'A', buyerName: 'BigBasket Aggregation' },
        { id: 'req-2', cropName: 'Nashik Red Onion', quantity: 1200, targetPrice: 32, qualityGrade: 'A', buyerName: 'Reliance Fresh Hub' },
        { id: 'req-3', cropName: 'Organic Potato', quantity: 800, targetPrice: 22, qualityGrade: 'Standard', buyerName: 'Mother Dairy Safal' }
      ];

      const allMatches = [];
      sampleBuyerRequirements.forEach((req) => {
        const matches = matchingService.findMatchesForRequirement(req, products);
        allMatches.push(...matches);
      });

      // 4. Supply Chain Health Scorecard
      const health = supplyChainAnalyticsService.calculateSupplyChainHealth(orders, products, routes || [], forecastList);

      setForecasts(forecastList);
      setRegionalDemand(regional);
      setSupplyDemandGaps(gaps);
      setRedistributionOpportunities(redis);
      setSmartMatches(allMatches);
      setSupplyChainHealth(health);
      setLastUpdated(result.lastUpdated || Date.now());

      // Hybrid data architecture: compute data composition for transparency
      setDataComposition(getDataComposition(products, orders));
    } catch (err) {
      console.error('Failed to load supply chain intelligence:', err);
      setError('Smart Supply Chain Intelligence temporarily unavailable. Core marketplace features remain operational.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [orders, products, routes]);

  // Initial load
  useEffect(() => {
    let isMounted = true;

    async function init() {
      try {
        const result = await demandForecastService.getDemandForecasts(orders, products, false);
        if (!isMounted) return;

        const regional = demandForecastService.getRegionalDemand(orders, products);
        const forecastList = result.forecasts || [];
        const gaps = supplyDemandService.aggregateRegionalGaps(products, forecastList);
        const redis = redistributionService.generateRedistributionRecommendations(gaps, routes || []);

        const sampleBuyerRequirements = [
          { id: 'req-1', cropName: 'Desi Tomato', quantity: 500, targetPrice: 28, qualityGrade: 'A', buyerName: 'BigBasket Aggregation' },
          { id: 'req-2', cropName: 'Nashik Red Onion', quantity: 1200, targetPrice: 32, qualityGrade: 'A', buyerName: 'Reliance Fresh Hub' },
          { id: 'req-3', cropName: 'Organic Potato', quantity: 800, targetPrice: 22, qualityGrade: 'Standard', buyerName: 'Mother Dairy Safal' }
        ];

        const allMatches = [];
        sampleBuyerRequirements.forEach((req) => {
          const matches = matchingService.findMatchesForRequirement(req, products);
          allMatches.push(...matches);
        });

        const health = supplyChainAnalyticsService.calculateSupplyChainHealth(orders, products, routes || [], forecastList);

        setForecasts(forecastList);
        setRegionalDemand(regional);
        setSupplyDemandGaps(gaps);
        setRedistributionOpportunities(redis);
        setSmartMatches(allMatches);
        setSupplyChainHealth(health);
        setLastUpdated(result.lastUpdated || Date.now());
        setDataComposition(getDataComposition(products, orders));
        setLoading(false);
      } catch (err) {
        if (!isMounted) return;
        console.error('Failed to load supply chain intelligence:', err);
        setError('Smart Supply Chain Intelligence temporarily unavailable. Core marketplace features remain operational.');
        setLoading(false);
      }
    }

    init();

    return () => {
      isMounted = false;
    };
  }, [orders, products, routes]);

  // Manual refresh handler with in-flight debounce
  const refreshForecasts = useCallback(() => {
    if (refreshing) return;
    loadForecasts(true);
  }, [loadForecasts, refreshing]);

  // KPI Calculations
  const kpis = useMemo(() => {
    const totalOrders = orders.length;
    const isLimitedData = totalOrders < 3;

    const analyzedCount = forecasts.length;
    const demandSignals = forecasts.filter(
      (f) => f.classification === 'HIGH DEMAND' || f.classification === 'RISING DEMAND'
    ).length;
    const potentialShortages = supplyDemandGaps.filter(
      (g) => g.status === 'Potential Shortage'
    ).length;
    const potentialSurpluses = supplyDemandGaps.filter(
      (g) => g.status === 'Potential Surplus'
    ).length;

    return {
      isLimitedData,
      totalOrders,
      productsAnalyzed: analyzedCount > 0 ? analyzedCount : (isLimitedData ? 'Limited data' : 0),
      demandSignals: analyzedCount > 0 ? demandSignals : (isLimitedData ? 'Limited data' : 0),
      potentialShortages: analyzedCount > 0 ? potentialShortages : (isLimitedData ? 'Limited data' : 0),
      potentialSurpluses: analyzedCount > 0 ? potentialSurpluses : (isLimitedData ? 'Limited data' : 0),
      activeMatches: smartMatches.length,
      redistributionCount: redistributionOpportunities.length
    };
  }, [forecasts, orders, supplyDemandGaps, smartMatches, redistributionOpportunities]);

  // Role-specific helpers
  const getFarmerInsights = useCallback((farmerProducts = [], location = {}) => {
    return demandForecastService.getFarmerRecommendations(farmerProducts, forecasts, location);
  }, [forecasts]);

  const getFarmerOpportunityScores = useCallback((farmerProducts = []) => {
    return farmerProducts.map((p) => {
      const cropName = p.name || 'Produce';
      const forecastMatch = forecasts.find((f) => f.cropName?.toLowerCase().includes(cropName.toLowerCase()));
      const growthPercent = forecastMatch?.growthPercent || 15;
      const forecastDemand = forecastMatch?.forecastDemand || 1000;
      const farmerInventory = Number(p.quantity || p.stock || 0);

      return opportunityScoreService.calculateFarmerOpportunity({
        cropName,
        farmerInventory,
        forecastDemand,
        nearbySupply: Math.round(forecastDemand * 0.4),
        growthPercent,
        activeBuyers: 3,
        hasLogisticsNearby: true
      });
    });
  }, [forecasts]);

  const getFPOInsights = useCallback((memberFarmers = [], aggregatedInventory = []) => {
    return demandForecastService.getFPOInsights(memberFarmers, aggregatedInventory, forecasts);
  }, [forecasts]);

  const getFPOAggregationOpportunities = useCallback((aggregatedInventory = []) => {
    return aggregatedInventory.map((item) => {
      const cropName = item.cropName || item.name || 'Crop';
      const forecastMatch = forecasts.find((f) => f.cropName?.toLowerCase().includes(cropName.toLowerCase()));
      const forecastDemand = forecastMatch?.forecastDemand || 3000;

      return opportunityScoreService.calculateFPOOpportunity({
        cropName,
        memberTotalInventory: Number(item.totalQuantity || item.quantity || 1500),
        regionalForecastDemand: forecastDemand,
        memberCount: item.farmerCount || 8
      });
    });
  }, [forecasts]);

  const getBuyerInsights = useCallback((preferredLocations = []) => {
    return demandForecastService.getBulkBuyerSignals(forecasts, preferredLocations);
  }, [forecasts]);

  const getProcurementPlan = useCallback((requirement) => {
    return procurementService.generateProcurementPlan(requirement, products);
  }, [products]);

  const getConsumerRecommendations = useCallback(() => {
    return demandForecastService.getConsumerRecommendations(products, forecasts);
  }, [products, forecasts]);

  const value = {
    forecasts,
    regionalDemand,
    supplyDemandGaps,
    smartMatches,
    redistributionOpportunities,
    supplyChainHealth,
    kpis,
    loading,
    refreshing,
    lastUpdated,
    error,
    refreshForecasts,
    getFarmerInsights,
    getFarmerOpportunityScores,
    getFPOInsights,
    getFPOAggregationOpportunities,
    getBuyerInsights,
    getProcurementPlan,
    getConsumerRecommendations,
    // Hybrid data architecture: data composition transparency
    dataComposition
  };

  return <AIContext.Provider value={value}>{children}</AIContext.Provider>;
}

export function useAI() {
  const context = useContext(AIContext);
  if (!context) {
    throw new Error('useAI must be used within an AIProvider');
  }
  return context;
}
