/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { MARKETPLACE_PRODUCTS } from '../data/demoData';
import { productService } from '../services/productService';
import { isSupabaseConfigured } from '../lib/supabase';
import { normalizeProduct, deduplicateById } from '../utils/normalizers';
import { updateConnectionStatus, isDemoRecord } from '../services/hybridDataService';

const ProductContext = createContext();

const PRODUCTS_STORAGE_KEY = 'fasalsetu_products_v1';

export function ProductProvider({ children }) {
  const [connectionStatus, setConnectionStatus] = useState(
    isSupabaseConfigured() ? 'live' : 'demo-fallback'
  );

  const [products, setProducts] = useState(() => {
    try {
      const saved = localStorage.getItem(PRODUCTS_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (err) {
      console.error('Error loading products from localStorage', err);
    }
    // Normalize demo products with source tagging
    return MARKETPLACE_PRODUCTS.map((p) => normalizeProduct(p, 'demo'));
  });

  // Hydrate from Supabase and merge with demo data (Hybrid Architecture)
  useEffect(() => {
    let isMounted = true;

    async function loadHybridProducts() {
      if (isSupabaseConfigured()) {
        try {
          const cloudProds = await productService.getPublicProducts();
          if (isMounted) {
            if (cloudProds && cloudProds.length > 0) {
              // Normalize Supabase records as 'live' (unless they have is_demo flag)
              const liveFormatted = cloudProds.map((cp) => normalizeProduct({
                id: cp.id,
                name: cp.name,
                hindi_name: cp.hindi_name,
                category: cp.category,
                seller_name: cp.seller_name,
                seller_profile_id: cp.seller_profile_id,
                seller_type: cp.seller_type,
                city: cp.city,
                district: cp.district,
                state: cp.state,
                approximate_location: cp.approximate_location,
                price: cp.price,
                unit: cp.unit,
                quantity_available: cp.quantity_available,
                reserved_quantity: cp.reserved_quantity,
                minimum_order_quantity: cp.minimum_order_quantity,
                harvest_date: cp.harvest_date,
                quality: cp.quality,
                organic: cp.organic,
                image_url: cp.image_url,
                description: cp.description,
                is_demo: cp.is_demo,
                created_at: cp.created_at
              }, cp.is_demo ? 'demo' : 'live'));

              // Normalize demo products
              const demoFormatted = MARKETPLACE_PRODUCTS.map((p) => normalizeProduct(p, 'demo'));

              // Merge: live first (priority), then demo fallback, deduplicate
              const merged = deduplicateById([...liveFormatted, ...demoFormatted]);
              setProducts(merged);

              setConnectionStatus('live');
              updateConnectionStatus(true);
            } else {
              // Supabase configured but no records — still use demo as baseline
              setProducts(MARKETPLACE_PRODUCTS.map((p) => normalizeProduct(p, 'demo')));
              setConnectionStatus('live');
              updateConnectionStatus(true);
            }
          }
        } catch (e) {
          console.warn('Supabase product fetch note:', e.message);
          if (isMounted) {
            setConnectionStatus('demo-fallback');
            updateConnectionStatus(false);
          }
        }
      }
    }

    loadHybridProducts();

    return () => {
      isMounted = false;
    };
  }, []);

  // Persist products to localStorage for offline readiness
  useEffect(() => {
    try {
      localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(products));
    } catch (err) {
      console.error('Error saving products to localStorage', err);
    }
  }, [products]);

  const getProducts = () => products;

  const getProduct = (id) => {
    return products.find((p) => String(p.id) === String(id));
  };

  const addProduct = async (newProductData, sellerProfileId) => {
    const newId = `p-${Date.now()}`;
    const productToAdd = normalizeProduct({
      id: newId,
      name: newProductData.name,
      hindiName: newProductData.hindiName || newProductData.name,
      category: newProductData.category || 'Vegetables',
      farmer: newProductData.farmer || 'Verified Producer',
      farmerId: sellerProfileId || newProductData.farmerId || null,
      farmerType: newProductData.farmerType || 'Individual Farmer',
      location: newProductData.location || 'Farm',
      state: newProductData.state || 'India',
      district: newProductData.district || '',
      approximateLocation: newProductData.approximateLocation || `Near ${newProductData.location || 'Farm'}, ${newProductData.state || 'India'}`,
      price: newProductData.price,
      typicalRetailPrice: newProductData.typicalRetailPrice,
      unit: newProductData.unit || 'kg',
      quantityAvailable: newProductData.quantityAvailable,
      reservedQuantity: 0,
      minimumOrderQuantity: newProductData.minimumOrderQuantity || 1,
      harvestDate: newProductData.harvestDate || 'Harvested Today',
      quality: newProductData.quality || 'Grade A',
      organic: newProductData.organic,
      distance: newProductData.distance || 'Local Farm Gate',
      image: newProductData.image,
      description: newProductData.description || 'Freshly harvested produce from our farm, graded and packed for direct delivery.'
    }, 'live'); // New user-created products are always 'live'

    // If Supabase is connected and sellerProfileId is known, insert to DB
    if (isSupabaseConfigured() && sellerProfileId) {
      try {
        const cloudRecord = await productService.createProduct({
          seller_profile_id: sellerProfileId,
          seller_type: newProductData.farmerType?.toLowerCase() === 'fpo' ? 'fpo' : 'farmer',
          name: newProductData.name,
          hindi_name: newProductData.hindiName || null,
          category: newProductData.category || 'Vegetables',
          description: newProductData.description,
          price: Number(newProductData.price),
          unit: newProductData.unit || 'kg',
          quantity_available: Number(newProductData.quantityAvailable),
          minimum_order_quantity: Number(newProductData.minimumOrderQuantity || 1),
          quality: newProductData.quality || 'Grade A',
          organic: Boolean(newProductData.organic),
          image_url: newProductData.image || null,
          is_active: true,
          is_demo: false
        });
        if (cloudRecord?.id) {
          productToAdd.id = cloudRecord.id;
        }
      } catch (err) {
        console.warn('Cloud product insert note:', err.message);
      }
    }

    setProducts((prev) => [productToAdd, ...prev]);
    return productToAdd;
  };

  const updateProduct = async (id, updatedFields) => {
    // Check if the product is a demo record — block core field modifications
    const target = products.find((p) => String(p.id) === String(id));
    if (target && isDemoRecord(target)) {
      // Allow only quantity changes on demo products for interaction; block name/price changes
      const safeFields = {};
      if (updatedFields.quantityAvailable !== undefined) {
        safeFields.quantityAvailable = Number(updatedFields.quantityAvailable);
      }
      if (Object.keys(safeFields).length === 0) {
        console.warn('Cannot modify core fields of demo products');
        return;
      }
      setProducts((prev) =>
        prev.map((p) => {
          if (String(p.id) === String(id)) {
            return { ...p, ...safeFields, updatedAt: new Date().toISOString() };
          }
          return p;
        })
      );
      return;
    }

    if (isSupabaseConfigured() && !String(id).startsWith('p-')) {
      try {
        await productService.updateProduct(id, {
          price: updatedFields.price !== undefined ? Number(updatedFields.price) : undefined,
          quantity_available: updatedFields.quantityAvailable !== undefined ? Number(updatedFields.quantityAvailable) : undefined,
          is_active: updatedFields.is_active !== undefined ? updatedFields.is_active : undefined
        });
      } catch (e) {
        console.warn('Cloud product update note:', e.message);
      }
    }

    setProducts((prev) =>
      prev.map((p) => {
        if (String(p.id) === String(id)) {
          return {
            ...p,
            ...updatedFields,
            price: updatedFields.price !== undefined ? Number(updatedFields.price) : p.price,
            quantityAvailable: updatedFields.quantityAvailable !== undefined ? Number(updatedFields.quantityAvailable) : p.quantityAvailable,
            updatedAt: new Date().toISOString()
          };
        }
        return p;
      })
    );
  };

  const deleteProduct = async (id) => {
    // Block deletion of demo products
    const target = products.find((p) => String(p.id) === String(id));
    if (target && isDemoRecord(target)) {
      console.warn('Cannot delete demo products — they are part of the baseline dataset');
      return false;
    }

    if (isSupabaseConfigured() && !String(id).startsWith('p-')) {
      try {
        await productService.deleteProduct(id);
      } catch (e) {
        console.warn('Cloud product delete note:', e.message);
      }
    }
    setProducts((prev) => prev.filter((p) => String(p.id) !== String(id)));
    return true;
  };

  const updateInventory = (id, newQuantity) => {
    updateProduct(id, { quantityAvailable: Math.max(0, Number(newQuantity)) });
  };

  /**
   * Safe reservation when an order is placed.
   * Decrements quantityAvailable and increments reservedQuantity.
   */
  const reserveInventory = (id, quantity) => {
    const qty = Number(quantity);
    const prod = products.find((p) => String(p.id) === String(id));
    if (!prod) return false;
    if (prod.quantityAvailable < qty) return false;

    setProducts((prev) =>
      prev.map((p) => {
        if (String(p.id) === String(id)) {
          return {
            ...p,
            quantityAvailable: Math.max(0, p.quantityAvailable - qty),
            reservedQuantity: (p.reservedQuantity || 0) + qty,
            updatedAt: new Date().toISOString()
          };
        }
        return p;
      })
    );
    return true;
  };

  /**
   * Finalize deduction when order is confirmed/dispatched.
   */
  const deductInventory = (id, quantity) => {
    const qty = Number(quantity);
    setProducts((prev) =>
      prev.map((p) => {
        if (String(p.id) === String(id)) {
          const newReserved = Math.max(0, (p.reservedQuantity || 0) - qty);
          return {
            ...p,
            reservedQuantity: newReserved,
            totalSold: (p.totalSold || 0) + qty,
            updatedAt: new Date().toISOString()
          };
        }
        return p;
      })
    );
  };

  /**
   * Release reserved inventory back to available stock upon order cancellation.
   */
  const releaseInventory = (id, quantity) => {
    const qty = Number(quantity);
    setProducts((prev) =>
      prev.map((p) => {
        if (String(p.id) === String(id)) {
          const newReserved = Math.max(0, (p.reservedQuantity || 0) - qty);
          return {
            ...p,
            quantityAvailable: p.quantityAvailable + qty,
            reservedQuantity: newReserved,
            updatedAt: new Date().toISOString()
          };
        }
        return p;
      })
    );
  };

  /**
   * Reset only demo products to defaults. Live products are preserved.
   */
  const resetToDefaultProducts = useCallback(() => {
    setProducts((prev) => {
      const liveProducts = prev.filter((p) => !isDemoRecord(p));
      const freshDemo = MARKETPLACE_PRODUCTS.map((p) => normalizeProduct(p, 'demo'));
      return deduplicateById([...liveProducts, ...freshDemo]);
    });
  }, []);

  return (
    <ProductContext.Provider
      value={{
        products,
        connectionStatus,
        getProducts,
        getProduct,
        addProduct,
        updateProduct,
        deleteProduct,
        updateInventory,
        reserveInventory,
        deductInventory,
        releaseInventory,
        resetToDefaultProducts
      }}
    >
      {children}
    </ProductContext.Provider>
  );
}

export function useProducts() {
  const context = useContext(ProductContext);
  if (!context) {
    throw new Error('useProducts must be used within a ProductProvider');
  }
  return context;
}
