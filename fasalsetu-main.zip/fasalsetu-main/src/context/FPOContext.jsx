/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useContext, useState } from 'react';
import { fpoService } from '../services/fpoService';
import { isSupabaseConfigured } from '../lib/supabase';

const FPOContext = createContext();

const FPO_STORAGE_KEY = 'fasalsetu_fpo_v1';

// Demo member farmers tagged for hybrid data architecture
const INITIAL_MEMBER_FARMERS = [
  {
    id: 'FPO-MB-101',
    name: 'Ramesh Kumar',
    village: 'Dankaur',
    district: 'Gautam Buddha Nagar',
    state: 'Uttar Pradesh',
    landSize: '4.5 Acres',
    products: ['Desi Tomatoes', 'Kufri Potatoes', 'Mustard Seed'],
    totalSupplied: '14.2 Tonnes',
    status: 'Active',
    joinedDate: 'Jan 2024',
    phone: '+91 98712 34567'
  },
  {
    id: 'FPO-MB-102',
    name: 'Suresh Chandra Sharma',
    village: 'Jewar',
    district: 'Gautam Buddha Nagar',
    state: 'Uttar Pradesh',
    landSize: '8.0 Acres',
    products: ['Sharbati Wheat', 'Mustard Oilseed', 'Barley'],
    totalSupplied: '22.8 Tonnes',
    status: 'Active',
    joinedDate: 'Feb 2024',
    phone: '+91 98111 22334'
  },
  {
    id: 'FPO-MB-103',
    name: 'Harpreet Singh Sandhu',
    village: 'Dadri',
    district: 'Gautam Buddha Nagar',
    state: 'Uttar Pradesh',
    landSize: '12.5 Acres',
    products: ['Basmati Paddy', 'Green Peas', 'Cauliflower'],
    totalSupplied: '31.5 Tonnes',
    status: 'Active',
    joinedDate: 'Mar 2024',
    phone: '+91 99222 33445'
  },
  {
    id: 'FPO-MB-104',
    name: 'Mahesh Verma',
    village: 'Bilaspur',
    district: 'Gautam Buddha Nagar',
    state: 'Uttar Pradesh',
    landSize: '3.0 Acres',
    products: ['Spinach', 'Coriander', 'Methi Leaves'],
    totalSupplied: '6.4 Tonnes',
    status: 'Active',
    joinedDate: 'May 2024',
    phone: '+91 98450 11223'
  },
  {
    id: 'FPO-MB-105',
    name: 'Babu Lal Yadav',
    village: 'Rabupura',
    district: 'Gautam Buddha Nagar',
    state: 'Uttar Pradesh',
    landSize: '5.2 Acres',
    products: ['Red Onion', 'Garlic', 'Green Chilli'],
    totalSupplied: '11.0 Tonnes',
    status: 'Pending',
    joinedDate: 'Aug 2024',
    phone: '+91 97123 99887'
  },
  {
    id: 'FPO-MB-106',
    name: 'Ramphal Chaudhary',
    village: 'Chhajarsi',
    district: 'Hapur',
    state: 'Uttar Pradesh',
    landSize: '6.8 Acres',
    products: ['Sugarcane Jaggery', 'Organic Bajra'],
    totalSupplied: '9.8 Tonnes',
    status: 'Inactive',
    joinedDate: 'Nov 2023',
    phone: '+91 98990 44556'
  }
].map(m => ({ ...m, source: 'demo', isDemo: true }));

const INITIAL_FPO_LOCATIONS = [
  {
    id: 'FPO-LOC-1',
    name: 'Dankaur Central Aggregation Center',
    district: 'Gautam Buddha Nagar',
    state: 'Uttar Pradesh',
    farmers: 42,
    produce: 'Vegetables, Tomatoes, Spinach, Dairy',
    status: 'Primary Hub',
    verified: true,
    latitude: 28.352,
    longitude: 77.55
  },
  {
    id: 'FPO-LOC-2',
    name: 'Jewar Grain & Mustard Collection Yard',
    district: 'Gautam Buddha Nagar',
    state: 'Uttar Pradesh',
    farmers: 38,
    produce: 'Wheat, Mustard, Pulses, Barley',
    status: 'Operational',
    verified: true,
    latitude: 28.131,
    longitude: 77.556
  },
  {
    id: 'FPO-LOC-3',
    name: 'Dadri Eastern Cooperative Hub',
    district: 'Gautam Buddha Nagar',
    state: 'Uttar Pradesh',
    farmers: 26,
    produce: 'Paddy, Green Peas, Leafy Greens',
    status: 'Operational',
    verified: true,
    latitude: 28.553,
    longitude: 77.555
  },
  {
    id: 'FPO-LOC-4',
    name: 'Yamuna Expressway Cold Transit Staging',
    district: 'Greater Noida',
    state: 'Uttar Pradesh',
    farmers: 18,
    produce: 'Grade-A Fresh Retail Crates',
    status: 'Logistics Staging',
    verified: true,
    latitude: 28.468,
    longitude: 77.502
  }
];

const INITIAL_AGGREGATED_INVENTORY = [
  {
    crop: 'Wheat (Sharbati & Lokwan)',
    totalQuantity: 8500,
    available: 6200,
    reserved: 2300,
    avgPrice: 28,
    farmersCount: 32,
    unit: 'kg'
  },
  {
    crop: 'Desi Country Tomatoes',
    totalQuantity: 4200,
    available: 3100,
    reserved: 1100,
    avgPrice: 26,
    farmersCount: 24,
    unit: 'kg'
  },
  {
    crop: 'Kufri Jyoti Potatoes',
    totalQuantity: 6800,
    available: 5400,
    reserved: 1400,
    avgPrice: 22,
    farmersCount: 19,
    unit: 'kg'
  },
  {
    crop: 'Red Onion (Nashik Special)',
    totalQuantity: 3400,
    available: 2600,
    reserved: 800,
    avgPrice: 25,
    farmersCount: 15,
    unit: 'kg'
  },
  {
    crop: 'Yellow Mustard Seed',
    totalQuantity: 1700,
    available: 1350,
    reserved: 350,
    avgPrice: 62,
    farmersCount: 18,
    unit: 'kg'
  }
];

export function FPOProvider({ children }) {
  const [fpoData, setFpoData] = useState(() => {
    try {
      const saved = localStorage.getItem(FPO_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.memberFarmers) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Failed to load FPO data from localStorage:', e);
    }
    return {
      fpoName: 'Kisan Vikas Producer Co. Ltd.',
      registrationNumber: 'U01409UP2022PTC168924',
      totalMembersCount: 124,
      totalFarmLocationsCount: 18,
      activeProduceCount: 42,
      totalSalesFormatted: '₹8.4L',
      totalProduceFormatted: '24.6 Tonnes',
      memberFarmers: INITIAL_MEMBER_FARMERS,
      farmLocations: INITIAL_FPO_LOCATIONS,
      aggregatedInventory: INITIAL_AGGREGATED_INVENTORY
    };
  });

  const saveFPOData = (updated) => {
    setFpoData(updated);
    try {
      localStorage.setItem(FPO_STORAGE_KEY, JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to persist FPO data:', e);
    }
  };

  const addMemberFarmer = async (farmer, fpoProfileId) => {
    if (isSupabaseConfigured() && fpoProfileId) {
      try {
        await fpoService.addMember(fpoProfileId, farmer);
      } catch (e) {
        console.warn('Supabase addMember note:', e.message);
      }
    }

    const newFarmer = {
      id: `FPO-MB-${100 + fpoData.memberFarmers.length + 1}`,
      joinedDate: 'Just now',
      totalSupplied: '0.0 Tonnes',
      status: 'Active',
      ...farmer
    };
    const updated = {
      ...fpoData,
      totalMembersCount: fpoData.totalMembersCount + 1,
      memberFarmers: [newFarmer, ...fpoData.memberFarmers]
    };
    saveFPOData(updated);
    return newFarmer;
  };

  const addFarmLocation = (loc) => {
    const newLoc = {
      id: `FPO-LOC-${fpoData.farmLocations.length + 1}`,
      status: 'Operational',
      verified: true,
      ...loc
    };
    const updated = {
      ...fpoData,
      totalFarmLocationsCount: fpoData.totalFarmLocationsCount + 1,
      farmLocations: [...fpoData.farmLocations, newLoc]
    };
    saveFPOData(updated);
    return newLoc;
  };

  return (
    <FPOContext.Provider
      value={{
        ...fpoData,
        addMemberFarmer,
        addFarmLocation
      }}
    >
      {children}
    </FPOContext.Provider>
  );
}

export function useFPO() {
  const context = useContext(FPOContext);
  if (!context) {
    throw new Error('useFPO must be used within an FPOProvider');
  }
  return context;
}
