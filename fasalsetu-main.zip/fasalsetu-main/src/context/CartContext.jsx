/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useContext, useState, useEffect } from 'react';

const CartContext = createContext();

const CART_STORAGE_KEY = 'fasalsetu_cart_v1';

export function CartProvider({ children }) {
  const [cartItems, setCartItems] = useState(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch (err) {
      console.error('Error loading cart from localStorage', err);
      return [];
    }
  });

  // Persist to localStorage whenever cartItems changes
  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cartItems));
    } catch (err) {
      console.error('Error saving cart to localStorage', err);
    }
  }, [cartItems]);

  const addItem = (product, quantity = 1) => {
    const qty = Math.max(1, parseInt(quantity, 10) || 1);
    setCartItems((prevItems) => {
      const existingIndex = prevItems.findIndex((item) => item.id === product.id);
      if (existingIndex > -1) {
        const updated = [...prevItems];
        const newQty = updated[existingIndex].quantity + qty;
        // Cap at available quantity if known
        const maxQty = product.quantityAvailable || 10000;
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: Math.min(newQty, maxQty)
        };
        return updated;
      }
      return [
        ...prevItems,
        {
          id: product.id,
          name: product.name,
          hindiName: product.hindiName,
          price: product.price,
          typicalRetailPrice: product.typicalRetailPrice || Math.round(product.price * 1.35),
          unit: product.unit || 'kg',
          farmer: product.farmer || 'Local Producer',
          farmerId: product.farmerId || 'farmer_1',
          farmerType: product.farmerType || 'Farmer',
          fpoId: product.fpoId || (product.farmerType === 'FPO' ? 'fpo_1' : null),
          location: product.location || 'Western UP',
          farmLocation: product.approximateLocation || product.location || 'Western UP Farm Cluster',
          latitude: product.latitude,
          longitude: product.longitude,
          image: product.image,
          category: product.category,
          quality: product.quality,
          organic: product.organic,
          quantity: Math.min(qty, product.quantityAvailable || 10000),
          quantityAvailable: product.quantityAvailable,
          // Hybrid data architecture: track product source
          source: product.source || 'demo',
          isDemo: Boolean(product.isDemo)
        }
      ];
    });
  };

  const removeItem = (productId) => {
    setCartItems((prevItems) => prevItems.filter((item) => item.id !== productId));
  };

  const updateQuantity = (productId, quantity) => {
    const qty = parseInt(quantity, 10);
    if (qty <= 0) {
      removeItem(productId);
      return;
    }
    setCartItems((prevItems) =>
      prevItems.map((item) => {
        if (item.id === productId) {
          const maxQty = item.quantityAvailable || 10000;
          return { ...item, quantity: Math.min(qty, maxQty) };
        }
        return item;
      })
    );
  };

  const increaseQuantity = (productId, delta = 1) => {
    setCartItems((prevItems) =>
      prevItems.map((item) => {
        if (item.id === productId) {
          const maxQty = item.quantityAvailable || 10000;
          return { ...item, quantity: Math.min(item.quantity + (delta || 1), maxQty) };
        }
        return item;
      })
    );
  };

  const decreaseQuantity = (productId, delta = 1) => {
    setCartItems((prevItems) =>
      prevItems
        .map((item) => {
          if (item.id === productId) {
            const newQty = item.quantity - (delta || 1);
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean)
    );
  };

  const clearCart = () => {
    setCartItems([]);
  };

  // Calculations
  const totalQuantity = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const totalUniqueItems = cartItems.length;

  const subtotal = cartItems.reduce(
    (acc, item) => acc + item.price * item.quantity,
    0
  );

  const typicalRetailTotal = cartItems.reduce(
    (acc, item) => acc + (item.typicalRetailPrice || item.price * 1.35) * item.quantity,
    0
  );

  const totalSavings = Math.max(0, typicalRetailTotal - subtotal);

  // Delivery fee model for Noida/Gr. Noida
  // Free delivery for cart > ₹500, else flat ₹35 EV delivery charge
  const deliveryFee = subtotal === 0 ? 0 : subtotal >= 500 ? 0 : 35;
  const grandTotal = subtotal + deliveryFee;

  const estimatedDelivery = subtotal > 0 ? 'Same-Day Evening Dispatch (Within 4-6 Hours)' : null;

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addItem,
        removeItem,
        updateQuantity,
        increaseQuantity,
        decreaseQuantity,
        clearCart,
        totalQuantity,
        totalUniqueItems,
        subtotal,
        typicalRetailTotal,
        totalSavings,
        deliveryFee,
        grandTotal,
        estimatedDelivery
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);

  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
