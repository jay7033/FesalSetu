/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useContext, useState } from 'react';
import { buyerService } from '../services/buyerService';
import { isSupabaseConfigured } from '../lib/supabase';

const BuyerContext = createContext();

const BUYER_STORAGE_KEY = 'fasalsetu_buyers_v1';
const SAVED_PRODUCTS_KEY = 'fasalsetu_saved_products_v1';

const INITIAL_PREFERRED_LOCATIONS = [
  { id: 'pref_1', city: 'Gautam Buddha Nagar', state: 'Uttar Pradesh', distance: '12-30 km', activeHub: true },
  { id: 'pref_2', city: 'Meerut', state: 'Uttar Pradesh', distance: '65 km', activeHub: true },
  { id: 'pref_3', city: 'Nashik', state: 'Maharashtra', distance: 'Interstate Bulk', activeHub: false }
].map(l => ({ ...l, source: 'demo', isDemo: true }));

const INITIAL_BULK_CROPS = [
  {
    id: 'crop_wheat',
    crop: 'Wheat (Sharbati & Lokwan)',
    availableTonnes: 18.5,
    priceRange: '₹26 – ₹30/kg',
    minOrder: '500 kg',
    suppliersCount: 23,
    peakSeason: 'Current Harvest',
    category: 'Grains & Cereals'
  },
  {
    id: 'crop_rice',
    crop: '1121 Basmati Rice (Paddy/Milled)',
    availableTonnes: 12.0,
    priceRange: '₹38 – ₹45/kg',
    minOrder: '1,000 kg',
    suppliersCount: 16,
    peakSeason: 'Post-Harvest Batch',
    category: 'Grains & Cereals'
  },
  {
    id: 'crop_potato',
    crop: 'Kufri Jyoti Cold-Storage Potato',
    availableTonnes: 24.0,
    priceRange: '₹16 – ₹20/kg',
    minOrder: '500 kg',
    suppliersCount: 19,
    peakSeason: 'Direct Cold Vault',
    category: 'Tubers & Roots'
  },
  {
    id: 'crop_onion',
    crop: 'Red Onion (Grade-A Sorting)',
    availableTonnes: 15.5,
    priceRange: '₹22 – ₹28/kg',
    minOrder: '250 kg',
    suppliersCount: 14,
    peakSeason: 'Available',
    category: 'Alliums'
  },
  {
    id: 'crop_tomato',
    crop: 'Desi Hybrid Red Tomatoes',
    availableTonnes: 8.2,
    priceRange: '₹24 – ₹30/kg',
    minOrder: '200 kg',
    suppliersCount: 11,
    peakSeason: 'Daily Pluck',
    category: 'Fresh Vegetables'
  },
  {
    id: 'crop_maize',
    crop: 'Yellow Feed & Food Maize',
    availableTonnes: 14.0,
    priceRange: '₹19 – ₹23/kg',
    minOrder: '1,000 kg',
    suppliersCount: 9,
    peakSeason: 'Available',
    category: 'Grains & Cereals'
  },
  {
    id: 'crop_pulses',
    crop: 'Organic Chana & Moong Dal',
    availableTonnes: 9.5,
    priceRange: '₹72 – ₹85/kg',
    minOrder: '200 kg',
    suppliersCount: 15,
    peakSeason: 'Sun Dried',
    category: 'Pulses'
  }
].map(c => ({ ...c, source: 'demo', isDemo: true }));

const INITIAL_SUPPLIERS = [
  {
    id: 'sup_1',
    name: 'Kisan Vikas Producer Co. Ltd.',
    type: 'FPO Cluster',
    location: 'Near Dankaur, Greater Noida',
    state: 'Uttar Pradesh',
    produce: 'Tomatoes, Potatoes, Wheat, Mustard',
    availableQty: '24.6 Tonnes',
    price: '₹22 – ₹28/kg',
    distance: '18 km',
    rating: 4.9,
    ordersCompleted: 142
  },
  {
    id: 'sup_2',
    name: 'Ramesh Kumar (Individual Farmer)',
    type: 'Direct Farm Producer',
    location: 'Near Jewar Cluster',
    state: 'Uttar Pradesh',
    produce: 'Desi Tomatoes, Red Carrots',
    availableQty: '1.8 Tonnes',
    price: '₹24 – ₹26/kg',
    distance: '24 km',
    rating: 4.8,
    ordersCompleted: 36
  },
  {
    id: 'sup_3',
    name: 'Yamuna Valley Agro Producers',
    type: 'FPO Collective',
    location: 'Near Dadri Eastern Corridor',
    state: 'Uttar Pradesh',
    produce: 'Basmati Paddy, Green Peas, Spinach',
    availableQty: '16.5 Tonnes',
    price: '₹32 – ₹42/kg',
    distance: '22 km',
    rating: 4.9,
    ordersCompleted: 88
  },
  {
    id: 'sup_4',
    name: 'Suresh Chandra Sharma',
    type: 'Direct Farm Producer',
    location: 'Near Rabupura',
    state: 'Uttar Pradesh',
    produce: 'Sharbati Wheat, Mustard Oilseed',
    availableQty: '8.4 Tonnes',
    price: '₹28/kg',
    distance: '31 km',
    rating: 4.7,
    ordersCompleted: 19
  }
].map(s => ({ ...s, source: 'demo', isDemo: true }));

const INITIAL_PRICE_COMPARISON = [
  {
    produce: 'Sharbati Wheat',
    farmPrice: 28,
    mandiPrice: 33,
    retailPrice: 42,
    unit: 'kg',
    savingsPct: 33,
    savingsPerTon: '₹14,000'
  },
  {
    produce: 'Desi Tomatoes',
    farmPrice: 26,
    mandiPrice: 34,
    retailPrice: 48,
    unit: 'kg',
    savingsPct: 45,
    savingsPerTon: '₹22,000'
  },
  {
    produce: 'Kufri Potatoes',
    farmPrice: 20,
    mandiPrice: 25,
    retailPrice: 32,
    unit: 'kg',
    savingsPct: 37,
    savingsPerTon: '₹12,000'
  },
  {
    produce: 'Red Onions',
    farmPrice: 24,
    mandiPrice: 30,
    retailPrice: 38,
    unit: 'kg',
    savingsPct: 36,
    savingsPerTon: '₹14,000'
  },
  {
    produce: 'Basmati Paddy/Rice',
    farmPrice: 42,
    mandiPrice: 52,
    retailPrice: 70,
    unit: 'kg',
    savingsPct: 40,
    savingsPerTon: '₹28,000'
  }
].map(p => ({ ...p, source: 'demo', isDemo: true }));

export function BuyerProvider({ children }) {
  const [savedProductIds, setSavedProductIds] = useState(() => {
    try {
      const saved = localStorage.getItem(SAVED_PRODUCTS_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load saved products:', e);
    }
    return ['1', '3', '7']; // Default bookmarked demo product IDs
  });

  const [preferredLocations, setPreferredLocations] = useState(() => {
    try {
      const saved = localStorage.getItem(BUYER_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.preferredLocations) return parsed.preferredLocations;
      }
    } catch (e) {
      console.error('Failed to load buyer preferences:', e);
    }
    return INITIAL_PREFERRED_LOCATIONS;
  });

  const toggleSaveProduct = async (productId, consumerProfileId) => {
    if (isSupabaseConfigured() && consumerProfileId) {
      try {
        await buyerService.toggleSavedProduct(consumerProfileId, productId);
      } catch (e) {
        console.warn('Supabase toggleSavedProduct note:', e.message);
      }
    }

    setSavedProductIds((prev) => {
      const strId = String(productId);
      const next = prev.includes(strId) ? prev.filter((id) => id !== strId) : [...prev, strId];
      try {
        localStorage.setItem(SAVED_PRODUCTS_KEY, JSON.stringify(next));
      } catch (e) {
        console.error('Failed to save favorites to localStorage:', e);
      }
      return next;
    });
  };

  const isProductSaved = (productId) => {
    return savedProductIds.includes(String(productId));
  };

  const addPreferredLocation = (location) => {
    const newLoc = {
      id: `pref_${Date.now()}`,
      activeHub: true,
      source: 'live',
      isDemo: false,
      ...location
    };
    const next = [...preferredLocations, newLoc];
    setPreferredLocations(next);
    try {
      localStorage.setItem(BUYER_STORAGE_KEY, JSON.stringify({ preferredLocations: next }));
    } catch (e) {
      console.error('Failed to save preferred locations:', e);
    }
  };

  const removePreferredLocation = (id) => {
    const next = preferredLocations.filter((l) => l.id !== id);
    setPreferredLocations(next);
    try {
      localStorage.setItem(BUYER_STORAGE_KEY, JSON.stringify({ preferredLocations: next }));
    } catch (e) {
      console.error('Failed to save preferred locations:', e);
    }
  };

  return (
    <BuyerContext.Provider
      value={{
        savedProductIds,
        toggleSaveProduct,
        isProductSaved,
        preferredLocations,
        addPreferredLocation,
        removePreferredLocation,
        bulkProduceCrops: INITIAL_BULK_CROPS,
        suppliersList: INITIAL_SUPPLIERS,
        priceComparisonData: INITIAL_PRICE_COMPARISON
      }}
    >
      {children}
    </BuyerContext.Provider>
  );
}

export function useBuyer() {
  const context = useContext(BuyerContext);
  if (!context) {
    throw new Error('useBuyer must be used within a BuyerProvider');
  }
  return context;
}
