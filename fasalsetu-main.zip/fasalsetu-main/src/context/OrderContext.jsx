/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useContext, useState, useEffect } from 'react';
import { INITIAL_DEMO_ORDERS } from '../data/demoData';
import { useProducts } from './ProductContext';
import { useNotifications } from './NotificationContext';
import { useAuth } from './AuthContext';
import { ORDER_LIFECYCLE_STEPS, VALID_STATUS_TRANSITIONS } from '../constants/orderStatus';
import { orderService } from '../services/orderService';
import { isSupabaseConfigured } from '../lib/supabase';
import { isDemoRecord } from '../services/hybridDataService';

export { ORDER_LIFECYCLE_STEPS, VALID_STATUS_TRANSITIONS };

const OrderContext = createContext();

const ORDERS_STORAGE_KEY = 'fasalsetu_orders_v1';

// Seed initial orders enriched with buyerRole and multi-supplier fulfillment details
const SEED_ORDERS = INITIAL_DEMO_ORDERS.map((ord, idx) => ({
  id: ord.id || `FS${1024 - idx}`,
  buyerId: idx % 2 === 0 ? 'e4444444-4444-4444-8444-444444444444' : 'e3333333-3333-4333-8333-333333333333',
  buyerName: ord.buyer,
  buyerRole: idx % 2 === 0 ? 'bulk_buyer' : 'consumer',
  farmerId: 'e1111111-1111-4111-8111-111111111111',
  farmerName: 'Ramesh Kumar',
  fpoId: 'e2222222-2222-4222-8222-222222222222',
  fpoName: 'Kisan Samriddhi Producer Co. Ltd.',
  farmLocationId: 'f1111111-1111-1111-1111-111111111111',
  product: ord.product,
  items: [
    {
      id: `it-${idx}-1`,
      productId: '11111111-1111-1111-1111-111111111111',
      name: ord.product,
      quantity: ord.quantity,
      unit: ord.unit || 'kg',
      price: Math.round(ord.amount / ord.quantity),
      subtotal: ord.amount,
      farmerId: 'e1111111-1111-4111-8111-111111111111',
      farmerName: 'Ramesh Kumar',
      farmLocation: ord.location
    }
  ],
  fulfillments: [
    {
      supplierId: 'e1111111-1111-4111-8111-111111111111',
      supplierName: 'Ramesh Kumar',
      supplierType: 'Farmer',
      status: ord.status,
      farmLocation: ord.location,
      items: [
        {
          name: ord.product,
          quantity: ord.quantity,
          unit: ord.unit || 'kg',
          price: Math.round(ord.amount / ord.quantity),
          subtotal: ord.amount
        }
      ]
    }
  ],
  quantity: ord.quantity,
  unit: ord.unit || 'kg',
  subtotal: ord.amount,
  deliveryFee: ord.quantity > 50 ? 0 : 35,
  savings: Math.round(ord.amount * 0.25),
  total: ord.amount + (ord.quantity > 50 ? 0 : 35),
  amount: ord.amount,
  status: ord.status,
  deliveryType: 'delivery',
  deliveryEstimate: 'Today within 4-6 hours',
  buyerLocation: {
    address: ord.location,
    city: 'Noida',
    district: 'Gautam Buddha Nagar',
    state: 'Uttar Pradesh'
  },
  location: ord.location,
  date: ord.date || 'Today, 08:00 AM',
  createdAt: new Date(Date.now() - idx * 3600 * 1000 * 12).toISOString(),
  updatedAt: new Date().toISOString(),
  paymentMethod: 'Cash on Delivery',
  paymentStatus: ord.paymentStatus || 'Escrow Secured',
  timeline: [
    { status: 'Pending', timestamp: new Date(Date.now() - idx * 3600 * 1000 * 12).toISOString(), note: 'Order Placed by Buyer' },
    ...(ord.status !== 'Pending' ? [{ status: 'Confirmed', timestamp: new Date(Date.now() - idx * 3600 * 1000 * 10).toISOString(), note: 'Confirmed by Farmer' }] : []),
    ...(ord.status === 'Preparing' || ord.status === 'Ready for Pickup' || ord.status === 'Picked Up' || ord.status === 'In Transit' || ord.status === 'Delivered' ? [{ status: 'Preparing', timestamp: new Date(Date.now() - idx * 3600 * 1000 * 8).toISOString(), note: 'Fresh Harvest Graded and Packed' }] : []),
    ...(ord.status === 'Ready for Pickup' || ord.status === 'Picked Up' || ord.status === 'In Transit' || ord.status === 'Delivered' ? [{ status: 'Ready for Pickup', timestamp: new Date(Date.now() - idx * 3600 * 1000 * 5).toISOString(), note: 'Sealed for Farm-Gate Pickup' }] : []),
    ...(ord.status === 'Picked Up' || ord.status === 'In Transit' || ord.status === 'Delivered' ? [{ status: 'Picked Up', timestamp: new Date(Date.now() - idx * 3600 * 1000 * 3).toISOString(), note: 'Picked up by Hyperlocal EV Courier' }] : []),
    ...(ord.status === 'In Transit' || ord.status === 'Delivered' ? [{ status: 'In Transit', timestamp: new Date(Date.now() - idx * 3600 * 1000 * 1).toISOString(), note: 'Transit via Yamuna Expressway' }] : []),
    ...(ord.status === 'Delivered' ? [{ status: 'Delivered', timestamp: new Date().toISOString(), note: 'Delivered at Doorstep' }] : [])
  ],
  // Hybrid data architecture: tag demo orders
  source: 'demo',
  isDemo: true
}));

export function OrderProvider({ children }) {
  const { user, isDemo } = useAuth();
  const { reserveInventory, deductInventory, releaseInventory } = useProducts();
  const { addNotification } = useNotifications();

  const [orders, setOrders] = useState(() => {
    try {
      const saved = localStorage.getItem(ORDERS_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Failed to load orders from localStorage:', e);
    }
    return SEED_ORDERS;
  });

  // Hydrate orders for the authenticated user from Supabase
  useEffect(() => {
    let isMounted = true;

    async function loadUserOrders() {
      if (!isSupabaseConfigured() || !user?.id) {
        if (!user || isDemo) {
          setOrders(SEED_ORDERS);
        } else {
          setOrders([]);
        }
        return;
      }

      try {
        let cloudOrders = null;
        if (user.role === 'farmer' || user.role === 'fpo') {
          const fulfillments = await orderService.getOrdersForSeller(user.id);
          if (fulfillments && fulfillments.length > 0) {
            cloudOrders = fulfillments.map((f) => {
              const baseOrd = f.orders || {};
              return {
                id: f.order_id || f.id,
                orderNumber: baseOrd.order_number || `FS-${f.id.slice(0, 6)}`,
                buyerId: baseOrd.buyer_profile_id,
                buyerRole: baseOrd.buyer_role || 'consumer',
                farmerId: f.seller_profile_id,
                farmerName: user.name,
                status: f.status || baseOrd.status || 'Pending',
                total: Number(baseOrd.total) || 0,
                amount: Number(baseOrd.total) || 0,
                date: baseOrd.created_at ? new Date(baseOrd.created_at).toLocaleDateString() : 'Today',
                createdAt: baseOrd.created_at || f.created_at,
                updatedAt: f.updated_at || baseOrd.created_at,
                items: (baseOrd.order_items || []).map((it) => ({
                  id: it.id,
                  productId: it.product_id,
                  name: it.product_name,
                  quantity: Number(it.quantity),
                  unit: it.unit,
                  price: Number(it.price),
                  subtotal: Number(it.subtotal)
                })),
                fulfillments: [f],
                source: baseOrd.is_demo ? 'demo' : 'live',
                isDemo: Boolean(baseOrd.is_demo)
              };
            });
          }
        } else {
          const rawOrders = await orderService.getOrdersForBuyer(user.id);
          if (rawOrders && rawOrders.length > 0) {
            cloudOrders = rawOrders.map((o) => ({
              id: o.id,
              orderNumber: o.order_number,
              buyerId: o.buyer_profile_id,
              buyerRole: o.buyer_role,
              status: o.status,
              total: Number(o.total),
              amount: Number(o.total),
              subtotal: Number(o.subtotal),
              deliveryFee: Number(o.delivery_fee),
              date: o.created_at ? new Date(o.created_at).toLocaleDateString() : 'Today',
              createdAt: o.created_at,
              updatedAt: o.updated_at,
              items: (o.order_items || []).map((it) => ({
                id: it.id,
                productId: it.product_id,
                name: it.product_name,
                quantity: Number(it.quantity),
                unit: it.unit,
                price: Number(it.price),
                subtotal: Number(it.subtotal),
                farmLocation: it.farm_location_label
              })),
              fulfillments: o.order_fulfillments || [],
              timeline: (o.order_timeline || []).map((t) => ({
                status: t.status,
                timestamp: t.created_at,
                note: t.note
              })),
              source: o.is_demo ? 'demo' : 'live',
              isDemo: Boolean(o.is_demo)
            }));
          }
        }

        if (isMounted) {
          if (cloudOrders && cloudOrders.length > 0) {
            if (isDemo) {
              setOrders([...cloudOrders, ...SEED_ORDERS.filter((s) => !cloudOrders.some((c) => c.id === s.id))]);
            } else {
              setOrders(cloudOrders);
            }
          } else if (isDemo) {
            setOrders(SEED_ORDERS);
          } else {
            setOrders([]);
          }
        }
      } catch (err) {
        console.warn('Load user orders note:', err.message);
        if (isMounted && isDemo) {
          setOrders(SEED_ORDERS);
        }
      }
    }

    loadUserOrders();

    return () => {
      isMounted = false;
    };
  }, [user, isDemo]);

  // Subscribe to Supabase Realtime order status changes
  useEffect(() => {
    let sub = null;
    if (isSupabaseConfigured()) {
      sub = orderService.subscribeToOrderUpdates((payload) => {
        if (payload?.new && payload.new.id) {
          const updatedRow = payload.new;
          setOrders((prev) =>
            prev.map((o) => {
              if (o.id === updatedRow.id || o.id === updatedRow.order_number) {
                return {
                  ...o,
                  status: updatedRow.status,
                  updatedAt: updatedRow.updated_at
                };
              }
              return o;
            })
          );
        }
      });
    }

    return () => {
      if (sub?.unsubscribe) sub.unsubscribe();
    };
  }, []);

  const saveOrders = (updatedOrders) => {
    setOrders(updatedOrders);
    try {
      localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(updatedOrders));
    } catch (e) {
      console.error('Failed to save orders to localStorage:', e);
    }
  };

  /**
   * Helper to check if a transition is valid according to sequential lifecycle rules.
   */
  const canTransitionStatus = (currentStatus, targetStatus) => {
    const validTargets = VALID_STATUS_TRANSITIONS[currentStatus] || [];
    return validTargets.includes(targetStatus);
  };

  /**
   * Update order status following strict sequential rules.
   * Interlocks with inventory and dispatches notifications.
   */
  const updateOrderStatus = async (orderId, newStatus, note = '') => {
    const targetOrder = orders.find((o) => o.id === orderId);
    if (!targetOrder) return { success: false, error: 'Order not found' };

    // Check transition validity
    if (!canTransitionStatus(targetOrder.status, newStatus)) {
      return {
        success: false,
        error: `Cannot transition order from "${targetOrder.status}" directly to "${newStatus}". Please follow the sequential fulfillment stages.`
      };
    }

    // Call Supabase RPC if configured and valid UUID
    if (isSupabaseConfigured() && targetOrder.id && !targetOrder.id.startsWith('FS') && !targetOrder.id.startsWith('PO')) {
      try {
        await orderService.updateOrderStatus(targetOrder.id, newStatus, targetOrder.farmerId || targetOrder.buyerId, note);
      } catch (rpcErr) {
        console.warn('Supabase updateOrderStatus note:', rpcErr.message);
      }
    }

    const updatedTimelineItem = {
      status: newStatus,
      timestamp: new Date().toISOString(),
      note: note || `Status updated to ${newStatus}`
    };

    // Inventory effect:
    // If order confirmed or delivered, deduct reserved stock permanently
    if (newStatus === 'Delivered' || (newStatus === 'Confirmed' && targetOrder.status === 'Pending')) {
      targetOrder.items.forEach((it) => {
        if (it.productId) deductInventory(it.productId, it.quantity);
      });
    }

    // If order cancelled, release inventory back to available
    if (newStatus === 'Cancelled') {
      targetOrder.items.forEach((it) => {
        if (it.productId) releaseInventory(it.productId, it.quantity);
      });
    }

    const updatedOrders = orders.map((order) => {
      if (order.id === orderId) {
        return {
          ...order,
          status: newStatus,
          updatedAt: new Date().toISOString(),
          timeline: [...(order.timeline || []), updatedTimelineItem],
          fulfillments: (order.fulfillments || []).map((f) => ({ ...f, status: newStatus }))
        };
      }
      return order;
    });

    saveOrders(updatedOrders);

    // Trigger Notification for Consumer & Supplier
    addNotification({
      type: `order_${newStatus.toLowerCase().replace(/\s+/g, '_')}`,
      title: `Order #${orderId} ${newStatus}`,
      message: `Your order status has changed to ${newStatus}.`,
      recipientRole: targetOrder.buyerRole || 'consumer',
      orderId
    });

    return { success: true };
  };

  /**
   * Create a new order (Consumer checkout or Bulk Buyer PO).
   * Supports multi-supplier items grouped into fulfillments.
   */
  const createOrder = async (orderData) => {
    const prefix = orderData.buyerRole === 'bulk_buyer' ? 'PO' : 'FS';
    const newId = `${prefix}${1040 + orders.length}`;

    // Group items by supplier for multi-farmer fulfillment architecture
    const fulfillmentsMap = {};
    const items = orderData.items || [];

    items.forEach((item) => {
      const supplierKey = item.farmerName || item.fpoName || 'FasalSetu Producer Hub';
      if (!fulfillmentsMap[supplierKey]) {
        fulfillmentsMap[supplierKey] = {
          supplierId: item.farmerId || item.fpoId || 'supp_1',
          supplierName: supplierKey,
          supplierType: item.fpoName ? 'FPO Cluster' : 'Farmer',
          farmLocation: item.farmLocation || 'Western UP Cluster',
          status: 'Pending',
          items: []
        };
      }
      fulfillmentsMap[supplierKey].items.push(item);

      // Safe inventory reservation
      if (item.productId) {
        reserveInventory(item.productId, item.quantity);
      }
    });

    const fulfillments = Object.values(fulfillmentsMap);

    const newOrder = {
      id: newId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      date: 'Just now',
      status: orderData.status || 'Pending',
      paymentMethod: orderData.paymentMethod || 'Cash on Delivery',
      paymentStatus: orderData.paymentMethod === 'Demo Online Payment' ? 'Paid (Escrow Secured)' : 'Pay on Delivery',
      deliveryType: orderData.deliveryType || 'delivery',
      deliveryEstimate: orderData.deliveryEstimate || 'Next Day (Within 24 Hours)',
      fulfillments,
      timeline: [
        {
          status: 'Pending',
          timestamp: new Date().toISOString(),
          note: 'Order successfully placed by buyer'
        }
      ],
      ...orderData,
      items,
      // Tag as live (user-created) order
      source: 'live',
      isDemo: false
    };

    // If Supabase is configured and buyerId is a valid UUID, attempt cloud RPC
    if (isSupabaseConfigured() && orderData.buyerId && orderData.buyerId.includes('-')) {
      try {
        const cloudOrder = await orderService.createOrder({
          buyerId: orderData.buyerId,
          buyerRole: orderData.buyerRole || 'consumer',
          deliveryType: orderData.deliveryType || 'delivery',
          paymentMethod: orderData.paymentMethod || 'cod',
          deliveryAddress: orderData.deliveryAddress || orderData.buyerLocation?.address,
          deliveryEstimate: orderData.deliveryEstimate,
          items: items.map((it) => ({
            id: it.productId || it.id,
            quantity: it.quantity
          }))
        });

        if (cloudOrder?.order_number) {
          newOrder.id = cloudOrder.order_number;
          newOrder.cloudId = cloudOrder.id;
        }
      } catch (err) {
        console.warn('Cloud order transaction note:', err.message);
      }
    }

    const updated = [newOrder, ...orders];
    saveOrders(updated);

    // Notify Farmers & FPOs of incoming order
    addNotification({
      type: 'order_received',
      title: 'New Order Received',
      message: `${newOrder.buyerName || 'Buyer'} placed Order #${newOrder.id} for ${newOrder.product || `${items.length} items`}.`,
      recipientRole: 'farmer',
      orderId: newOrder.id
    });

    // Notify Consumer
    addNotification({
      type: 'order_created',
      title: 'Order Placed Successfully',
      message: `Your Order #${newOrder.id} is placed and sent to the producers for confirmation.`,
      recipientRole: newOrder.buyerRole || 'consumer',
      orderId: newOrder.id
    });

    return newOrder;
  };

  /**
   * Consumer / Bulk Buyer Order Cancellation
   * Allowed only for 'Pending' or 'Confirmed' orders.
   */
  const cancelOrder = async (orderId, reason = 'Buyer requested cancellation') => {
    const target = orders.find((o) => o.id === orderId);
    if (!target) return { success: false, error: 'Order not found' };

    if (target.status !== 'Pending' && target.status !== 'Confirmed') {
      return {
        success: false,
        error: `Order cannot be cancelled in "${target.status}" state as packing or transit has already started.`
      };
    }

    // Block cancellation of demo orders (they are illustrative baseline)
    if (isDemoRecord(target)) {
      return {
        success: false,
        error: 'Demo orders are part of the baseline dataset and cannot be cancelled.'
      };
    }

    // Call Supabase cancel RPC if online
    if (isSupabaseConfigured() && target.cloudId) {
      try {
        await orderService.cancelOrder(target.cloudId, target.buyerId, reason);
      } catch (e) {
        console.warn('Cloud cancellation note:', e.message);
      }
    }

    // Release inventory back
    target.items.forEach((it) => {
      if (it.productId) releaseInventory(it.productId, it.quantity);
    });

    const updated = orders.map((o) => {
      if (o.id === orderId) {
        return {
          ...o,
          status: 'Cancelled',
          cancellationReason: reason,
          updatedAt: new Date().toISOString(),
          timeline: [
            ...(o.timeline || []),
            {
              status: 'Cancelled',
              timestamp: new Date().toISOString(),
              note: `Cancelled: ${reason}`
            }
          ]
        };
      }
      return o;
    });

    saveOrders(updated);

    addNotification({
      type: 'order_cancelled',
      title: `Order #${orderId} Cancelled`,
      message: `Order #${orderId} was cancelled (${reason}).`,
      recipientRole: 'farmer',
      orderId
    });

    return { success: true };
  };

  const getOrderById = (orderId) => {
    return orders.find((o) => o.id === orderId || o.order_number === orderId);
  };

  const getOrdersByRole = (role, entityNameOrId) => {
    if (role === 'farmer') {
      return orders.filter((o) => {
        if (!entityNameOrId) return true;
        return (
          o.farmerId === entityNameOrId ||
          o.farmerName === entityNameOrId ||
          (o.fulfillments && o.fulfillments.some((f) => f.supplierName === entityNameOrId || f.supplierId === entityNameOrId))
        );
      });
    }
    if (role === 'fpo') {
      return orders.filter((o) => {
        if (!entityNameOrId) return true;
        return (
          o.fpoId === entityNameOrId ||
          o.fpoName === entityNameOrId ||
          (o.fulfillments && o.fulfillments.some((f) => f.supplierType === 'FPO Cluster'))
        );
      });
    }
    if (role === 'consumer') {
      return orders.filter((o) => o.buyerRole === 'consumer');
    }
    if (role === 'bulk_buyer') {
      return orders.filter((o) => o.buyerRole === 'bulk_buyer');
    }
    return orders;
  };

  /**
   * Reset only demo orders to defaults. Live orders are preserved.
   */
  const resetOrders = () => {
    setOrders((prev) => {
      const liveOrders = prev.filter((o) => !isDemoRecord(o));
      return [...liveOrders, ...SEED_ORDERS];
    });
    try {
      localStorage.removeItem(ORDERS_STORAGE_KEY);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <OrderContext.Provider
      value={{
        orders,
        getOrderById,
        updateOrderStatus,
        createOrder,
        cancelOrder,
        canTransitionStatus,
        getOrdersByRole,
        resetOrders
      }}
    >
      {children}
    </OrderContext.Provider>
  );
}

export function useOrders() {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error('useOrders must be used within an OrderProvider');
  }
  return context;
}
