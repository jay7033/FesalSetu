/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { reverseGeocode } from '../services/geocoding';
import { getCurrentPosition, handleLocationError } from '../services/geolocation';
import { locationService } from '../services/locationService';
import { isSupabaseConfigured } from '../lib/supabase';
import { useAuth } from './AuthContext';

const LocationContext = createContext();

const FARM_LOCATIONS_STORAGE_KEY = 'fasalsetu_farm_locations_v2';
const BUYER_LOCATION_STORAGE_KEY = 'fasalsetu_buyer_location_v1';

const INITIAL_DEMO_FARM_LOCATIONS = [
  {
    id: 'farm-loc-1',
    name: 'Dankaur Production Farm',
    latitude: 28.3512,
    longitude: 77.5510,
    accuracy: 35,
    village: 'Dankaur',
    locality: 'Dankaur Mandi Road',
    city: 'Greater Noida',
    district: 'Gautam Buddha Nagar',
    state: 'Uttar Pradesh',
    stateCode: 'UP',
    pincode: '203201',
    country: 'India',
    countryCode: 'IN',
    formattedAddress: 'Dankaur Mandi Road, Dankaur, Greater Noida, Gautam Buddha Nagar, Uttar Pradesh - 203201',
    approximateLocation: 'Near Dankaur, Greater Noida',
    source: 'demo',
    isDemo: true,
    isDefault: true,
    capturedAt: '2026-03-01T08:00:00.000Z'
  },
  {
    id: 'farm-loc-2',
    name: 'Jewar Agricultural Cluster',
    latitude: 28.1294,
    longitude: 77.5559,
    accuracy: 50,
    village: 'Jewar',
    locality: 'Yamuna Expressway Agro Belt',
    city: 'Jewar',
    district: 'Gautam Buddha Nagar',
    state: 'Uttar Pradesh',
    stateCode: 'UP',
    pincode: '203135',
    country: 'India',
    countryCode: 'IN',
    formattedAddress: 'Yamuna Expressway Agro Belt, Jewar, Gautam Buddha Nagar, Uttar Pradesh - 203135',
    approximateLocation: 'Near Jewar, Uttar Pradesh',
    source: 'demo',
    isDemo: true,
    isDefault: false,
    capturedAt: '2026-03-01T08:00:00.000Z'
  }
];

export function LocationProvider({ children }) {
  const { user, isDemo } = useAuth();

  // 1. Multiple Farm Locations for Farmer / FPO
  const [farmLocations, setFarmLocations] = useState(() => {
    try {
      const saved = localStorage.getItem(FARM_LOCATIONS_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
      return INITIAL_DEMO_FARM_LOCATIONS;
    } catch {
      return INITIAL_DEMO_FARM_LOCATIONS;
    }
  });

  // Hydrate farm locations for authenticated farmer/FPO from Supabase
  useEffect(() => {
    let isMounted = true;

    async function loadUserLocations() {
      if (!isSupabaseConfigured() || !user?.id) {
        if (!user || isDemo) {
          setFarmLocations(INITIAL_DEMO_FARM_LOCATIONS);
        } else {
          setFarmLocations([]);
        }
        return;
      }

      try {
        if (user.role === 'farmer' || user.role === 'fpo') {
          const cloudLocations = await locationService.getFarmLocations(user.id);
          if (isMounted) {
            if (cloudLocations && cloudLocations.length > 0) {
              const formatted = cloudLocations.map((loc) => ({
                id: loc.id,
                name: loc.farm_title || 'Primary Farm Plot',
                latitude: Number(loc.latitude),
                longitude: Number(loc.longitude),
                accuracy: Number(loc.accuracy) || null,
                village: loc.village,
                locality: loc.locality,
                city: loc.city,
                district: loc.district,
                state: loc.state,
                stateCode: loc.state_code,
                pincode: loc.pincode,
                formattedAddress: loc.formatted_address,
                approximateLocation: loc.approximate_location || `Near ${loc.city || loc.district}, ${loc.state}`,
                source: loc.source || 'gps',
                isDefault: Boolean(loc.is_default),
                isDemo: Boolean(loc.is_demo)
              }));
              setFarmLocations(formatted);
            } else if (isDemo) {
              setFarmLocations(INITIAL_DEMO_FARM_LOCATIONS);
            } else {
              setFarmLocations([]);
            }
          }
        }
      } catch (err) {
        console.warn('Load farm locations note:', err.message);
      }
    }

    loadUserLocations();

    return () => {
      isMounted = false;
    };
  }, [user, isDemo]);

  // Current active / working location detection state (for registration or adding new location)
  const [activeDetectedLocation, setActiveDetectedLocation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [permissionStatus, setPermissionStatus] = useState('prompt'); // 'prompt' | 'granted' | 'denied'

  // 2. Buyer Location State
  const [buyerLocation, setBuyerLocation] = useState(() => {
    try {
      const saved = localStorage.getItem(BUYER_LOCATION_STORAGE_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [buyerLoading, setBuyerLoading] = useState(false);
  const [buyerError, setBuyerError] = useState(null);

  // Sync farm locations to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(FARM_LOCATIONS_STORAGE_KEY, JSON.stringify(farmLocations));
    } catch (e) {
      console.error('Failed to persist farm locations', e);
    }
  }, [farmLocations]);

  // Sync buyer location to localStorage
  useEffect(() => {
    if (buyerLocation) {
      try {
        localStorage.setItem(BUYER_LOCATION_STORAGE_KEY, JSON.stringify(buyerLocation));
      } catch (e) {
        console.error('Failed to persist buyer location', e);
      }
    }
  }, [buyerLocation]);

  // Default Farm Location (Single source of truth for products and profile)
  const defaultFarmLocation = useMemo(() => {
    return farmLocations.find((loc) => loc.isDefault) || farmLocations[0] || null;
  }, [farmLocations]);

  // Alias `location` to defaultFarmLocation for backwards compatibility
  const location = defaultFarmLocation;

  /**
   * Request Current GPS Location (Farmer explicitly clicks [USE MY CURRENT LOCATION])
   */
  const requestCurrentLocation = async (customOptions = {}) => {
    setLoading(true);
    setError(null);

    try {
      const position = await getCurrentPosition(customOptions);
      setPermissionStatus('granted');

      let geocoded = null;
      try {
        geocoded = await reverseGeocode(position.latitude, position.longitude);
      } catch {
        // Fallback when geocoder is unreachable
        geocoded = {
          village: '',
          locality: '',
          city: 'Local Area',
          district: 'District',
          state: 'India',
          stateCode: 'IN',
          pincode: '',
          country: 'India',
          countryCode: 'IN',
          formattedAddress: `Coordinates: ${position.latitude.toFixed(4)}, ${position.longitude.toFixed(4)}`,
          approximateLocation: `Near GPS (${position.latitude.toFixed(2)}°N, ${position.longitude.toFixed(2)}°E)`
        };
      }

      const detected = {
        id: `farm-loc-${Date.now()}`,
        name: `${geocoded.city || geocoded.district || 'New'} Farm Location`,
        latitude: position.latitude,
        longitude: position.longitude,
        accuracy: Math.round(position.accuracy),
        ...geocoded,
        source: 'device',
        isDefault: farmLocations.length === 0,
        capturedAt: new Date().toISOString()
      };

      setActiveDetectedLocation(detected);
      setLoading(false);
      return detected;
    } catch (err) {
      setLoading(false);
      const friendlyMsg = handleLocationError(err);
      if (err.code === 1) setPermissionStatus('denied');
      setError(friendlyMsg);
      throw new Error(friendlyMsg);
    }
  };

  /**
   * Set a manual location fallback (Country, State, District, City, Village, Pincode)
   */
  const setManualLocation = (manualData) => {
    const manualLoc = {
      id: `farm-loc-${Date.now()}`,
      name: manualData.name || `${manualData.city || manualData.district || 'Manual'} Farm`,
      latitude: Number(manualData.latitude) || 28.5355,
      longitude: Number(manualData.longitude) || 77.3910,
      accuracy: 500,
      village: manualData.village || '',
      locality: manualData.locality || '',
      city: manualData.city || manualData.district || 'City',
      district: manualData.district || 'District',
      state: manualData.state || 'Uttar Pradesh',
      stateCode: manualData.stateCode || '',
      pincode: manualData.pincode || '',
      country: manualData.country || 'India',
      countryCode: 'IN',
      formattedAddress: [
        manualData.village,
        manualData.city,
        manualData.district,
        manualData.state,
        manualData.pincode
      ].filter(Boolean).join(', '),
      approximateLocation: `Near ${manualData.city || manualData.district || 'Farm'}, ${manualData.state || 'India'}`,
      source: 'manual',
      isDefault: farmLocations.length === 0,
      capturedAt: new Date().toISOString()
    };

    setActiveDetectedLocation(manualLoc);
    setError(null);
    return manualLoc;
  };

  /**
   * Confirm Location and save it into the list of Farm Locations
   */
  const confirmLocation = (locationToConfirm = null) => {
    const target = locationToConfirm || activeDetectedLocation;
    if (!target) return null;

    const confirmed = {
      ...target,
      confirmed: true,
      capturedAt: new Date().toISOString()
    };

    setFarmLocations((prev) => {
      // If this is set to default, unset others
      const isFirst = prev.length === 0;
      const willBeDefault = target.isDefault || isFirst;

      const updated = prev.map((loc) => ({
        ...loc,
        isDefault: willBeDefault ? false : loc.isDefault
      }));

      // Check if updating existing
      const existingIdx = updated.findIndex((l) => l.id === confirmed.id);
      if (existingIdx >= 0) {
        updated[existingIdx] = { ...confirmed, isDefault: willBeDefault };
        return updated;
      } else {
        return [{ ...confirmed, isDefault: willBeDefault }, ...updated];
      }
    });

    setActiveDetectedLocation(null);
    return confirmed;
  };

  /**
   * Add a new Farm Location
   */
  const addFarmLocation = async (newLocation, ownerProfileId) => {
    const effectiveOwnerId = ownerProfileId || user?.id;
    if (isSupabaseConfigured() && effectiveOwnerId) {
      try {
        await locationService.addFarmLocation({
          owner_profile_id: effectiveOwnerId,
          owner_type: 'farmer',
          farm_title: newLocation.name || 'Primary Farm Plot',
          latitude: newLocation.latitude,
          longitude: newLocation.longitude,
          accuracy: newLocation.accuracy || null,
          village: newLocation.village || null,
          locality: newLocation.locality || null,
          city: newLocation.city || null,
          district: newLocation.district || 'Gautam Buddha Nagar',
          state: newLocation.state || 'Uttar Pradesh',
          formatted_address: newLocation.formattedAddress || 'Farm Plot',
          source: newLocation.source || 'gps',
          is_default: Boolean(newLocation.isDefault)
        });
      } catch (e) {
        console.warn('Supabase addFarmLocation note:', e.message);
      }
    }

    const locWithId = {
      id: newLocation.id || `farm-loc-${Date.now()}`,
      name: newLocation.name || `Farm Location ${farmLocations.length + 1}`,
      isDefault: Boolean(newLocation.isDefault || farmLocations.length === 0),
      capturedAt: new Date().toISOString(),
      source: 'live',
      isDemo: false,
      ...newLocation
    };

    setFarmLocations((prev) => {
      if (locWithId.isDefault) {
        return [locWithId, ...prev.map((l) => ({ ...l, isDefault: false }))];
      }
      return [...prev, locWithId];
    });

    return locWithId;
  };

  /**
   * Update an existing Farm Location
   */
  const updateFarmLocation = (id, updates) => {
    setFarmLocations((prev) =>
      prev.map((loc) => {
        if (loc.id === id) {
          return { ...loc, ...updates };
        }
        if (updates.isDefault) {
          return { ...loc, isDefault: false };
        }
        return loc;
      })
    );
  };

  /**
   * Delete a Farm Location
   */
  const deleteFarmLocation = (id) => {
    // Block deletion of demo locations
    const target = farmLocations.find((loc) => loc.id === id);
    if (target && (target.isDemo || target.source === 'demo')) {
      console.warn('Cannot delete demo farm locations — they are part of the baseline dataset');
      return;
    }

    setFarmLocations((prev) => {
      if (prev.length <= 1) return prev; // Keep at least one location
      const filtered = prev.filter((loc) => loc.id !== id);
      // If deleted location was default, make first remaining default
      const wasDefault = prev.find((loc) => loc.id === id)?.isDefault;
      if (wasDefault && filtered.length > 0) {
        filtered[0].isDefault = true;
      }
      return filtered;
    });
  };

  /**
   * Set a Farm Location as Default
   */
  const setDefaultFarmLocation = (id) => {
    setFarmLocations((prev) =>
      prev.map((loc) => ({
        ...loc,
        isDefault: loc.id === id
      }))
    );
  };

  /**
   * Clear active detected location
   */
  const clearLocation = () => {
    setActiveDetectedLocation(null);
    setError(null);
  };

  /**
   * Request Buyer Location (For "Deliver to my location" / "Find produce near me")
   */
  const requestBuyerLocation = async () => {
    setBuyerLoading(true);
    setBuyerError(null);

    try {
      const position = await getCurrentPosition({ timeout: 10000 });
      let geocoded = null;
      try {
        geocoded = await reverseGeocode(position.latitude, position.longitude);
      } catch {
        geocoded = {
          village: '',
          city: 'Current Location',
          district: 'District',
          state: 'India',
          formattedAddress: `Coordinates: ${position.latitude.toFixed(4)}, ${position.longitude.toFixed(4)}`,
          approximateLocation: 'Near Current GPS Position'
        };
      }

      const buyerLoc = {
        latitude: position.latitude,
        longitude: position.longitude,
        accuracy: Math.round(position.accuracy),
        locality: geocoded.locality || geocoded.village || '',
        city: geocoded.city,
        district: geocoded.district,
        state: geocoded.state,
        formattedAddress: geocoded.formattedAddress,
        approximateLocation: geocoded.approximateLocation,
        isSet: true
      };

      setBuyerLocation(buyerLoc);
      setBuyerLoading(false);
      return buyerLoc;
    } catch (err) {
      setBuyerLoading(false);
      const msg = handleLocationError(err);
      setBuyerError(msg);
      throw new Error(msg);
    }
  };

  const clearBuyerLocation = () => {
    setBuyerLocation(null);
    setBuyerError(null);
    try {
      localStorage.removeItem(BUYER_LOCATION_STORAGE_KEY);
    } catch {
      // ignore
    }
  };

  const value = {
    // Farm Locations & Default
    farmLocations,
    defaultFarmLocation,
    location, // Alias to defaultFarmLocation for backwards compatibility
    activeDetectedLocation,
    loading,
    error,
    permissionStatus,

    // Detection & Confirmation
    requestCurrentLocation,
    reverseGeocode,
    setManualLocation,
    confirmLocation,
    clearLocation,

    // Multiple Farm Location Management
    addFarmLocation,
    updateFarmLocation,
    deleteFarmLocation,
    setDefaultFarmLocation,

    // Buyer location
    buyerLocation,
    buyerLoading,
    buyerError,
    requestBuyerLocation,
    clearBuyerLocation
  };

  return (
    <LocationContext.Provider value={value}>
      {children}
    </LocationContext.Provider>
  );
}

export function useLocation() {
  const context = useContext(LocationContext);
  if (!context) {
    throw new Error('useLocation must be used within a LocationProvider');
  }
  return context;
}
