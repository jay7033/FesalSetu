/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { logisticsService } from '../services/logistics/logisticsService';
import { shipmentService } from '../services/logistics/shipmentService';
import { pickupService } from '../services/logistics/pickupService';
import { useNotifications } from './NotificationContext';
import { useOrders } from './OrderContext';

const LogisticsContext = createContext(null);

export function LogisticsProvider({ children }) {
  const { addNotification } = useNotifications();
  const { orders } = useOrders();

  const [routes, setRoutes] = useState([]);
  const [shipments, setShipments] = useState([]);
  const [pickupSchedules, setPickupSchedules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Load logistics data
  const loadLogisticsData = useCallback(async (isRefresh = false) => {
    try {
      if (isRefresh) setRefreshing(true);
      const [fetchedRoutes, fetchedShipments, fetchedPickups] = await Promise.all([
        logisticsService.getRoutes(),
        logisticsService.getShipments(),
        logisticsService.getPickupSchedules()
      ]);

      // Tag routes/shipments/pickups with hybrid source
      const tagDemoRecords = (records) => (records || []).map(r => ({
        ...r,
        source: r.source || 'demo',
        isDemo: r.isDemo !== undefined ? r.isDemo : true
      }));

      setRoutes(tagDemoRecords(fetchedRoutes));
      setShipments(tagDemoRecords(fetchedShipments));
      setPickupSchedules(tagDemoRecords(fetchedPickups));
    } catch (err) {
      console.error('Failed to load logistics records:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    let isMounted = true;
    async function init() {
      try {
        const [fetchedRoutes, fetchedShipments, fetchedPickups] = await Promise.all([
          logisticsService.getRoutes(),
          logisticsService.getShipments(),
          logisticsService.getPickupSchedules()
        ]);
        if (isMounted) {
          const tagDemoInit = (records) => (records || []).map(r => ({
            ...r,
            source: r.source || 'demo',
            isDemo: r.isDemo !== undefined ? r.isDemo : true
          }));
          setRoutes(tagDemoInit(fetchedRoutes));
          setShipments(tagDemoInit(fetchedShipments));
          setPickupSchedules(tagDemoInit(fetchedPickups));
          setLoading(false);
        }
      } catch (err) {
        console.error('Failed to load logistics records:', err);
        if (isMounted) setLoading(false);
      }
    }
    init();
    return () => {
      isMounted = false;
    };
  }, []);

  // Create an optimized route plan
  const createRoutePlan = useCallback(({
    fulfillments = [],
    origin,
    destination,
    vehicleType = 'Small Truck'
  }) => {
    const newRoute = logisticsService.planRouteFromFulfillments({
      fulfillments,
      origin,
      destination,
      vehicleType
    });

    setRoutes((prev) => [newRoute, ...prev]);

    // Create corresponding shipments for each fulfillment
    fulfillments.forEach((ful) => {
      const newShipment = shipmentService.createShipment({
        orderId: ful.orderId || 'FS1024',
        fulfillmentId: ful.id || 'ful-1',
        routeId: newRoute.id,
        supplierName: ful.supplierName,
        buyerName: ful.buyerName || 'Buyer',
        destinationCity: destination?.city || 'Noida',
        quantity: ful.quantity || 50
      });
      setShipments((prev) => [newShipment, ...prev]);
    });

    addNotification({
      title: 'New Collection Route Created',
      message: `Route ${newRoute.routeNumber} planned: ${newRoute.stops.length} stops, ~${newRoute.totalDistanceKm} km.`,
      type: 'logistics'
    });

    return newRoute;
  }, [addNotification]);

  // Update Shipment Status
  const updateShipmentStatus = useCallback((shipmentId, targetStatus) => {
    setShipments((prev) => {
      const target = prev.find((s) => s.id === shipmentId || s.trackingNumber === shipmentId);
      if (!target) return prev;

      const result = shipmentService.advanceStatus(target, targetStatus);
      if (!result.success) {
        console.warn(result.error);
        return prev;
      }

      addNotification({
        title: `Shipment ${result.shipment.trackingNumber}`,
        message: `Status updated to ${targetStatus.replace(/_/g, ' ')}.`,
        type: 'logistics'
      });

      return prev.map((s) => (s.id === shipmentId || s.trackingNumber === shipmentId ? result.shipment : s));
    });
  }, [addNotification]);

  // Schedule a Producer Pickup
  const schedulePickup = useCallback((params) => {
    const newSchedule = pickupService.createSchedule(params);
    setPickupSchedules((prev) => [newSchedule, ...prev]);

    addNotification({
      title: 'Farm Pickup Scheduled',
      message: `Pickup for ${params.quantity || 50} kg scheduled at ${newSchedule.timeWindowFormatted}.`,
      type: 'logistics'
    });

    return newSchedule;
  }, [addNotification]);

  // Update Pickup Status
  const updatePickupStatus = useCallback((scheduleId, targetStatus) => {
    setPickupSchedules((prev) => {
      const target = prev.find((p) => p.id === scheduleId);
      if (!target) return prev;

      const result = pickupService.advanceStatus(target, targetStatus);
      if (!result.success) {
        console.warn(result.error);
        return prev;
      }

      return prev.map((p) => (p.id === scheduleId ? result.schedule : p));
    });
  }, []);

  // Update Route Status
  const updateRouteStatus = useCallback((routeId, targetStatus) => {
    setRoutes((prev) => {
      const target = prev.find((r) => r.id === routeId || r.routeNumber === routeId);
      if (!target) return prev;

      const result = logisticsService.advanceRouteStatus(target, targetStatus);
      if (!result.success) {
        console.warn(result.error);
        return prev;
      }

      return prev.map((r) => (r.id === routeId || r.routeNumber === routeId ? result.route : r));
    });
  }, []);

  // Query helpers for role dashboards
  const getShipmentByOrderId = useCallback((orderId) => {
    if (!orderId) return null;
    return shipments.find(
      (s) => s.orderId === orderId || s.orderNumber === orderId || s.orderNumber === `FS-${orderId}`
    ) || shipments[0] || null;
  }, [shipments]);

  const getFarmerPickups = useCallback((farmerName) => {
    if (!farmerName) return pickupSchedules;
    return pickupSchedules.filter(
      (p) => !p.farmerName || p.farmerName.toLowerCase().includes(farmerName.toLowerCase())
    );
  }, [pickupSchedules]);

  const getFPOOperations = useCallback((fpoName) => {
    const todayPickups = pickupSchedules.length;
    const activeRoutesCount = routes.filter((r) => r.status === 'PLANNED' || r.status === 'IN_PROGRESS').length;
    const totalVolume = routes.reduce((acc, r) => acc + (Number(r.totalLoad) || 0), 0);
    const avgUtilization = routes.length > 0
      ? Math.round(routes.reduce((acc, r) => acc + ((r.totalLoad / r.vehicleCapacity) * 100), 0) / routes.length)
      : 75;

    return {
      fpoName,
      todayPickups,
      activeRoutesCount,
      totalVolume,
      avgUtilization,
      routes,
      pickupSchedules
    };
  }, [pickupSchedules, routes]);

  const getBulkBuyerShipments = useCallback((buyerName) => {
    return shipments.filter(
      (s) => !buyerName || !s.buyerName || s.buyerName.toLowerCase().includes(buyerName.toLowerCase())
    );
  }, [shipments]);

  // Overall Logistics KPIs
  const kpis = useMemo(() => {
    const activeRoutesCount = routes.filter((r) => r.status === 'PLANNED' || r.status === 'IN_PROGRESS').length;
    const todayShipmentsCount = shipments.length;
    const pendingPickupsCount = pickupSchedules.filter((p) => p.status === 'SCHEDULED' || p.status === 'PENDING').length;
    const totalFleetLoad = routes.reduce((acc, r) => acc + (Number(r.totalLoad) || 0), 0);
    const totalDistanceSaved = routes.reduce((acc, r) => acc + (Number(r.distanceSavedKm) || 0), 0);
    const avgDistanceReduction = routes.length > 0
      ? Math.round(routes.reduce((acc, r) => acc + (Number(r.percentSaved) || 0), 0) / routes.length)
      : 24;

    return {
      activeRoutesCount,
      todayShipmentsCount,
      pendingPickupsCount,
      totalFleetLoad,
      totalDistanceSaved: Math.round(totalDistanceSaved * 10) / 10,
      avgDistanceReduction
    };
  }, [routes, shipments, pickupSchedules]);

  const value = {
    routes,
    shipments,
    pickupSchedules,
    kpis,
    loading,
    refreshing,
    orders,
    refreshLogistics: () => loadLogisticsData(true),
    createRoutePlan,
    updateShipmentStatus,
    schedulePickup,
    updatePickupStatus,
    updateRouteStatus,
    getShipmentByOrderId,
    getFarmerPickups,
    getFPOOperations,
    getBulkBuyerShipments
  };

  return <LogisticsContext.Provider value={value}>{children}</LogisticsContext.Provider>;
}

export function useLogistics() {
  const context = useContext(LogisticsContext);
  if (!context) {
    throw new Error('useLogistics must be used within a LogisticsProvider');
  }
  return context;
}
