/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useContext, useState } from 'react';
import { notificationService } from '../services/notificationService';
import { isSupabaseConfigured } from '../lib/supabase';

const NotificationContext = createContext();

const NOTIFICATIONS_STORAGE_KEY = 'fasalsetu_notifications_v1';

const INITIAL_NOTIFICATIONS = [
  {
    id: 'notif_1',
    type: 'order_received',
    title: 'New Order Received',
    message: 'Consumer ordered 100 kg Desi Country Tomatoes (Order #FS1024).',
    recipientRole: 'farmer',
    orderId: 'FS1024',
    read: false,
    createdAt: new Date(Date.now() - 3600 * 1000 * 2).toISOString(),
    timeAgo: '2h ago'
  },
  {
    id: 'notif_2',
    type: 'order_confirmed',
    title: 'Order Confirmed',
    message: 'Farmer Ramesh Kumar has confirmed your Order #FS1024. Packing in progress.',
    recipientRole: 'consumer',
    orderId: 'FS1024',
    read: false,
    createdAt: new Date(Date.now() - 3600 * 1000).toISOString(),
    timeAgo: '1h ago'
  },
  {
    id: 'notif_3',
    type: 'order_transit',
    title: 'Order In Transit',
    message: 'Order #FS1024 is out for delivery via Yamuna Expressway EV corridor.',
    recipientRole: 'consumer',
    orderId: 'FS1024',
    read: true,
    createdAt: new Date(Date.now() - 1800 * 1000).toISOString(),
    timeAgo: '30m ago'
  },
  {
    id: 'notif_4',
    type: 'bulk_po',
    title: 'Bulk PO Submitted',
    message: 'FreshMart Institutional placed a 500 kg Wheat procurement request.',
    recipientRole: 'fpo',
    orderId: 'FS1020',
    read: false,
    createdAt: new Date(Date.now() - 7200 * 1000).toISOString(),
    timeAgo: '2h ago'
  }
];

export function NotificationProvider({ children }) {
  const [notifications, setNotifications] = useState(() => {
    try {
      const saved = localStorage.getItem(NOTIFICATIONS_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Failed to load notifications from localStorage:', e);
    }
    return INITIAL_NOTIFICATIONS;
  });

  const saveNotifications = (updated) => {
    setNotifications(updated);
    try {
      localStorage.setItem(NOTIFICATIONS_STORAGE_KEY, JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to persist notifications:', e);
    }
  };

  const addNotification = ({ type, title, message, recipientRole, orderId, recipientProfileId }) => {
    const newNotif = {
      id: `notif_${Date.now()}`,
      type: type || 'order_update',
      title: title || 'Order Update',
      message,
      recipientRole: recipientRole || 'all',
      recipientProfileId: recipientProfileId || null,
      orderId,
      read: false,
      createdAt: new Date().toISOString(),
      timeAgo: 'Just now'
    };

    const updated = [newNotif, ...notifications];
    saveNotifications(updated);
    return newNotif;
  };

  const markAsRead = async (id) => {
    if (isSupabaseConfigured() && !String(id).startsWith('notif_')) {
      try {
        await notificationService.markAsRead(id);
      } catch (e) {
        console.warn('Supabase markAsRead note:', e.message);
      }
    }
    const updated = notifications.map((n) => (n.id === id ? { ...n, read: true } : n));
    saveNotifications(updated);
  };

  const markAllAsRead = async (role) => {
    const updated = notifications.map((n) => {
      if (!role || n.recipientRole === role || n.recipientRole === 'all') {
        return { ...n, read: true };
      }
      return n;
    });
    saveNotifications(updated);
  };

  const getNotificationsForRole = (role) => {
    if (!role) return notifications;
    return notifications.filter(
      (n) => n.recipientRole === role || n.recipientRole === 'all'
    );
  };

  const unreadCountForRole = (role) => {
    return getNotificationsForRole(role).filter((n) => !n.read).length;
  };

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        addNotification,
        markAsRead,
        markAllAsRead,
        getNotificationsForRole,
        unreadCountForRole
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
}
