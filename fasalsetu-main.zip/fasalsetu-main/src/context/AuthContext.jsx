/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useContext, useState, useEffect } from 'react';
import { authService } from '../services/authService';
import { isSupabaseConfigured } from '../lib/supabase';

const AuthContext = createContext();

const AUTH_STORAGE_KEY = 'fasalsetu_auth_v1';

// Pre-seeded demo user accounts (for hackathon evaluation convenience & fallback)
// Tagged isDemo: true for hybrid data architecture identification
export const DEMO_ACCOUNTS = {
  farmer: {
    id: 'e1111111-1111-4111-8111-111111111111',
    name: 'Ramesh Kumar',
    entityName: 'Green Valley Natural Farms',
    email: 'farmer@fasalsetu.demo',
    phone: '+91 98765 43210',
    role: 'farmer',
    farmerType: 'Individual Farmer',
    location: 'Dankaur, Greater Noida, UP',
    createdAt: '2026-01-15T08:00:00.000Z',
    isDemo: true,
    source: 'demo'
  },
  fpo: {
    id: 'e2222222-2222-4222-8222-222222222222',
    name: 'Kisan Samriddhi Producer Co.',
    entityName: 'Kisan Samriddhi FPO',
    email: 'fpo@fasalsetu.demo',
    phone: '+91 98111 22334',
    role: 'fpo',
    farmerType: 'Farmer Producer Organization',
    location: 'Jewar, Gautam Buddha Nagar, UP',
    memberCount: 240,
    registrationNo: 'FPO-UP-2024-8921',
    createdAt: '2026-01-10T10:30:00.000Z',
    isDemo: true,
    source: 'demo'
  },
  consumer: {
    id: 'e3333333-3333-4333-8333-333333333333',
    name: 'Priya Sharma',
    entityName: 'Personal Household',
    email: 'consumer@fasalsetu.demo',
    phone: '+91 99222 33445',
    role: 'consumer',
    location: 'Sector 62, Noida, UP',
    society: 'Gaur City 2',
    createdAt: '2026-02-01T14:20:00.000Z',
    isDemo: true,
    source: 'demo'
  },
  bulk_buyer: {
    id: 'e4444444-4444-4444-8444-444444444444',
    name: 'Arun Verma',
    entityName: 'FreshMart Urban Supermarkets',
    email: 'bulkbuyer@fasalsetu.demo',
    phone: '+91 97333 44556',
    role: 'bulk_buyer',
    businessType: 'Retail Chain & Apartment Bulk Aggregator',
    location: 'Greater Noida West, UP',
    gstin: '09AAACH7409R1ZZ',
    createdAt: '2026-01-20T11:00:00.000Z',
    isDemo: true,
    source: 'demo'
  },
  logistics_head: {
    id: 'usr-head-north-01',
    name: 'Vikramaditya Singhania',
    entityName: 'North India Logistics Command',
    email: 'head@fasalsetu.demo',
    phone: '+91 98100 11223',
    role: 'logistics_head',
    regionId: 'north',
    regionName: 'North India Command',
    location: 'Expressway Tower, Sector 128, Noida',
    createdAt: '2026-01-01T06:00:00.000Z',
    isDemo: true,
    source: 'demo'
  },
  delivery_assigner: {
    id: 'usr-assigner-north-a',
    name: 'Raj Kumar',
    entityName: 'Zone A Operations Coordination',
    email: 'assigner.north.a@fasalsetu.demo',
    phone: '+91 98110 22331',
    role: 'delivery_assigner',
    regionId: 'north',
    zoneId: 'zone-north-a',
    zoneName: 'Zone A - Greater Noida West',
    location: 'Gaur City Cluster Hub, Greater Noida West',
    createdAt: '2026-01-05T07:30:00.000Z',
    isDemo: true,
    source: 'demo'
  },
  delivery_boy: {
    id: 'db-north-001',
    name: 'Ravi Kumar',
    entityName: 'Zone A Rapid Fleet',
    email: 'delivery.ravi@fasalsetu.demo',
    phone: '+91 98700 00001',
    role: 'delivery_boy',
    regionId: 'north',
    zoneId: 'zone-north-a',
    zoneName: 'Zone A - Greater Noida West',
    vehicleType: 'EV_SCOOTER',
    vehicleCapacityKg: 35,
    location: 'Sector 16C, Greater Noida West',
    createdAt: '2026-01-12T09:00:00.000Z',
    isDemo: true,
    source: 'demo'
  }
};

/**
 * Returns the default dashboard path for any given role
 */
export function getRoleDashboardPath(role) {
  switch (role) {
    case 'farmer':
      return '/farmer/dashboard';
    case 'fpo':
      return '/fpo/dashboard';
    case 'consumer':
      return '/consumer/dashboard';
    case 'bulk_buyer':
      return '/bulk-buyer/dashboard';
    case 'logistics_head':
      return '/logistics';
    case 'delivery_assigner':
      return '/logistics/zone';
    case 'delivery_boy':
      return '/delivery/dashboard';
    default:
      return '/marketplace';
  }
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const savedSession = localStorage.getItem(AUTH_STORAGE_KEY);
      if (savedSession) {
        const parsed = JSON.parse(savedSession);
        if (parsed && parsed.role && parsed.id) {
          return parsed;
        }
      }
    } catch (err) {
      console.error('Failed to parse auth session from localStorage', err);
      localStorage.removeItem(AUTH_STORAGE_KEY);
    }
    return null;
  });
  const [isLoading, setIsLoading] = useState(true);

  // Initialize Supabase session on mount & subscribe to auth state changes
  useEffect(() => {
    let isMounted = true;

    async function initSession() {
      if (isSupabaseConfigured()) {
        try {
          const sessionData = await authService.getSession();
          if (sessionData?.profile && isMounted) {
            const authUser = {
              id: sessionData.profile.id,
              name: sessionData.profile.full_name,
              email: sessionData.profile.email,
              phone: sessionData.profile.phone,
              role: sessionData.profile.role,
              avatarUrl: sessionData.profile.avatar_url,
              createdAt: sessionData.profile.created_at,
              isDemo: Boolean(sessionData.profile.is_demo),
              source: sessionData.profile.is_demo ? 'demo' : 'live'
            };
            setUser(authUser);
            localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(authUser));
          } else if (!sessionData?.session && isMounted) {
            // Supabase is configured but has NO active auth session
            // Stale live sessions in localStorage must be cleared
            const saved = localStorage.getItem(AUTH_STORAGE_KEY);
            if (saved) {
              try {
                const parsed = JSON.parse(saved);
                if (!parsed.isDemo) {
                  setUser(null);
                  localStorage.removeItem(AUTH_STORAGE_KEY);
                }
              } catch {
                // ignore
              }
            }
          }
        } catch (e) {
          console.warn('Supabase session restore note:', e.message);
        }
      }
      if (isMounted) setIsLoading(false);
    }

    initSession();

    const { data: authSub } = authService.onAuthStateChange(async (event, session) => {
      if (!isMounted) return;
      if (!session?.user && isSupabaseConfigured()) {
        // User signed out in Supabase
        setUser(null);
        localStorage.removeItem(AUTH_STORAGE_KEY);
      } else if (session?.user && (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED' || event === 'USER_UPDATED')) {
        try {
          const sessionData = await authService.getSession();
          if (sessionData?.profile && isMounted) {
            const authUser = {
              id: sessionData.profile.id,
              name: sessionData.profile.full_name,
              email: sessionData.profile.email,
              phone: sessionData.profile.phone,
              role: sessionData.profile.role,
              avatarUrl: sessionData.profile.avatar_url,
              createdAt: sessionData.profile.created_at,
              isDemo: Boolean(sessionData.profile.is_demo),
              source: sessionData.profile.is_demo ? 'demo' : 'live'
            };
            setUser(authUser);
            localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(authUser));
          }
        } catch (e) {
          console.warn('Auth state change sync note:', e.message);
        }
      }
    });

    return () => {
      isMounted = false;
      if (authSub?.subscription?.unsubscribe) {
        authSub.subscription.unsubscribe();
      }
    };
  }, []);

  /**
   * Login Function
   * Authenticates via Supabase Auth or demo accounts
   */
  const login = async (emailOrPhone, password, role) => {
    setIsLoading(true);

    try {
      // 1. If Supabase is configured, attempt Supabase Auth
      if (isSupabaseConfigured() && emailOrPhone && password) {
        try {
          const authRes = await authService.signIn({ email: emailOrPhone, password });
          if (authRes?.profile) {
            const authenticatedUser = {
              id: authRes.profile.id,
              name: authRes.profile.full_name,
              email: authRes.profile.email,
              phone: authRes.profile.phone,
              role: authRes.profile.role,
              avatarUrl: authRes.profile.avatar_url,
              createdAt: authRes.profile.created_at,
              isDemo: Boolean(authRes.profile.is_demo),
              source: authRes.profile.is_demo ? 'demo' : 'live'
            };

            setUser(authenticatedUser);
            localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(authenticatedUser));
            setIsLoading(false);
            return authenticatedUser;
          }
        } catch (supaErr) {
          // If this is not a demo account, throw error directly (do not silently replace user)
          const isDemoAccount = Object.values(DEMO_ACCOUNTS).some(
            (d) => d.email.toLowerCase() === emailOrPhone?.toLowerCase()
          ) || emailOrPhone === 'demo';

          if (!isDemoAccount) {
            throw supaErr;
          }
          console.warn('Supabase signIn fallback to demo check:', supaErr.message);
        }
      }

      // 2. Demo / Fallback Authentication for Hackathon Evaluation
      const targetDemo = DEMO_ACCOUNTS[role];
      const registeredUsersKey = 'fasalsetu_registered_users_v1';
      let customUser = null;

      try {
        const registered = JSON.parse(localStorage.getItem(registeredUsersKey) || '[]');
        customUser = registered.find(
          (u) =>
            (u.email?.toLowerCase() === emailOrPhone?.toLowerCase() || u.phone === emailOrPhone) &&
            u.role === role
        );
      } catch {
        // ignore
      }

      const isDemoTarget = targetDemo && (
        targetDemo.email.toLowerCase() === emailOrPhone?.toLowerCase() ||
        targetDemo.phone === emailOrPhone ||
        emailOrPhone === 'demo'
      );

      const authenticatedUser =
        customUser ||
        (isDemoTarget
          ? targetDemo
          : {
              id: `user-${role}-${Date.now()}`,
              name: emailOrPhone ? emailOrPhone.split('@')[0] : 'User',
              email: emailOrPhone || `${role}@user.local`,
              role: role,
              phone: '+91 98765 00000',
              createdAt: new Date().toISOString(),
              isDemo: false,
              source: 'live'
            });

      setUser(authenticatedUser);
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(authenticatedUser));
      setIsLoading(false);
      return authenticatedUser;
    } catch (err) {
      setIsLoading(false);
      throw err;
    }
  };

  /**
   * Signup Function
   * Registers a new user via Supabase Auth or local storage fallback
   */
  const signup = async (userData) => {
    setIsLoading(true);

    try {
      if (isSupabaseConfigured() && userData.email && userData.password) {
        const authRes = await authService.signUp({
          email: userData.email,
          password: userData.password,
          name: userData.name,
          phone: userData.phone,
          role: userData.role,
          entityName: userData.entityName,
          location: userData.location,
          state: userData.state
        });

        if (authRes?.profile) {
          const newUser = {
            id: authRes.profile.id,
            name: authRes.profile.full_name,
            email: authRes.profile.email,
            phone: authRes.profile.phone,
            role: authRes.profile.role,
            createdAt: authRes.profile.created_at,
            isDemo: false,
            source: 'live',
            needsEmailConfirmation: Boolean(authRes.needsEmailConfirmation)
          };

          if (authRes.session) {
            setUser(newUser);
            localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(newUser));
          }
          setIsLoading(false);
          return newUser;
        }
      }

      // Local / Offline fallback
      const newUser = {
        id: `local-${userData.role}-${Date.now()}`,
        name: userData.name,
        email: userData.email,
        phone: userData.phone || '',
        role: userData.role,
        entityName: userData.entityName || userData.name,
        location: userData.location || 'India',
        state: userData.state || 'Uttar Pradesh',
        createdAt: new Date().toISOString(),
        isDemo: false,
        source: 'live',
        ...userData
      };

      try {
        const registeredUsersKey = 'fasalsetu_registered_users_v1';
        const existing = JSON.parse(localStorage.getItem(registeredUsersKey) || '[]');
        existing.push(newUser);
        localStorage.setItem(registeredUsersKey, JSON.stringify(existing));
      } catch {
        // ignore
      }

      setUser(newUser);
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(newUser));
      setIsLoading(false);
      return newUser;
    } catch (err) {
      setIsLoading(false);
      throw err;
    }
  };

  /**
   * Logout Function
   * Signs out of Supabase and clears local memory session
   */
  const logout = async () => {
    try {
      await authService.signOut();
    } catch (e) {
      console.warn('Sign out error:', e);
    }
    setUser(null);
    localStorage.removeItem(AUTH_STORAGE_KEY);
  };

  const value = {
    user,
    role: user?.role || null,
    isAuthenticated: Boolean(user && user.role),
    isDemo: Boolean(user?.isDemo),
    isLoading,
    isSupabaseConnected: isSupabaseConfigured(),
    login,
    signup,
    logout,
    getDashboardPath: () => (user?.role ? getRoleDashboardPath(user.role) : '/marketplace')
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
