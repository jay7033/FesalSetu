/**
 * FasalSetu — Central Data Normalizers
 * Transforms both Supabase DB rows and local demo objects into a unified frontend schema.
 * Every normalized record carries `source` ('live' | 'demo') and `isDemo` (boolean).
 */

// ============================================================
// PRODUCT NORMALIZER
// ============================================================

/**
 * Normalizes a product from any source into the canonical frontend schema.
 * @param {object} raw - Raw product data (Supabase row or demoData entry)
 * @param {'live'|'demo'} source - Data origin
 * @returns {object} Normalized product
 */
export function normalizeProduct(raw, source = 'demo') {
  if (!raw) return null;

  const isDemo = source === 'demo' || raw.isDemo === true || raw.is_demo === true || raw.source === 'demo';
  const resolvedSource = isDemo ? 'demo' : (source || 'live');

  return {
    id: raw.id,
    name: raw.name || raw.product_name || '',
    hindiName: raw.hindiName || raw.hindi_name || raw.name || '',
    category: raw.category || 'Vegetables',
    farmer: raw.farmer || raw.seller_name || 'Verified Producer',
    farmerId: raw.farmerId || raw.seller_profile_id || null,
    farmerType: raw.farmerType || (raw.seller_type === 'fpo' ? 'FPO' : 'Individual Farmer'),
    location: raw.location || raw.city || raw.district || 'India',
    state: raw.state || 'India',
    district: raw.district || raw.city || '',
    approximateLocation: raw.approximateLocation || raw.approximate_location ||
      (raw.city || raw.district ? `Near ${raw.city || raw.district}, ${raw.state || 'India'}` : 'India'),
    price: Number(raw.price) || 0,
    typicalRetailPrice: Number(raw.typicalRetailPrice) || Math.round((Number(raw.price) || 0) * 1.35),
    unit: raw.unit || 'kg',
    quantityAvailable: Number(raw.quantityAvailable ?? raw.quantity_available ?? 0),
    reservedQuantity: Number(raw.reservedQuantity ?? raw.reserved_quantity ?? 0),
    minimumOrderQuantity: Number(raw.minimumOrderQuantity ?? raw.minimum_order_quantity ?? 1),
    harvestDate: raw.harvestDate || raw.harvest_date || 'Fresh Harvest',
    quality: raw.quality || 'Grade A',
    organic: Boolean(raw.organic),
    distance: raw.distance || '',
    image: raw.image || raw.image_url || 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=600&q=80',
    description: raw.description || '',
    source: resolvedSource,
    isDemo,
    createdAt: raw.createdAt || raw.created_at || new Date().toISOString()
  };
}

// ============================================================
// ORDER NORMALIZER
// ============================================================

/**
 * Normalizes an order from any source.
 * @param {object} raw - Raw order data
 * @param {'live'|'demo'} source - Data origin
 * @returns {object} Normalized order
 */
export function normalizeOrder(raw, source = 'demo') {
  if (!raw) return null;

  const isDemo = source === 'demo' || raw.isDemo === true || raw.is_demo === true || raw.source === 'demo';
  const resolvedSource = isDemo ? 'demo' : (source || 'live');

  return {
    ...raw,
    orderNumber: raw.orderNumber || raw.order_number,
    totalAmount: raw.totalAmount !== undefined ? raw.totalAmount : raw.total_amount,
    source: resolvedSource,
    isDemo
  };
}

// ============================================================
// FARMER / PROFILE NORMALIZER
// ============================================================

/**
 * Normalizes a farmer or user profile from any source.
 * @param {object} raw - Raw profile data
 * @param {'live'|'demo'} source - Data origin
 * @returns {object} Normalized profile
 */
export function normalizeFarmer(raw, source = 'demo') {
  if (!raw) return null;

  const isDemo = source === 'demo' || raw.isDemo === true || raw.is_demo === true || raw.source === 'demo';
  const resolvedSource = isDemo ? 'demo' : (source || 'live');

  return {
    ...raw,
    source: resolvedSource,
    isDemo
  };
}

// ============================================================
// LOCATION NORMALIZER
// ============================================================

/**
 * Normalizes a farm or buyer location. GPS privacy masking is handled at display level.
 * @param {object} raw - Raw location data
 * @param {'live'|'demo'} source - Data origin
 * @returns {object} Normalized location
 */
export function normalizeLocation(raw, source = 'demo') {
  if (!raw) return null;

  const isDemo = source === 'demo' || raw.isDemo === true || raw.is_demo === true || raw.source === 'demo';
  const resolvedSource = isDemo ? 'demo' : (source || 'live');

  return {
    ...raw,
    approximateLocation: raw.approximateLocation || raw.approximate_location ||
      `Near ${raw.city || raw.district || raw.village || 'Farm'}, ${raw.state || 'India'}`,
    source: resolvedSource,
    isDemo
  };
}

// ============================================================
// SHIPMENT / LOGISTICS NORMALIZER
// ============================================================

/**
 * Normalizes a shipment or logistics route.
 * @param {object} raw - Raw shipment/route data
 * @param {'live'|'demo'} source - Data origin
 * @returns {object} Normalized record
 */
export function normalizeShipment(raw, source = 'demo') {
  if (!raw) return null;

  const isDemo = source === 'demo' || raw.isDemo === true || raw.is_demo === true || raw.source === 'demo';
  const resolvedSource = isDemo ? 'demo' : (source || 'live');

  return {
    ...raw,
    source: resolvedSource,
    isDemo
  };
}

// ============================================================
// DEDUPLICATION
// ============================================================

/**
 * Deduplicates an array of records by `id`.
 * When duplicates exist, 'live' source records take priority over 'demo'.
 * @param {Array} items - Array of normalized records
 * @returns {Array} Deduplicated array
 */
export function deduplicateById(items) {
  if (!items || !Array.isArray(items)) return [];

  const seen = new Map();

  for (const item of items) {
    const key = String(item.id);
    const existing = seen.get(key);

    if (!existing) {
      seen.set(key, item);
    } else {
      // Live source wins over demo
      if (item.source === 'live' && existing.source === 'demo') {
        seen.set(key, item);
      }
      // If both are same source, keep the first one (earlier in array = higher priority)
    }
  }

  return Array.from(seen.values());
}
