/**
 * Order Status Lifecycle Constants for FasalSetu
 * Sequential fulfillment progression & valid state transition definitions
 */

export const ORDER_LIFECYCLE_STEPS = [
  'Pending',
  'Confirmed',
  'Preparing',
  'Ready for Pickup',
  'Picked Up',
  'In Transit',
  'Delivered'
];

export const VALID_STATUS_TRANSITIONS = {
  'Pending': ['Confirmed', 'Cancelled'],
  'Confirmed': ['Preparing', 'Cancelled'],
  'Preparing': ['Ready for Pickup'],
  'Ready for Pickup': ['Picked Up', 'In Transit'],
  'Picked Up': ['In Transit'],
  'In Transit': ['Delivered'],
  'Delivered': [],
  'Cancelled': []
};
