/**
 * Notification Service
 * Manages in-app alerts, read states, and Realtime notification subscriptions.
 */

import { supabase, isSupabaseConfigured } from '../lib/supabase.js';

export const notificationService = {
  /**
   * Fetches notifications for a specific user
   */
  async getNotifications(profileId) {
    if (!isSupabaseConfigured() || !profileId) return null;

    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('recipient_profile_id', profileId)
      .order('created_at', { ascending: false })
      .limit(30);

    if (error) {
      console.warn('Error fetching notifications:', error.message);
      return null;
    }
    return data || [];
  },

  /**
   * Marks a single notification as read
   */
  async markAsRead(notificationId) {
    if (!isSupabaseConfigured()) return;

    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('id', notificationId);

    if (error) console.warn('Error marking notification as read:', error.message);
  },

  /**
   * Marks all notifications for a user as read
   */
  async markAllAsRead(profileId) {
    if (!isSupabaseConfigured() || !profileId) return;

    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('recipient_profile_id', profileId);

    if (error) console.warn('Error marking all notifications as read:', error.message);
  },

  /**
   * Subscribes to realtime notifications for a user
   */
  subscribeToNotifications(profileId, onNotification) {
    if (!isSupabaseConfigured() || !profileId) {
      return { unsubscribe: () => {} };
    }

    const channel = supabase
      .channel(`public:notifications:${profileId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `recipient_profile_id=eq.${profileId}`
        },
        (payload) => {
          if (onNotification) onNotification(payload.new);
        }
      )
      .subscribe((status, err) => {
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          console.warn(`[Realtime:notifications] Subscription ${status}:`, err?.message || 'WebSocket connection could not be established; operating with local/rest state.');
        }
      });

    return {
      unsubscribe: () => {
        supabase.removeChannel(channel);
      }
    };
  }
};

export default notificationService;
