/**
 * Inventory Service
 * Queries inventory transaction logs, reserved quantities, and stock adjustments.
 */

import { supabase, isSupabaseConfigured } from '../lib/supabase.js';

export const inventoryService = {
  /**
   * Fetches audit transaction logs for a product
   */
  async getInventoryLedger(productId) {
    if (!isSupabaseConfigured()) return null;

    const { data, error } = await supabase
      .from('inventory_transactions')
      .select('*')
      .eq('product_id', productId)
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('Error fetching inventory transactions:', error.message);
      return null;
    }
    return data || [];
  },

  /**
   * Records a manual inventory adjustment
   */
  async recordAdjustment(productId, quantityDelta, note, userId) {
    if (!isSupabaseConfigured()) return null;

    // Fetch current stock
    const { data: prod, error: fetchErr } = await supabase
      .from('products')
      .select('quantity_available')
      .eq('id', productId)
      .single();

    if (fetchErr) throw fetchErr;

    const newQty = Math.max(0, Number(prod.quantity_available) + Number(quantityDelta));

    const { data: updated, error: updateErr } = await supabase
      .from('products')
      .update({ quantity_available: newQty, updated_at: new Date().toISOString() })
      .eq('id', productId)
      .select()
      .single();

    if (updateErr) throw updateErr;

    await supabase.from('inventory_transactions').insert([{
      product_id: productId,
      type: 'adjustment',
      quantity: Math.abs(quantityDelta),
      note: note || 'Manual inventory adjustment',
      created_by: userId
    }]);

    return updated;
  }
};

export default inventoryService;
