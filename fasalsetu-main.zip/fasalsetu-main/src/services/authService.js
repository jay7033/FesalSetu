/**
 * Authentication Service
 * Manages Supabase Auth, role retrieval from database, and session persistence.
 */

import { supabase, isSupabaseConfigured } from '../lib/supabase.js';

export const authService = {
  /**
   * Registers a new user with Supabase Auth and attaches role metadata
   */
  async signUp({ email, password, name, phone, role, entityName, location, state }) {
    if (!isSupabaseConfigured()) {
      // In offline/demo fallback mode, simulate database user
      return {
        user: {
          id: `demo-${role}-${Date.now()}`,
          email,
          user_metadata: { name, full_name: name, role, phone, entityName }
        },
        profile: {
          id: `demo-${role}-${Date.now()}`,
          email,
          full_name: name,
          phone,
          role,
          created_at: new Date().toISOString()
        }
      };
    }

    const cleanEmail = (email || '').trim().toLowerCase();
    const cleanPassword = typeof password === 'string' ? password.trim() : password;

    // Real Supabase Auth SignUp
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: cleanEmail,
      password: cleanPassword,
      options: {
        data: {
          full_name: name,
          name,
          phone,
          role,
          entity_name: entityName,
          location,
          state
        }
      }
    });

    if (authError) {
      if (authError.message?.toLowerCase().includes('invalid') && cleanEmail.startsWith('testing@')) {
        throw new Error('Supabase Auth flags "testing@" addresses as reserved/invalid test emails. Please use a standard email address like yourname@gmail.com.');
      }
      throw authError;
    }

    const user = authData.user;
    if (!user) return { user: null, profile: null };

    const session = authData.session;
    const needsEmailConfirmation = !session && (!user.confirmed_at && (!user.identities || user.identities.length > 0));

    // If an active session was returned (email confirmation disabled or auto-confirmed)
    let profile = null;
    if (session) {
      try {
        const { data: dbProfile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();
        profile = dbProfile;
      } catch (err) {
        console.warn('Profile fetch note after signup:', err);
      }
    }

    const resolvedProfile = profile || {
      id: user.id,
      email: user.email || cleanEmail,
      full_name: name || user.email?.split('@')[0],
      phone,
      role,
      is_demo: false
    };

    return {
      user,
      session,
      needsEmailConfirmation,
      profile: resolvedProfile
    };
  },

  /**
   * Logs in a user via Supabase Auth and fetches verified profile from DB
   */
  async signIn({ email, password }) {
    if (!isSupabaseConfigured()) {
      return null;
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) throw error;

    const user = data.user;
    if (!user) return null;

    // Fetch verified profile from database (never trust client role)
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single();

    if (profileError && profileError.code !== 'PGRST116') {
      console.warn('Error fetching verified profile:', profileError);
    }

    let verifiedProfile = profile;
    // CASE B: If new Supabase user exists in auth.users but has no public.profiles row, create it
    if (!verifiedProfile && isSupabaseConfigured()) {
      const initialRole = user.user_metadata?.role || 'consumer';
      const initialName = user.user_metadata?.full_name || user.user_metadata?.name || user.email.split('@')[0];
      try {
        const { data: newProfile } = await supabase
          .from('profiles')
          .upsert({
            id: user.id,
            email: user.email,
            full_name: initialName,
            phone: user.user_metadata?.phone || null,
            role: initialRole,
            is_demo: false
          }, { onConflict: 'id' })
          .select()
          .single();
        if (newProfile) verifiedProfile = newProfile;
      } catch (err) {
        console.warn('Auto profile initialization notice:', err);
      }
    }

    return {
      user,
      profile: verifiedProfile || {
        id: user.id,
        email: user.email,
        full_name: user.user_metadata?.full_name || user.user_metadata?.name || user.email.split('@')[0],
        role: user.user_metadata?.role || 'consumer',
        is_demo: false
      }
    };
  },

  /**
   * Signs out of Supabase Auth
   */
  async signOut() {
    if (!isSupabaseConfigured()) return;
    const { error } = await supabase.auth.signOut();
    if (error) console.warn('Supabase sign out error:', error);
  },

  /**
   * Gets current active session and verified profile
   */
  async getSession() {
    if (!isSupabaseConfigured()) return null;

    const { data: { session }, error } = await supabase.auth.getSession();
    if (error || !session?.user) return null;

    const user = session.user;
    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single();

    return {
      session,
      user,
      profile: profile || {
        id: user.id,
        email: user.email,
        full_name: user.user_metadata?.full_name || user.user_metadata?.name || user.email.split('@')[0],
        role: user.user_metadata?.role || 'consumer',
        is_demo: false
      }
    };
  },

  /**
   * Subscribes to auth state changes
   */
  onAuthStateChange(callback) {
    if (!isSupabaseConfigured()) {
      return { data: { subscription: { unsubscribe: () => {} } } };
    }
    return supabase.auth.onAuthStateChange(callback);
  }
};

export default authService;
