/**
 * Profile Service
 * Manages user profile information and role extensions.
 */

import { supabase, isSupabaseConfigured } from '../lib/supabase.js';

export const profileService = {
  /**
   * Fetches full profile with role-specific extension
   */
  async getProfile(userId) {
    if (!isSupabaseConfigured() || !userId) return null;

    const { data: profile, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();

    if (error) return null;

    let extension = null;
    if (profile.role === 'farmer') {
      const { data } = await supabase.from('farmer_profiles').select('*').eq('profile_id', userId).single();
      extension = data;
    } else if (profile.role === 'fpo') {
      const { data } = await supabase.from('fpo_profiles').select('*').eq('profile_id', userId).single();
      extension = data;
    } else if (profile.role === 'consumer') {
      const { data } = await supabase.from('consumer_profiles').select('*').eq('profile_id', userId).single();
      extension = data;
    } else if (profile.role === 'bulk_buyer') {
      const { data } = await supabase.from('bulk_buyer_profiles').select('*').eq('profile_id', userId).single();
      extension = data;
    }

    return { ...profile, extension };
  },

  /**
   * Updates base profile and role extension
   */
  async updateProfile(userId, updates) {
    if (!isSupabaseConfigured() || !userId) return null;

    const { data, error } = await supabase
      .from('profiles')
      .update({
        full_name: updates.full_name || updates.name,
        phone: updates.phone,
        avatar_url: updates.avatar_url,
        updated_at: new Date().toISOString()
      })
      .eq('id', userId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Uploads avatar photo to Supabase Storage
   */
  async uploadAvatar(file, userId) {
    if (!isSupabaseConfigured() || !file || !userId) return null;

    const fileExt = file.name.split('.').pop();
    const fileName = `${userId}/avatar.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from('avatars')
      .upload(fileName, file, { upsert: true });

    if (uploadError) {
      console.warn('Avatar upload error:', uploadError.message);
      return null;
    }

    const { data } = supabase.storage
      .from('avatars')
      .getPublicUrl(fileName);

    return data.publicUrl;
  }
};

export default profileService;
