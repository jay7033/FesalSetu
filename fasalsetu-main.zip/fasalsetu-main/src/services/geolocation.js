/**
 * FasalSetu Geolocation Service
 * Wraps the HTML5 Geolocation API with robust error handling and high-accuracy configuration.
 */

export const GEOLOCATION_ERRORS = {
  PERMISSION_DENIED: 'PERMISSION_DENIED',
  POSITION_UNAVAILABLE: 'POSITION_UNAVAILABLE',
  TIMEOUT: 'TIMEOUT',
  UNSUPPORTED: 'UNSUPPORTED',
  UNKNOWN: 'UNKNOWN'
};

/**
 * Friendly user-facing messages according to standard error codes.
 */
export function handleLocationError(error) {
  if (!error) return 'An unexpected error occurred while detecting location.';

  if (typeof error === 'string') return error;

  switch (error.code) {
    case 1: // PERMISSION_DENIED
      return 'Location permission was denied. Please allow location access in your browser settings or select your location manually.';
    case 2: // POSITION_UNAVAILABLE
      return 'Location information is currently unavailable from your device. Please try again or enter location manually.';
    case 3: // TIMEOUT
      return 'Location detection timed out. Please check your GPS/network signal or select location manually.';
    default:
      return error.message || 'Unable to detect location. Please select your location manually.';
  }
}

/**
 * Requests current device GPS coordinates with high accuracy.
 * Never calls silently without user action.
 * @param {Object} customOptions
 * @returns {Promise<{ latitude: number, longitude: number, accuracy: number, timestamp: number }>}
 */
export function getCurrentPosition(customOptions = {}) {
  return new Promise((resolve, reject) => {
    if (!('geolocation' in navigator)) {
      const err = new Error('Geolocation is not supported by your browser or environment.');
      err.code = 0;
      err.type = GEOLOCATION_ERRORS.UNSUPPORTED;
      reject(err);
      return;
    }

    const defaultOptions = {
      enableHighAccuracy: true,
      timeout: 15000,
      maximumAge: 60000, // 1 minute cached position max
      ...customOptions
    };

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy || 20,
          timestamp: position.timestamp || Date.now()
        });
      },
      (error) => {
        reject(error);
      },
      defaultOptions
    );
  });
}
