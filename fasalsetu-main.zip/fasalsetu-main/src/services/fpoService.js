/**
 * FPO Service
 * Manages producer collective member rosters, farm aggregation yards, and cluster inventory.
 */

import { supabase, isSupabaseConfigured } from '../lib/supabase.js';

export const fpoService = {
  /**
   * Fetches member farmers enrolled in this FPO
   */
  async getFPOMembers(fpoProfileId) {
    if (!isSupabaseConfigured() || !fpoProfileId) return null;

    const { data, error } = await supabase
      .from('fpo_members')
      .select('*')
      .eq('fpo_profile_id', fpoProfileId)
      .order('joined_at', { ascending: false });

    if (error) {
      console.warn('Error fetching FPO members:', error.message);
      return null;
    }
    return data || [];
  },

  /**
   * Enrolls a new member farmer into the FPO
   */
  async addMember(fpoProfileId, memberData) {
    if (!isSupabaseConfigured()) return null;

    const { data, error } = await supabase
      .from('fpo_members')
      .insert([{
        fpo_profile_id: fpoProfileId,
        farmer_name: memberData.name || memberData.farmer_name,
        village: memberData.village,
        district: memberData.district,
        crop_focus: memberData.cropFocus || memberData.crop_focus,
        land_acres: memberData.landAcres || memberData.land_acres || 2.5,
        status: 'active'
      }])
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Updates FPO profile info
   */
  async updateFPOProfile(profileId, updates) {
    if (!isSupabaseConfigured()) return null;

    const { data, error } = await supabase
      .from('fpo_profiles')
      .update(updates)
      .eq('profile_id', profileId)
      .select()
      .single();

    if (error) throw error;
    return data;
  }
};

export default fpoService;
