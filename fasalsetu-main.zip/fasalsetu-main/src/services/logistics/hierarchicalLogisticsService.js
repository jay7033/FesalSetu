/**
 * FasalSetu — Hierarchical Regional Logistics Service
 * Manages Regional Logistics Heads, Operational Zones, Zone Assigners, Delivery Boys & Tasks.
 * Implements dynamic zone balancing, automated assignment, and hybrid live/demo state.
 */

import { supabase, isSupabaseConfigured } from '../../lib/supabase.js';
import { 
  NORTH_REGION_LOGISTICS_HEAD,
  NORTH_REGION_ZONES,
  NORTH_REGION_DELIVERY_BOYS,
  NORTH_REGION_DELIVERY_TASKS
} from '../../data/demoData.js';
import { autoAssignTaskZoneFirst } from './smartAssignmentService.js';

const STORAGE_KEYS = {
  TASKS: 'fasalsetu_delivery_tasks_v1',
  BOYS: 'fasalsetu_delivery_boys_v1',
  ZONES: 'fasalsetu_logistics_zones_v1'
};

function getLocalData(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore
  }
  return fallback;
}

function setLocalData(key, data) {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch {
    // ignore
  }
}

export const hierarchicalLogisticsService = {
  /**
   * Get Regional Logistics Head profile
   */
  getRegionalHead: (regionId = 'north') => {
    if (regionId === 'north') {
      return NORTH_REGION_LOGISTICS_HEAD;
    }
    return {
      ...NORTH_REGION_LOGISTICS_HEAD,
      regionId,
      name: `${regionId.toUpperCase()} Regional Officer`
    };
  },

  /**
   * Get all zones in a region with dynamic workload analytics
   */
  getZones: async (regionId = 'north') => {
    // Live Supabase query if configured
    if (isSupabaseConfigured()) {
      try {
        const { data, error } = await supabase
          .from('logistics_zones')
          .select('*')
          .eq('region_id', regionId);
        if (!error && data && data.length > 0) {
          return data.map(d => ({ ...d, isDemo: false, source: 'live' }));
        }
      } catch (err) {
        console.warn('Supabase getZones query failed, falling back to cached/demo:', err);
      }
    }

    // Demo / Local storage
    const localZones = getLocalData(STORAGE_KEYS.ZONES, NORTH_REGION_ZONES);
    const tasks = getLocalData(STORAGE_KEYS.TASKS, NORTH_REGION_DELIVERY_TASKS);
    const boys = getLocalData(STORAGE_KEYS.BOYS, NORTH_REGION_DELIVERY_BOYS);

    // Compute dynamic workload statistics
    return localZones.map((zone) => {
      const zoneBoys = boys.filter((b) => b.zoneId === zone.id);
      const zoneTasks = tasks.filter((t) => t.zoneId === zone.id);
      const activeTasks = zoneTasks.filter((t) => !['DELIVERED', 'CANCELLED'].includes(t.status));
      const delayedTasks = zoneTasks.filter((t) => t.status === 'DELAYED');
      const unassignedTasks = zoneTasks.filter((t) => t.status === 'UNASSIGNED');
      const completedToday = zoneTasks.filter((t) => t.status === 'DELIVERED').length;

      const activeBoys = zoneBoys.filter((b) => b.status === 'AVAILABLE' || b.status === 'ON_DELIVERY').length;
      const ratio = activeBoys > 0 ? activeTasks.length / activeBoys : 0;

      let status = 'BALANCED';
      if (ratio > 1.4 || unassignedTasks.length > 2) status = 'HIGH_WORKLOAD';
      if (ratio > 2.0) status = 'OVERLOADED';

      return {
        ...zone,
        teamSize: zoneBoys.length,
        activeDeliveryBoys: activeBoys,
        activeDeliveriesCount: activeTasks.length,
        delayedDeliveriesCount: delayedTasks.length,
        unassignedDeliveriesCount: unassignedTasks.length,
        completedTodayCount: completedToday,
        workloadRatio: Number(ratio.toFixed(2)),
        status,
        isDemo: true,
        source: 'demo'
      };
    });
  },

  /**
   * Get single zone by ID
   */
  getZoneById: async (zoneId) => {
    const zones = await hierarchicalLogisticsService.getZones();
    return zones.find((z) => z.id === zoneId) || zones[0] || null;
  },

  /**
   * Get Delivery Boys (Filtered by zone or region)
   */
  getDeliveryBoys: async ({ regionId = 'north', zoneId = null } = {}) => {
    if (isSupabaseConfigured()) {
      try {
        let query = supabase.from('logistics_members').select('*').eq('role', 'delivery_boy');
        if (regionId) query = query.eq('region_id', regionId);
        if (zoneId) query = query.eq('zone_id', zoneId);
        const { data, error } = await query;
        if (!error && data && data.length > 0) {
          return data.map(d => ({ ...d, isDemo: false, source: 'live' }));
        }
      } catch (err) {
        console.warn('Supabase getDeliveryBoys query failed, falling back:', err);
      }
    }

    const allBoys = getLocalData(STORAGE_KEYS.BOYS, NORTH_REGION_DELIVERY_BOYS);
    return allBoys.filter((b) => {
      if (zoneId && b.zoneId !== zoneId) return false;
      if (regionId && b.regionId !== regionId) return false;
      return true;
    });
  },

  /**
   * Get Delivery Boy by ID or Email
   */
  getDeliveryBoyByIdOrEmail: async (identifier) => {
    const boys = await hierarchicalLogisticsService.getDeliveryBoys();
    return boys.find((b) => b.id === identifier || b.email === identifier) || null;
  },

  /**
   * Get Delivery Tasks (Filtered by region, zone, boy, or status)
   */
  getDeliveryTasks: async ({ regionId = 'north', zoneId = null, deliveryBoyId = null, status = null } = {}) => {
    if (isSupabaseConfigured()) {
      try {
        let query = supabase.from('delivery_tasks').select('*');
        if (regionId) query = query.eq('region_id', regionId);
        if (zoneId) query = query.eq('zone_id', zoneId);
        if (deliveryBoyId) query = query.eq('delivery_boy_id', deliveryBoyId);
        if (status) query = query.eq('status', status);
        const { data, error } = await query;
        if (!error && data && data.length > 0) {
          return data.map(d => ({ ...d, isDemo: false, source: 'live' }));
        }
      } catch (err) {
        console.warn('Supabase getDeliveryTasks query failed, falling back:', err);
      }
    }

    const allTasks = getLocalData(STORAGE_KEYS.TASKS, NORTH_REGION_DELIVERY_TASKS);
    return allTasks.filter((t) => {
      if (regionId && t.regionId !== regionId) return false;
      if (zoneId && t.zoneId !== zoneId) return false;
      if (deliveryBoyId && t.deliveryBoyId !== deliveryBoyId) return false;
      if (status && t.status !== status) return false;
      return true;
    });
  },

  /**
   * Update delivery task status (e.g. PICKUP_PENDING -> PICKED_UP -> IN_TRANSIT -> DELIVERED)
   */
  updateTaskStatus: async (taskId, newStatus, notes = '') => {
    if (isSupabaseConfigured()) {
      try {
        await supabase
          .from('delivery_tasks')
          .update({
            status: newStatus,
            notes,
            updated_at: new Date().toISOString()
          })
          .eq('id', taskId);
      } catch (err) {
        console.warn('Supabase updateTaskStatus error:', err);
      }
    }

    const allTasks = getLocalData(STORAGE_KEYS.TASKS, NORTH_REGION_DELIVERY_TASKS);
    const updated = allTasks.map((t) => {
      if (t.id === taskId) {
        return {
          ...t,
          status: newStatus,
          notes: notes || t.notes,
          actualDeliveryTime: newStatus === 'DELIVERED' ? new Date().toISOString() : t.actualDeliveryTime,
          actualPickupTime: newStatus === 'PICKED_UP' ? new Date().toISOString() : t.actualPickupTime
        };
      }
      return t;
    });

    setLocalData(STORAGE_KEYS.TASKS, updated);
    return updated.find((t) => t.id === taskId);
  },

  /**
   * Assign delivery task manually
   */
  assignTaskManual: async (taskId, deliveryBoyId, assignerUserId = 'usr-assigner-north-a', reason = 'Manual coordinator assignment') => {
    const boys = await hierarchicalLogisticsService.getDeliveryBoys();
    const boy = boys.find((b) => b.id === deliveryBoyId);
    if (!boy) throw new Error('Selected delivery boy not found');

    const allTasks = getLocalData(STORAGE_KEYS.TASKS, NORTH_REGION_DELIVERY_TASKS);
    const updated = allTasks.map((t) => {
      if (t.id === taskId) {
        return {
          ...t,
          deliveryBoyId: boy.id,
          deliveryBoyName: boy.name,
          assignedByUserId: assignerUserId,
          assignmentSource: 'manual',
          assignmentReason: reason,
          assignedAt: new Date().toISOString(),
          status: 'ASSIGNED'
        };
      }
      return t;
    });

    // Increment active tasks on boy
    const allBoys = getLocalData(STORAGE_KEYS.BOYS, NORTH_REGION_DELIVERY_BOYS);
    const updatedBoys = allBoys.map((b) => {
      if (b.id === boy.id) {
        return {
          ...b,
          activeTasksCount: (b.activeTasksCount || 0) + 1,
          status: 'ON_DELIVERY'
        };
      }
      return b;
    });

    setLocalData(STORAGE_KEYS.TASKS, updated);
    setLocalData(STORAGE_KEYS.BOYS, updatedBoys);

    return updated.find((t) => t.id === taskId);
  },

  /**
   * Trigger Smart Auto-Assignment for an unassigned order task
   */
  autoAssignOrderTask: async (taskOrId) => {
    let task = taskOrId;
    if (typeof taskOrId === 'string') {
      const allTasks = await hierarchicalLogisticsService.getDeliveryTasks();
      task = allTasks.find((t) => t.id === taskOrId);
    }
    if (!task) throw new Error('Task not found');

    // 1. Fetch delivery boys in task's primary zone
    const primaryZoneBoys = await hierarchicalLogisticsService.getDeliveryBoys({ zoneId: task.zoneId });

    // 2. Fetch neighbor boys across North region
    const allNorthBoys = await hierarchicalLogisticsService.getDeliveryBoys({ regionId: task.regionId || 'north' });
    const neighborBoys = allNorthBoys.filter((b) => b.zoneId !== task.zoneId);

    // 3. Run Zone-First Smart Assignment Algorithm
    const assignmentResult = autoAssignTaskZoneFirst(task, primaryZoneBoys, neighborBoys);

    if (assignmentResult.assignedBoy) {
      const allTasks = getLocalData(STORAGE_KEYS.TASKS, NORTH_REGION_DELIVERY_TASKS);
      const updated = allTasks.map((t) => {
        if (t.id === task.id) {
          return {
            ...t,
            deliveryBoyId: assignmentResult.assignedBoy.id,
            deliveryBoyName: assignmentResult.assignedBoy.name,
            assignmentSource: assignmentResult.source,
            assignmentScore: assignmentResult.score,
            assignmentReason: assignmentResult.reason,
            assignedAt: new Date().toISOString(),
            status: 'ASSIGNED'
          };
        }
        return t;
      });

      // Update boy workload
      const allBoys = getLocalData(STORAGE_KEYS.BOYS, NORTH_REGION_DELIVERY_BOYS);
      const updatedBoys = allBoys.map((b) => {
        if (b.id === assignmentResult.assignedBoy.id) {
          return {
            ...b,
            activeTasksCount: (b.activeTasksCount || 0) + 1,
            status: 'ON_DELIVERY'
          };
        }
        return b;
      });

      setLocalData(STORAGE_KEYS.TASKS, updated);
      setLocalData(STORAGE_KEYS.BOYS, updatedBoys);

      return {
        success: true,
        task: updated.find((t) => t.id === task.id),
        ...assignmentResult
      };
    }

    // No candidate found: Mark unassigned
    return {
      success: false,
      reason: assignmentResult.reason,
      status: 'UNASSIGNED'
    };
  },

  /**
   * Reassign a delivery boy to another zone (Dynamic Balancing intervention)
   */
  reassignDeliveryBoyZone: async (boyId, targetZoneId) => {
    const allBoys = getLocalData(STORAGE_KEYS.BOYS, NORTH_REGION_DELIVERY_BOYS);
    const updated = allBoys.map((b) => {
      if (b.id === boyId) {
        return { ...b, zoneId: targetZoneId };
      }
      return b;
    });
    setLocalData(STORAGE_KEYS.BOYS, updated);
    return updated.find((b) => b.id === boyId);
  },

  /**
   * Calculate Regional Supervision KPIs for Logistics Head
   */
  getRegionalKPISummary: async (regionId = 'north') => {
    const zones = await hierarchicalLogisticsService.getZones(regionId);
    const boys = await hierarchicalLogisticsService.getDeliveryBoys({ regionId });
    const tasks = await hierarchicalLogisticsService.getDeliveryTasks({ regionId });

    const totalZones = zones.length;
    const totalAssigners = zones.filter((z) => z.assigner).length;
    const totalDeliveryBoys = boys.length;

    const availableBoys = boys.filter((b) => b.status === 'AVAILABLE').length;
    const onDeliveryBoys = boys.filter((b) => b.status === 'ON_DELIVERY').length;
    const offlineBoys = boys.filter((b) => b.status === 'OFFLINE' || b.status === 'BREAK').length;

    const todayDelivered = tasks.filter((t) => t.status === 'DELIVERED').length;
    const inTransit = tasks.filter((t) => t.status === 'IN_TRANSIT' || t.status === 'OUT_FOR_DELIVERY').length;
    const delayed = tasks.filter((t) => t.status === 'DELAYED').length;
    const unassigned = tasks.filter((t) => t.status === 'UNASSIGNED').length;

    // Imbalance alerts
    const overloadedZones = zones.filter((z) => z.status === 'HIGH_WORKLOAD' || z.status === 'OVERLOADED');

    return {
      regionId,
      totalZones,
      totalAssigners,
      totalDeliveryBoys,
      availableBoys,
      onDeliveryBoys,
      offlineBoys,
      totalTodayDeliveries: tasks.length,
      todayDelivered,
      inTransit,
      delayed,
      unassigned,
      overloadedZones,
      completionRatePercent: tasks.length > 0 ? Math.round((todayDelivered / tasks.length) * 100) : 100
    };
  },

  /**
   * Calculate Zone-Specific KPIs for Zone Coordinator / Delivery Assigner
   */
  getZoneKPISummary: async (zoneId) => {
    const zone = await hierarchicalLogisticsService.getZoneById(zoneId);
    const boys = await hierarchicalLogisticsService.getDeliveryBoys({ zoneId });
    const tasks = await hierarchicalLogisticsService.getDeliveryTasks({ zoneId });

    const availableBoys = boys.filter((b) => b.status === 'AVAILABLE').length;
    const onDeliveryBoys = boys.filter((b) => b.status === 'ON_DELIVERY').length;
    const offlineBoys = boys.filter((b) => b.status === 'OFFLINE' || b.status === 'BREAK').length;

    const activeDeliveries = tasks.filter((t) => !['DELIVERED', 'CANCELLED'].includes(t.status));
    const unassigned = tasks.filter((t) => t.status === 'UNASSIGNED');
    const delayed = tasks.filter((t) => t.status === 'DELAYED');
    const deliveredToday = tasks.filter((t) => t.status === 'DELIVERED');

    return {
      zone,
      teamSize: boys.length,
      availableBoys,
      onDeliveryBoys,
      offlineBoys,
      activeDeliveriesCount: activeDeliveries.length,
      unassignedCount: unassigned.length,
      delayedCount: delayed.length,
      deliveredTodayCount: deliveredToday.length,
      boys,
      tasks
    };
  }
};
