// Logistics Utilities, Vehicle Profiles, and Lifecycle Transitions

export const VEHICLE_PROFILES = {
  'Mini Truck': {
    type: 'Mini Truck',
    capacityKg: 500,
    baseCost: 350,
    ratePerKm: 12,
    description: 'Tata Ace / EV 3-Wheeler for small farm lots'
  },
  'Small Truck': {
    type: 'Small Truck',
    capacityKg: 1000,
    baseCost: 500,
    ratePerKm: 15,
    description: 'Bolero Maxi Truck for village cluster pickups'
  },
  'Medium Truck': {
    type: 'Medium Truck',
    capacityKg: 2500,
    baseCost: 850,
    ratePerKm: 20,
    description: 'Eicher 14-ft for inter-district Mandi and hub aggregation'
  },
  'Large Truck': {
    type: 'Large Truck',
    capacityKg: 5000,
    baseCost: 1400,
    ratePerKm: 28,
    description: 'Multi-axle commercial reefer for institutional bulk transport'
  }
};

// Aliases for uppercase keys
VEHICLE_PROFILES.MINI_TRUCK = VEHICLE_PROFILES['Mini Truck'];
VEHICLE_PROFILES.SMALL_TRUCK = VEHICLE_PROFILES['Small Truck'];
VEHICLE_PROFILES.MEDIUM_TRUCK = VEHICLE_PROFILES['Medium Truck'];
VEHICLE_PROFILES.LARGE_TRUCK = VEHICLE_PROFILES['Large Truck'];

/**
 * Resolves vehicle profile by key or returns Small Truck default
 */
export function getVehicleProfile(key = 'Small Truck') {
  if (!key) return VEHICLE_PROFILES['Small Truck'];
  if (VEHICLE_PROFILES[key]) return VEHICLE_PROFILES[key];
  const str = String(key).toLowerCase();
  if (str.includes('mini') || str.includes('500') || str.includes('3-wheeler') || str.includes('ace')) {
    return VEHICLE_PROFILES['Mini Truck'];
  }
  if (str.includes('medium') || str.includes('2500') || str.includes('14-ft') || str.includes('eicher')) {
    return VEHICLE_PROFILES['Medium Truck'];
  }
  if (str.includes('large') || str.includes('5000') || str.includes('reefer') || str.includes('multi-axle')) {
    return VEHICLE_PROFILES['Large Truck'];
  }
  if (str.includes('small') || str.includes('1000') || str.includes('bolero')) {
    return VEHICLE_PROFILES['Small Truck'];
  }
  return VEHICLE_PROFILES['Small Truck'];
}

export const LOGISTICS_SPEED_CONFIG = {
  AVG_SPEED_KMH: 40,        // Blended corridor average speed
  PICKUP_DWELL_MINS: 15,    // Dwell time to verify quality & weigh crates
  DELIVERY_DWELL_MINS: 10,  // Dropoff and signature confirmation
  HUB_DWELL_MINS: 20        // Consolidate crates at aggregation hub
};

// ----------------------------------------------------
// SEQUENTIAL LIFECYCLE TRANSITIONS
// ----------------------------------------------------
export const SHIPMENT_LIFECYCLE_STEPS = [
  'CREATED',
  'PICKUP_SCHEDULED',
  'PICKED_UP',
  'IN_TRANSIT',
  'OUT_FOR_DELIVERY',
  'DELIVERED'
];

export const VALID_SHIPMENT_TRANSITIONS = {
  CREATED: ['PICKUP_SCHEDULED', 'CANCELLED'],
  PICKUP_SCHEDULED: ['PICKED_UP', 'CANCELLED'],
  PICKED_UP: ['IN_TRANSIT', 'CANCELLED'],
  IN_TRANSIT: ['OUT_FOR_DELIVERY', 'DELIVERED'],
  OUT_FOR_DELIVERY: ['DELIVERED', 'IN_TRANSIT'],
  DELIVERED: [],
  CANCELLED: []
};

export const PICKUP_LIFECYCLE_STEPS = [
  'PENDING',
  'SCHEDULED',
  'READY',
  'PICKED_UP'
];

export const VALID_PICKUP_TRANSITIONS = {
  PENDING: ['SCHEDULED', 'CANCELLED'],
  SCHEDULED: ['READY', 'MISSED', 'CANCELLED'],
  READY: ['PICKED_UP', 'MISSED', 'CANCELLED'],
  MISSED: ['SCHEDULED', 'CANCELLED'],
  PICKED_UP: [],
  CANCELLED: []
};

export const ROUTE_LIFECYCLE_STEPS = [
  'PLANNED',
  'ASSIGNED',
  'IN_PROGRESS',
  'COMPLETED'
];

export const VALID_ROUTE_TRANSITIONS = {
  PLANNED: ['ASSIGNED', 'CANCELLED'],
  ASSIGNED: ['IN_PROGRESS', 'PLANNED', 'CANCELLED'],
  IN_PROGRESS: ['COMPLETED', 'CANCELLED'],
  COMPLETED: [],
  CANCELLED: []
};

/**
 * Validates sequential shipment status transitions
 */
export function canTransitionShipmentStatus(currentStatus, targetStatus) {
  if (!currentStatus || !targetStatus) return false;
  if (currentStatus === targetStatus) return true;
  const allowed = VALID_SHIPMENT_TRANSITIONS[currentStatus];
  return Array.isArray(allowed) && allowed.includes(targetStatus);
}

/**
 * Validates sequential pickup schedule transitions
 */
export function canTransitionPickupStatus(currentStatus, targetStatus) {
  if (!currentStatus || !targetStatus) return false;
  if (currentStatus === targetStatus) return true;
  const allowed = VALID_PICKUP_TRANSITIONS[currentStatus];
  return Array.isArray(allowed) && allowed.includes(targetStatus);
}

/**
 * Validates sequential route plan transitions
 */
export function canTransitionRouteStatus(currentStatus, targetStatus) {
  if (!currentStatus || !targetStatus) return false;
  if (currentStatus === targetStatus) return true;
  const allowed = VALID_ROUTE_TRANSITIONS[currentStatus];
  return Array.isArray(allowed) && allowed.includes(targetStatus);
}

export const SHIPMENT_STATUSES = SHIPMENT_LIFECYCLE_STEPS;
export const PICKUP_STATUSES = PICKUP_LIFECYCLE_STEPS;
export const ROUTE_STATUSES = ROUTE_LIFECYCLE_STEPS;

/**
 * Calculates prototype transport cost estimate
 */
export function calculateTransportCost(args = 0, maybeVehicleType = 'Small Truck') {
  let distanceKm = 0;
  let vehicleKey = 'Small Truck';
  let stopCount = 0;

  if (typeof args === 'object' && args !== null) {
    distanceKm = args.distanceKm ?? 0;
    vehicleKey = args.vehicleKey || args.vehicleType || 'Small Truck';
    stopCount = args.stopCount ?? 0;
  } else {
    distanceKm = Number(args) || 0;
    vehicleKey = maybeVehicleType || 'Small Truck';
  }

  const profile = getVehicleProfile(vehicleKey);
  const km = Math.max(Number(distanceKm) || 0, 0);
  const baseFee = profile.baseCost;
  const distanceFee = Math.round(km * profile.ratePerKm);
  const stopHandlingFee = stopCount > 2 ? (stopCount - 2) * 50 : 0;
  const totalCost = Math.round(baseFee + distanceFee + stopHandlingFee);

  return {
    totalCost,
    breakdown: {
      baseFee,
      distanceFee,
      stopHandlingFee
    },
    valueOf: () => totalCost,
    toString: () => String(totalCost),
    [Symbol.toPrimitive]: (hint) => (hint === 'string' ? String(totalCost) : totalCost)
  };
}

/**
 * Formats duration in hours and minutes (e.g. 2h 15m or 45m)
 */
export function formatDuration(minutes = 0) {
  const mins = Math.max(Math.round(Number(minutes) || 0), 0);
  if (mins < 60) {
    return `${mins}m`;
  }
  const hrs = Math.floor(mins / 60);
  const rem = mins % 60;
  return rem > 0 ? `${hrs}h ${rem}m` : `${hrs}h`;
}
