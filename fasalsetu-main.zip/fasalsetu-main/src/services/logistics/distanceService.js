// Distance Service wrapping Haversine calculations and distance matrices
import { calculateDistance as haversineDistance } from '../../utils/distance.js';

export const distanceService = {
  /**
   * Calculates distance between two point objects { latitude, longitude } in km.
   */
  getDistance(pointA, pointB) {
    if (!pointA || !pointB) return null;
    const lat1 = Number(pointA.latitude ?? pointA.lat);
    const lon1 = Number(pointA.longitude ?? pointA.lng ?? pointA.lon);
    const lat2 = Number(pointB.latitude ?? pointB.lat);
    const lon2 = Number(pointB.longitude ?? pointB.lng ?? pointB.lon);

    if (isNaN(lat1) || isNaN(lon1) || isNaN(lat2) || isNaN(lon2)) {
      return null;
    }

    return haversineDistance(lat1, lon1, lat2, lon2);
  },

  /**
   * Calculates total path distance in km along an ordered sequence of points.
   */
  calculateTotalPathDistance(orderedPoints = []) {
    if (!Array.isArray(orderedPoints) || orderedPoints.length < 2) {
      return 0;
    }

    let total = 0;
    for (let i = 0; i < orderedPoints.length - 1; i++) {
      const dist = this.getDistance(orderedPoints[i], orderedPoints[i + 1]);
      if (dist !== null) {
        total += dist;
      }
    }

    return Math.round(total * 10) / 10;
  }
};

export function calculateHaversineDistance(lat1, lon1, lat2, lon2) {
  if (lat1 === null || lat1 === undefined || lon1 === null || lon1 === undefined ||
      lat2 === null || lat2 === undefined || lon2 === null || lon2 === undefined) {
    return 0;
  }
  const nlat1 = Number(lat1);
  const nlon1 = Number(lon1);
  const nlat2 = Number(lat2);
  const nlon2 = Number(lon2);
  if (isNaN(nlat1) || isNaN(nlon1) || isNaN(nlat2) || isNaN(nlon2)) {
    return 0;
  }
  return haversineDistance(nlat1, nlon1, nlat2, nlon2);
}

export function buildDistanceMatrix(locations = []) {
  const matrix = {};
  locations.forEach((locA) => {
    const idA = locA.id || locA.name || 'loc';
    matrix[idA] = {};
    locations.forEach((locB) => {
      const idB = locB.id || locB.name || 'loc';
      if (idA === idB) {
        matrix[idA][idB] = 0;
      } else {
        const d = distanceService.getDistance(locA, locB);
        matrix[idA][idB] = d !== null ? d : 0;
      }
    });
  });
  return matrix;
}

export function calculateTotalRouteDistance(orderedPoints = []) {
  return distanceService.calculateTotalPathDistance(orderedPoints);
}
