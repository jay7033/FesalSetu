// Shipment Service: Tracking, Number Generation, and Status Transitions
import { canTransitionShipmentStatus, SHIPMENT_LIFECYCLE_STEPS } from './logisticsUtils.js';

export const shipmentService = {
  /**
   * Generates a formal tracking number (e.g. FS-SHP-2026-00124)
   */
  generateTrackingNumber() {
    const year = new Date().getFullYear();
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    return `FS-SHP-${year}-${randomSuffix}`;
  },

  /**
   * Constructs a shipment record from an order and fulfillment
   */
  createShipment({
    orderId,
    fulfillmentId,
    routeId = null,
    orderNumber = null,
    supplierName = 'Farmer Collective',
    buyerName = 'Consumer',
    destinationCity = 'Noida',
    quantity = 0,
    unit = 'kg'
  }) {
    const trackingNumber = this.generateTrackingNumber();
    const now = new Date().toISOString();

    return {
      id: `shp-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      orderId,
      fulfillmentId,
      routeId,
      orderNumber: orderNumber || `FS-${orderId}`,
      trackingNumber,
      supplierName,
      buyerName,
      destinationCity,
      quantity,
      unit,
      status: 'CREATED',
      lifecycle: SHIPMENT_LIFECYCLE_STEPS,
      timeline: [{ status: 'CREATED', timestamp: now, note: 'Shipment manifest initialized' }],
      createdAt: now,
      updatedAt: now,
      pickupTime: null,
      estimatedDeliveryTime: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(),
      actualDeliveryTime: null
    };
  },

  /**
   * Updates shipment status with sequential lifecycle validation
   */
  advanceStatus(shipment, targetStatus) {
    if (!shipment) {
      return { success: false, error: 'Shipment record not found.' };
    }

    if (!canTransitionShipmentStatus(shipment.status, targetStatus)) {
      return {
        success: false,
        error: `Invalid transition: cannot advance shipment from ${shipment.status} to ${targetStatus}.`
      };
    }

    const now = new Date().toISOString();
    const timeline = Array.isArray(shipment.timeline) ? [...shipment.timeline] : [];
    timeline.push({ status: targetStatus, timestamp: now });

    const updated = {
      ...shipment,
      status: targetStatus,
      timeline,
      updatedAt: now
    };

    if (targetStatus === 'PICKED_UP') {
      updated.pickupTime = now;
    } else if (targetStatus === 'DELIVERED') {
      updated.actualDeliveryTime = now;
    }

    return {
      success: true,
      shipment: updated
    };
  }
};

export const generateTrackingNumber = () => shipmentService.generateTrackingNumber();
export const createShipmentRecord = (args) => shipmentService.createShipment(args);
export const advanceShipmentStatus = (s, t) => shipmentService.advanceStatus(s, t);
