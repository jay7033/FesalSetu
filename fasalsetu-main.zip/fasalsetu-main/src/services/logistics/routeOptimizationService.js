// Route Optimization Engine: Nearest-Neighbor Heuristic, 2-Opt Local Search, Capacity Validation & ETA Estimation
import { distanceService } from './distanceService.js';
import { 
  LOGISTICS_SPEED_CONFIG, 
  calculateTransportCost,
  getVehicleProfile
} from './logisticsUtils.js';

class PrototypeRoutingProvider {
  /**
   * Nearest-Neighbor route construction from origin through all stops to destination.
   */
  constructNearestNeighborTour(origin, stops, destination) {
    if (!stops || stops.length === 0) {
      return [origin, destination].filter(Boolean);
    }

    const unvisited = [...stops];
    const tour = [origin];
    let currentPoint = origin;

    while (unvisited.length > 0) {
      let nearestIndex = 0;
      let minDistance = Infinity;

      for (let i = 0; i < unvisited.length; i++) {
        const dist = distanceService.getDistance(currentPoint, unvisited[i]);
        if (dist !== null && dist < minDistance) {
          minDistance = dist;
          nearestIndex = i;
        }
      }

      const nextStop = unvisited.splice(nearestIndex, 1)[0];
      tour.push(nextStop);
      currentPoint = nextStop;
    }

    if (destination) {
      tour.push(destination);
    }

    return tour;
  }

  /**
   * 2-Opt optimization to untangle crossings in intermediate stops.
   * Preserves fixed origin (index 0) and destination (last index).
   */
  optimize2Opt(tour) {
    if (!tour || tour.length <= 3) {
      return tour;
    }

    let bestTour = [...tour];
    let bestDistance = distanceService.calculateTotalPathDistance(bestTour);
    let improved = true;
    let iterations = 0;
    const MAX_ITERATIONS = 50;

    // Only swap intermediate stops (index 1 to length - 2)
    while (improved && iterations < MAX_ITERATIONS) {
      improved = false;
      iterations++;

      for (let i = 1; i < bestTour.length - 2; i++) {
        for (let j = i + 1; j < bestTour.length - 1; j++) {
          // Perform 2-opt swap (reverse segment from i to j)
          const newTour = [
            ...bestTour.slice(0, i),
            ...bestTour.slice(i, j + 1).reverse(),
            ...bestTour.slice(j + 1)
          ];

          const newDistance = distanceService.calculateTotalPathDistance(newTour);
          if (newDistance < bestDistance - 0.01) { // 10m threshold
            bestTour = newTour;
            bestDistance = newDistance;
            improved = true;
            break;
          }
        }
        if (improved) break;
      }
    }

    return bestTour;
  }
}

export const defaultRoutingProvider = new PrototypeRoutingProvider();

export const routeOptimizationService = {
  provider: defaultRoutingProvider,

  setProvider(newProvider) {
    if (newProvider && typeof newProvider.constructNearestNeighborTour === 'function') {
      this.provider = newProvider;
    }
  },

  /**
   * Validates if total load satisfies vehicle capacity.
   */
  validateCapacity(totalLoadKg = 0, vehicleType = 'Small Truck') {
    const profile = getVehicleProfile(vehicleType);
    const capacityKg = profile.capacityKg;
    const requiredKg = Math.max(Number(totalLoadKg) || 0, 0);
    const isValid = requiredKg <= capacityKg;
    const excessKg = isValid ? 0 : Math.round(requiredKg - capacityKg);
    const utilizationPercent = Math.min(Math.round((requiredKg / capacityKg) * 100), 100);

    return {
      isValid,
      vehicleType: profile.type,
      capacityKg,
      requiredKg,
      excessKg,
      utilizationPercent
    };
  },

  /**
   * Estimates total travel and dwell duration in minutes.
   */
  estimateDuration(distanceKm = 0, stops = []) {
    const travelMinutes = (distanceKm / LOGISTICS_SPEED_CONFIG.AVG_SPEED_KMH) * 60;
    
    let dwellMinutes = 0;
    stops.forEach((stop) => {
      const type = stop.stopType || stop.type || 'PICKUP';
      if (type === 'PICKUP') {
        dwellMinutes += LOGISTICS_SPEED_CONFIG.PICKUP_DWELL_MINS;
      } else if (type === 'DELIVERY') {
        dwellMinutes += LOGISTICS_SPEED_CONFIG.DELIVERY_DWELL_MINS;
      } else if (type === 'HUB') {
        dwellMinutes += LOGISTICS_SPEED_CONFIG.HUB_DWELL_MINS;
      }
    });

    return Math.round(travelMinutes + dwellMinutes);
  },

  /**
   * Generates a fully optimized route from origin, intermediate stops, and destination.
   */
  optimizeRoute({
    origin,
    stops = [],
    destination,
    vehicleType = 'Small Truck',
    apply2Opt = true
  }) {
    // 1. Calculate unoptimized naive distance for comparison benchmark
    const naiveTour = [origin, ...stops, destination].filter(Boolean);
    const naiveDistance = distanceService.calculateTotalPathDistance(naiveTour);

    // 2. Build nearest-neighbor tour
    const initialTour = this.provider.constructNearestNeighborTour(origin, stops, destination);

    // 3. Apply 2-Opt improvement if enabled
    const optimizedTour = apply2Opt ? this.provider.optimize2Opt(initialTour) : initialTour;
    const optimizedDistance = distanceService.calculateTotalPathDistance(optimizedTour);

    // 4. Calculate savings
    const distanceSaved = Math.max(Math.round((naiveDistance - optimizedDistance) * 10) / 10, 0);
    const percentSaved = naiveDistance > 0 
      ? Math.round((distanceSaved / naiveDistance) * 1000) / 10 
      : 0;

    // 5. Total load and capacity checks
    const totalLoadKg = stops.reduce((acc, s) => acc + (Number(s.loadQuantity || s.quantity) || 0), 0);
    const capacityCheck = this.validateCapacity(totalLoadKg, vehicleType);

    // 6. ETA and cost estimation
    const estimatedMinutes = this.estimateDuration(optimizedDistance, stops);
    const estimatedCost = calculateTransportCost(optimizedDistance, vehicleType);

    // 7. Format stops with sequential arrival progression
    let accumulatedTime = Date.now();
    const formattedStops = optimizedTour.map((point, index) => {
      const isOrigin = index === 0;
      const isDest = index === optimizedTour.length - 1;
      const stopType = isOrigin ? 'ORIGIN' : isDest ? 'DELIVERY' : (point.stopType || 'PICKUP');

      // Estimate progressive arrival
      const segDistance = index > 0 ? (distanceService.getDistance(optimizedTour[index - 1], point) || 5) : 0;
      const segDurationMinutes = (segDistance / LOGISTICS_SPEED_CONFIG.AVG_SPEED_KMH) * 60;
      accumulatedTime += (segDurationMinutes * 60 * 1000);

      const estimatedArrival = new Date(accumulatedTime).toISOString();

      return {
        ...point,
        sequenceNumber: index + 1,
        stopType,
        estimatedArrival,
        approximateAddress: point.approximateAddress || point.address || point.city || 'Regional Hub'
      };
    });

    return {
      optimizedTour: formattedStops,
      totalDistanceKm: optimizedDistance,
      naiveDistanceKm: naiveDistance,
      distanceSavedKm: distanceSaved,
      percentSaved,
      estimatedDurationMinutes: estimatedMinutes,
      estimatedCost,
      totalLoadKg,
      capacityCheck,
      vehicleType
    };
  },

  /**
   * Splits orders into multiple feasible routes if load exceeds single vehicle capacity.
   */
  splitIntoRoutes(stops = [], vehicleType = 'Small Truck', origin, destination) {
    const profile = getVehicleProfile(vehicleType);
    const maxCapacity = profile.capacityKg;

    const routes = [];
    let currentBatch = [];
    let currentBatchLoad = 0;

    stops.forEach((stop) => {
      const stopLoad = Number(stop.loadQuantity || stop.quantity || stop.loadKg) || 0;

      if (currentBatchLoad + stopLoad > maxCapacity && currentBatch.length > 0) {
        // Finalize current route batch
        const opt = this.optimizeRoute({
          origin,
          stops: currentBatch,
          destination,
          vehicleType: profile.type
        });
        routes.push({
          ...opt,
          totalLoadKg: currentBatchLoad
        });
        currentBatch = [];
        currentBatchLoad = 0;
      }

      currentBatch.push(stop);
      currentBatchLoad += stopLoad;
    });

    if (currentBatch.length > 0) {
      const opt = this.optimizeRoute({
        origin,
        stops: currentBatch,
        destination,
        vehicleType: profile.type
      });
      routes.push({
        ...opt,
        totalLoadKg: currentBatchLoad
      });
    }

    return routes;
  }
};

export function optimizeRoute(args) {
  let origin = args?.origin;
  let stops = args?.stops || [];
  let destination = args?.destination;
  const vehicleType = args?.vehicleType || args?.vehicleKey || 'Small Truck';
  const apply2Opt = args?.apply2Opt !== false;

  // If origin/destination not explicitly separated, take first and last of stops
  if (!origin && stops.length > 0) {
    origin = stops[0];
    if (!destination && stops.length > 1) {
      destination = stops[stops.length - 1];
      stops = stops.slice(1, -1);
    } else {
      stops = stops.slice(1);
    }
  }

  const res = routeOptimizationService.optimizeRoute({
    origin,
    stops,
    destination,
    vehicleType,
    apply2Opt
  });

  return {
    ...res,
    optimizedStops: res.optimizedTour,
    optimizedDistanceKm: res.totalDistanceKm,
    naiveDistanceKm: res.naiveDistanceKm,
    algorithm: 'NEAREST_NEIGHBOR_2OPT'
  };
}

export function validateCapacity(args, maybeVehicleType) {
  let totalLoadKg = 0;
  let vehicleType = 'Small Truck';

  if (typeof args === 'object' && args !== null) {
    totalLoadKg = args.totalLoadKg ?? args.requiredKg ?? 0;
    vehicleType = args.vehicleType || args.vehicleKey || 'Small Truck';
  } else {
    totalLoadKg = Number(args) || 0;
    vehicleType = maybeVehicleType || 'Small Truck';
  }

  return routeOptimizationService.validateCapacity(totalLoadKg, vehicleType);
}

export function splitIntoRoutes(args) {
  const stops = args?.stops || [];
  const vehicleType = args?.vehicleType || args?.vehicleKey || 'Small Truck';
  const origin = args?.origin;
  const destination = args?.destination;

  const routes = routeOptimizationService.splitIntoRoutes(stops, vehicleType, origin, destination);
  return routes.map((r) => ({
    ...r,
    totalLoadKg: r.totalLoadKg
  }));
}

export function calculateRouteETA(args) {
  const stops = args?.stops || [];
  let accumulatedTime = Date.now();

  const formattedStops = stops.map((stop, idx) => {
    if (idx > 0) {
      accumulatedTime += (15 * 60 * 1000);
    }
    return {
      ...stop,
      estimatedArrival: new Date(accumulatedTime).toISOString()
    };
  });

  return { stops: formattedStops };
}
