// Central Logistics Service: Route CRUD, Supabase Persistence & Realtime Integration
import { supabase, isSupabaseConfigured } from '../../lib/supabase.js';
import { routeOptimizationService } from './routeOptimizationService.js';
import { canTransitionRouteStatus } from './logisticsUtils.js';

const ROUTES_STORAGE_KEY = 'fasalsetu_logistics_routes_v1';
const SHIPMENTS_STORAGE_KEY = 'fasalsetu_logistics_shipments_v1';
const PICKUPS_STORAGE_KEY = 'fasalsetu_logistics_pickups_v1';

// Seed initial demo route and shipments for seamless offline experience
const INITIAL_DEMO_ROUTES = [
  {
    id: 'rt-101',
    routeNumber: 'FS-RT-2026-0018',
    status: 'PLANNED',
    vehicleType: 'Small Truck',
    vehicleCapacity: 1000,
    totalLoad: 680,
    totalDistanceKm: 42.5,
    estimatedDurationMinutes: 105,
    estimatedCost: 1138,
    distanceSavedKm: 14.2,
    percentSaved: 25.1,
    startLocation: { name: 'Yamuna Farm Aggregation Yard', city: 'Greater Noida', state: 'Uttar Pradesh', lat: 28.35, lng: 77.53 },
    endLocation: { name: 'Noida Society Hub Sector 62', city: 'Noida', state: 'Uttar Pradesh', lat: 28.62, lng: 77.36 },
    stops: [
      {
        sequenceNumber: 1,
        stopType: 'ORIGIN',
        approximateAddress: 'Yamuna Farm Aggregation Yard, Greater Noida',
        loadQuantity: 0,
        estimatedArrival: '09:00 AM'
      },
      {
        sequenceNumber: 2,
        stopType: 'PICKUP',
        approximateAddress: 'Green Valley Farms, Dankaur',
        producerName: 'Ramesh Kumar',
        cropName: 'Desi Tomato',
        loadQuantity: 280,
        estimatedArrival: '09:30 AM'
      },
      {
        sequenceNumber: 3,
        stopType: 'PICKUP',
        approximateAddress: 'Kisan Samriddhi Center, Jewar',
        producerName: 'Kisan Samriddhi FPO',
        cropName: 'Organic Potato',
        loadQuantity: 400,
        estimatedArrival: '10:15 AM'
      },
      {
        sequenceNumber: 4,
        stopType: 'DELIVERY',
        approximateAddress: 'Noida Sector 62 Dropoff Hub',
        buyerName: 'Consumer & Retail Group',
        loadQuantity: 680,
        estimatedArrival: '11:15 AM'
      }
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: 'rt-102',
    routeNumber: 'FS-RT-2026-0019',
    status: 'IN_PROGRESS',
    vehicleType: 'Medium Truck',
    vehicleCapacity: 2500,
    totalLoad: 1800,
    totalDistanceKm: 68.0,
    estimatedDurationMinutes: 140,
    estimatedCost: 2210,
    distanceSavedKm: 21.5,
    percentSaved: 24.0,
    startLocation: { name: 'Jewar Multi-Farm Collection Yard', city: 'Jewar', state: 'Uttar Pradesh', lat: 28.12, lng: 77.55 },
    endLocation: { name: 'Ghaziabad Wholesale Terminal', city: 'Ghaziabad', state: 'Uttar Pradesh', lat: 28.66, lng: 77.45 },
    stops: [
      {
        sequenceNumber: 1,
        stopType: 'ORIGIN',
        approximateAddress: 'Jewar Central Hub, Jewar',
        loadQuantity: 0,
        estimatedArrival: '08:00 AM'
      },
      {
        sequenceNumber: 2,
        stopType: 'PICKUP',
        approximateAddress: 'Kisan Samriddhi Center, Jewar',
        producerName: 'Balram Singh',
        cropName: 'Sharbati Wheat',
        loadQuantity: 1000,
        estimatedArrival: '08:45 AM'
      },
      {
        sequenceNumber: 3,
        stopType: 'PICKUP',
        approximateAddress: 'Dadri Farmer Yard',
        producerName: 'Dadri Bio Cluster',
        cropName: 'Mustard Seed',
        loadQuantity: 800,
        estimatedArrival: '09:30 AM'
      },
      {
        sequenceNumber: 4,
        stopType: 'DELIVERY',
        approximateAddress: 'Ghaziabad Regional Delivery Hub',
        buyerName: 'FreshMart Institutional',
        loadQuantity: 1800,
        estimatedArrival: '10:45 AM'
      }
    ],
    createdAt: new Date().toISOString()
  }
];

const INITIAL_DEMO_SHIPMENTS = [
  {
    id: 'shp-201',
    orderId: 'FS1024',
    orderNumber: 'FS-1024',
    trackingNumber: 'FS-SHP-2026-1024',
    supplierName: 'Ramesh Kumar',
    buyerName: 'Pooja Sharma',
    destinationCity: 'Noida',
    quantity: 12,
    unit: 'kg',
    status: 'IN_TRANSIT',
    pickupTime: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
    estimatedDeliveryTime: new Date(Date.now() + 45 * 60 * 1000).toISOString(),
    createdAt: new Date().toISOString()
  },
  {
    id: 'shp-202',
    orderId: 'FS1023',
    orderNumber: 'FS-1023',
    trackingNumber: 'FS-SHP-2026-1023',
    supplierName: 'Kisan Samriddhi FPO',
    buyerName: 'FreshMart Retail & Institutional',
    destinationCity: 'Greater Noida',
    quantity: 500,
    unit: 'kg',
    status: 'PICKUP_SCHEDULED',
    pickupTime: null,
    estimatedDeliveryTime: new Date(Date.now() + 180 * 60 * 1000).toISOString(),
    createdAt: new Date().toISOString()
  }
];

const INITIAL_DEMO_PICKUPS = [
  {
    id: 'pkl-301',
    fulfillmentId: 'ful-1',
    farmerName: 'Ramesh Kumar',
    farmLocationText: 'Green Valley Natural Farms, Dankaur',
    cropName: 'Desi Tomato',
    scheduledDate: new Date().toISOString().split('T')[0],
    timeWindowStart: '10:00',
    timeWindowEnd: '12:00',
    timeWindowFormatted: '10:00 AM – 12:00 PM',
    quantity: 120,
    status: 'SCHEDULED',
    notes: 'Please arrive at Gate 2 near cold room',
    createdAt: new Date().toISOString()
  }
];

export const logisticsService = {
  /**
   * Generates a formal route identifier (e.g. FS-RT-2026-0042)
   */
  generateRouteNumber() {
    const year = new Date().getFullYear();
    const suffix = Math.floor(1000 + Math.random() * 9000);
    return `FS-RT-${year}-${suffix}`;
  },

  /**
   * Plans and optimizes a multi-stop route from active order fulfillments.
   */
  planRouteFromFulfillments({
    fulfillments = [],
    origin = { name: 'Yamuna Hub', city: 'Greater Noida', latitude: 28.35, longitude: 77.53 },
    destination = { name: 'Noida Metro Hub', city: 'Noida', latitude: 28.62, longitude: 77.36 },
    vehicleType = 'Small Truck'
  }) {
    // Map fulfillments to intermediate pickup stops
    const stops = fulfillments.map((ful, idx) => ({
      fulfillmentId: ful.id || `ful-${idx}`,
      orderId: ful.orderId,
      stopType: 'PICKUP',
      producerName: ful.supplierName || 'Farm Producer',
      approximateAddress: ful.originAddress || ful.farmLocation?.approximateLocation || ful.farmLocation || 'Greater Noida Cluster',
      latitude: ful.lat || ful.farmLocation?.latitude || (28.35 + (idx * 0.05)),
      longitude: ful.lng || ful.farmLocation?.longitude || (77.53 + (idx * 0.03)),
      loadQuantity: Number(ful.quantityKg || ful.quantity) || 50,
      cropName: ful.cropName || (ful.items?.[0]?.name) || 'Fresh Produce'
    }));

    const optimized = routeOptimizationService.optimizeRoute({
      origin,
      stops,
      destination,
      vehicleType
    });

    const routeNumber = this.generateRouteNumber();
    const newRoute = {
      id: `rt-${Date.now()}`,
      routeNumber,
      status: 'PLANNED',
      vehicleType,
      vehicleCapacity: optimized.capacityCheck.capacityKg,
      totalLoad: optimized.totalLoadKg,
      totalDistanceKm: optimized.totalDistanceKm,
      estimatedDurationMinutes: optimized.estimatedDurationMinutes,
      estimatedCost: optimized.estimatedCost,
      distanceSavedKm: optimized.distanceSavedKm,
      percentSaved: optimized.percentSaved,
      startLocation: origin,
      endLocation: destination,
      stops: optimized.optimizedTour,
      createdAt: new Date().toISOString()
    };

    return newRoute;
  },

  /**
   * Retrieves active routes
   */
  async getRoutes() {
    if (isSupabaseConfigured()) {
      try {
        const { data, error } = await supabase
          .from('logistics_routes')
          .select('*, logistics_route_stops(*)')
          .order('created_at', { ascending: false });

        if (!error && data && data.length > 0) {
          return data.map((d) => ({
            id: d.id,
            routeNumber: d.route_number,
            status: d.status,
            vehicleType: d.vehicle_type,
            vehicleCapacity: Number(d.vehicle_capacity),
            totalLoad: Number(d.total_load),
            totalDistanceKm: Number(d.total_distance_km),
            estimatedDurationMinutes: d.estimated_duration_minutes,
            estimatedCost: Number(d.estimated_cost),
            startLocation: d.start_location,
            endLocation: d.end_location,
            stops: (d.logistics_route_stops || []).map((s) => ({
              sequenceNumber: s.sequence_number,
              stopType: s.stop_type,
              approximateAddress: s.approximate_address,
              loadQuantity: Number(s.load_quantity),
              status: s.status,
              estimatedArrival: s.estimated_arrival
            })),
            createdAt: d.created_at
          }));
        }
      } catch (err) {
        console.warn('Supabase routes fetch fallback to local:', err);
      }
    }

    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem(ROUTES_STORAGE_KEY);
      if (stored) {
        try {
          return JSON.parse(stored);
        } catch {
          // ignore error
        }
      }
      localStorage.setItem(ROUTES_STORAGE_KEY, JSON.stringify(INITIAL_DEMO_ROUTES));
    }

    return INITIAL_DEMO_ROUTES;
  },

  /**
   * Retrieves shipments
   */
  async getShipments() {
    if (isSupabaseConfigured()) {
      try {
        const { data, error } = await supabase
          .from('shipments')
          .select('*')
          .order('created_at', { ascending: false });

        if (!error && data && data.length > 0) {
          return data.map((s) => ({
            id: s.id,
            orderId: s.order_id,
            fulfillmentId: s.fulfillment_id,
            routeId: s.route_id,
            trackingNumber: s.tracking_number,
            status: s.status,
            pickupTime: s.pickup_time,
            estimatedDeliveryTime: s.estimated_delivery_time,
            actualDeliveryTime: s.actual_delivery_time,
            createdAt: s.created_at
          }));
        }
      } catch (err) {
        console.warn('Supabase shipments fetch fallback to local:', err);
      }
    }

    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem(SHIPMENTS_STORAGE_KEY);
      if (stored) {
        try {
          return JSON.parse(stored);
        } catch {
          // ignore error
        }
      }
      localStorage.setItem(SHIPMENTS_STORAGE_KEY, JSON.stringify(INITIAL_DEMO_SHIPMENTS));
    }

    return INITIAL_DEMO_SHIPMENTS;
  },

  /**
   * Retrieves pickup schedules
   */
  async getPickupSchedules() {
    if (isSupabaseConfigured()) {
      try {
        const { data, error } = await supabase
          .from('pickup_schedules')
          .select('*')
          .order('scheduled_date', { ascending: true });

        if (!error && data && data.length > 0) {
          return data.map((p) => ({
            id: p.id,
            fulfillmentId: p.fulfillment_id,
            farmLocationId: p.farm_location_id,
            scheduledDate: p.scheduled_date,
            timeWindowStart: p.time_window_start,
            timeWindowEnd: p.time_window_end,
            timeWindowFormatted: `${p.time_window_start} – ${p.time_window_end}`,
            quantity: Number(p.quantity),
            status: p.status,
            notes: p.notes,
            createdAt: p.created_at
          }));
        }
      } catch (err) {
        console.warn('Supabase pickup schedules fetch fallback to local:', err);
      }
    }

    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem(PICKUPS_STORAGE_KEY);
      if (stored) {
        try {
          return JSON.parse(stored);
        } catch {
          // ignore error
        }
      }
      localStorage.setItem(PICKUPS_STORAGE_KEY, JSON.stringify(INITIAL_DEMO_PICKUPS));
    }

    return INITIAL_DEMO_PICKUPS;
  },

  /**
   * Transitions route status
   */
  advanceRouteStatus(route, targetStatus) {
    if (!route) {
      return { success: false, error: 'Route not found.' };
    }

    if (!canTransitionRouteStatus(route.status, targetStatus)) {
      return {
        success: false,
        error: `Cannot change route status from ${route.status} to ${targetStatus}.`
      };
    }

    const updated = {
      ...route,
      status: targetStatus,
      updatedAt: new Date().toISOString()
    };

    return { success: true, route: updated };
  },

  /**
   * Synchronously retrieves demo or locally stored routes
   */
  getAllRoutes() {
    if (typeof window !== 'undefined') {
      try {
        const stored = localStorage.getItem(ROUTES_STORAGE_KEY);
        if (stored) return JSON.parse(stored);
      } catch {
        // fallback
      }
    }
    return INITIAL_DEMO_ROUTES;
  },

  /**
   * Creates and optimizes a new route from fulfillments with success envelope
   */
  createRouteFromFulfillments({ fulfillments = [], origin, destination, vehicleType, vehicleKey } = {}) {
    try {
      const route = this.planRouteFromFulfillments({
        fulfillments,
        origin,
        destination,
        vehicleType: vehicleType || vehicleKey || 'Small Truck'
      });
      return { success: true, route };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }
};
