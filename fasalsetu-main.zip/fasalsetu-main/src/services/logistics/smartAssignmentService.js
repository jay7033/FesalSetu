/**
 * FasalSetu Smart Delivery Assignment Service
 * Deterministic multi-factor scoring model:
 * Distance (25%), Current Workload (20%), Route Compatibility (20%),
 * Vehicle Capacity (15%), Availability (10%), ETA / Priority (10%)
 */

export const ASSIGNMENT_WEIGHTS = {
  DISTANCE: 0.25,
  WORKLOAD: 0.20,
  ROUTE_COMPATIBILITY: 0.20,
  VEHICLE_CAPACITY: 0.15,
  AVAILABILITY: 0.10,
  ETA_PRIORITY: 0.10
};

/**
 * Calculates haversine distance in kilometers between two lat/lng pairs
 */
export function calculateDistanceKm(lat1, lon1, lat2, lon2) {
  if (!lat1 || !lon1 || !lat2 || !lon2) return 10.0;
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Number((R * c).toFixed(2));
}

/**
 * Evaluates candidate delivery boys against an order task using deterministic multi-criteria scoring.
 * 
 * @param {Object} task - Delivery task with pickup and delivery locations, totalWeightKg, priority
 * @param {Array} candidateBoys - List of delivery boys belonging to target zone/pool
 * @param {Object} options - Configuration options (allowBusyFallback, maxDistanceKm)
 * @returns {Object} { bestCandidate, score, reason, scoredCandidates }
 */
export function evaluateAndAssignDeliveryBoy(task, candidateBoys = [], options = {}) {
  const {
    maxAcceptableDistanceKm = 25.0
  } = options;

  if (!candidateBoys || candidateBoys.length === 0) {
    return {
      bestCandidate: null,
      score: 0,
      reason: 'No registered delivery boys located in the target operational zone.',
      scoredCandidates: []
    };
  }

  const pickupLat = task.pickupLocation?.lat || task.pickupLocation?.latitude || 28.35;
  const pickupLng = task.pickupLocation?.lng || task.pickupLocation?.longitude || 77.53;
  const orderWeightKg = Number(task.totalWeightKg || task.weightKg || 25);

  const scoredCandidates = candidateBoys.map((boy) => {
    // 1. Distance Score (25%): Closer is higher (100 at 0km, 0 at maxAcceptableDistanceKm)
    const distanceKm = calculateDistanceKm(boy.currentLat, boy.currentLng, pickupLat, pickupLng);
    const distanceScore = Math.max(0, Math.min(100, 100 - (distanceKm / maxAcceptableDistanceKm) * 100));

    // 2. Workload Score (20%): 0 active tasks = 100, 1 = 70, 2 = 30, 3+ = 0
    const activeTasks = boy.activeTasksCount || 0;
    let workloadScore = 100;
    if (activeTasks === 1) workloadScore = 70;
    else if (activeTasks === 2) workloadScore = 35;
    else if (activeTasks >= 3) workloadScore = 0;

    // 3. Route Compatibility Score (20%): Evaluates if delivery boy is heading towards pickup/drop
    let routeCompatibilityScore = 80;
    if (boy.status === 'AVAILABLE') routeCompatibilityScore = 95;
    else if (boy.status === 'ON_DELIVERY') routeCompatibilityScore = 60;

    // 4. Vehicle Capacity Score (15%): Sufficient capacity is 100, marginal is 50, insufficient is 0
    const boyCapacity = Number(boy.vehicleCapacityKg || 40);
    let capacityScore = 100;
    if (boyCapacity < orderWeightKg) {
      capacityScore = 0; // Ineligible for this heavy parcel
    } else if (boyCapacity < orderWeightKg * 1.2) {
      capacityScore = 75; // Tight capacity
    }

    // 5. Availability Status Score (10%)
    let availabilityScore = 0;
    if (boy.status === 'AVAILABLE') availabilityScore = 100;
    else if (boy.status === 'ON_DELIVERY' && activeTasks < 3) availabilityScore = 50;

    // 6. ETA / Priority Score (10%): Faster estimated pickup for high/express priorities
    let etaPriorityScore = 85;
    if (task.priority === 'EXPRESS') {
      etaPriorityScore = distanceKm <= 5 ? 100 : Math.max(20, 100 - distanceKm * 10);
    } else if (task.priority === 'HIGH') {
      etaPriorityScore = distanceKm <= 10 ? 95 : 70;
    }

    // Weighted Total Score
    const totalScore = Number(
      (
        distanceScore * ASSIGNMENT_WEIGHTS.DISTANCE +
        workloadScore * ASSIGNMENT_WEIGHTS.WORKLOAD +
        routeCompatibilityScore * ASSIGNMENT_WEIGHTS.ROUTE_COMPATIBILITY +
        capacityScore * ASSIGNMENT_WEIGHTS.VEHICLE_CAPACITY +
        availabilityScore * ASSIGNMENT_WEIGHTS.AVAILABILITY +
        etaPriorityScore * ASSIGNMENT_WEIGHTS.ETA_PRIORITY
      ).toFixed(2)
    );

    // Hard disqualification: Cannot carry payload or is offline
    const isEligible = capacityScore > 0 && boy.status !== 'OFFLINE';

    return {
      boy,
      distanceKm,
      isEligible,
      breakdown: {
        distanceScore,
        workloadScore,
        routeCompatibilityScore,
        capacityScore,
        availabilityScore,
        etaPriorityScore
      },
      totalScore: isEligible ? totalScore : 0
    };
  });

  // Sort eligible candidates by score descending
  const eligibleCandidates = scoredCandidates
    .filter((c) => c.isEligible)
    .sort((a, b) => b.totalScore - a.totalScore);

  if (eligibleCandidates.length === 0) {
    return {
      bestCandidate: null,
      score: 0,
      reason: `No eligible delivery boys with required vehicle capacity (${orderWeightKg} kg) and active availability found in this zone.`,
      scoredCandidates
    };
  }

  const best = eligibleCandidates[0];
  const vehicleLabel = best.boy.vehicleType ? best.boy.vehicleType.replace('_', ' ') : 'vehicle';
  const reason = `Assigned automatically to ${best.boy.name} (Score: ${best.totalScore}%) — ${best.distanceKm} km from pickup, ${best.boy.activeTasksCount || 0} active tasks, with compatible ${vehicleLabel} (${best.boy.vehicleCapacityKg} kg payload capacity).`;

  return {
    bestCandidate: best.boy,
    score: best.totalScore,
    reason,
    scoredCandidates
  };
}

/**
 * High-level Zone-First Auto-Assignment Flow:
 * 1. Checks candidates in task's assigned zone
 * 2. If no candidate found, checks neighboring zones (fallback)
 * 3. Returns assignment result
 */
export function autoAssignTaskZoneFirst(task, allZoneBoys = [], allNeighborBoys = []) {
  // Pass 1: Zone-First Search
  const zoneResult = evaluateAndAssignDeliveryBoy(task, allZoneBoys);
  if (zoneResult.bestCandidate && zoneResult.score >= 50) {
    return {
      assignedBoy: zoneResult.bestCandidate,
      score: zoneResult.score,
      reason: zoneResult.reason,
      source: 'automatic',
      status: 'ASSIGNED'
    };
  }

  // Pass 2: Cross-Zone Fallback Search
  if (allNeighborBoys && allNeighborBoys.length > 0) {
    const fallbackResult = evaluateAndAssignDeliveryBoy(task, allNeighborBoys);
    if (fallbackResult.bestCandidate && fallbackResult.score >= 45) {
      return {
        assignedBoy: fallbackResult.bestCandidate,
        score: fallbackResult.score,
        reason: `[Cross-Zone Fallback] ${fallbackResult.reason}`,
        source: 'fallback',
        status: 'ASSIGNED'
      };
    }
  }

  // Pass 3: Unassigned with notification alert
  return {
    assignedBoy: null,
    score: 0,
    reason: `All delivery boys in primary zone and adjacent corridors are currently at maximum capacity or offline. Coordinator intervention required.`,
    source: 'fallback',
    status: 'UNASSIGNED'
  };
}
