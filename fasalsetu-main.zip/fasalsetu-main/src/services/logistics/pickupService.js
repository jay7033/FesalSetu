// Pickup Scheduling & Planning Service for Producers (Farmers and FPOs)
import { canTransitionPickupStatus } from './logisticsUtils.js';

export const pickupService = {
  /**
   * Creates a pickup schedule record
   */
  createSchedule({
    fulfillmentId,
    farmLocationId = null,
    farmerName = 'Producer',
    farmLocationText = 'Greater Noida Yard',
    scheduledDate = null,
    timeWindowStart = '10:00',
    timeWindowEnd = '12:00',
    quantity = 50,
    cropName = 'Fresh Produce',
    notes = ''
  }) {
    const today = new Date().toISOString().split('T')[0];
    const now = new Date().toISOString();

    return {
      id: `pkl-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      fulfillmentId,
      farmLocationId,
      farmerName,
      farmLocationText,
      cropName,
      scheduledDate: scheduledDate || today,
      timeWindowStart,
      timeWindowEnd,
      timeWindowFormatted: `${timeWindowStart} – ${timeWindowEnd}`,
      quantity,
      status: 'SCHEDULED',
      notes,
      createdAt: now,
      updatedAt: now
    };
  },

  /**
   * Transitions pickup status (e.g. from SCHEDULED to READY, or READY to PICKED_UP)
   */
  advanceStatus(schedule, targetStatus) {
    if (!schedule) {
      return { success: false, error: 'Pickup schedule not found.' };
    }

    if (!canTransitionPickupStatus(schedule.status, targetStatus)) {
      return {
        success: false,
        error: `Invalid transition: cannot change pickup schedule from ${schedule.status} to ${targetStatus}.`
      };
    }

    const updated = {
      ...schedule,
      status: targetStatus,
      updatedAt: new Date().toISOString()
    };

    return {
      success: true,
      schedule: updated
    };
  }
};

export const createPickupSchedule = (args) => pickupService.createSchedule(args);
export const advancePickupStatus = (p, t) => pickupService.advanceStatus(p, t);
