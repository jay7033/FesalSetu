/**
 * Reverse Geocoding Service for Pan-India Farm Locations
 * Reverse geocodes latitude/longitude to Indian village, city, district, state, and pincode
 * Configurable via environment variables with graceful offline fallback
 */

const REVERSE_GEOCODE_ENDPOINT = 
  import.meta.env.VITE_REVERSE_GEOCODE_API_URL || 
  'https://nominatim.openstreetmap.org/reverse';

/**
 * Reverse Geocode GPS coordinates
 * @param {number} latitude 
 * @param {number} longitude 
 * @returns {Promise<Object>} Formatted location object
 */
export async function reverseGeocode(latitude, longitude) {
  if (!latitude || !longitude) {
    throw new Error('Latitude and Longitude are required for reverse geocoding');
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000); // 6s timeout

    const url = `${REVERSE_GEOCODE_ENDPOINT}?lat=${latitude}&lon=${longitude}&format=json&addressdetails=1&accept-language=en`;
    
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        'Accept': 'application/json',
      }
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`Geocoding HTTP ${response.status}`);
    }

    const data = await response.json();
    const addr = data.address || {};

    const village = addr.village || addr.hamlet || addr.suburb || addr.neighbourhood || '';
    const locality = addr.residential || addr.road || addr.suburb || '';
    const city = addr.city || addr.town || addr.municipality || addr.village || addr.county || 'Local Area';
    const district = addr.state_district || addr.county || addr.district || city;
    const state = addr.state || inferIndianStateFromCoords(latitude, longitude) || 'Uttar Pradesh';
    const pincode = addr.postcode || '';
    const country = addr.country || 'India';
    const countryCode = (addr.country_code || 'in').toUpperCase();

    // Human-readable formatted address
    const parts = [village, city, district, state, pincode].filter(Boolean);
    const formattedAddress = parts.join(', ');

    return {
      success: true,
      latitude: Number(latitude),
      longitude: Number(longitude),
      village,
      locality,
      city,
      district,
      state,
      stateCode: getStateCode(state),
      pincode,
      country,
      countryCode,
      formattedAddress: formattedAddress || `Coordinates: ${latitude.toFixed(4)}, ${longitude.toFixed(4)}`,
      approximateLocation: `Near ${city || district}, ${state}`,
      source: 'device',
      capturedAt: new Date().toISOString()
    };
  } catch (err) {
    console.warn('Remote reverse-geocoding unavailable or timed out, using fallback heuristics:', err.message);

    // Graceful fallback heuristics so registration NEVER breaks!
    const inferredState = inferIndianStateFromCoords(latitude, longitude) || 'Uttar Pradesh';
    const inferredDistrict = inferDistrictFromCoords(latitude, longitude) || 'Gautam Buddha Nagar';

    return {
      success: true,
      fallback: true,
      latitude: Number(latitude),
      longitude: Number(longitude),
      village: '',
      locality: '',
      city: inferredDistrict,
      district: inferredDistrict,
      state: inferredState,
      stateCode: getStateCode(inferredState),
      pincode: '',
      country: 'India',
      countryCode: 'IN',
      formattedAddress: `Near ${inferredDistrict}, ${inferredState}`,
      approximateLocation: `Near ${inferredDistrict}, ${inferredState}`,
      notice: 'Coordinates detected. Address lookup temporarily unavailable.',
      source: 'device',
      capturedAt: new Date().toISOString()
    };
  }
}

/**
 * Standard Indian State Code mapping
 */
export function getStateCode(stateName) {
  const map = {
    'Uttar Pradesh': 'UP',
    'Maharashtra': 'MH',
    'Punjab': 'PB',
    'Karnataka': 'KA',
    'Tamil Nadu': 'TN',
    'West Bengal': 'WB',
    'Madhya Pradesh': 'MP',
    'Rajasthan': 'RJ',
    'Gujarat': 'GJ',
    'Andhra Pradesh': 'AP',
    'Haryana': 'HR',
    'Delhi': 'DL',
    'Bihar': 'BR',
    'Kerala': 'KL',
    'Telangana': 'TS'
  };
  return map[stateName] || 'IN';
}

/**
 * Approximate state determination from coordinates for fallback
 */
function inferIndianStateFromCoords(lat, lon) {
  if (lat >= 28 && lat <= 29 && lon >= 77 && lon <= 78) return 'Uttar Pradesh';
  if (lat >= 18 && lat <= 21 && lon >= 72 && lon <= 75) return 'Maharashtra';
  if (lat >= 30 && lat <= 32 && lon >= 74 && lon <= 77) return 'Punjab';
  if (lat >= 11 && lat <= 18 && lon >= 74 && lon <= 78) return 'Karnataka';
  if (lat >= 8 && lat <= 13 && lon >= 76 && lon <= 80) return 'Tamil Nadu';
  if (lat >= 21 && lat <= 27 && lon >= 85 && lon <= 90) return 'West Bengal';
  if (lat >= 21 && lat <= 26 && lon >= 74 && lon <= 82) return 'Madhya Pradesh';
  if (lat >= 23 && lat <= 30 && lon >= 69 && lon <= 78) return 'Rajasthan';
  if (lat >= 20 && lat <= 24 && lon >= 68 && lon <= 74) return 'Gujarat';
  if (lat >= 13 && lat <= 19 && lon >= 76 && lon <= 84) return 'Andhra Pradesh';
  return 'Uttar Pradesh';
}

function inferDistrictFromCoords(lat, lon) {
  if (lat >= 28.3 && lat <= 28.7 && lon >= 77.3 && lon <= 77.7) return 'Gautam Buddha Nagar';
  if (lat >= 19.8 && lat <= 20.2 && lon >= 73.6 && lon <= 74.0) return 'Nashik';
  if (lat >= 30.8 && lat <= 31.0 && lon >= 75.7 && lon <= 76.0) return 'Ludhiana';
  if (lat >= 26.7 && lat <= 27.0 && lon >= 80.8 && lon <= 81.1) return 'Lucknow';
  if (lat >= 12.8 && lat <= 13.1 && lon >= 77.4 && lon <= 77.7) return 'Bengaluru Rural';
  return 'Local District';
}
