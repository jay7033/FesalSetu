/**
 * Location Service
 * Manages farm and buyer geographical records, default selections, and privacy safeguards.
 */

import { supabase, isSupabaseConfigured } from '../lib/supabase.js';

export const locationService = {
  /**
   * Fetches all farm locations owned by an authenticated farmer or FPO
   */
  async getFarmLocations(ownerProfileId) {
    if (!isSupabaseConfigured() || !ownerProfileId) return null;

    const { data, error } = await supabase
      .from('farm_locations')
      .select('*')
      .eq('owner_profile_id', ownerProfileId)
      .order('is_default', { ascending: false });

    if (error) {
      console.warn('Error fetching farm locations:', error.message);
      return null;
    }
    return data || [];
  },

  /**
   * Adds a new farm location with reverse-geocoded coordinates
   */
  async addFarmLocation(locationData) {
    if (!isSupabaseConfigured()) return null;

    // If marked default, unset other defaults
    if (locationData.is_default && locationData.owner_profile_id) {
      await supabase
        .from('farm_locations')
        .update({ is_default: false })
        .eq('owner_profile_id', locationData.owner_profile_id);
    }

    const { data, error } = await supabase
      .from('farm_locations')
      .insert([locationData])
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Updates an existing farm location
   */
  async updateFarmLocation(id, updates) {
    if (!isSupabaseConfigured()) return null;

    const { data, error } = await supabase
      .from('farm_locations')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Deletes a farm location
   */
  async deleteFarmLocation(id) {
    if (!isSupabaseConfigured()) return null;

    const { error } = await supabase
      .from('farm_locations')
      .delete()
      .eq('id', id);

    if (error) throw error;
    return true;
  },

  /**
   * Fetches buyer delivery or sourcing locations
   */
  async getBuyerLocations(profileId) {
    if (!isSupabaseConfigured() || !profileId) return null;

    const { data, error } = await supabase
      .from('buyer_locations')
      .select('*')
      .eq('profile_id', profileId)
      .order('is_default', { ascending: false });

    if (error) return null;
    return data || [];
  },

  /**
   * Saves a new buyer location
   */
  async addBuyerLocation(locationData) {
    if (!isSupabaseConfigured()) return null;

    if (locationData.is_default && locationData.profile_id) {
      await supabase
        .from('buyer_locations')
        .update({ is_default: false })
        .eq('profile_id', locationData.profile_id);
    }

    const { data, error } = await supabase
      .from('buyer_locations')
      .insert([locationData])
      .select()
      .single();

    if (error) throw error;
    return data;
  }
};

export default locationService;
