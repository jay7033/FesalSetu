/**
 * Order Service
 * Handles transactional order placement via PostgreSQL RPC, multi-supplier queries,
 * sequential status transitions, order cancellation, and Realtime synchronization.
 */

import { supabase, isSupabaseConfigured } from '../lib/supabase.js';

export const orderService = {
  /**
   * Places an order atomically using create_order_transaction RPC
   */
  async createOrder({
    buyerId,
    buyerRole,
    deliveryType,
    paymentMethod,
    deliveryAddress,
    deliveryEstimate,
    buyerLocationId,
    items
  }) {
    if (!isSupabaseConfigured()) return null;

    const formattedItems = items.map((item) => ({
      product_id: item.id || item.productId,
      quantity: Number(item.quantity)
    }));

    const { data, error } = await supabase.rpc('create_order_transaction', {
      p_buyer_id: buyerId,
      p_buyer_role: buyerRole,
      p_delivery_type: deliveryType,
      p_payment_method: paymentMethod,
      p_delivery_address: deliveryAddress,
      p_delivery_estimate: deliveryEstimate,
      p_buyer_location_id: buyerLocationId || null,
      p_items: formattedItems
    });

    if (error) throw error;
    return data;
  },

  /**
   * Fetches all orders placed by a specific consumer or bulk buyer
   */
  async getOrdersForBuyer(buyerProfileId) {
    if (!isSupabaseConfigured()) return null;

    const { data, error } = await supabase
      .from('orders')
      .select(`
        *,
        order_items (*),
        order_fulfillments (*),
        order_timeline (*)
      `)
      .eq('buyer_profile_id', buyerProfileId)
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('Error fetching buyer orders:', error.message);
      return null;
    }
    return data || [];
  },

  /**
   * Fetches all fulfillments / orders assigned to a specific producer (Farmer or FPO)
   */
  async getOrdersForSeller(sellerProfileId) {
    if (!isSupabaseConfigured()) return null;

    const { data, error } = await supabase
      .from('order_fulfillments')
      .select(`
        *,
        orders (
          id,
          order_number,
          buyer_profile_id,
          buyer_role,
          subtotal,
          delivery_fee,
          total,
          delivery_type,
          payment_method,
          payment_status,
          status,
          delivery_address,
          delivery_estimate,
          created_at,
          order_items (*)
        )
      `)
      .eq('seller_profile_id', sellerProfileId)
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('Error fetching seller fulfillments:', error.message);
      return null;
    }
    return data || [];
  },

  /**
   * Fetches a single order with items, fulfillments, and audit timeline
   */
  async getOrderById(orderId) {
    if (!isSupabaseConfigured()) return null;

    const { data, error } = await supabase
      .from('orders')
      .select(`
        *,
        order_items (*),
        order_fulfillments (*),
        order_timeline (*)
      `)
      .or(`id.eq.${orderId},order_number.eq.${orderId}`)
      .single();

    if (error) return null;
    return data;
  },

  /**
   * Advances order status sequentially via update_order_status RPC
   */
  async updateOrderStatus(orderId, newStatus, userId, note) {
    if (!isSupabaseConfigured()) return null;

    const { data, error } = await supabase.rpc('update_order_status', {
      p_order_id: orderId,
      p_new_status: newStatus,
      p_user_id: userId,
      p_note: note || null
    });

    if (error) throw error;
    return data;
  },

  /**
   * Cancels order and releases reserved stock via cancel_order_transaction RPC
   */
  async cancelOrder(orderId, userId, reason) {
    if (!isSupabaseConfigured()) return null;

    const { data, error } = await supabase.rpc('cancel_order_transaction', {
      p_order_id: orderId,
      p_user_id: userId,
      p_reason: reason || 'Cancelled before dispatch'
    });

    if (error) throw error;
    return data;
  },

  /**
   * Realtime subscription for order status updates
   */
  subscribeToOrderUpdates(onUpdate) {
    if (!isSupabaseConfigured()) {
      return { unsubscribe: () => {} };
    }

    const channel = supabase
      .channel('public:orders')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'orders' },
        (payload) => {
          if (onUpdate) onUpdate(payload);
        }
      )
      .subscribe((status, err) => {
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          console.warn(`[Realtime:orders] Subscription ${status}:`, err?.message || 'WebSocket connection could not be established; operating with local/rest state.');
        }
      });

    return {
      unsubscribe: () => {
        supabase.removeChannel(channel);
      }
    };
  }
};

export default orderService;
