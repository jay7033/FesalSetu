/**
 * Buyer Service
 * Manages consumer saved products (favorites) and bulk buyer procurement preferences.
 */

import { supabase, isSupabaseConfigured } from '../lib/supabase.js';

export const buyerService = {
  /**
   * Fetches list of saved product IDs for a consumer
   */
  async getSavedProducts(consumerProfileId) {
    if (!isSupabaseConfigured() || !consumerProfileId) return null;

    const { data, error } = await supabase
      .from('saved_products')
      .select('product_id')
      .eq('consumer_profile_id', consumerProfileId);

    if (error) {
      console.warn('Error fetching saved products:', error.message);
      return null;
    }
    return (data || []).map((row) => row.product_id);
  },

  /**
   * Toggles bookmark of a product for a consumer
   */
  async toggleSavedProduct(consumerProfileId, productId) {
    if (!isSupabaseConfigured() || !consumerProfileId) return null;

    // Check if currently saved
    const { data } = await supabase
      .from('saved_products')
      .select('id')
      .eq('consumer_profile_id', consumerProfileId)
      .eq('product_id', productId)
      .single();

    if (data) {
      // Remove
      await supabase
        .from('saved_products')
        .delete()
        .eq('id', data.id);
      return false; // Not saved anymore
    } else {
      // Add
      await supabase
        .from('saved_products')
        .insert([{
          consumer_profile_id: consumerProfileId,
          product_id: productId
        }]);
      return true; // Now saved
    }
  }
};

export default buyerService;
