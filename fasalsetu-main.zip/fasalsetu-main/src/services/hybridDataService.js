/**
 * FasalSetu — Hybrid Data Service
 * Orchestrates the merge of live Supabase data with demo/seed data.
 * Provides connection status detection and data source utilities.
 */

import { isSupabaseConfigured } from '../lib/supabase.js';
import { deduplicateById } from '../utils/normalizers.js';

// ============================================================
// CONNECTION STATUS
// ============================================================

let _cachedStatus = null;
let _lastCheck = 0;
const CHECK_INTERVAL_MS = 30000; // Re-check every 30 seconds

/**
 * Returns the current data connection status.
 * @returns {'live'|'demo-fallback'}
 */
export function getConnectionStatus() {
  if (!isSupabaseConfigured()) return 'demo-fallback';
  // When Supabase is configured, assume live unless proven otherwise
  return _cachedStatus || 'live';
}

/**
 * Updates the cached connection status (called by contexts after fetching).
 * @param {boolean} supabaseReachable
 */
export function updateConnectionStatus(supabaseReachable) {
  _cachedStatus = supabaseReachable ? 'live' : 'demo-fallback';
  _lastCheck = Date.now();
}

/**
 * Returns whether enough time has passed for a re-check.
 */
export function shouldRecheck() {
  return Date.now() - _lastCheck > CHECK_INTERVAL_MS;
}

// ============================================================
// MERGE & DEDUPLICATE PIPELINE
// ============================================================

/**
 * Generic merge pipeline: normalize both sets → concatenate → deduplicate by ID (live wins).
 * @param {Array} liveData - Records from Supabase (already normalized with source='live')
 * @param {Array} demoData - Records from demo/seed data (already normalized with source='demo')
 * @returns {Array} Merged and deduplicated array
 */
export function mergeAndDeduplicate(liveData, demoData) {
  const live = Array.isArray(liveData) ? liveData : [];
  const demo = Array.isArray(demoData) ? demoData : [];

  // Live data comes first so it takes priority in deduplication
  const combined = [...live, ...demo];
  return deduplicateById(combined);
}

// ============================================================
// RECORD UTILITY CHECKS
// ============================================================

/**
 * Checks if a record is demo data.
 * @param {object} record
 * @returns {boolean}
 */
export function isDemoRecord(record) {
  if (!record) return false;
  return record.isDemo === true || record.is_demo === true || record.source === 'demo';
}

/**
 * Checks whether the current user can modify a given record.
 * Demo records owned by demo accounts are immutable for normal users.
 * @param {object} record - The record to check
 * @param {string} userId - The current user's ID
 * @returns {boolean}
 */
export function canModifyRecord(record, _userId) {
  if (!record) return false;

  // Live records: user can modify if they own it (ownership check is done by RLS at DB level)
  if (!isDemoRecord(record)) return true;

  // Demo records: generally immutable
  // Exception: if the user is the demo account that "owns" it, allow limited interaction
  // But for safety, block modifications of core demo data
  return false;
}

/**
 * Returns a data composition summary for AI/analytics transparency.
 * @param {Array} products - Combined normalized products
 * @param {Array} orders - Combined normalized orders
 * @returns {object} Composition metrics
 */
export function getDataComposition(products, orders) {
  const prods = Array.isArray(products) ? products : [];
  const ords = Array.isArray(orders) ? orders : [];

  const liveProducts = prods.filter(p => !isDemoRecord(p)).length;
  const demoProducts = prods.filter(p => isDemoRecord(p)).length;
  const liveOrders = ords.filter(o => !isDemoRecord(o)).length;
  const demoOrders = ords.filter(o => isDemoRecord(o)).length;

  return {
    totalProducts: prods.length,
    liveProducts,
    demoProducts,
    totalOrders: ords.length,
    liveOrders,
    demoOrders,
    hasLiveData: liveProducts > 0 || liveOrders > 0,
    primarySource: liveOrders > demoOrders ? 'live' : 'demo-baseline',
    label: liveOrders > 0
      ? `Based on ${liveOrders} live + ${demoOrders} demo data points`
      : `Forecast based on demo baseline + available data`
  };
}

export const hybridDataService = {
  getConnectionStatus,
  updateConnectionStatus,
  shouldRecheck,
  mergeAndDeduplicate,
  isDemoRecord,
  canModifyRecord,
  getDataComposition
};

export default hybridDataService;
