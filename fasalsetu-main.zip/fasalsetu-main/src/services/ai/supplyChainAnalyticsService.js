/**
 * Supply-Chain Efficiency Analytics
 * Computes composite scorecard indicators: Demand Coverage, Supply Availability,
 * Fulfillment Efficiency, and Logistics Route Efficiency across active marketplace data.
 */

export const supplyChainAnalyticsService = {
  /**
   * Calculate unified supply-chain health metrics from real orders, inventory, and logistics routes.
   *
   * @param {Array} orders - Marketplace orders from OrderContext
   * @param {Array} products - Available products from ProductContext
   * @param {Array} routes - Logistics routes from LogisticsContext
   * @param {Array} forecasts - Demand forecasts from AIContext
   * @returns {Object} Scorecard metrics
   */
  calculateSupplyChainHealth(orders = [], products = [], routes = [], forecasts = []) {
    // 1. Demand Coverage %
    // Proportion of forecasted demand that has matching inventory listed
    let totalForecastDemand = forecasts.reduce((acc, f) => acc + (f.forecastDemand || f.forecastQuantity || 0), 0);
    let totalAvailableSupply = products.reduce((acc, p) => acc + Number(p.quantity || p.stock || 0), 0);
    
    let demandCoverage = 82; // Baseline prototype demo score
    if (totalForecastDemand > 0) {
      demandCoverage = Math.min(100, Math.round((totalAvailableSupply / totalForecastDemand) * 100));
    }

    // 2. Supply Availability %
    // Percentage of listed products that have healthy in-stock inventory (> 20 units)
    let supplyAvailability = 76;
    if (products.length > 0) {
      const inStockCount = products.filter((p) => Number(p.quantity || p.stock || 0) > 20).length;
      supplyAvailability = Math.round((inStockCount / products.length) * 100);
    }

    // 3. Fulfillment Efficiency %
    // Percentage of orders that are Delivered, Shipped, or Confirmed (vs Cancelled)
    let fulfillmentEfficiency = 91;
    if (orders.length > 0) {
      const nonCancelledOrders = orders.filter((o) => o.status !== 'Cancelled');
      const fulfilledCount = nonCancelledOrders.filter((o) => 
        ['Delivered', 'Completed', 'Dispatched', 'Confirmed', 'Out for Delivery'].includes(o.status)
      ).length;
      fulfillmentEfficiency = Math.round((fulfilledCount / nonCancelledOrders.length) * 100);
    }

    // 4. Logistics Efficiency %
    // Ratio of optimized vehicle utilization across planned and active routes
    let logisticsEfficiency = 84;
    if (routes.length > 0) {
      const utilizations = routes.map((r) => {
        const cap = Number(r.vehicle_capacity || r.vehicleCapacity || 1000);
        const load = Number(r.total_load || r.totalLoad || 0);
        return cap > 0 ? (load / cap) : 0.8;
      });
      const avgUtil = utilizations.reduce((a, b) => a + b, 0) / utilizations.length;
      logisticsEfficiency = Math.min(100, Math.round(avgUtil * 100));
    }

    // 5. Inventory Pressure Index (0-100)
    // Measures turnover: higher means inventory is rapidly depleting
    const totalOrderQty = orders.reduce((acc, o) => {
      const items = o.items || [];
      return acc + items.reduce((sum, item) => sum + Number(item.quantity || 1), 0);
    }, 0);
    const inventoryPressure = totalAvailableSupply > 0
      ? Math.min(100, Math.round((totalOrderQty / (totalAvailableSupply + totalOrderQty)) * 100))
      : 45;

    return {
      demandCoverage: Math.max(10, demandCoverage),
      supplyAvailability: Math.max(10, supplyAvailability),
      fulfillmentEfficiency: Math.max(10, fulfillmentEfficiency),
      logisticsEfficiency: Math.max(10, logisticsEfficiency),
      inventoryPressure,
      totalActiveProducts: products.length,
      totalOrdersEvaluated: orders.length,
      totalActiveRoutes: routes.length,
      isPrototypeIndicator: true,
      lastEvaluatedAt: new Date().toISOString()
    };
  }
};
