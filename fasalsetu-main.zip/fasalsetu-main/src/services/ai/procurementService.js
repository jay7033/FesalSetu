/**
 * Intelligent Bulk Procurement Engine
 * Aggregates multi-supplier sources to fulfill large buyer purchase orders.
 * Optimizes for fewest suppliers, MOQ satisfaction, minimal travel distance, and cost efficiency.
 */

import { calculateDistance } from '../../utils/distance.js';
import { matchingService } from './matchingService.js';

export const procurementService = {
  /**
   * Recommend optimal multi-supplier procurement plan for a buyer requirement.
   *
   * @param {Object} requirement - { cropName, quantity, targetPrice, buyerLocation }
   * @param {Array} availableProducts - Candidate products in marketplace
   * @returns {Object} Procurement recommendation plan
   */
  generateProcurementPlan(requirement, availableProducts = []) {
    if (!requirement || !requirement.quantity) {
      return {
        status: 'INSUFFICIENT_DATA',
        message: 'Valid requirement quantity required to generate procurement plan.'
      };
    }

    const requestedCrop = (requirement.cropName || '').toLowerCase();
    const targetQty = Number(requirement.quantity || 1000);
    const buyerLoc = requirement.buyerLocation || { latitude: 28.5355, longitude: 77.3910, city: 'Noida' };

    // Filter candidate products matching crop
    const candidates = availableProducts
      .filter((p) => {
        const pName = (p.name || '').toLowerCase();
        return pName.includes(requestedCrop) || requestedCrop.includes(pName);
      })
      .map((p) => {
        const stock = Number(p.quantity || p.stock || 0);
        const price = Number(p.price || 0);
        const pLat = p.location?.latitude || 28.4744;
        const pLng = p.location?.longitude || 77.5040;
        const distKm = Math.round(calculateDistance(buyerLoc.latitude, buyerLoc.longitude, pLat, pLng) || 35);
        const matchResult = matchingService.calculateMatch(p, {
          cropName: requirement.cropName,
          quantity: Math.min(stock, targetQty),
          price: requirement.targetPrice,
          distanceKm: distKm
        });

        return {
          id: p.id,
          name: p.name,
          supplierName: p.farmer || p.fpoName || 'FasalSetu Producer',
          supplierRole: p.fpoId ? 'FPO' : 'Farmer',
          stock,
          pricePerKg: price,
          distanceKm: distKm,
          qualityGrade: p.qualityGrade || 'A',
          approximateAddress: p.approximateLocation || p.location?.city || 'Regional Hub',
          matchScore: matchResult.matchScore
        };
      })
      .filter((c) => c.stock > 0);

    if (!candidates.length) {
      return {
        status: 'NO_SUPPLIERS',
        cropName: requirement.cropName,
        requiredQuantity: targetQty,
        recommendedQuantity: 0,
        suppliers: [],
        message: 'No active suppliers currently listed for this crop.'
      };
    }

    // Strategy 1: Fewest Suppliers (Prioritize high stock & high match score)
    const sortedByCapacity = [...candidates].sort((a, b) => {
      // Prioritize FPOs or large inventory first to reduce stop count
      if (b.stock !== a.stock) return b.stock - a.stock;
      return a.distanceKm - b.distanceKm;
    });

    // Strategy 2: Lowest Distance (Hyperlocal proximity corridor)
    const sortedByDistance = [...candidates].sort((a, b) => a.distanceKm - b.distanceKm);

    const buildPlanFromList = (list) => {
      let accumulatedQty = 0;
      const selectedSuppliers = [];
      let totalDistance = 0;
      let totalCost = 0;

      for (const item of list) {
        if (accumulatedQty >= targetQty) break;

        const needed = targetQty - accumulatedQty;
        const allocated = Math.min(item.stock, needed);

        accumulatedQty += allocated;
        totalDistance += item.distanceKm;
        totalCost += (allocated * item.pricePerKg);

        selectedSuppliers.push({
          supplierId: item.id,
          supplierName: item.supplierName,
          supplierRole: item.supplierRole,
          allocatedQuantity: Math.round(allocated),
          pricePerKg: item.pricePerKg,
          distanceKm: item.distanceKm,
          approximateAddress: item.approximateAddress,
          matchScore: item.matchScore
        });
      }

      return {
        selectedSuppliers,
        totalAllocated: Math.round(accumulatedQty),
        supplierCount: selectedSuppliers.length,
        totalDistanceKm: Math.round(totalDistance),
        totalCost: Math.round(totalCost),
        avgMatchScore: selectedSuppliers.length
          ? Math.round(selectedSuppliers.reduce((acc, s) => acc + s.matchScore, 0) / selectedSuppliers.length)
          : 0
      };
    };

    const planCapacity = buildPlanFromList(sortedByCapacity);
    const planDistance = buildPlanFromList(sortedByDistance);

    // Prefer plan with fewer suppliers if distance difference is reasonable
    const bestPlan = (planCapacity.supplierCount <= planDistance.supplierCount)
      ? planCapacity
      : (planDistance.totalDistanceKm < planCapacity.totalDistanceKm * 0.7 ? planDistance : planCapacity);

    const fulfillmentPercent = Math.min(100, Math.round((bestPlan.totalAllocated / targetQty) * 100));

    return {
      status: 'OPTIMIZED',
      cropName: requirement.cropName,
      requiredQuantity: targetQty,
      recommendedQuantity: bestPlan.totalAllocated,
      fulfillmentPercent,
      deficitQuantity: Math.max(0, targetQty - bestPlan.totalAllocated),
      supplierCount: bestPlan.supplierCount,
      suppliers: bestPlan.selectedSuppliers,
      estimatedDistanceKm: bestPlan.totalDistanceKm,
      estimatedCost: bestPlan.totalCost,
      matchScore: bestPlan.avgMatchScore,
      comparison: {
        optionA: {
          label: 'Fewest Stops (High Capacity)',
          supplierCount: planCapacity.supplierCount,
          totalDistanceKm: planCapacity.totalDistanceKm
        },
        optionB: {
          label: 'Closest Corridors (Low Distance)',
          supplierCount: planDistance.supplierCount,
          totalDistanceKm: planDistance.totalDistanceKm
        }
      },
      explanation: `Aggregated ${bestPlan.supplierCount} verified supplier${bestPlan.supplierCount > 1 ? 's' : ''} to deliver ${bestPlan.totalAllocated.toLocaleString('en-IN')} kg (${fulfillmentPercent}% fulfillment) across ~${bestPlan.totalDistanceKm} km total collection corridor.`
    };
  }
};
