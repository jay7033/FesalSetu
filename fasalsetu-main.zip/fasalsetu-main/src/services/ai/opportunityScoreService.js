/**
 * Opportunity Scoring Service
 * Generates transparent 0-100 opportunity scores and decision-support guidance for Farmers and FPOs.
 * Strictly adheres to non-coercive, decision-support advisory rules.
 */

import { aiExplanationService } from './aiExplanationService.js';

export const opportunityScoreService = {
  /**
   * Calculate Farmer Opportunity Score for a crop based on demand velocity, supply scarcity,
   * farmer's inventory, and nearby logistics access.
   *
   * @param {Object} params
   * @param {string} params.cropName
   * @param {number} params.farmerInventory - kg currently held
   * @param {number} params.forecastDemand - projected regional demand
   * @param {number} params.nearbySupply - current competitive listings
   * @param {number} params.growthPercent - demand growth rate
   * @param {number} [params.activeBuyers] - number of buyers querying crop
   * @param {boolean} [params.hasLogisticsNearby] - whether route is active nearby
   * @returns {Object} Farmer Opportunity Evaluation
   */
  calculateFarmerOpportunity({
    cropName,
    farmerInventory = 0,
    forecastDemand = 1000,
    nearbySupply = 200,
    growthPercent = 15,
    activeBuyers = 3,
    hasLogisticsNearby = true
  }) {
    // Component 1: Demand velocity (30%)
    let demandScore = 70;
    if (growthPercent > 20) demandScore = 100;
    else if (growthPercent > 10) demandScore = 85;
    else if (growthPercent > 0) demandScore = 75;
    else demandScore = 50;

    // Component 2: Supply Scarcity (30%)
    // If nearbySupply is low relative to forecastDemand, scarcity is high -> high score
    const supplyDemandRatio = forecastDemand > 0 ? (nearbySupply / forecastDemand) : 1;
    let scarcityScore = 70;
    if (supplyDemandRatio < 0.3) scarcityScore = 100;
    else if (supplyDemandRatio < 0.6) scarcityScore = 85;
    else if (supplyDemandRatio < 1.0) scarcityScore = 70;
    else scarcityScore = 40;

    // Component 3: Farmer Capacity to Fulfill (20%)
    // Farmer has inventory to sell
    let inventoryScore = 80;
    if (farmerInventory > 0) {
      inventoryScore = Math.min(100, Math.max(50, Math.round((farmerInventory / 500) * 100)));
    }

    // Component 4: Market Activity & Logistics (20%)
    let marketScore = (activeBuyers > 0 ? 80 : 50) + (hasLogisticsNearby ? 20 : 0);
    marketScore = Math.min(100, marketScore);

    // Weighted Score
    const compositeScore = Math.round(
      (demandScore * 0.30) +
      (scarcityScore * 0.30) +
      (inventoryScore * 0.20) +
      (marketScore * 0.20)
    );

    const score = Math.min(100, Math.max(0, compositeScore));

    // Suggested listing range based on farmer inventory and forecast gap
    const potentialListingLow = Math.max(50, Math.round(farmerInventory * 0.4 / 10) * 10 || 100);
    const potentialListingHigh = Math.max(potentialListingLow + 50, Math.round(farmerInventory * 0.7 / 10) * 10 || 200);
    const suggestedListing = `${potentialListingLow}–${potentialListingHigh} kg`;

    const supplyStatus = supplyDemandRatio < 0.6 ? 'Potential Shortage' : (supplyDemandRatio > 1.2 ? 'Potential Surplus' : 'Balanced');

    const explanations = aiExplanationService.explainOpportunity({
      growthPercent,
      supplyStatus,
      activeBuyersCount: activeBuyers,
      logisticsRouteNearby: hasLogisticsNearby
    });

    // Production signal (Decision Support only)
    let productionSignal = 'Neutral';
    let signalRecommendation = 'Maintain standard crop allocation.';
    if (score >= 80) {
      productionSignal = 'Positive (High Demand Signal)';
      signalRecommendation = `Consider increasing ${cropName} allocation based on current marketplace demand signals.`;
    } else if (score >= 65) {
      productionSignal = 'Moderate';
      signalRecommendation = `Steady demand projected. Consider listing staged batches.`;
    } else {
      productionSignal = 'Cautious';
      signalRecommendation = `Supply is currently high. Prioritize secured pre-orders.`;
    }

    return {
      cropName,
      score,
      demandLevel: growthPercent > 15 ? 'HIGH' : (growthPercent > 5 ? 'MODERATE' : 'STABLE'),
      supplyLevel: supplyDemandRatio < 0.5 ? 'LOW' : (supplyDemandRatio < 1.0 ? 'MODERATE' : 'HIGH'),
      farmerInventory: Math.round(farmerInventory),
      forecastDemand: Math.round(forecastDemand),
      suggestedListing,
      recommendation: `Consider listing ${suggestedListing} to capture rising regional buyer demand.`,
      productionSignal,
      signalRecommendation,
      confidenceScore: Math.min(92, Math.round(65 + (activeBuyers * 5))),
      explanations
    };
  },

  /**
   * Calculate FPO Aggregation Intelligence across member inventories.
   *
   * @param {Object} params
   * @param {string} params.cropName
   * @param {number} params.memberTotalInventory - Combined inventory of member farmers
   * @param {number} params.regionalForecastDemand - Projected regional procurement
   * @param {number} [params.memberCount] - Number of participating members
   * @returns {Object} FPO Aggregation Opportunity
   */
  calculateFPOOpportunity({
    cropName,
    memberTotalInventory = 1500,
    regionalForecastDemand = 2500,
    memberCount = 8
  }) {
    const gap = Math.round(regionalForecastDemand - memberTotalInventory);

    let opportunityTier = 'BALANCED';
    let actionRecommendation = '';

    if (gap > 500) {
      opportunityTier = 'HIGH';
      actionRecommendation = `Prioritize member batch aggregation. Regional procurement demand exceeds current member pool by ~${gap.toLocaleString('en-IN')} kg.`;
    } else if (gap < -500) {
      opportunityTier = 'SURPLUS_MANAGEMENT';
      actionRecommendation = `Member pool has ~${Math.abs(gap).toLocaleString('en-IN')} kg excess volume. Explore inter-regional redistribution or bulk buyer contracts.`;
    } else {
      opportunityTier = 'STABLE';
      actionRecommendation = `Member production closely balances regional consumption velocity. Maintain scheduled collections.`;
    }

    const score = gap > 0 ? Math.min(95, 70 + Math.round((gap / 1000) * 10)) : Math.max(50, 70 - Math.round((Math.abs(gap) / 1000) * 10));

    return {
      cropName,
      memberInventory: Math.round(memberTotalInventory),
      regionalForecast: Math.round(regionalForecastDemand),
      potentialGap: gap,
      opportunityTier,
      score,
      memberCount,
      actionRecommendation,
      confidenceScore: 82
    };
  },

  /**
   * Generate observed marketplace price trend (without making future price guarantees).
   */
  calculateObservedPriceSignal(historicalPrices = [], recentPrices = []) {
    if (!historicalPrices.length || !recentPrices.length) {
      return {
        available: false,
        message: 'Price signal unavailable (insufficient transaction history).'
      };
    }

    const calcMedian = (arr) => {
      const sorted = [...arr].sort((a, b) => a - b);
      const mid = Math.floor(sorted.length / 2);
      return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
    };

    const historicalMedian = calcMedian(historicalPrices);
    const recentMedian = calcMedian(recentPrices);

    if (historicalMedian <= 0) {
      return { available: false, message: 'Price signal unavailable.' };
    }

    const observedChangePercent = Number((((recentMedian - historicalMedian) / historicalMedian) * 100).toFixed(1));

    return {
      available: true,
      label: 'Observed marketplace price trend',
      historicalMedianPrice: Math.round(historicalMedian),
      recentMedianPrice: Math.round(recentMedian),
      observedChangePercent,
      trend: observedChangePercent > 2 ? 'RISING' : (observedChangePercent < -2 ? 'DECLINING' : 'STABLE'),
      disclaimer: 'Past transaction medians reflect marketplace history only; not a guaranteed price prediction.'
    };
  }
};
