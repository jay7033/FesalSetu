// Central Demand Forecast Service (Provider Pattern with Cache & Supabase Persistence)
import { supabase, isSupabaseConfigured } from '../../lib/supabase.js';
import { analyzeMarketplaceDemand } from './demandAnalyticsService.js';
import { aggregateRegionalDemand } from './regionalDemandService.js';
import { 
  generateFarmerRecommendations, 
  generateFPOInsights, 
  generateBulkBuyerSignals, 
  generateConsumerRecommendations 
} from './recommendationService.js';

// Cache configuration: 24 hours validity
const CACHE_KEY = 'fasalsetu_demand_forecasts_v1';
const CACHE_TTL_MS = 24 * 60 * 60 * 1000;

/**
 * Interface Provider: Statistical Baseline Engine
 * Cleanly separated so future ML models can implement the same generateForecasts contract.
 */
class StatisticalForecastProvider {
  constructor(name = 'StatisticalForecastProvider-v1.0') {
    this.name = name;
  }

  generateForecasts(orders = [], products = []) {
    return analyzeMarketplaceDemand(orders, products);
  }

  generateRegionalAnalysis(orders = [], products = []) {
    return aggregateRegionalDemand(orders, products);
  }
}

export const defaultForecastProvider = new StatisticalForecastProvider();

export const demandForecastService = {
  provider: defaultForecastProvider,

  /**
   * Sets custom forecast provider (for future ML models).
   */
  setProvider(newProvider) {
    if (newProvider && typeof newProvider.generateForecasts === 'function') {
      this.provider = newProvider;
    }
  },

  /**
   * Retrieves or computes demand forecasts with caching and Supabase synchronization.
   */
  async getDemandForecasts(orders = [], products = [], forceRefresh = false) {
    // 1. Check local memory/storage cache unless forceRefresh
    if (!forceRefresh && typeof window !== 'undefined') {
      try {
        const cachedStr = localStorage.getItem(CACHE_KEY);
        if (cachedStr) {
          const cached = JSON.parse(cachedStr);
          const isFresh = (Date.now() - (cached.timestamp || 0)) < CACHE_TTL_MS;
          if (isFresh && Array.isArray(cached.data) && cached.data.length > 0) {
            return {
              forecasts: cached.data,
              fromCache: true,
              lastUpdated: cached.timestamp
            };
          }
        }
      } catch (err) {
        console.warn('AI Cache retrieval warning:', err);
      }
    }

    // 2. Try fetching persisted forecasts from Supabase if configured
    if (isSupabaseConfigured() && !forceRefresh) {
      try {
        const { data, error } = await supabase
          .from('demand_forecasts')
          .select('*')
          .order('generated_at', { ascending: false });

        if (!error && data && data.length > 0) {
          // Normalize Supabase fields to frontend structure
          const formatted = data.map((d) => ({
            cropName: d.crop_name,
            category: d.category || 'Vegetables',
            historicalDemand: Number(d.historical_demand) || 0,
            recent7DaysDemand: Number(d.recent_demand) || 0,
            forecastQuantity: Number(d.forecast_quantity) || 0,
            growthPercent: Number(d.demand_growth_percent) || 0,
            classification: d.demand_classification || 'STABLE',
            supplyStatus: d.supply_status || 'Balanced',
            confidenceScore: d.confidence_score || 70,
            confidenceTier: (d.confidence_score || 70) >= 75 ? 'High' : 'Moderate',
            confidenceFactors: Array.isArray(d.confidence_factors) ? d.confidence_factors : [],
            primaryState: d.state,
            primaryDistrict: d.district,
            primaryCity: d.city,
            totalOrders: 10
          }));

          return {
            forecasts: formatted,
            fromCache: false,
            lastUpdated: new Date(data[0].generated_at).getTime()
          };
        }
      } catch (sbErr) {
        console.warn('Supabase forecast lookup fallback to calculation:', sbErr);
      }
    }

    // 3. Deterministic calculation via Forecast Provider
    const calculatedForecasts = this.provider.generateForecasts(orders, products);
    const now = Date.now();

    // Cache locally
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(CACHE_KEY, JSON.stringify({
          data: calculatedForecasts,
          timestamp: now
        }));
      } catch (err) {
        console.warn('Failed to cache AI forecasts in localStorage:', err);
      }
    }

    return {
      forecasts: calculatedForecasts,
      fromCache: false,
      lastUpdated: now
    };
  },

  /**
   * Regional Demand aggregation
   */
  getRegionalDemand(orders = [], products = []) {
    return this.provider.generateRegionalAnalysis(orders, products);
  },

  /**
   * Farmer recommendations
   */
  getFarmerRecommendations(farmerProducts = [], forecasts = [], location = {}) {
    return generateFarmerRecommendations(farmerProducts, forecasts, location);
  },

  /**
   * FPO Insights
   */
  getFPOInsights(memberFarmers = [], aggregatedInventory = [], forecasts = []) {
    return generateFPOInsights(memberFarmers, aggregatedInventory, forecasts);
  },

  /**
   * Bulk Buyer Signals
   */
  getBulkBuyerSignals(forecasts = [], preferredLocations = []) {
    return generateBulkBuyerSignals(forecasts, preferredLocations);
  },

  /**
   * Consumer Produce Recommendations
   */
  getConsumerRecommendations(products = [], forecasts = []) {
    return generateConsumerRecommendations(products, forecasts);
  }
};
