// AI Mathematical & Statistical Utilities for Demand Intelligence

export const DEMAND_THRESHOLDS = {
  MIN_ORDERS_FOR_PREDICTION: 3,
  RISING_GROWTH_PERCENT: 15.0,
  DECLINING_GROWTH_PERCENT: -10.0,
  SHORTAGE_RATIO: 1.15, // Forecast Demand > Supply * 1.15 -> Shortage
  SURPLUS_RATIO: 1.25,  // Supply > Forecast Demand * 1.25 -> Surplus
  HIGH_VOLUME_KG: 1500  // High volume threshold for classification
};

/**
 * Calculates percentage growth between recent and previous periods.
 * Returns 0 if both are 0. Handles zero denominator gracefully.
 */
export function calculateGrowthPercent(recentDemand = 0, previousDemand = 0) {
  const recent = Number(recentDemand) || 0;
  const previous = Number(previousDemand) || 0;

  if (previous <= 0) {
    if (recent <= 0) return 0;
    return 100.0; // New demand appearing
  }

  const growth = ((recent - previous) / previous) * 100.0;
  return Math.round(growth * 10) / 10;
}

/**
 * Weighted Moving Average (WMA)
 * Default weights: 50% recent 7-day, 30% mid-term 14-day, 20% long-term 30-day
 */
export function calculateWeightedDemand(recent = 0, mid = 0, long = 0, weights = [0.5, 0.3, 0.2]) {
  const r = Number(recent) || 0;
  const m = Number(mid) || 0;
  const l = Number(long) || 0;
  const totalWeight = weights[0] + weights[1] + weights[2];

  if (totalWeight === 0) return 0;
  const weighted = (r * weights[0] + m * weights[1] + l * weights[2]) / totalWeight;
  return Math.round(weighted);
}

/**
 * Classifies demand based on growth percentage, order volume, and sample size.
 */
export function classifyDemand(growthPercent, recentVolume = 0, sampleSize = 0) {
  if (sampleSize < DEMAND_THRESHOLDS.MIN_ORDERS_FOR_PREDICTION) {
    return 'INSUFFICIENT DATA';
  }

  const growth = Number(growthPercent) || 0;
  const volume = Number(recentVolume) || 0;

  if (growth >= DEMAND_THRESHOLDS.RISING_GROWTH_PERCENT) {
    return volume >= DEMAND_THRESHOLDS.HIGH_VOLUME_KG ? 'HIGH DEMAND' : 'RISING DEMAND';
  }

  if (growth <= DEMAND_THRESHOLDS.DECLINING_GROWTH_PERCENT) {
    return volume < 300 ? 'LOW DEMAND' : 'DECLINING';
  }

  return 'STABLE';
}

/**
 * Determines supply status comparing forecast demand against available inventory.
 */
export function evaluateSupplyStatus(forecastDemand = 0, availableSupply = 0, sampleSize = 0) {
  if (sampleSize < DEMAND_THRESHOLDS.MIN_ORDERS_FOR_PREDICTION) {
    return 'Insufficient Data';
  }

  const forecast = Number(forecastDemand) || 0;
  const supply = Number(availableSupply) || 0;

  if (forecast > supply * DEMAND_THRESHOLDS.SHORTAGE_RATIO) {
    return 'Potential Shortage';
  }

  if (supply > forecast * DEMAND_THRESHOLDS.SURPLUS_RATIO) {
    return 'Potential Surplus';
  }

  return 'Balanced';
}

/**
 * Formats volume in kg or tonnes (e.g. 1,250 kg or 3.5 T)
 */
export function formatDemandVolume(kg = 0) {
  const val = Number(kg) || 0;
  if (val >= 1000) {
    return `${(val / 1000).toFixed(1)} T`;
  }
  return `${Math.round(val)} kg`;
}
