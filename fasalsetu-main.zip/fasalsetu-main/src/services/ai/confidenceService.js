// Transparent Confidence Score & Explainability Engine for Agricultural Forecasting

/**
 * Calculates a transparent confidence score (0-100%) based on empirical factors.
 * Also generates human-readable explainability bullet points.
 * 
 * @param {Object} params
 * @param {number} params.orderCount - Total historical orders in dataset
 * @param {number} params.recentOrderCount - Orders within last 14 days
 * @param {number} params.growthPercent - Demand growth rate
 * @param {number} params.distinctBuyersCount - Buyer diversity
 * @param {number} params.availableSupply - Existing inventory
 * @param {number} params.forecastQuantity - Expected demand
 * @returns {{ confidenceScore: number, confidenceTier: string, factors: string[] }}
 */
export function calculateConfidenceScore({
  orderCount = 0,
  recentOrderCount = 0,
  growthPercent = 0,
  distinctBuyersCount = 1,
  availableSupply = 0,
  forecastQuantity = 0
}) {
  const factors = [];
  let score = 30; // Baseline prior for active market listing

  // Factor 1: Sample Size
  if (orderCount === 0) {
    return {
      confidenceScore: 10,
      confidenceTier: 'Low',
      factors: [
        'Insufficient historical data — 0 transactions recorded',
        'Early-stage marketplace signal only',
        'Confidence will improve as transactions occur'
      ]
    };
  }

  if (orderCount < 3) {
    return {
      confidenceScore: 25,
      confidenceTier: 'Low',
      factors: [
        `Limited sample: only ${orderCount} historical order(s) available`,
        'Preliminary baseline estimate subject to variability',
        'Requires 3+ orders for full confidence modeling'
      ]
    };
  }

  if (orderCount >= 20) {
    score += 30;
    factors.push(`Robust dataset: ${orderCount} historical transactions analyzed`);
  } else if (orderCount >= 10) {
    score += 20;
    factors.push(`Moderate sample: ${orderCount} completed transactions`);
  } else {
    score += 10;
    factors.push(`Initial dataset: ${orderCount} historical transactions`);
  }

  // Factor 2: Recency
  if (recentOrderCount >= 5) {
    score += 20;
    factors.push(`Strong recent activity: ${recentOrderCount} orders in the last 14 days`);
  } else if (recentOrderCount >= 2) {
    score += 12;
    factors.push(`Recent market activity: ${recentOrderCount} order(s) in the last 14 days`);
  } else {
    score += 4;
    factors.push('Lower recent transaction frequency');
  }

  // Factor 3: Growth & Trend Stability
  const absGrowth = Math.abs(growthPercent);
  if (absGrowth <= 35) {
    score += 12;
    factors.push(`Stable demand pattern (${growthPercent >= 0 ? '+' : ''}${growthPercent}% change)`);
  } else {
    score += 6;
    factors.push(`High demand volatility observed (${growthPercent >= 0 ? '+' : ''}${growthPercent}% surge)`);
  }

  // Factor 4: Buyer Diversity
  if (distinctBuyersCount >= 4) {
    score += 8;
    factors.push(`Broad regional buyer spread across ${distinctBuyersCount} distinct accounts`);
  } else {
    score += 4;
    factors.push('Buyer base concentrated in initial institutional segments');
  }

  // Factor 5: Inventory Pressure Context
  if (forecastQuantity > 0 && availableSupply > 0) {
    const ratio = Math.round((forecastQuantity / availableSupply) * 100);
    factors.push(`Supply-to-forecast ratio: ${ratio}% coverage against expected demand`);
  }

  // Bound score between 15% and 88% (no fake 99% certainty in agricultural forecasting)
  const boundedScore = Math.min(Math.max(score, 15), 88);

  let confidenceTier = 'Moderate';
  if (boundedScore >= 75) {
    confidenceTier = 'High';
  } else if (boundedScore < 50) {
    confidenceTier = 'Low';
  }

  return {
    confidenceScore: boundedScore,
    confidenceTier,
    factors
  };
}
