// Role-Specific AI Recommendation Engine
import { formatDemandVolume } from './aiUtils.js';

/**
 * Generates personalized recommendations for Farmers based on their inventory and regional demand.
 * 
 * @param {Array} farmerProducts - The logged-in farmer's products
 * @param {Array} marketInsights - Global or regional demand insights
 * @param {Object} location - Farmer's verified farm location
 * @returns {Array} List of farmer recommendations
 */
export function generateFarmerRecommendations(farmerProducts = [], marketInsights = [], _location = {}) {
  const recommendations = [];

  // Map farmer's crops
  const farmerCropMap = {};
  farmerProducts.forEach((p) => {
    const name = p.name || p.title;
    farmerCropMap[name] = (farmerCropMap[name] || 0) + (p.quantity || p.stock || 0);
  });

  marketInsights.forEach((insight) => {
    const cropName = insight.cropName;
    const existingStock = farmerCropMap[cropName];

    // If farmer grows this crop or if market demand is high/rising
    if (existingStock !== undefined || insight.classification === 'HIGH DEMAND' || insight.classification === 'RISING DEMAND') {
      const isShortage = insight.supplyStatus === 'Potential Shortage';
      const growth = insight.growthPercent;

      let suggestedMin = 50;
      let suggestedMax = 100;

      if (insight.forecastQuantity > 1000) {
        suggestedMin = 200;
        suggestedMax = 350;
      } else if (insight.forecastQuantity > 500) {
        suggestedMin = 100;
        suggestedMax = 180;
      }

      let recommendationText = '';
      if (isShortage) {
        recommendationText = `High regional shortage detected. Consider listing fresh batch to capture peak farm-gate demand in ${insight.primaryDistrict}.`;
      } else if (growth >= 15) {
        recommendationText = `Demand is rising (+${growth}%). Good window to list ready harvest.`;
      } else {
        recommendationText = `Steady baseline demand in your district. Maintain consistent weekly harvest listings.`;
      }

      recommendations.push({
        cropName,
        classification: insight.classification,
        growthPercent: growth,
        forecastQuantity: insight.forecastQuantity,
        availableSupply: insight.availableSupply,
        suggestedListingMin: suggestedMin,
        suggestedListingMax: suggestedMax,
        suggestedRangeFormatted: `${suggestedMin}–${suggestedMax} kg`,
        recommendationText,
        confidenceScore: insight.confidenceScore,
        confidenceTier: insight.confidenceTier,
        isShortage,
        locationContext: insight.primaryDistrict
      });
    }
  });

  return recommendations.slice(0, 4);
}

/**
 * Generates aggregation & procurement insights for FPO managers.
 * 
 * @param {Array} memberFarmers - FPO registered members
 * @param {Array} aggregatedInventory - FPO aggregated produce inventory
 * @param {Array} marketInsights - Marketplace demand insights
 * @returns {Array} FPO aggregation recommendations
 */
export function generateFPOInsights(memberFarmers = [], aggregatedInventory = [], marketInsights = []) {
  const fpoInsights = [];

  marketInsights.forEach((insight) => {
    const cropName = insight.cropName;
    
    // Find aggregated supply in FPO
    const fpoCrop = aggregatedInventory.find((i) => (i.crop || i.name) === cropName);
    const memberSupply = fpoCrop ? Number(fpoCrop.quantity || fpoCrop.volume || 0) : 0;
    const forecastDemand = insight.forecastQuantity;

    const gap = forecastDemand - memberSupply;
    const isShortage = gap > 0;

    let priority = 'Normal';
    let action = 'Monitor regional order velocity';

    if (isShortage && insight.classification === 'HIGH DEMAND') {
      priority = 'High Priority';
      action = `Prioritize ${cropName} aggregation across member farms. Estimated regional deficit of ~${formatDemandVolume(gap)}.`;
    } else if (gap < -500) {
      priority = 'Surplus Advisory';
      action = `Member supply exceeds immediate local demand. Consider coordinating institutional bulk buyer contracts.`;
    }

    fpoInsights.push({
      cropName,
      regionalDemand: insight.classification,
      memberSupply,
      memberSupplyFormatted: formatDemandVolume(memberSupply),
      forecastDemand,
      forecastDemandFormatted: formatDemandVolume(forecastDemand),
      gap: Math.abs(gap),
      gapFormatted: formatDemandVolume(Math.abs(gap)),
      isDeficit: isShortage,
      priority,
      action,
      confidenceScore: insight.confidenceScore,
      primaryDistrict: insight.primaryDistrict
    });
  });

  return fpoInsights.slice(0, 5);
}

/**
 * Generates procurement signals for Bulk Buyers.
 * 
 * @param {Array} marketInsights - Platform demand insights
 * @param {Array} preferredLocations - Buyer's delivery/procurement hubs
 * @returns {Array} Bulk buyer procurement recommendations
 */
export function generateBulkBuyerSignals(marketInsights = [], _preferredLocations = []) {
  const signals = [];

  marketInsights.forEach((insight) => {
    const supply = insight.availableSupply;
    if (supply > 0) {
      const suggestedMin = Math.max(Math.round(supply * 0.25), 250);
      const suggestedMax = Math.min(Math.round(supply * 0.6), 5000);

      signals.push({
        cropName: insight.cropName,
        region: insight.primaryDistrict,
        state: insight.primaryState,
        demandClassification: insight.classification,
        availableSupply: supply,
        availableSupplyFormatted: formatDemandVolume(supply),
        suggestedProcurementFormatted: `${suggestedMin}–${suggestedMax} kg`,
        confidenceScore: insight.confidenceScore,
        confidenceTier: insight.confidenceTier,
        procurementAdvisory: `Ample farm-gate availability in ${insight.primaryDistrict}. Initiate early dispatch PO to lock preferred batch rates.`
      });
    }
  });

  return signals.slice(0, 4);
}

/**
 * Generates lightweight freshness & popularity signals for Consumers.
 * 
 * @param {Array} products - Catalog products
 * @param {Array} marketInsights - Platform insights
 * @returns {Array} Recommended consumer products
 */
export function generateConsumerRecommendations(products = [], marketInsights = []) {
  const highDemandCrops = new Set(
    marketInsights
      .filter((i) => i.classification === 'HIGH DEMAND' || i.classification === 'RISING DEMAND')
      .map((i) => i.cropName.toLowerCase())
  );

  return products.map((prod) => {
    const isTrending = highDemandCrops.has((prod.name || '').toLowerCase());
    return {
      ...prod,
      isTrendingDemand: isTrending,
      demandSignal: isTrending ? 'Trending Fresh Produce' : 'Fresh Harvest'
    };
  });
}
