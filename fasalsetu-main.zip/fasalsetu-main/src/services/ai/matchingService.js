/**
 * Smart Farmer-Buyer Matching Engine
 * Deterministic multi-factor scoring algorithm connecting producer inventory with buyer requirements.
 * Prototype weights are centralized and documented.
 */

import { calculateDistance } from '../../utils/distance.js';
import { aiExplanationService } from './aiExplanationService.js';

// Centralized Prototype Weights (Must sum to 100%)
export const MATCH_WEIGHTS = {
  QUANTITY: 25,   // Quantity compatibility
  DISTANCE: 20,   // Spatial proximity / logistics viability
  QUALITY: 20,    // Quality / grade match
  PRICE: 15,      // Price compatibility with buyer target
  FRESHNESS: 10,  // Harvest recency / shelf-life
  DEMAND: 10      // Current marketplace demand velocity
};

export const matchingService = {
  /**
   * Calculate a deterministic match score (0-100) between a producer product and a buyer requirement.
   *
   * @param {Object} product - Producer inventory item
   * @param {Object} requirement - Buyer purchase requirement
   * @returns {Object} { matchScore, breakdown, explanationFactors }
   */
  calculateMatch(product, requirement) {
    if (!product || !requirement) {
      return {
        matchScore: 0,
        breakdown: { quantity: 0, distance: 0, quality: 0, price: 0, freshness: 0, demand: 0 },
        explanationFactors: ['Insufficient data to evaluate match']
      };
    }

    // 1. Quantity Compatibility (25%)
    // Compares product available stock against requested quantity
    const availableQty = Number(product.quantity || product.stock || 0);
    const requestedQty = Number(requirement.quantity || requirement.requestedQty || 1);
    const qtyRatio = requestedQty > 0 ? Math.min(availableQty / requestedQty, 1.25) : 0;
    // Score peaks at 100% fulfillment, partial fulfillment gets proportional points
    let quantityScore = 0;
    if (qtyRatio >= 1.0) {
      quantityScore = 100;
    } else {
      quantityScore = Math.max(0, Math.round(qtyRatio * 100));
    }

    // 2. Distance Compatibility (20%)
    // Evaluates proximity. < 30km = 100, 30-80km = 85, 80-150km = 65, 150-300km = 40, > 300km = 20
    let distanceKm = 30; // fallback reasonable regional distance
    if (product.location?.latitude && requirement.location?.latitude) {
      distanceKm = calculateDistance(
        product.location.latitude,
        product.location.longitude,
        requirement.location.latitude,
        requirement.location.longitude
      );
    } else if (typeof requirement.distanceKm === 'number') {
      distanceKm = requirement.distanceKm;
    }

    let distanceScore = 100;
    if (distanceKm <= 35) {
      distanceScore = 100;
    } else if (distanceKm <= 80) {
      distanceScore = 85;
    } else if (distanceKm <= 150) {
      distanceScore = 65;
    } else if (distanceKm <= 300) {
      distanceScore = 40;
    } else {
      distanceScore = Math.max(10, Math.round(100 - (distanceKm / 10)));
    }

    // 3. Quality Compatibility (20%)
    // Compares quality grade (Grade A, Organic, Standard, B Grade)
    const productQuality = (product.qualityGrade || product.grade || 'A').toUpperCase();
    const reqQuality = (requirement.qualityGrade || requirement.grade || 'A').toUpperCase();
    let qualityScore = 75;
    if (productQuality === reqQuality) {
      qualityScore = 100;
    } else if (productQuality.includes('A') || productQuality.includes('ORGANIC')) {
      qualityScore = 90; // Higher grade than standard
    } else {
      qualityScore = 70;
    }

    // 4. Price Compatibility (15%)
    // Compares product unit price with buyer target unit price
    const prodPrice = Number(product.price || 0);
    const targetPrice = Number(requirement.targetPrice || requirement.price || prodPrice);
    let priceScore = 80;
    let priceVariancePercent = 0;
    if (targetPrice > 0 && prodPrice > 0) {
      priceVariancePercent = ((prodPrice - targetPrice) / targetPrice) * 100;
      if (priceVariancePercent <= 0) {
        priceScore = 100; // cheaper or exact match
      } else if (priceVariancePercent <= 10) {
        priceScore = 85;
      } else if (priceVariancePercent <= 25) {
        priceScore = 60;
      } else {
        priceScore = Math.max(20, Math.round(100 - (priceVariancePercent * 2)));
      }
    }

    // 5. Freshness / Shelf-Life (10%)
    // Days since harvest: 0-2 days = 100, 3-5 days = 85, 6-10 days = 60
    const harvestDate = product.harvestDate ? new Date(product.harvestDate) : new Date();
    const now = new Date();
    const freshnessDays = Math.max(0, Math.round((now - harvestDate) / (1000 * 60 * 60 * 24)));
    let freshnessScore = 100;
    if (freshnessDays <= 2) {
      freshnessScore = 100;
    } else if (freshnessDays <= 5) {
      freshnessScore = 85;
    } else if (freshnessDays <= 10) {
      freshnessScore = 65;
    } else {
      freshnessScore = Math.max(30, 100 - (freshnessDays * 6));
    }

    // 6. Demand Relevance (10%)
    const demandClassification = requirement.demandClassification || 'HIGH DEMAND';
    let demandScore = 75;
    if (demandClassification === 'HIGH DEMAND') demandScore = 100;
    else if (demandClassification === 'RISING DEMAND') demandScore = 85;
    else if (demandClassification === 'STABLE') demandScore = 70;
    else if (demandClassification === 'DECLINING') demandScore = 40;

    // Weighted Composite Score
    const compositeScore = (
      (quantityScore * MATCH_WEIGHTS.QUANTITY) +
      (distanceScore * MATCH_WEIGHTS.DISTANCE) +
      (qualityScore * MATCH_WEIGHTS.QUALITY) +
      (priceScore * MATCH_WEIGHTS.PRICE) +
      (freshnessScore * MATCH_WEIGHTS.FRESHNESS) +
      (demandScore * MATCH_WEIGHTS.DEMAND)
    ) / 100;

    const finalMatchScore = Math.round(Math.min(100, Math.max(0, compositeScore)));

    // Generate explainable factors
    const explanationFactors = aiExplanationService.explainMatch({
      quantityFulfillmentPercent: requestedQty > 0 ? (availableQty / requestedQty) * 100 : 100,
      distanceKm,
      qualityMatch: qualityScore >= 85,
      freshnessDays,
      priceVariancePercent,
      demandClassification
    });

    return {
      matchScore: finalMatchScore,
      breakdown: {
        quantity: quantityScore,
        distance: distanceScore,
        quality: qualityScore,
        price: priceScore,
        freshness: freshnessScore,
        demand: demandScore
      },
      distanceKm: Math.round(distanceKm),
      explanationFactors
    };
  },

  /**
   * Find best product matches for a buyer's requirement.
   */
  findMatchesForRequirement(requirement, availableProducts = []) {
    if (!requirement || !availableProducts.length) return [];

    const matches = availableProducts
      .filter((p) => {
        // Crop name match or category match
        const cropMatch = p.name?.toLowerCase().includes(requirement.cropName?.toLowerCase() || '') ||
                          requirement.cropName?.toLowerCase().includes(p.name?.toLowerCase() || '');
        return cropMatch;
      })
      .map((product) => {
        const evaluation = this.calculateMatch(product, requirement);
        return {
          id: `sm-${product.id}-${requirement.id || 'req'}`,
          productId: product.id,
          productName: product.name,
          sellerName: product.farmer || product.fpoName || 'FasalSetu Producer',
          sellerRole: product.fpoId ? 'fpo' : 'farmer',
          buyerId: requirement.buyerId || 'bb-001',
          buyerName: requirement.buyerName || 'Verified Bulk Buyer',
          availableQuantity: Number(product.quantity || product.stock || 0),
          requestedQuantity: Number(requirement.quantity || 100),
          price: product.price,
          unit: product.unit || 'kg',
          approximateLocation: product.approximateLocation || product.location?.city || 'Regional Hub',
          ...evaluation
        };
      })
      .sort((a, b) => b.matchScore - a.matchScore);

    return matches;
  }
};
