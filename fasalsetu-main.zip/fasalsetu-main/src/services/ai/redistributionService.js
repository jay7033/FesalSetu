/**
 * Regional Surplus Redistribution Engine
 * Connects surplus regions with shortage regions and combines hyperlocal logistics
 * (distance, vehicle capacity, and existing scheduled routes) to suggest consolidated dispatches.
 */

import { calculateDistance } from '../../utils/distance.js';
import { VEHICLE_PROFILES } from '../logistics/logisticsUtils.js';
import { aiExplanationService } from './aiExplanationService.js';

export const redistributionService = {
  /**
   * Evaluate redistribution opportunity between a surplus region and a shortage region.
   *
   * @param {Object} surplusRecord
   * @param {Object} shortageRecord
   * @param {Array} existingRoutes - Logistics routes from fleet network
   * @returns {Object|null} Redistribution recommendation
   */
  evaluateRedistribution(surplusRecord, shortageRecord, existingRoutes = []) {
    if (!surplusRecord || !shortageRecord) return null;
    if (surplusRecord.cropName.toLowerCase() !== shortageRecord.cropName.toLowerCase()) return null;

    const surplusAmount = Math.abs(surplusRecord.potentialGap || surplusRecord.availableSupply - surplusRecord.forecastDemand);
    const shortageAmount = Math.abs(shortageRecord.potentialGap || shortageRecord.forecastDemand - shortageRecord.availableSupply);

    if (surplusAmount <= 0 || shortageAmount <= 0) return null;

    const transferableQuantity = Math.min(surplusAmount, shortageAmount);

    // Approximate distance between regions
    // Default coordinates for known corridors (Jewar/Greater Noida to Delhi/Noida, Nashik to Mumbai, etc.)
    const REGIONAL_COORDINATES = {
      'gautam buddha nagar': { lat: 28.4744, lng: 77.5040, name: 'Jewar / Gr. Noida' },
      'noida': { lat: 28.5355, lng: 77.3910, name: 'Noida Urban' },
      'bulandshahr': { lat: 28.4069, lng: 77.8498, name: 'Bulandshahr' },
      'aligarh': { lat: 27.8974, lng: 78.0880, name: 'Aligarh' },
      'nashik': { lat: 19.9975, lng: 73.7898, name: 'Nashik' },
      'mumbai': { lat: 19.0760, lng: 72.8777, name: 'Mumbai' }
    };

    const originKey = (surplusRecord.district || surplusRecord.city || '').toLowerCase();
    const destKey = (shortageRecord.district || shortageRecord.city || '').toLowerCase();

    const originCoord = REGIONAL_COORDINATES[originKey] || { lat: 28.4744, lng: 77.5040, name: surplusRecord.district || 'Origin' };
    const destCoord = REGIONAL_COORDINATES[destKey] || { lat: 28.5355, lng: 77.3910, name: shortageRecord.district || 'Destination' };

    const distanceKm = Math.round(calculateDistance(originCoord.lat, originCoord.lng, destCoord.lat, destCoord.lng) || 45);

    // Select suitable vehicle from fleet profiles based on transferable load
    let recommendedVehicle = VEHICLE_PROFILES.MINI_TRUCK;
    if (transferableQuantity > 2500) {
      recommendedVehicle = VEHICLE_PROFILES.LARGE_TRUCK;
    } else if (transferableQuantity > 1000) {
      recommendedVehicle = VEHICLE_PROFILES.MEDIUM_TRUCK;
    } else if (transferableQuantity > 500) {
      recommendedVehicle = VEHICLE_PROFILES.SMALL_TRUCK;
    }

    // Check if an existing fleet route operates along this corridor
    const matchingRoute = existingRoutes.find((r) => {
      const startCity = r.start_location?.city || r.startLocation?.city || '';
      const endCity = r.end_location?.city || r.endLocation?.city || '';
      return (
        (startCity.toLowerCase().includes(originKey) || originKey.includes(startCity.toLowerCase())) &&
        (endCity.toLowerCase().includes(destKey) || destKey.includes(endCity.toLowerCase()))
      );
    });

    const routeAvailable = Boolean(matchingRoute);
    const availableCapacity = matchingRoute ? Math.max(0, matchingRoute.vehicle_capacity - matchingRoute.total_load) : recommendedVehicle.capacity;

    const confidenceScore = routeAvailable ? 82 : (distanceKm <= 60 ? 76 : 68);

    const explanationBullets = aiExplanationService.explainRedistribution({
      originRegion: `${surplusRecord.district}, ${surplusRecord.state}`,
      destinationRegion: `${shortageRecord.district}, ${shortageRecord.state}`,
      surplusKg: surplusAmount,
      shortageKg: shortageAmount,
      distanceKm,
      vehicleCapacityKg: availableCapacity,
      routeAvailable
    });

    return {
      id: `redis-${surplusRecord.cropName}-${surplusRecord.district}-${shortageRecord.district}`.toLowerCase().replace(/\s+/g, '-'),
      cropName: surplusRecord.cropName,
      originRegion: `${surplusRecord.district}, ${surplusRecord.state}`,
      destinationRegion: `${shortageRecord.district}, ${shortageRecord.state}`,
      surplusAvailable: Math.round(surplusAmount),
      deficitQuantity: Math.round(shortageAmount),
      transferableQuantity: Math.round(transferableQuantity),
      distanceKm,
      recommendedVehicle: recommendedVehicle.name,
      vehicleCapacity: recommendedVehicle.capacity,
      existingRouteAvailable: routeAvailable,
      existingRouteNumber: matchingRoute ? matchingRoute.route_number || matchingRoute.routeNumber : null,
      availableCapacityOnRoute: Math.round(availableCapacity),
      actionRecommendation: routeAvailable
        ? `Consider consolidating ~${Math.round(transferableQuantity).toLocaleString('en-IN')} kg with active route ${matchingRoute.route_number || 'FS-RT-2026-001'}.`
        : `Consider scheduling a dedicated ${recommendedVehicle.name} dispatch along the ${distanceKm} km transit corridor.`,
      confidenceScore,
      explanationBullets
    };
  },

  /**
   * Scan all regional gap records and find high-value redistribution corridors.
   */
  generateRedistributionRecommendations(gapRecords = [], existingRoutes = []) {
    const surpluses = gapRecords.filter((g) => g.status === 'Potential Surplus');
    const shortages = gapRecords.filter((g) => g.status === 'Potential Shortage');

    const recommendations = [];

    surpluses.forEach((surplus) => {
      shortages.forEach((shortage) => {
        if (surplus.cropName.toLowerCase() === shortage.cropName.toLowerCase() && surplus.district !== shortage.district) {
          const plan = this.evaluateRedistribution(surplus, shortage, existingRoutes);
          if (plan) {
            recommendations.push(plan);
          }
        }
      });
    });

    // Sort by transferable quantity descending
    return recommendations.sort((a, b) => b.transferableQuantity - a.transferableQuantity);
  }
};
