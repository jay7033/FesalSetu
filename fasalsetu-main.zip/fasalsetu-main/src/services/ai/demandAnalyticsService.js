// Demand Analytics Service: Aggregation, Historical Analysis & Moving Averages
import { calculateGrowthPercent, calculateWeightedDemand, classifyDemand, evaluateSupplyStatus } from './aiUtils.js';
import { calculateConfidenceScore } from './confidenceService.js';

/**
 * Aggregates marketplace orders by crop and computes statistical indicators.
 * 
 * @param {Array} orders - Roster of platform orders
 * @param {Array} products - Current marketplace products
 * @returns {Array} cropDemandInsights
 */
export function analyzeMarketplaceDemand(orders = [], products = []) {
  if (!orders || orders.length === 0) {
    return [];
  }

  const now = Date.now();
  const DAY_MS = 24 * 60 * 60 * 1000;

  // 1. Group order items by crop name
  const cropStats = {};

  orders.forEach((order) => {
    // Parse order date
    const orderTime = new Date(order.createdAt || order.date || now).getTime();
    const ageDays = (now - orderTime) / DAY_MS;

    const buyerId = order.buyerId || order.buyer_profile_id || 'buyer-default';
    const district = order.deliveryLocation?.district || order.district || 'Gautam Buddha Nagar';
    const state = order.deliveryLocation?.state || order.state || 'Uttar Pradesh';
    const city = order.deliveryLocation?.city || order.city || 'Noida';

    const items = order.items || [];
    items.forEach((item) => {
      const crop = (item.name || item.crop || 'Produce').trim();
      if (!cropStats[crop]) {
        cropStats[crop] = {
          cropName: crop,
          category: item.category || 'Vegetables',
          totalOrders: 0,
          recent7DaysDemand: 0,
          previous7DaysDemand: 0, // 8-14 days ago
          midTerm14DaysDemand: 0,
          longTerm30DaysDemand: 0,
          totalHistoricalDemand: 0,
          recentOrderCount: 0,
          buyers: new Set(),
          regions: new Set(),
          states: new Set([state]),
          districts: new Set([district]),
          cities: new Set([city]),
          unit: item.unit || 'kg'
        };
      }

      const qty = Number(item.quantity) || 0;
      cropStats[crop].totalOrders += 1;
      cropStats[crop].totalHistoricalDemand += qty;
      cropStats[crop].buyers.add(buyerId);
      cropStats[crop].regions.add(`${district}, ${state}`);
      cropStats[crop].states.add(state);
      cropStats[crop].districts.add(district);
      cropStats[crop].cities.add(city);

      if (ageDays <= 7) {
        cropStats[crop].recent7DaysDemand += qty;
        cropStats[crop].recentOrderCount += 1;
      } else if (ageDays <= 14) {
        cropStats[crop].previous7DaysDemand += qty;
        cropStats[crop].recentOrderCount += 1;
      }

      if (ageDays <= 14) {
        cropStats[crop].midTerm14DaysDemand += qty;
      }

      if (ageDays <= 30) {
        cropStats[crop].longTerm30DaysDemand += qty;
      }
    });
  });

  // 2. Cross-reference available supply from products catalog
  const cropSupply = {};
  products.forEach((prod) => {
    const crop = (prod.name || prod.title || '').trim();
    if (!cropSupply[crop]) {
      cropSupply[crop] = 0;
    }
    const avail = (Number(prod.quantity) || 0) - (Number(prod.reservedQuantity) || 0);
    cropSupply[crop] += Math.max(avail, 0);
  });

  // 3. Compute forecasts, classifications, and confidence
  const insights = Object.values(cropStats).map((stat) => {
    const growthPercent = calculateGrowthPercent(
      stat.recent7DaysDemand,
      stat.previous7DaysDemand
    );

    // Weighted demand calculation for the next 7-day period
    const baselineForecast = calculateWeightedDemand(
      stat.recent7DaysDemand,
      stat.midTerm14DaysDemand / 2, // normalized to 7-day rate
      stat.longTerm30DaysDemand / 4.28 // normalized to 7-day rate
    );

    // If recent growth is strong, apply a bounded trend multiplier (max 1.25x)
    let trendFactor = 1.0;
    if (growthPercent > 0) {
      trendFactor = Math.min(1 + (growthPercent / 200), 1.25);
    } else if (growthPercent < 0) {
      trendFactor = Math.max(1 + (growthPercent / 200), 0.8);
    }

    const forecastQuantity = Math.round(baselineForecast * trendFactor);
    const availableSupply = cropSupply[stat.cropName] || 0;

    const classification = classifyDemand(
      growthPercent,
      stat.recent7DaysDemand,
      stat.totalOrders
    );

    const supplyStatus = evaluateSupplyStatus(
      forecastQuantity,
      availableSupply,
      stat.totalOrders
    );

    const confidenceResult = calculateConfidenceScore({
      orderCount: stat.totalOrders,
      recentOrderCount: stat.recentOrderCount,
      growthPercent,
      distinctBuyersCount: stat.buyers.size,
      availableSupply,
      forecastQuantity
    });

    return {
      cropName: stat.cropName,
      category: stat.category,
      unit: stat.unit,
      totalOrders: stat.totalOrders,
      recent7DaysDemand: stat.recent7DaysDemand,
      previous7DaysDemand: stat.previous7DaysDemand,
      historicalDemand: stat.totalHistoricalDemand,
      forecastQuantity,
      growthPercent,
      classification,
      supplyStatus,
      availableSupply,
      confidenceScore: confidenceResult.confidenceScore,
      confidenceTier: confidenceResult.confidenceTier,
      confidenceFactors: confidenceResult.factors,
      primaryState: Array.from(stat.states)[0] || 'Uttar Pradesh',
      primaryDistrict: Array.from(stat.districts)[0] || 'Gautam Buddha Nagar',
      primaryCity: Array.from(stat.cities)[0] || 'Noida'
    };
  });

  return insights;
}
