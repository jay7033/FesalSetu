/**
 * AI Explanation Service
 * Generates deterministic, human-readable explanations from numerical intelligence factors.
 * Strictly adheres to transparent rule-based logic without hallucinations or fabricated claims.
 */

export const aiExplanationService = {
  /**
   * Explain why a specific farmer/FPO product matched a buyer requirement.
   */
  explainMatch({
    quantityFulfillmentPercent,
    distanceKm,
    qualityMatch,
    freshnessDays,
    priceVariancePercent,
    demandClassification
  }) {
    const factors = [];

    // Quantity factor
    if (quantityFulfillmentPercent >= 100) {
      factors.push(`✓ Quantity completely fulfills 100% of buyer requirement`);
    } else if (quantityFulfillmentPercent >= 70) {
      factors.push(`✓ Quantity meets ${Math.round(quantityFulfillmentPercent)}% of buyer requirement`);
    } else {
      factors.push(`• Partial fulfillment available (${Math.round(quantityFulfillmentPercent)}% of requested volume)`);
    }

    // Distance factor
    if (distanceKm <= 35) {
      factors.push(`✓ Producer is within hyperlocal radius (${Math.round(distanceKm)} km)`);
    } else if (distanceKm <= 80) {
      factors.push(`✓ Producer is within direct regional dispatch range (${Math.round(distanceKm)} km)`);
    } else {
      factors.push(`• Inter-district delivery corridor (${Math.round(distanceKm)} km)`);
    }

    // Quality factor
    if (qualityMatch) {
      factors.push(`✓ Quality grade aligns directly with buyer standard`);
    } else {
      factors.push(`• Standard market grade produce`);
    }

    // Freshness factor
    if (freshnessDays <= 2) {
      factors.push(`✓ Harvest freshness is optimal (harvested within ${freshnessDays} days)`);
    } else if (freshnessDays <= 5) {
      factors.push(`✓ Harvest date is recent (${freshnessDays} days ago)`);
    } else {
      factors.push(`• Cured produce within standard shelf-life window`);
    }

    // Price factor
    if (priceVariancePercent <= 0) {
      factors.push(`✓ Price is at or below buyer target (${Math.abs(Math.round(priceVariancePercent))}% favorable)`);
    } else if (priceVariancePercent <= 10) {
      factors.push(`✓ Price is within preferred commercial corridor (+${Math.round(priceVariancePercent)}%)`);
    } else {
      factors.push(`• Premium pricing tier based on quality/certification`);
    }

    // Demand relevance
    if (demandClassification === 'HIGH DEMAND' || demandClassification === 'RISING DEMAND') {
      factors.push(`✓ Strong active marketplace demand signal`);
    }

    return factors;
  },

  /**
   * Explain why a specific crop is an opportunity for a farmer or FPO.
   */
  explainOpportunity({
    growthPercent,
    supplyStatus,
    activeBuyersCount,
    logisticsRouteNearby
  }) {
    const reasons = [];

    if (growthPercent > 0) {
      reasons.push(`Demand increased ${Math.round(growthPercent)}% over the previous comparison period.`);
    } else {
      reasons.push(`Demand has maintained consistent baseline volume across regional markets.`);
    }

    if (supplyStatus === 'Potential Shortage') {
      reasons.push(`Nearby inventory is below forecast demand, signaling favorable absorption.`);
    } else if (supplyStatus === 'Balanced') {
      reasons.push(`Regional supply and demand are balanced with steady daily turnover.`);
    } else {
      reasons.push(`Surplus conditions observed; recommended target is quality or pre-order contracts.`);
    }

    if (activeBuyersCount > 0) {
      reasons.push(`${activeBuyersCount} verified buyer${activeBuyersCount > 1 ? 's are' : ' is'} currently seeking this category.`);
    }

    if (logisticsRouteNearby) {
      reasons.push(`Existing consolidated logistics routes pass directly through this collection corridor.`);
    }

    return reasons;
  },

  /**
   * Explain regional redistribution rationale.
   */
  explainRedistribution({
    originRegion,
    destinationRegion,
    surplusKg,
    shortageKg,
    distanceKm,
    vehicleCapacityKg,
    routeAvailable
  }) {
    const bullets = [];
    bullets.push(`Surplus of ~${Math.round(surplusKg).toLocaleString('en-IN')} kg identified in ${originRegion}.`);
    bullets.push(`Estimated absorption capacity of ~${Math.round(shortageKg).toLocaleString('en-IN')} kg in ${destinationRegion}.`);
    bullets.push(`Transit distance is ${Math.round(distanceKm)} km along the primary transport corridor.`);
    
    if (routeAvailable) {
      bullets.push(`Existing scheduled route can accommodate up to ${Math.round(vehicleCapacityKg).toLocaleString('en-IN')} kg consolidated load.`);
    } else {
      bullets.push(`Dedicated dispatch recommended if aggregated batch exceeds minimum load threshold.`);
    }

    return bullets;
  }
};
