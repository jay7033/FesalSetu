/**
 * Supply-Demand Gap Prediction Engine
 * Computes forecast demand against available marketplace inventory to project regional supply status.
 * Strictly outputs "Potential Shortage", "Balanced", or "Potential Surplus" (no definitive claims).
 */

export const supplyDemandService = {
  /**
   * Analyze regional gap for a given crop.
   *
   * @param {Object} params
   * @param {string} params.cropName
   * @param {number} params.forecastDemand - Forecasted demand in kg
   * @param {number} params.availableSupply - Currently listed available stock in kg
   * @param {string} params.state
   * @param {string} params.district
   * @param {string} [params.city]
   * @returns {Object} Gap analysis record
   */
  calculateGap({
    cropName,
    forecastDemand = 0,
    availableSupply = 0,
    state = 'Uttar Pradesh',
    district = 'Gautam Buddha Nagar',
    city = 'Greater Noida'
  }) {
    const fDemand = Number(forecastDemand) || 0;
    const aSupply = Number(availableSupply) || 0;

    // Handle zero or insufficient data cases
    if (fDemand <= 0 && aSupply <= 0) {
      return {
        cropName,
        state,
        district,
        city,
        forecastDemand: 0,
        availableSupply: 0,
        potentialGap: 0,
        status: 'Insufficient Data',
        confidenceScore: 30,
        ratio: 1.0,
        explanation: 'Insufficient historical transactions or inventory listings to compute gap.'
      };
    }

    // Potential Gap = Forecast Demand - Available Supply
    // Positive gap => demand exceeds supply => Potential Shortage
    // Negative gap => supply exceeds demand => Potential Surplus
    const potentialGap = Math.round(fDemand - aSupply);
    const ratio = aSupply > 0 ? fDemand / aSupply : (fDemand > 0 ? 5.0 : 0);

    let status = 'Balanced';
    let confidenceScore = 75;
    let explanation = '';

    if (fDemand > 0 && aSupply === 0) {
      status = 'Potential Shortage';
      confidenceScore = 65;
      explanation = `Zero local listings against projected demand of ${fDemand.toLocaleString('en-IN')} kg.`;
    } else if (ratio > 1.25) {
      status = 'Potential Shortage';
      confidenceScore = Math.min(88, Math.round(65 + Math.min(fDemand, 5000) / 250));
      explanation = `Projected demand exceeds available local inventory by ~${Math.abs(potentialGap).toLocaleString('en-IN')} kg.`;
    } else if (ratio < 0.75) {
      status = 'Potential Surplus';
      confidenceScore = Math.min(85, Math.round(65 + Math.min(aSupply, 5000) / 250));
      explanation = `Available local supply exceeds projected demand by ~${Math.abs(potentialGap).toLocaleString('en-IN')} kg.`;
    } else {
      status = 'Balanced';
      confidenceScore = 78;
      explanation = `Marketplace supply is closely matched with current consumption velocity.`;
    }

    return {
      cropName,
      state,
      district,
      city,
      forecastDemand: Math.round(fDemand),
      availableSupply: Math.round(aSupply),
      potentialGap,
      status,
      confidenceScore,
      ratio: Number(ratio.toFixed(2)),
      explanation
    };
  },

  /**
   * Aggregate supply-demand across all active products and regional forecasts.
   */
  aggregateRegionalGaps(products = [], forecasts = []) {
    if (!forecasts.length && !products.length) {
      return [];
    }

    // Group available supply by crop & district
    const supplyMap = new Map();
    products.forEach((p) => {
      const crop = p.name || 'Produce';
      const district = p.location?.district || p.district || 'Gautam Buddha Nagar';
      const state = p.location?.state || p.state || 'Uttar Pradesh';
      const key = `${crop.toLowerCase()}___${state.toLowerCase()}___${district.toLowerCase()}`;

      const existing = supplyMap.get(key) || {
        cropName: crop,
        state,
        district,
        availableSupply: 0
      };
      existing.availableSupply += Number(p.quantity || p.stock || 0);
      supplyMap.set(key, existing);
    });

    // Group forecasts by crop & district
    const gapResults = [];
    const processedKeys = new Set();

    forecasts.forEach((f) => {
      const crop = f.cropName || 'Produce';
      const district = f.primaryDistrict || 'Gautam Buddha Nagar';
      const state = f.state || 'Uttar Pradesh';
      const key = `${crop.toLowerCase()}___${state.toLowerCase()}___${district.toLowerCase()}`;
      processedKeys.add(key);

      const supplyData = supplyMap.get(key);
      const availableSupply = supplyData ? supplyData.availableSupply : 0;

      const gap = this.calculateGap({
        cropName: crop,
        forecastDemand: f.forecastDemand || f.forecastQuantity || 500,
        availableSupply,
        state,
        district,
        city: f.primaryCity || district
      });

      gapResults.push({
        id: `gap-${crop}-${district}`.toLowerCase().replace(/\s+/g, '-'),
        ...gap,
        category: f.category || 'Vegetables',
        growthPercent: f.growthPercent || f.demandGrowthPercent || 0
      });
    });

    // Also include supply items that might not have direct forecasts
    supplyMap.forEach((val, key) => {
      if (!processedKeys.has(key)) {
        const gap = this.calculateGap({
          cropName: val.cropName,
          forecastDemand: 0,
          availableSupply: val.availableSupply,
          state: val.state,
          district: val.district
        });
        gapResults.push({
          id: `gap-${val.cropName}-${val.district}`.toLowerCase().replace(/\s+/g, '-'),
          ...gap,
          category: 'Produce',
          growthPercent: 0
        });
      }
    });

    return gapResults;
  }
};
