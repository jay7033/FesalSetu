// Regional Demand Intelligence & Geographic Aggregation (Privacy Preserved)

/**
 * Aggregates marketplace orders by geographic clusters (State, District, City).
 * STRICT PRIVACY REQUIREMENT: Never exposes latitude, longitude, or GPS accuracy.
 * 
 * @param {Array} orders - Platform orders
 * @param {Array} products - Catalog products
 * @returns {Object} Regional demand hierarchy and clusters
 */
export function aggregateRegionalDemand(orders = [], _products = []) {
  const regions = {};

  orders.forEach((order) => {
    // Coarse location metadata only
    const state = order.deliveryLocation?.state || order.state || 'Uttar Pradesh';
    const district = order.deliveryLocation?.district || order.district || 'Gautam Buddha Nagar';
    const city = order.deliveryLocation?.city || order.city || 'Noida';

    const regionKey = `${district}, ${state}`;

    if (!regions[regionKey]) {
      regions[regionKey] = {
        regionKey,
        state,
        district,
        city,
        totalOrders: 0,
        totalVolumeKg: 0,
        crops: {},
        activeBuyersCount: new Set()
      };
    }

    const buyerId = order.buyerId || order.buyer_profile_id || 'buyer-default';
    regions[regionKey].totalOrders += 1;
    regions[regionKey].activeBuyersCount.add(buyerId);

    (order.items || []).forEach((item) => {
      const crop = item.name || item.crop || 'Produce';
      const qty = Number(item.quantity) || 0;
      regions[regionKey].totalVolumeKg += qty;
      regions[regionKey].crops[crop] = (regions[regionKey].crops[crop] || 0) + qty;
    });
  });

  // Map to structured display cards with demand density color coding
  const regionList = Object.values(regions).map((reg) => {
    const topCrop = Object.entries(reg.crops).sort((a, b) => b[1] - a[1])[0] || ['Mixed', 0];
    
    let density = 'Low';
    let densityColor = 'emerald';
    let statusIcon = '🟢';

    if (reg.totalVolumeKg >= 2500) {
      density = 'High';
      densityColor = 'rose';
      statusIcon = '🔴';
    } else if (reg.totalVolumeKg >= 1000) {
      density = 'Rising';
      densityColor = 'amber';
      statusIcon = '🟠';
    } else if (reg.totalVolumeKg >= 400) {
      density = 'Moderate';
      densityColor = 'yellow';
      statusIcon = '🟡';
    } else if (reg.totalOrders < 3) {
      density = 'Insufficient data';
      densityColor = 'slate';
      statusIcon = '⚪';
    }

    return {
      regionKey: reg.regionKey,
      state: reg.state,
      district: reg.district,
      city: reg.city,
      totalOrders: reg.totalOrders,
      totalVolumeKg: Math.round(reg.totalVolumeKg),
      topCrop: topCrop[0],
      topCropVolume: Math.round(topCrop[1]),
      uniqueBuyers: reg.activeBuyersCount.size,
      density,
      densityColor,
      statusIcon
    };
  });

  // Sort by highest activity
  regionList.sort((a, b) => b.totalVolumeKg - a.totalVolumeKg);

  return {
    regions: regionList,
    totalRegionsCount: regionList.length,
    topRegion: regionList[0] || null
  };
}
