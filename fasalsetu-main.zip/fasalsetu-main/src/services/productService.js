/**
 * Product Service
 * Manages produce catalog queries, seller CRUD operations, and safe location masking.
 */

import { supabase, isSupabaseConfigured } from '../lib/supabase.js';

export const productService = {
  /**
   * Fetches public marketplace products with privacy-safe regional locations
   */
  async getPublicProducts() {
    if (!isSupabaseConfigured()) return null;

    try {
      const { data, error } = await supabase
        .from('public_products')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.warn('Error querying public_products view, falling back to base table:', error.message);
        // Fallback to base table without sensitive coordinates
        const { data: baseData, error: baseError } = await supabase
          .from('products')
          .select(`
            id,
            seller_profile_id,
            seller_type,
            name,
            hindi_name,
            category,
            description,
            price,
            unit,
            quantity_available,
            minimum_order_quantity,
            quality,
            organic,
            harvest_date,
            image_url,
            is_active,
            created_at,
            farm_locations (
              city,
              district,
              state
            )
          `)
          .eq('is_active', true);

        if (baseError) throw baseError;

        return (baseData || []).map((p) => ({
          ...p,
          approximate_location: p.farm_locations ? `${p.farm_locations.district || p.farm_locations.city}, ${p.farm_locations.state}` : 'India'
        }));
      }

      return data || [];
    } catch (e) {
      console.warn('Supabase getPublicProducts failed:', e.message);
      return null;
    }
  },

  /**
   * Fetches full product details by ID
   */
  async getProductById(productId) {
    if (!isSupabaseConfigured()) return null;

    const { data, error } = await supabase
      .from('products')
      .select(`
        id,
        seller_profile_id,
        seller_type,
        name,
        hindi_name,
        category,
        description,
        price,
        unit,
        quantity_available,
        reserved_quantity,
        minimum_order_quantity,
        quality,
        organic,
        harvest_date,
        image_url,
        is_active,
        farm_locations (
          city,
          district,
          state
        )
      `)
      .eq('id', productId)
      .single();

    if (error) return null;
    return data;
  },

  /**
   * Fetches all products owned by a specific seller (Farmer or FPO)
   */
  async getSellerProducts(sellerProfileId) {
    if (!isSupabaseConfigured()) return null;

    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('seller_profile_id', sellerProfileId)
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('Error fetching seller products:', error.message);
      return null;
    }
    return data || [];
  },

  /**
   * Creates a new product for an authenticated seller
   */
  async createProduct(productData) {
    if (!isSupabaseConfigured()) return null;

    const { data, error } = await supabase
      .from('products')
      .insert([productData])
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Updates an existing product owned by the seller
   */
  async updateProduct(productId, updates) {
    if (!isSupabaseConfigured()) return null;

    const { data, error } = await supabase
      .from('products')
      .update(updates)
      .eq('id', productId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Deletes a product owned by the seller
   */
  async deleteProduct(productId) {
    if (!isSupabaseConfigured()) return null;

    const { error } = await supabase
      .from('products')
      .delete()
      .eq('id', productId);

    if (error) throw error;
    return true;
  },

  /**
   * Uploads product photo to Supabase Storage
   */
  async uploadProductImage(file, sellerId) {
    if (!isSupabaseConfigured() || !file) return null;

    const fileExt = file.name.split('.').pop();
    const fileName = `${sellerId}/${Date.now()}.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from('product-images')
      .upload(fileName, file, { upsert: true });

    if (uploadError) {
      console.warn('Product image upload error:', uploadError.message);
      return null;
    }

    const { data } = supabase.storage
      .from('product-images')
      .getPublicUrl(fileName);

    return data.publicUrl;
  }
};

export default productService;
