import React from 'react';
import { 
  Truck, 
  CheckCircle2, 
  Clock, 
  AlertCircle 
} from 'lucide-react';
import { SHIPMENT_LIFECYCLE_STEPS } from '../../services/logistics/logisticsUtils.js';

export default function ShipmentStatus({ shipment }) {
  if (!shipment) return null;

  const {
    trackingNumber,
    status = 'CREATED',
    supplierName,
    buyerName,
    destinationCity,
    quantity,
    unit = 'kg',
    estimatedDeliveryTime
  } = shipment;

  const currentIndex = SHIPMENT_LIFECYCLE_STEPS.indexOf(status);
  const isCancelled = status === 'CANCELLED';

  const stepLabels = {
    CREATED: 'Order Dispatched',
    PICKUP_SCHEDULED: 'Pickup Scheduled',
    PICKED_UP: 'Loaded at Farm',
    IN_TRANSIT: 'In Transit',
    OUT_FOR_DELIVERY: 'Out for Delivery',
    DELIVERED: 'Delivered'
  };

  const formattedETA = estimatedDeliveryTime
    ? new Date(estimatedDeliveryTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : '45 mins';

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400">
              <Truck className="w-4 h-4" />
            </span>
            <span className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider">
              {trackingNumber}
            </span>
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            {quantity} {unit} from {supplierName || 'Farm Producer'}
          </h3>
        </div>

        <div className="text-right">
          <span className="text-[11px] text-slate-400 block">Destination:</span>
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
            {destinationCity} ({buyerName || 'Buyer'})
          </span>
        </div>
      </div>

      {/* Visual Multi-Stage Tracker */}
      {isCancelled ? (
        <div className="p-4 bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/50 rounded-xl flex items-center gap-2 text-rose-700 dark:text-rose-400 text-xs">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>Shipment was cancelled. Reserved inventory returned to farm catalog.</span>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="grid grid-cols-6 gap-1 relative">
            {SHIPMENT_LIFECYCLE_STEPS.map((step, idx) => {
              const isPast = idx < currentIndex;
              const isCurrent = idx === currentIndex;

              return (
                <div key={step} className="flex flex-col items-center text-center">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                      isPast
                        ? 'bg-emerald-600 text-white'
                        : isCurrent
                        ? 'bg-emerald-500 text-white ring-4 ring-emerald-100 dark:ring-emerald-950/60'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                    }`}
                  >
                    {isPast ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                  </div>
                  <span
                    className={`text-[10px] mt-2 hidden sm:block leading-tight ${
                      isCurrent
                        ? 'font-bold text-emerald-600 dark:text-emerald-400'
                        : isPast
                        ? 'font-medium text-slate-700 dark:text-slate-300'
                        : 'text-slate-400'
                    }`}
                  >
                    {stepLabels[step]}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
            <span className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-emerald-600" />
              <span>Status: <strong className="text-slate-900 dark:text-white capitalize">{status.replace(/_/g, ' ').toLowerCase()}</strong></span>
            </span>
            <span>Estimated Arrival: <strong className="font-mono text-emerald-600 dark:text-emerald-400">{formattedETA}</strong></span>
          </div>
        </div>
      )}
    </div>
  );
}
