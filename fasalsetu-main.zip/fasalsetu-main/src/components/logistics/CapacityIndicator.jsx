import React from 'react';
import { Truck, AlertTriangle, CheckCircle2 } from 'lucide-react';

export default function CapacityIndicator({
  vehicleType = 'Small Truck',
  capacityKg = 1000,
  totalLoadKg = 0,
  showOverloadWarning = true
}) {
  const cap = Number(capacityKg) || 1000;
  const load = Number(totalLoadKg) || 0;
  const utilization = Math.round((load / cap) * 100);
  const isOverloaded = load > cap;
  const excess = isOverloaded ? Math.round(load - cap) : 0;

  let barColor = 'bg-emerald-500';
  if (isOverloaded) {
    barColor = 'bg-rose-500';
  } else if (utilization > 85) {
    barColor = 'bg-amber-500';
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-xs">
        <span className="flex items-center gap-1.5 font-medium text-slate-700 dark:text-slate-300">
          <Truck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          <span>{vehicleType} Capacity</span>
        </span>
        <span className="font-mono font-bold text-slate-900 dark:text-white">
          {load.toLocaleString()} / {cap.toLocaleString()} kg
          <span className={`ml-1.5 text-xs font-semibold ${isOverloaded ? 'text-rose-600' : 'text-slate-500'}`}>
            ({utilization}%)
          </span>
        </span>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-500 ${barColor}`}
          style={{ width: `${Math.min(utilization, 100)}%` }}
        />
      </div>

      {/* Overload Alert */}
      {isOverloaded && showOverloadWarning && (
        <div className="p-3 bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/50 rounded-xl flex items-start gap-2.5 text-rose-800 dark:text-rose-300 text-xs animate-in fade-in">
          <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5 text-rose-600" />
          <div className="space-y-0.5">
            <span className="font-bold block">Vehicle Capacity Exceeded</span>
            <p className="text-[11px] text-rose-700 dark:text-rose-300">
              Required: <strong>{load.toLocaleString()} kg</strong>. Selected: <strong>{cap.toLocaleString()} kg</strong>. Excess load: <strong>{excess.toLocaleString()} kg</strong>. Please split into multiple routes or choose a larger commercial truck.
            </p>
          </div>
        </div>
      )}

      {!isOverloaded && utilization > 0 && (
        <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
          <CheckCircle2 className="w-3 h-3 text-emerald-500 flex-shrink-0" />
          <span>Within safe commercial payload limits.</span>
        </div>
      )}
    </div>
  );
}
