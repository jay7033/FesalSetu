import React from 'react';
import { Clock, MapPin, CheckCircle2, Truck, Calendar } from 'lucide-react';

export default function PickupSchedule({
  schedule,
  onMarkReady = null
}) {
  if (!schedule) return null;

  const {
    id,
    cropName = 'Fresh Harvest',
    quantity = 50,
    unit = 'kg',
    scheduledDate,
    timeWindowFormatted = '10:00 AM – 12:00 PM',
    status = 'SCHEDULED',
    farmLocationText = 'Farm Yard',
    notes
  } = schedule;

  const statusConfig = {
    SCHEDULED: {
      label: 'Scheduled',
      bg: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800'
    },
    READY: {
      label: 'Ready for Pickup',
      bg: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800'
    },
    PICKED_UP: {
      label: 'Picked Up',
      bg: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/40 dark:text-blue-400 dark:border-blue-800'
    },
    MISSED: {
      label: 'Rescheduled',
      bg: 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-400 dark:border-rose-800'
    }
  };

  const current = statusConfig[status] || statusConfig['SCHEDULED'];

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4 hover:border-slate-300 dark:hover:border-slate-700 transition-colors">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400 mb-1">
            <Truck className="w-3.5 h-3.5" />
            <span>COLLECTION DISPATCH</span>
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            {cropName} ({quantity} {unit})
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5">
            <MapPin className="w-3 h-3 text-slate-400" />
            <span>{farmLocationText}</span>
          </p>
        </div>

        <span className={`text-xs font-bold px-2.5 py-1 rounded-full border ${current.bg}`}>
          {current.label}
        </span>
      </div>

      <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-2 text-xs">
        <div>
          <span className="text-[10px] text-slate-400 block mb-0.5">Scheduled Date</span>
          <span className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1">
            <Calendar className="w-3 h-3 text-slate-400" />
            {scheduledDate || 'Today'}
          </span>
        </div>
        <div>
          <span className="text-[10px] text-slate-400 block mb-0.5">Pickup Window</span>
          <span className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1">
            <Clock className="w-3 h-3 text-emerald-600" />
            {timeWindowFormatted}
          </span>
        </div>
      </div>

      {notes && (
        <p className="text-xs text-slate-500 dark:text-slate-400 italic">
          Note: {notes}
        </p>
      )}

      {status === 'SCHEDULED' && onMarkReady && (
        <button
          onClick={() => onMarkReady(id)}
          className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Mark Crated & Ready for Truck</span>
        </button>
      )}
    </div>
  );
}
