import React from 'react';
import { Truck, Zap, Navigation } from 'lucide-react';
import { formatDuration } from '../../services/logistics/logisticsUtils.js';
import CapacityIndicator from './CapacityIndicator';

export default function RouteSummary({ route, onViewStops = null }) {
  if (!route) return null;

  const {
    routeNumber,
    status = 'PLANNED',
    vehicleType = 'Small Truck',
    vehicleCapacity = 1000,
    totalLoad = 0,
    totalDistanceKm = 0,
    estimatedDurationMinutes = 60,
    estimatedCost = 0,
    distanceSavedKm = 0,
    percentSaved = 0,
    stops = []
  } = route;

  const formattedDuration = formatDuration(estimatedDurationMinutes);

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400">
              <Truck className="w-4 h-4" />
            </span>
            <span className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider">
              {routeNumber}
            </span>
          </div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">
            Consolidated Farm Collection Route
          </h3>
        </div>

        <span
          className={`text-xs font-bold px-3 py-1 rounded-full self-start sm:self-auto border ${
            status === 'IN_PROGRESS'
              ? 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/40 dark:text-blue-400 dark:border-blue-800'
              : status === 'COMPLETED'
              ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800'
              : 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800'
          }`}
        >
          {status}
        </span>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-800">
          <span className="text-[11px] text-slate-400 block mb-1">Route Distance</span>
          <span className="text-base font-bold font-mono text-slate-900 dark:text-white">
            {totalDistanceKm} km
          </span>
        </div>

        <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-800">
          <span className="text-[11px] text-slate-400 block mb-1">Est. Travel Time</span>
          <span className="text-base font-bold font-mono text-slate-900 dark:text-white">
            {formattedDuration}
          </span>
        </div>

        <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-800">
          <span className="text-[11px] text-slate-400 block mb-1">Total Stops</span>
          <span className="text-base font-bold font-mono text-slate-900 dark:text-white">
            {stops.length} stops
          </span>
        </div>

        <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-800">
          <span className="text-[11px] text-slate-400 block mb-1">Est. Transport Cost</span>
          <span className="text-base font-bold font-mono text-emerald-600 dark:text-emerald-400">
            ₹{estimatedCost.toLocaleString()}
          </span>
        </div>
      </div>

      {/* Capacity Indicator */}
      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-100 dark:border-slate-800">
        <CapacityIndicator
          vehicleType={vehicleType}
          capacityKg={vehicleCapacity}
          totalLoadKg={totalLoad}
        />
      </div>

      {/* 2-Opt Optimization Savings Badge */}
      {distanceSavedKm > 0 && (
        <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200/60 dark:border-emerald-900/40 rounded-2xl flex items-center justify-between text-xs text-emerald-900 dark:text-emerald-300">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-emerald-600" />
            <span>
              2-Opt Route Optimization saved <strong>{distanceSavedKm} km</strong> ({percentSaved}% reduction vs sequential route)
            </span>
          </div>
          <span className="text-[10px] font-mono text-emerald-700 dark:text-emerald-400 font-bold uppercase">
            Corridor Optimized
          </span>
        </div>
      )}

      {onViewStops && (
        <button
          onClick={onViewStops}
          className="w-full py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs transition-colors flex items-center justify-center gap-2"
        >
          <Navigation className="w-3.5 h-3.5" />
          <span>View Stop-by-Stop Itinerary ({stops.length} Stops)</span>
        </button>
      )}
    </div>
  );
}
