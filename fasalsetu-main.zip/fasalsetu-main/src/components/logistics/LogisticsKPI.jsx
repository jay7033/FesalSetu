import React from 'react';
import { Truck, Package, Clock, Scale, Zap } from 'lucide-react';

export default function LogisticsKPI({ kpis }) {
  if (!kpis) return null;

  const {
    activeRoutesCount = 0,
    todayShipmentsCount = 0,
    pendingPickupsCount = 0,
    totalFleetLoad = 0,
    totalDistanceSaved = 0,
    avgDistanceReduction = 0
  } = kpis;

  return (
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs mb-2">
          <span>Active Routes</span>
          <Truck className="w-4 h-4 text-emerald-600" />
        </div>
        <div className="text-2xl font-black text-slate-900 dark:text-white">
          {activeRoutesCount}
        </div>
        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
          Coordinated collection routes
        </p>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs mb-2">
          <span>Active Shipments</span>
          <Package className="w-4 h-4 text-blue-600" />
        </div>
        <div className="text-2xl font-black text-slate-900 dark:text-white">
          {todayShipmentsCount}
        </div>
        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
          Produce batches in dispatch
        </p>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs mb-2">
          <span>Pending Pickups</span>
          <Clock className="w-4 h-4 text-amber-500" />
        </div>
        <div className="text-2xl font-black text-slate-900 dark:text-white">
          {pendingPickupsCount}
        </div>
        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
          Awaiting farm-gate arrival
        </p>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs mb-2">
          <span>Total Fleet Load</span>
          <Scale className="w-4 h-4 text-purple-600" />
        </div>
        <div className="text-2xl font-black text-slate-900 dark:text-white">
          {totalFleetLoad.toLocaleString()} kg
        </div>
        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
          Aggregated payload
        </p>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm col-span-2 lg:col-span-1">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs mb-2">
          <span>Route Efficiency</span>
          <Zap className="w-4 h-4 text-emerald-500" />
        </div>
        <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
          +{avgDistanceReduction}%
        </div>
        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
          ~{totalDistanceSaved} km saved via 2-Opt
        </p>
      </div>
    </div>
  );
}
