import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { Navigation, ShieldCheck } from 'lucide-react';

export default function RouteMap({
  stops = [],
  className = '',
  zoom = 11
}) {
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const [mapError, setMapError] = useState(false);

  // Filter valid stops with coordinates
  const validStops = useMemo(
    () => stops.filter(
      (s) => s.latitude && s.longitude && !isNaN(Number(s.latitude)) && !isNaN(Number(s.longitude))
    ),
    [stops]
  );

  useEffect(() => {
    if (validStops.length === 0 || !mapContainerRef.current) return;

    try {
      const styleUrl =
        import.meta.env.VITE_MAP_STYLE_URL ||
        'https://demotiles.maplibre.org/style.json';

      const center = [
        Number(validStops[0].longitude),
        Number(validStops[0].latitude)
      ];

      const map = new maplibregl.Map({
        container: mapContainerRef.current,
        style: styleUrl,
        center,
        zoom,
        attributionControl: false
      });

      map.addControl(new maplibregl.NavigationControl({ showCompass: true }), 'top-right');

      map.on('load', () => {
        // Add markers for each stop
        validStops.forEach((stop, idx) => {
          const el = document.createElement('div');
          const isOrigin = idx === 0;
          const isDest = idx === validStops.length - 1;
          const bgColor = isOrigin ? '#0284c7' : isDest ? '#9333ea' : '#059669';

          el.className = 'route-map-marker flex flex-col items-center cursor-pointer';
          el.innerHTML = `
            <div style="background-color: ${bgColor}; color: white; width: 26px; height: 26px; border-radius: 50%; box-shadow: 0 4px 6px rgba(0,0,0,0.3); border: 2px solid white; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: bold; font-family: monospace;">
              ${idx + 1}
            </div>
            <div style="background: rgba(15, 23, 42, 0.9); color: white; font-size: 9px; font-weight: bold; padding: 2px 6px; border-radius: 4px; margin-top: 2px; white-space: nowrap; border: 1px solid rgba(255, 255, 255, 0.2);">
              ${stop.stopType === 'ORIGIN' ? 'Depot' : stop.stopType === 'DELIVERY' ? 'Buyer' : (stop.producerName || `Stop ${idx + 1}`)}
            </div>
          `;

          new maplibregl.Marker({ element: el })
            .setLngLat([Number(stop.longitude), Number(stop.latitude)])
            .addTo(map);
        });

        // Fit bounds to show all stops
        if (validStops.length > 1) {
          const bounds = new maplibregl.LngLatBounds();
          validStops.forEach((s) => bounds.extend([Number(s.longitude), Number(s.latitude)]));
          map.fitBounds(bounds, { padding: 40, maxZoom: 14 });
        }
      });

      map.on('error', () => {
        setMapError(true);
      });

      mapInstanceRef.current = map;

      return () => {
        map.remove();
      };
    } catch {
      setTimeout(() => setMapError(true), 0);
    }
  }, [validStops, zoom]);

  return (
    <div className={`relative rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 ${className}`}>
      {/* Privacy Guarantee Pill */}
      <div className="absolute top-3 left-3 z-10 bg-white/90 dark:bg-slate-900/90 backdrop-blur-sm px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-1.5 text-[11px] font-medium text-slate-700 dark:text-slate-300 shadow-sm">
        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
        <span>Privacy Protected • Corridor Waypoints</span>
      </div>

      {mapError || validStops.length === 0 ? (
        <div className="h-64 flex flex-col items-center justify-center p-6 text-center text-slate-500 dark:text-slate-400 space-y-2">
          <Navigation className="w-8 h-8 text-slate-400" />
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">
            Route Waypoint Overview
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2 max-w-md pt-2">
            {stops.map((s, idx) => (
              <span
                key={idx}
                className="px-2.5 py-1 rounded-lg text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
              >
                #{idx + 1} {s.approximateAddress || s.city || 'Hub'}
              </span>
            ))}
          </div>
        </div>
      ) : (
        <div ref={mapContainerRef} className="w-full h-72 sm:h-80" />
      )}
    </div>
  );
}
