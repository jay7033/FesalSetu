import React from 'react';
import { MapPin, Clock, Package, Warehouse } from 'lucide-react';

export default function RouteStopCard({ stop }) {
  if (!stop) return null;

  const {
    sequenceNumber = 1,
    stopType = 'PICKUP',
    approximateAddress = 'Regional Hub',
    producerName,
    buyerName,
    cropName,
    loadQuantity = 0,
    estimatedArrival
  } = stop;

  const typeConfig = {
    ORIGIN: {
      label: 'Depot / Origin',
      color: 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700',
      icon: Warehouse
    },
    PICKUP: {
      label: 'Farm Pickup',
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800/60',
      icon: Package
    },
    HUB: {
      label: 'Aggregation Hub',
      color: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/40 dark:text-blue-400 dark:border-blue-800/60',
      icon: Warehouse
    },
    DELIVERY: {
      label: 'Buyer Delivery',
      color: 'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950/40 dark:text-purple-400 dark:border-purple-800/60',
      icon: MapPin
    }
  };

  const config = typeConfig[stopType] || typeConfig['PICKUP'];
  const Icon = config.icon;

  const formattedTime = estimatedArrival
    ? (typeof estimatedArrival === 'string' && estimatedArrival.includes('M')
        ? estimatedArrival
        : new Date(estimatedArrival).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }))
    : 'Estimated';

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm hover:border-slate-300 dark:hover:border-slate-700 transition-colors flex items-start gap-3.5">
      {/* Sequence Badge */}
      <div className="w-8 h-8 rounded-xl bg-slate-900 dark:bg-slate-800 text-white flex items-center justify-center text-xs font-bold font-mono flex-shrink-0">
        #{sequenceNumber}
      </div>

      <div className="flex-1 min-w-0 space-y-1.5">
        <div className="flex items-center justify-between gap-2">
          <span className={`inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${config.color}`}>
            <Icon className="w-3 h-3" />
            {config.label}
          </span>
          <span className="text-xs font-mono font-semibold text-slate-500 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {formattedTime}
          </span>
        </div>

        <div>
          <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">
            {producerName || buyerName || (stopType === 'ORIGIN' ? 'Fleet Aggregation Depot' : 'Delivery Destination')}
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1 truncate mt-0.5">
            <MapPin className="w-3 h-3 text-slate-400 flex-shrink-0" />
            <span className="truncate">{approximateAddress}</span>
          </p>
        </div>

        {loadQuantity > 0 && (
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-400 text-[11px]">{cropName || 'Fresh Produce'}:</span>
            <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
              {loadQuantity} kg
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
