import React from 'react';
import { AlertCircle, CheckCircle2, AlertTriangle, HelpCircle } from 'lucide-react';

export default function SupplyStatusBadge({ status = 'Balanced', size = 'md' }) {
  const isSm = size === 'sm';

  const config = {
    'Potential Shortage': {
      label: 'Potential Shortage',
      icon: AlertCircle,
      bg: 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-400 dark:border-rose-800/60',
      dot: 'bg-rose-500'
    },
    'Balanced': {
      label: 'Balanced Supply',
      icon: CheckCircle2,
      bg: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800/60',
      dot: 'bg-emerald-500'
    },
    'Potential Surplus': {
      label: 'Potential Surplus',
      icon: AlertTriangle,
      bg: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800/60',
      dot: 'bg-amber-500'
    },
    'Insufficient Data': {
      label: 'Insufficient Data',
      icon: HelpCircle,
      bg: 'bg-slate-100 text-slate-500 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700',
      dot: 'bg-slate-400'
    }
  };

  const current = config[status] || config['Balanced'];
  const Icon = current.icon;

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border font-medium transition-colors ${current.bg} ${
        isSm ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs'
      }`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${current.dot}`} />
      <Icon className={isSm ? 'w-3 h-3' : 'w-3.5 h-3.5'} />
      <span>{current.label}</span>
    </span>
  );
}
