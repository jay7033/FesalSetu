import React from 'react';
import { Activity } from 'lucide-react';

export default function SupplyChainHealthCard({ health }) {
  if (!health) return null;

  const {
    demandCoverage,
    supplyAvailability,
    fulfillmentEfficiency,
    logisticsEfficiency,
    totalActiveProducts,
    totalOrdersEvaluated,
    totalActiveRoutes
  } = health;

  const metrics = [
    {
      label: 'Demand Coverage',
      value: `${demandCoverage}%`,
      sub: 'Supply vs forecast balance',
      progress: demandCoverage,
      color: 'bg-blue-500'
    },
    {
      label: 'Supply Availability',
      value: `${supplyAvailability}%`,
      sub: 'Active stock continuity',
      progress: supplyAvailability,
      color: 'bg-emerald-500'
    },
    {
      label: 'Fulfillment Rate',
      value: `${fulfillmentEfficiency}%`,
      sub: 'Delivered & in-transit orders',
      progress: fulfillmentEfficiency,
      color: 'bg-purple-500'
    },
    {
      label: 'Logistics Efficiency',
      value: `${logisticsEfficiency}%`,
      sub: 'Consolidated fleet utilization',
      progress: logisticsEfficiency,
      color: 'bg-amber-500'
    }
  ];

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800/80 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              Supply Chain Health Scorecard
            </h3>
            <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500">
              Prototype Composite Indicators
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Real-time multi-actor efficiency metrics evaluated across {totalActiveProducts} products, {totalOrdersEvaluated} orders, and {totalActiveRoutes} routes.
          </p>
        </div>
      </div>

      {/* 4 Metric Progress Gauges */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {metrics.map((m, idx) => (
          <div key={idx} className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 flex flex-col justify-between">
            <div>
              <div className="text-xs text-slate-500 dark:text-slate-400 mb-1">{m.label}</div>
              <div className="text-2xl font-bold text-slate-900 dark:text-white mb-1">{m.value}</div>
              <div className="text-[11px] text-slate-400 mb-3">{m.sub}</div>
            </div>

            <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2 overflow-hidden">
              <div
                style={{ width: `${Math.min(100, m.progress)}%` }}
                className={`h-full rounded-full ${m.color} transition-all duration-500`}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
