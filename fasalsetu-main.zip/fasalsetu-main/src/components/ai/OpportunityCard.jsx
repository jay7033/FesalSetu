import React from 'react';
import { TrendingUp, Sparkles, HelpCircle } from 'lucide-react';

export default function OpportunityCard({ opportunity, onAction }) {
  if (!opportunity) return null;

  const {
    cropName,
    score,
    demandLevel,
    supplyLevel,
    suggestedListing,
    recommendation,
    confidenceScore,
    explanations = []
  } = opportunity;

  const scoreBadgeColor =
    score >= 80
      ? 'bg-emerald-500 text-white'
      : score >= 65
      ? 'bg-blue-500 text-white'
      : 'bg-amber-500 text-white';

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
      <div>
        {/* Header */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-primary/10 text-primary">
                Farmer Opportunity
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                Confidence: {confidenceScore}%
              </span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mt-1">
              {cropName}
            </h3>
          </div>
          <div className={`w-12 h-12 rounded-2xl flex flex-col items-center justify-center font-bold shadow-sm ${scoreBadgeColor}`}>
            <span className="text-base leading-none">{score}</span>
            <span className="text-[9px] uppercase tracking-wider opacity-90">/100</span>
          </div>
        </div>

        {/* Demand & Supply Signals */}
        <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between">
            <span className="text-slate-500 dark:text-slate-400">Market Demand</span>
            <span className="font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" />
              {demandLevel}
            </span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between">
            <span className="text-slate-500 dark:text-slate-400">Nearby Supply</span>
            <span className="font-bold text-amber-600 dark:text-amber-400">
              {supplyLevel}
            </span>
          </div>
        </div>

        {/* Suggested Listing Callout */}
        <div className="bg-primary/5 dark:bg-primary/10 border border-primary/20 rounded-xl p-3 mb-3">
          <div className="flex items-center justify-between text-xs mb-1">
            <span className="font-medium text-slate-600 dark:text-slate-400">Suggested Listing Volume</span>
            <span className="font-bold text-primary text-sm">{suggestedListing}</span>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            {recommendation}
          </p>
        </div>

        {/* Explainability bullets */}
        {explanations.length > 0 && (
          <div className="mb-4">
            <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-primary" />
              Why this opportunity?
            </div>
            <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-400">
              {explanations.slice(0, 3).map((exp, idx) => (
                <li key={idx} className="flex items-start gap-1.5">
                  <span className="text-primary">•</span>
                  <span>{exp}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Production Signal & Disclaimer */}
      <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400 text-[11px]">
            <HelpCircle className="w-3.5 h-3.5" />
            Decision-support advisory
          </div>
          {onAction && (
            <button
              onClick={() => onAction(opportunity)}
              className="text-xs font-semibold text-primary hover:text-primary-dark"
            >
              List Produce Now →
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
