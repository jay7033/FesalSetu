import React from 'react';
import { MapPin, ShieldCheck, Layers, Users, ShoppingBag } from 'lucide-react';

export default function DemandHeatmap({ regionalData = { regions: [] } }) {
  const regions = regionalData?.regions || [];

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400">
              <Layers className="w-4 h-4" />
            </span>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Pan-India Regional Demand Heatmap
            </h3>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Coarse geographic order density aggregated at District and State clusters
          </p>
        </div>

        <div className="flex items-center gap-1.5 text-[11px] font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/30 px-3 py-1.5 rounded-xl border border-emerald-200/60 dark:border-emerald-900/40">
          <ShieldCheck className="w-3.5 h-3.5 flex-shrink-0" />
          <span>GPS Protected • Zero Lat/Long Exposure</span>
        </div>
      </div>

      {/* Demand density legend */}
      <div className="flex flex-wrap items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl mb-5 text-xs text-slate-600 dark:text-slate-300">
        <span className="font-semibold text-slate-700 dark:text-slate-200 text-[11px]">
          Demand Density:
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
          High Demand (🔴)
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
          Rising Demand (🟠)
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-yellow-400" />
          Moderate Demand (🟡)
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
          Low Demand (🟢)
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-slate-600" />
          Insufficient Data (⚪)
        </span>
      </div>

      {/* Regional Cluster Cards */}
      {regions.length === 0 ? (
        <div className="text-center py-10 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
          <MapPin className="w-8 h-8 text-slate-400 mx-auto mb-2" />
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
            No Regional Order Clusters Yet
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mt-1">
            As buyers place orders across states, clusters appear automatically.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {regions.map((reg, idx) => (
            <div
              key={idx}
              className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-base">{reg.statusIcon}</span>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      {reg.district}
                    </h4>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">
                      {reg.state}
                    </span>
                  </div>
                </div>

                <span
                  className={`text-[11px] font-semibold px-2 py-0.5 rounded-full border ${
                    reg.densityColor === 'rose'
                      ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-400 dark:border-rose-900/50'
                      : reg.densityColor === 'amber'
                      ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-900/50'
                      : reg.densityColor === 'yellow'
                      ? 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-950/40 dark:text-yellow-400 dark:border-yellow-900/50'
                      : 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-900/50'
                  }`}
                >
                  {reg.density}
                </span>
              </div>

              <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 dark:text-slate-500 block">
                    Recorded Volume
                  </span>
                  <span className="font-semibold font-mono text-slate-800 dark:text-slate-200">
                    {reg.totalVolumeKg.toLocaleString()} kg
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 dark:text-slate-500 block">
                    Top Produce
                  </span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200 truncate block">
                    {reg.topCrop}
                  </span>
                </div>
              </div>

              <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                <span className="flex items-center gap-1">
                  <ShoppingBag className="w-3 h-3 text-slate-400" />
                  {reg.totalOrders} order(s)
                </span>
                <span className="flex items-center gap-1">
                  <Users className="w-3 h-3 text-slate-400" />
                  {reg.uniqueBuyers} buyer(s)
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
