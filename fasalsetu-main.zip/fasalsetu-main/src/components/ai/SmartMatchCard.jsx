import React from 'react';
import { Sparkles, MapPin, ArrowRight } from 'lucide-react';

export default function SmartMatchCard({ match, onSelect }) {
  if (!match) return null;

  const {
    productName,
    sellerName,
    sellerRole,
    buyerName,
    matchScore,
    availableQuantity,
    distanceKm,
    price,
    unit = 'kg',
    approximateLocation,
    breakdown = {},
    explanationFactors = []
  } = match;

  const scoreColor =
    matchScore >= 85
      ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800'
      : matchScore >= 70
      ? 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-800'
      : 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800';

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
      <div>
        {/* Header: Commodity & Score */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                {sellerRole === 'fpo' ? 'FPO Collective' : 'Direct Farmer'}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                for {buyerName}
              </span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mt-1">
              {productName}
            </h3>
          </div>
          <div className={`px-3 py-1.5 rounded-xl border font-bold text-center ${scoreColor}`}>
            <div className="text-xl leading-none">{matchScore}</div>
            <div className="text-[10px] uppercase font-semibold tracking-wider">Match Score</div>
          </div>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-3 gap-2 py-3 border-y border-slate-100 dark:border-slate-800/80 mb-3 text-center text-xs">
          <div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/50">
            <div className="text-slate-500 dark:text-slate-400">Available</div>
            <div className="font-bold text-slate-800 dark:text-slate-200">
              {availableQuantity.toLocaleString('en-IN')} {unit}
            </div>
          </div>
          <div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/50">
            <div className="text-slate-500 dark:text-slate-400">Distance</div>
            <div className="font-bold text-slate-800 dark:text-slate-200 flex items-center justify-center gap-0.5">
              <MapPin className="w-3 h-3 text-slate-400" />
              ~{distanceKm} km
            </div>
          </div>
          <div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/50">
            <div className="text-slate-500 dark:text-slate-400">Offered Price</div>
            <div className="font-bold text-emerald-600 dark:text-emerald-400">
              ₹{price}/{unit}
            </div>
          </div>
        </div>

        {/* Breakdown bars */}
        <div className="space-y-1 mb-4 text-[11px]">
          <div className="flex justify-between text-slate-500">
            <span>Quantity ({breakdown.quantity || 0}%)</span>
            <span>Distance ({breakdown.distance || 0}%)</span>
            <span>Quality ({breakdown.quality || 0}%)</span>
            <span>Price ({breakdown.price || 0}%)</span>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden flex">
            <div style={{ width: `${(breakdown.quantity || 0) * 0.25}%` }} className="bg-emerald-500 h-full" />
            <div style={{ width: `${(breakdown.distance || 0) * 0.20}%` }} className="bg-blue-500 h-full" />
            <div style={{ width: `${(breakdown.quality || 0) * 0.20}%` }} className="bg-purple-500 h-full" />
            <div style={{ width: `${(breakdown.price || 0) * 0.15}%` }} className="bg-amber-500 h-full" />
          </div>
        </div>

        {/* Explainability Section */}
        <div className="bg-slate-50 dark:bg-slate-800/40 rounded-xl p-3 mb-4">
          <div className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            Why this match?
          </div>
          <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-400">
            {explanationFactors.slice(0, 4).map((factor, idx) => (
              <li key={idx} className="flex items-start gap-1.5">
                <span className="text-slate-700 dark:text-slate-300">{factor}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Footer Details */}
      <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
        <div className="text-xs text-slate-500 truncate max-w-[200px]">
          <span className="font-medium text-slate-700 dark:text-slate-300">{sellerName}</span> • {approximateLocation}
        </div>
        {onSelect && (
          <button
            onClick={() => onSelect(match)}
            className="text-xs font-medium text-primary hover:text-primary-dark flex items-center gap-1"
          >
            Review Match <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
}
