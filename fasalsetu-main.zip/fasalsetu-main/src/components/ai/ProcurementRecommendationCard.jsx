import React from 'react';
import { Truck, ArrowRight } from 'lucide-react';

export default function ProcurementRecommendationCard({ plan, onReviewPO }) {
  if (!plan) return null;

  const {
    cropName,
    requiredQuantity,
    recommendedQuantity,
    fulfillmentPercent,
    supplierCount,
    suppliers = [],
    estimatedDistanceKm,
    estimatedCost,
    matchScore,
    comparison,
    explanation
  } = plan;

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800/80">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
              Procurement Recommendation
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Match Score: {matchScore}/100
            </span>
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white">
            {cropName} Bulk Sourcing Plan
          </h3>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-xs text-slate-400">Fulfillment</div>
            <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
              {fulfillmentPercent}%
            </div>
          </div>
          {onReviewPO && (
            <button
              onClick={() => onReviewPO(plan)}
              className="px-4 py-2 bg-primary hover:bg-primary-dark text-white rounded-xl text-xs font-semibold shadow-sm transition-all flex items-center gap-1.5"
            >
              Draft Commercial PO <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-4 text-xs">
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
          <div className="text-slate-500 dark:text-slate-400">Required Quantity</div>
          <div className="text-base font-bold text-slate-900 dark:text-white">
            {requiredQuantity.toLocaleString('en-IN')} kg
          </div>
        </div>
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
          <div className="text-slate-500 dark:text-slate-400">Recommended Allocation</div>
          <div className="text-base font-bold text-emerald-600 dark:text-emerald-400">
            {recommendedQuantity.toLocaleString('en-IN')} kg
          </div>
        </div>
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
          <div className="text-slate-500 dark:text-slate-400">Optimized Corridor</div>
          <div className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-1">
            <Truck className="w-4 h-4 text-slate-400" />
            ~{estimatedDistanceKm} km
          </div>
        </div>
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
          <div className="text-slate-500 dark:text-slate-400">Estimated Sourcing Cost</div>
          <div className="text-base font-bold text-slate-900 dark:text-white">
            ₹{estimatedCost.toLocaleString('en-IN')}
          </div>
        </div>
      </div>

      {/* Explanation Banner */}
      <p className="text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/30 p-3 rounded-xl mb-4 leading-relaxed">
        {explanation}
      </p>

      {/* Supplier Breakdown Table */}
      <div className="space-y-2 mb-4">
        <div className="text-xs font-semibold text-slate-700 dark:text-slate-300">
          Recommended Sourcing Breakdown ({supplierCount} Sources):
        </div>
        <div className="space-y-2">
          {suppliers.map((s, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs"
            >
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 flex items-center justify-center font-bold text-[10px]">
                  {idx + 1}
                </span>
                <div>
                  <div className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    {s.supplierName}
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-500">
                      {s.supplierRole}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400">{s.approximateAddress} (~{s.distanceKm} km)</div>
                </div>
              </div>

              <div className="text-right">
                <div className="font-bold text-slate-800 dark:text-slate-200">
                  {s.allocatedQuantity.toLocaleString('en-IN')} kg
                </div>
                <div className="text-[11px] text-emerald-600 dark:text-emerald-400">
                  @ ₹{s.pricePerKg}/kg
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Sourcing Strategy Comparison */}
      {comparison && (
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 text-xs border border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <span className="font-medium text-slate-500 dark:text-slate-400">Algorithm Optimization: </span>
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              Selected Option ({comparison.optionA.supplierCount} stops, ~{comparison.optionA.totalDistanceKm} km)
            </span>
          </div>
          <span className="text-[11px] text-slate-400">Corridor consolidation active</span>
        </div>
      )}
    </div>
  );
}
