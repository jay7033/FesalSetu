import React from 'react';
import { TrendingUp, TrendingDown, Minus, HelpCircle, Flame } from 'lucide-react';

export default function DemandTrendBadge({ classification = 'STABLE', growthPercent = null, size = 'md' }) {
  const isSm = size === 'sm';

  const config = {
    'HIGH DEMAND': {
      label: 'High Demand',
      icon: Flame,
      bg: 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-400 dark:border-rose-800/60',
      arrow: '↑'
    },
    'RISING DEMAND': {
      label: 'Rising Demand',
      icon: TrendingUp,
      bg: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800/60',
      arrow: '↑'
    },
    'STABLE': {
      label: 'Stable Demand',
      icon: Minus,
      bg: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/40 dark:text-blue-400 dark:border-blue-800/60',
      arrow: '→'
    },
    'DECLINING': {
      label: 'Declining',
      icon: TrendingDown,
      bg: 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700',
      arrow: '↓'
    },
    'LOW DEMAND': {
      label: 'Low Demand',
      icon: TrendingDown,
      bg: 'bg-slate-100 text-slate-600 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700',
      arrow: '↓'
    },
    'INSUFFICIENT DATA': {
      label: 'Insufficient Data',
      icon: HelpCircle,
      bg: 'bg-slate-100 text-slate-500 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700',
      arrow: '⚪'
    }
  };

  const current = config[classification] || config['STABLE'];
  const Icon = current.icon;

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border font-medium transition-colors ${current.bg} ${
        isSm ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs'
      }`}
    >
      <Icon className={isSm ? 'w-3 h-3' : 'w-3.5 h-3.5'} />
      <span>{current.label}</span>
      {growthPercent !== null && classification !== 'INSUFFICIENT DATA' && (
        <span className="font-semibold ml-0.5">
          ({growthPercent >= 0 ? `+${growthPercent}%` : `${growthPercent}%`})
        </span>
      )}
    </span>
  );
}
