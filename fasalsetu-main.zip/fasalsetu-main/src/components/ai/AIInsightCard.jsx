import { Sparkles, CheckCircle2, ChevronRight } from 'lucide-react';
import DemandTrendBadge from './DemandTrendBadge';
import SupplyStatusBadge from './SupplyStatusBadge';
import ForecastConfidence from './ForecastConfidence';

export default function AIInsightCard({
  forecast,
  onOpenDetails = null
}) {
  if (!forecast) return null;

  const {
    cropName,
    classification,
    growthPercent,
    forecastQuantity,
    availableSupply,
    supplyStatus,
    confidenceScore,
    confidenceTier,
    confidenceFactors = [],
    primaryDistrict,
    primaryState
  } = forecast;

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between">
      <div>
        {/* Header */}
        <div className="flex items-start justify-between gap-2 mb-3">
          <div>
            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI DEMAND SIGNAL</span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              {cropName}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {primaryDistrict}, {primaryState}
            </p>
          </div>

          <div className="flex flex-col items-end gap-1.5">
            <DemandTrendBadge classification={classification} growthPercent={growthPercent} size="sm" />
            <SupplyStatusBadge status={supplyStatus} size="sm" />
          </div>
        </div>

        {/* Metric Grid */}
        <div className="grid grid-cols-2 gap-2.5 my-4">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800">
            <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-0.5">
              Projected 7-Day Demand
            </span>
            <span className="text-base font-bold font-mono text-slate-900 dark:text-white">
              ~{forecastQuantity.toLocaleString()} kg
            </span>
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800">
            <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-0.5">
              Nearby Farm Supply
            </span>
            <span className="text-base font-bold font-mono text-slate-900 dark:text-white">
              {availableSupply.toLocaleString()} kg
            </span>
          </div>
        </div>

        {/* Explainability factors */}
        {confidenceFactors.length > 0 && (
          <div className="space-y-1.5 mb-4">
            <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 block">
              Forecast Drivers:
            </span>
            <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-400">
              {confidenceFactors.slice(0, 2).map((factor, idx) => (
                <li key={idx} className="flex items-start gap-1.5 text-[11px]">
                  <CheckCircle2 className="w-3 h-3 text-emerald-500 flex-shrink-0 mt-0.5" />
                  <span>{factor}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3">
        <ForecastConfidence score={confidenceScore} tier={confidenceTier} />

        {onOpenDetails && (
          <button
            onClick={() => onOpenDetails(forecast)}
            className="w-full flex items-center justify-between text-xs font-semibold py-2 px-3 rounded-xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors"
          >
            <span>Inspect Prediction Logic</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          </button>
        )}
      </div>
    </div>
  );
}
