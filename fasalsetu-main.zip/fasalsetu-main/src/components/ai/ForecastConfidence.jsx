import React from 'react';
import { ShieldCheck, Info } from 'lucide-react';

export default function ForecastConfidence({ score = 70, tier = 'Moderate', showBar = true }) {
  const boundedScore = Math.min(Math.max(Number(score) || 0, 0), 100);

  let barColor = 'bg-amber-500';
  let textColor = 'text-amber-700 dark:text-amber-400';

  if (boundedScore >= 75) {
    barColor = 'bg-emerald-500';
    textColor = 'text-emerald-700 dark:text-emerald-400';
  } else if (boundedScore < 50) {
    barColor = 'bg-slate-400';
    textColor = 'text-slate-600 dark:text-slate-400';
  }

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-xs">
        <span className="flex items-center gap-1.5 font-medium text-slate-700 dark:text-slate-300">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
          Forecast Confidence
        </span>
        <span className={`font-bold font-mono ${textColor}`}>
          {boundedScore}%
          <span className="text-[10px] font-normal text-slate-500 dark:text-slate-400 ml-1">
            ({tier})
          </span>
        </span>
      </div>

      {showBar && (
        <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${barColor}`}
            style={{ width: `${boundedScore}%` }}
          />
        </div>
      )}

      <div className="flex items-center gap-1 text-[10px] text-slate-400 dark:text-slate-500">
        <Info className="w-2.5 h-2.5 flex-shrink-0" />
        <span>Calculated from transaction recency & volume (prototype signal).</span>
      </div>
    </div>
  );
}
