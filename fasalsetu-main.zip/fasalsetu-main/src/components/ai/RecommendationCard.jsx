import React from 'react';
import { Sparkles, ArrowRight, MapPin, Scale } from 'lucide-react';
import DemandTrendBadge from './DemandTrendBadge';
import ForecastConfidence from './ForecastConfidence';

export default function RecommendationCard({
  cropName = 'Produce',
  classification = 'RISING DEMAND',
  growthPercent = 0,
  suggestedRangeFormatted = '100–150 kg',
  actionLabel = 'Suggested Listing Range',
  recommendationText = '',
  confidenceScore = 75,
  confidenceTier = 'High',
  locationContext = 'Noida',
  onActionClick = null
}) {
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between">
      <div>
        <div className="flex items-start justify-between gap-3 mb-3">
          <div>
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider mb-1">
              <Sparkles className="w-3 h-3" />
              AI Demand Opportunity
            </span>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              {cropName}
            </h3>
          </div>
          <DemandTrendBadge classification={classification} growthPercent={growthPercent} size="sm" />
        </div>

        <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-4">
          <MapPin className="w-3.5 h-3.5 text-slate-400" />
          <span>Regional Hub: {locationContext}</span>
        </div>

        <div className="p-3 bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/40 rounded-xl mb-4">
          <div className="flex items-center justify-between text-xs mb-1 text-emerald-900 dark:text-emerald-300">
            <span className="flex items-center gap-1 font-medium">
              <Scale className="w-3.5 h-3.5 text-emerald-600" />
              {actionLabel}
            </span>
            <span className="text-base font-bold font-mono text-emerald-700 dark:text-emerald-400">
              {suggestedRangeFormatted}
            </span>
          </div>
          <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
            {recommendationText}
          </p>
          <p className="text-[10px] text-slate-400 dark:text-slate-500 italic mt-1.5">
            * Recommended advisory based on local order velocity; does not guarantee purchase.
          </p>
        </div>
      </div>

      <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3">
        <ForecastConfidence score={confidenceScore} tier={confidenceTier} />

        {onActionClick && (
          <button
            onClick={onActionClick}
            className="w-full mt-2 inline-flex items-center justify-center gap-1.5 text-xs font-semibold py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white transition-colors"
          >
            <span>Take Action</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
}
