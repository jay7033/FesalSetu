import React from 'react';
import { 
  X, 
  Sparkles, 
  CheckCircle2, 
  MapPin
} from 'lucide-react';
import DemandTrendBadge from './DemandTrendBadge';
import SupplyStatusBadge from './SupplyStatusBadge';
import ForecastConfidence from './ForecastConfidence';

export default function ForecastDetailModal({ forecast, onClose }) {
  if (!forecast) return null;

  const {
    cropName,
    classification,
    growthPercent,
    forecastQuantity,
    availableSupply,
    recent7DaysDemand,
    supplyStatus,
    confidenceScore,
    confidenceTier,
    confidenceFactors = [],
    primaryDistrict,
    primaryState,
    totalOrders
  } = forecast;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div 
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-start justify-between gap-4 sticky top-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-sm z-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400 mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>EXPLAINABLE AI PREDICTION</span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              {cropName} Demand Forecast
            </h2>
            <div className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400 mt-1">
              <MapPin className="w-3.5 h-3.5" />
              <span>{primaryDistrict}, {primaryState}</span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Status Row */}
          <div className="flex flex-wrap items-center gap-2">
            <DemandTrendBadge classification={classification} growthPercent={growthPercent} />
            <SupplyStatusBadge status={supplyStatus} />
          </div>

          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-[11px] text-slate-400 block mb-1">Projected Demand</span>
              <span className="text-lg font-bold font-mono text-emerald-600 dark:text-emerald-400">
                ~{forecastQuantity.toLocaleString()} kg
              </span>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-[11px] text-slate-400 block mb-1">Nearby Farm Supply</span>
              <span className="text-lg font-bold font-mono text-slate-900 dark:text-white">
                {availableSupply.toLocaleString()} kg
              </span>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800 col-span-2 sm:col-span-1">
              <span className="text-[11px] text-slate-400 block mb-1">Recent 7-Day Orders</span>
              <span className="text-lg font-bold font-mono text-slate-900 dark:text-white">
                {recent7DaysDemand.toLocaleString()} kg
              </span>
            </div>
          </div>

          {/* Explainability Section */}
          <div className="p-4 bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/40 rounded-2xl space-y-3">
            <div className="flex items-center gap-2 text-sm font-bold text-emerald-900 dark:text-emerald-200">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>Why this forecast? (Explainability Factors)</span>
            </div>

            <ul className="space-y-2 text-xs text-slate-700 dark:text-slate-300">
              {confidenceFactors.length > 0 ? (
                confidenceFactors.map((factor, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                    <span>{factor}</span>
                  </li>
                ))
              ) : (
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                  <span>Calculated from historical transaction frequency and available inventory balance.</span>
                </li>
              )}
            </ul>
          </div>

          {/* Confidence Breakdown */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-3">
            <ForecastConfidence score={confidenceScore} tier={confidenceTier} />
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
              Confidence score synthesizes sample depth ({totalOrders || 5}+ orders), 14-day recency, trend volatility, and geographic buyer spread.
            </p>
          </div>

          {/* Model Note */}
          <div className="flex items-center justify-between text-[10px] text-slate-400 dark:text-slate-500 pt-2 border-t border-slate-100 dark:border-slate-800">
            <span>Model: Statistical Weighted Moving Average (v1.0)</span>
            <span>Generated: Today, {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
