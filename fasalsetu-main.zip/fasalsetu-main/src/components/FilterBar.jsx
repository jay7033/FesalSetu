import React from 'react';
import { 
  Filter, 
  RotateCcw, 
  MapPin, 
  Layers, 
  Tag, 
  CheckCircle2, 
  Sparkles,
  ArrowUpDown
} from 'lucide-react';

import { 
  CATEGORIES, 
  LOCATIONS, 
  INDIAN_STATES,
  DISTANCE_OPTIONS,
  PRICE_RANGES, 
  AVAILABILITY_OPTIONS, 
  QUALITY_OPTIONS, 
  SORT_OPTIONS 
} from '../data/demoData';


export default function FilterBar({
  filters,
  onFilterChange,
  onResetFilters,
  totalResults = 0,
  buyerLocation = null,
  className = ""
}) {
  const hasActiveFilters = 
    filters.category !== 'All' ||
    filters.state !== 'All India' ||
    filters.location !== 'All Locations' ||
    filters.distance !== 'all' ||
    filters.priceRange !== 'all' ||
    filters.availability !== 'all' ||
    filters.quality !== 'All' ||
    filters.sort !== 'recommended';

  return (
    <div className={`bg-white rounded-3xl border border-slate-200/90 shadow-sm p-5 space-y-6 ${className}`}>
      
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700">
            <Filter className="w-4 h-4" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm font-display">
            Filter Produce
          </h3>
          <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
            {totalResults} items
          </span>
        </div>

        {hasActiveFilters && (
          <button
            type="button"
            onClick={onResetFilters}
            className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 hover:underline focus:outline-none"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Clear All</span>
          </button>
        )}
      </div>

      {/* Sort Selector */}
      <div className="space-y-2">
        <label className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
          <ArrowUpDown className="w-3.5 h-3.5 text-emerald-600" />
          <span>Sort By</span>
        </label>
        <select
          value={filters.sort}
          onChange={(e) => onFilterChange('sort', e.target.value)}
          aria-label="Sort produce"
          className="w-full text-xs font-semibold py-2.5 px-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
        >
          {SORT_OPTIONS.map((opt) => (
            <option key={opt.id} value={opt.id}>
              {opt.label}
            </option>
          ))}
        </select>
      </div>

      {/* Distance Radius Filter (if buyer location is active) */}
      {buyerLocation && (
        <div className="space-y-2 p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200/80">
          <label className="text-xs font-bold uppercase tracking-wider text-emerald-950 flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-emerald-600" />
            <span>Distance Radius</span>
          </label>
          <div className="grid grid-cols-2 gap-1.5">
            {DISTANCE_OPTIONS.map((dist) => {
              const isSelected = filters.distance === dist.id;
              return (
                <button
                  key={dist.id}
                  type="button"
                  onClick={() => onFilterChange('distance', dist.id)}
                  className={`text-[11px] px-2 py-1.5 rounded-xl font-bold transition-all text-center ${
                    isSelected
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'bg-white text-slate-700 hover:bg-emerald-100/60 border border-emerald-200/60'
                  }`}
                >
                  {dist.label}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Indian State Selector (Pan-India) */}
      <div className="space-y-2">
        <label className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
          <MapPin className="w-3.5 h-3.5 text-emerald-600" />
          <span>State / Region</span>
        </label>
        <select
          value={filters.state || 'All India'}
          onChange={(e) => onFilterChange('state', e.target.value)}
          aria-label="Filter by Indian State"
          className="w-full text-xs font-semibold py-2.5 px-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
        >
          {INDIAN_STATES.map((st) => (
            <option key={st} value={st}>
              {st}
            </option>
          ))}
        </select>
      </div>

      {/* Category Filter */}
      <div className="space-y-2">
        <label className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
          <Layers className="w-3.5 h-3.5 text-emerald-600" />
          <span>Category</span>
        </label>
        <div className="flex flex-wrap gap-1.5">
          {CATEGORIES.map((cat) => {
            const isSelected = filters.category === cat;
            return (
              <button
                key={cat}
                type="button"
                onClick={() => onFilterChange('category', cat)}
                className={`text-xs px-3 py-1.5 rounded-xl font-medium transition-all duration-150 ${
                  isSelected
                    ? 'bg-emerald-700 text-white shadow-xs font-semibold'
                    : 'bg-slate-100 hover:bg-slate-200/80 text-slate-700'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Location / Hub Filter */}
      <div className="space-y-2">
        <label className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
          <MapPin className="w-3.5 h-3.5 text-emerald-600" />
          <span>City / Hub Cluster</span>
        </label>
        <select
          value={filters.location}
          onChange={(e) => onFilterChange('location', e.target.value)}
          aria-label="Filter by location"
          className="w-full text-xs font-semibold py-2.5 px-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
        >
          {LOCATIONS.map((loc) => (
            <option key={loc} value={loc}>
              {loc}
            </option>
          ))}
        </select>
      </div>


      {/* Price Range */}
      <div className="space-y-2">
        <label className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
          <Tag className="w-3.5 h-3.5 text-emerald-600" />
          <span>Price Bracket</span>
        </label>
        <div className="grid grid-cols-2 gap-1.5">
          {PRICE_RANGES.map((pr) => {
            const isSelected = filters.priceRange === pr.id;
            return (
              <button
                key={pr.id}
                type="button"
                onClick={() => onFilterChange('priceRange', pr.id)}
                className={`text-xs px-2.5 py-1.5 rounded-xl font-medium transition-all duration-150 text-center ${
                  isSelected
                    ? 'bg-emerald-700 text-white font-semibold'
                    : 'bg-slate-100 hover:bg-slate-200/80 text-slate-700'
                }`}
              >
                {pr.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Quality Grade */}
      <div className="space-y-2">
        <label className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
          <span>Quality Standard</span>
        </label>
        <div className="grid grid-cols-2 gap-1.5">
          {QUALITY_OPTIONS.map((qual) => {
            const isSelected = filters.quality === qual;
            return (
              <button
                key={qual}
                type="button"
                onClick={() => onFilterChange('quality', qual)}
                className={`text-xs px-2.5 py-1.5 rounded-xl font-medium transition-all duration-150 text-center ${
                  isSelected
                    ? 'bg-emerald-700 text-white font-semibold'
                    : 'bg-slate-100 hover:bg-slate-200/80 text-slate-700'
                }`}
              >
                {qual}
              </button>
            );
          })}
        </div>
      </div>

      {/* Availability Filter */}
      <div className="space-y-2">
        <label className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
          <span>Harvest Availability</span>
        </label>
        <div className="space-y-1">
          {AVAILABILITY_OPTIONS.map((avail) => {
            const isSelected = filters.availability === avail.id;
            return (
              <label 
                key={avail.id}
                className="flex items-center gap-2.5 p-2 rounded-xl hover:bg-slate-50 cursor-pointer text-xs font-medium text-slate-700 select-none"
              >
                <input
                  type="radio"
                  name="availability"
                  checked={isSelected}
                  onChange={() => onFilterChange('availability', avail.id)}
                  className="w-4 h-4 text-emerald-600 focus:ring-emerald-500 border-slate-300"
                />
                <span>{avail.label}</span>
              </label>
            );
          })}
        </div>
      </div>

    </div>
  );
}
