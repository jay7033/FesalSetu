import React from 'react';

export default function StatCard({
  title,
  value,
  change,
  subtext,
  icon: Icon,
  accent = 'emerald',
  isDemo = true
}) {
  const accentMap = {
    emerald: {
      iconBg: 'bg-emerald-50 border-emerald-200 text-emerald-700',
      bar: 'from-emerald-600 to-teal-500'
    },
    amber: {
      iconBg: 'bg-amber-50 border-amber-200 text-amber-700',
      bar: 'from-amber-500 to-orange-400'
    },
    blue: {
      iconBg: 'bg-blue-50 border-blue-200 text-blue-700',
      bar: 'from-blue-600 to-indigo-500'
    },
    purple: {
      iconBg: 'bg-purple-50 border-purple-200 text-purple-700',
      bar: 'from-purple-600 to-pink-500'
    }
  };

  const theme = accentMap[accent] || accentMap.emerald;

  return (
    <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-xs hover:shadow-md transition-all duration-300 relative overflow-hidden group">
      <div className="flex items-start justify-between mb-3">
        <div>
          <p className="text-xs font-bold uppercase tracking-wider text-slate-400">
            {title}
          </p>
          <p className="text-3xl font-black text-slate-950 font-display tracking-tight mt-1">
            {value}
          </p>
        </div>

        {Icon && (
          <div className={`p-3 rounded-2xl border shadow-2xs ${theme.iconBg}`}>
            <Icon className="w-5 h-5" />
          </div>
        )}
      </div>

      <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-100">
        <span className="text-slate-500">{subtext}</span>
        {change && (
          <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
            {change}
          </span>
        )}
      </div>

      {isDemo && (
        <span className="absolute top-2 right-2 text-[9px] font-mono text-slate-300 pointer-events-none">
          DEMO
        </span>
      )}

      {/* Hover bottom bar */}
      <div className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${theme.bar} opacity-0 group-hover:opacity-100 transition-opacity`} />
    </div>
  );
}
