import React from 'react';
import { MapPin, Navigation, Shield, Loader2, AlertCircle } from 'lucide-react';
import Button from '../Button';

export default function LocationPermission({
  onRequestLocation,
  onManualSelect,
  loading = false,
  error = null,
  title = 'Set Your Farm Location',
  subtitle = 'Detect your farm GPS location to connect with nearby buyers and automate produce origin.'
}) {
  return (
    <div className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-6">
      
      {/* Header */}
      <div className="flex items-start gap-4">
        <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-700 flex-shrink-0">
          <MapPin className="w-6 h-6" />
        </div>
        <div className="space-y-1">
          <h3 className="text-xl font-bold text-slate-900 font-display">
            {title}
          </h3>
          <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
            {subtitle}
          </p>
        </div>
      </div>

      {/* Privacy Notice Box */}
      <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 text-emerald-950 text-xs space-y-2">
        <div className="flex items-center gap-1.5 font-bold text-emerald-900">
          <Shield className="w-4 h-4 text-emerald-700 flex-shrink-0" />
          <span>Location Privacy Guaranteed</span>
        </div>
        <p className="text-[11px] text-emerald-800 leading-relaxed">
          FasalSetu uses your location to connect your farm with nearby buyers and optimize delivery. Your exact farm coordinates are never publicly displayed on marketplace cards — only approximate district/region is shown.
        </p>
      </div>

      {/* Error display if any */}
      {error && (
        <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-amber-700 flex-shrink-0 mt-0.5" />
          <p className="leading-relaxed flex-1">{error}</p>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
        <button
          type="button"
          onClick={onRequestLocation}
          disabled={loading}
          className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs sm:text-sm font-bold shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-emerald-200" />
              <span>Detecting GPS Coordinates...</span>
            </>
          ) : (
            <>
              <Navigation className="w-4 h-4 text-emerald-200" />
              <span>USE MY CURRENT LOCATION</span>
            </>
          )}
        </button>

        {onManualSelect && (
          <Button
            type="button"
            onClick={onManualSelect}
            variant="outline"
            size="md"
            className="w-full sm:w-auto justify-center"
          >
            SELECT LOCATION MANUALLY
          </Button>
        )}
      </div>

      <p className="text-[11px] text-slate-400">
        💡 Requires browser location permission. Live GPS detection is powered by HTML5 Geolocation.
      </p>

    </div>
  );
}
