import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Edit3, 
  Trash2, 
  ExternalLink, 
  MapPin, 
  Package, 
  PlusCircle, 
  Sparkles 
} from 'lucide-react';
import InventoryBadge from './InventoryBadge';
import ProductImage from '../ProductImage';
import Button from '../Button';

export default function ProductTable({
  products = [],
  onEdit,
  onDelete,
  farmLocations = []
}) {
  if (products.length === 0) {
    return (
      <div className="bg-white rounded-3xl border border-slate-200/90 p-12 text-center space-y-4 shadow-xs">
        <div className="w-16 h-16 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center mx-auto text-emerald-600">
          <Package className="w-8 h-8" />
        </div>
        <div className="space-y-1">
          <h3 className="text-lg font-bold text-slate-900 font-display">
            No produce listed yet
          </h3>
          <p className="text-slate-500 text-xs sm:text-sm max-w-sm mx-auto">
            List your freshly harvested agricultural produce from your confirmed farm locations directly to verified buyers.
          </p>
        </div>
        <div className="pt-2">
          <Button
            to="/farmer/add-product"
            variant="primary"
            size="md"
            leftIcon={PlusCircle}
          >
            Add First Product
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      
      {/* Desktop Table View */}
      <div className="hidden md:block bg-white rounded-3xl border border-slate-200/90 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/80 border-b border-slate-200/80 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3.5 px-6">Product</th>
                <th className="py-3.5 px-4">Origin Farm</th>
                <th className="py-3.5 px-4">Price</th>
                <th className="py-3.5 px-4">Stock Status</th>
                <th className="py-3.5 px-4">Quality Grade</th>
                <th className="py-3.5 px-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {products.map((product) => {
                const linkedFarm = farmLocations.find((f) => f.id === product.farmLocationId);
                const displayLoc = linkedFarm?.approximateLocation || product.approximateLocation || `Near ${product.location}, ${product.state || 'India'}`;

                return (
                  <tr key={product.id} className="hover:bg-slate-50/60 transition-colors">
                    
                    {/* Product name & thumbnail */}
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl overflow-hidden bg-slate-100 flex-shrink-0 border border-slate-200/60">
                          <ProductImage
                            src={product.image}
                            alt={product.name}
                            category={product.category}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-slate-900 text-sm">{product.name}</span>
                            {product.organic && (
                              <span className="p-0.5 rounded-full bg-emerald-100 text-emerald-800" title="Organic">
                                <Sparkles className="w-3 h-3" />
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-500">{product.hindiName || product.category}</p>
                        </div>
                      </div>
                    </td>

                    {/* Origin Farm */}
                    <td className="py-4 px-4">
                      <div className="space-y-0.5">
                        <span className="font-semibold text-slate-800 flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                          <span className="truncate max-w-[160px]">{linkedFarm?.name || displayLoc}</span>
                        </span>
                        <p className="text-[10px] text-slate-400 truncate max-w-[160px]">
                          {displayLoc}
                        </p>
                      </div>
                    </td>

                    {/* Price */}
                    <td className="py-4 px-4">
                      <div>
                        <span className="text-sm font-black text-slate-950 font-display">
                          ₹{product.price}
                        </span>
                        <span className="text-slate-500 text-[11px]">/{product.unit}</span>
                      </div>
                    </td>

                    {/* Stock & Badge */}
                    <td className="py-4 px-4">
                      <div className="space-y-1">
                        <span className="font-bold text-slate-800">
                          {product.quantityAvailable} {product.unit}
                        </span>
                        <div>
                          <InventoryBadge quantity={product.quantityAvailable} unit={product.unit} />
                        </div>
                      </div>
                    </td>

                    {/* Quality */}
                    <td className="py-4 px-4">
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200/60">
                        {product.quality || 'Grade A'}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="py-4 px-6 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <Link
                          to={`/product/${product.id}`}
                          target="_blank"
                          rel="noreferrer"
                          className="p-2 text-slate-500 hover:text-emerald-700 hover:bg-slate-100 rounded-xl transition-colors"
                          title="View on Public Marketplace"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </Link>

                        <button
                          type="button"
                          onClick={() => onEdit(product)}
                          className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                          title="Edit Produce"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => onDelete(product.id)}
                          className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer"
                          title="Delete Produce"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>

                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Mobile Card View */}
      <div className="grid grid-cols-1 gap-4 md:hidden">
        {products.map((product) => {
          const linkedFarm = farmLocations.find((f) => f.id === product.farmLocationId);
          const displayLoc = linkedFarm?.approximateLocation || product.approximateLocation || `Near ${product.location}, ${product.state || 'India'}`;

          return (
            <div key={product.id} className="bg-white rounded-2xl border border-slate-200/90 p-4 space-y-3 shadow-xs">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-xl overflow-hidden bg-slate-100 flex-shrink-0 border border-slate-200/60">
                  <ProductImage
                    src={product.image}
                    alt={product.name}
                    category={product.category}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <h4 className="font-bold text-slate-900 text-sm truncate">{product.name}</h4>
                    <span className="font-black text-slate-950 font-display">₹{product.price}/{product.unit}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 truncate">{product.hindiName || product.category}</p>
                  <p className="text-[11px] text-emerald-700 flex items-center gap-1 mt-0.5 truncate">
                    <MapPin className="w-3 h-3 flex-shrink-0" />
                    <span className="truncate">{displayLoc}</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-700">{product.quantityAvailable} {product.unit}</span>
                  <InventoryBadge quantity={product.quantityAvailable} unit={product.unit} />
                </div>

                <div className="flex items-center gap-1">
                  <Link
                    to={`/product/${product.id}`}
                    className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-slate-100 rounded-lg"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </Link>
                  <button
                    type="button"
                    onClick={() => onEdit(product)}
                    className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onDelete(product.id)}
                    className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
}
