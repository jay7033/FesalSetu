import React from 'react';
import { 
  Clock, 
  CheckCircle2, 
  Package, 
  Truck, 
  CheckCheck, 
  XCircle, 
  AlertCircle 
} from 'lucide-react';

export default function OrderStatusBadge({ status = 'Pending', size = 'sm' }) {
  const getStatusConfig = (st) => {
    switch (st?.toLowerCase()) {
      case 'confirmed':
        return {
          label: 'Confirmed',
          icon: CheckCircle2,
          classes: 'bg-emerald-50 text-emerald-800 border-emerald-300'
        };
      case 'preparing':
        return {
          label: 'Preparing',
          icon: Package,
          classes: 'bg-amber-50 text-amber-800 border-amber-300'
        };
      case 'ready for pickup':
        return {
          label: 'Ready for Pickup',
          icon: Clock,
          classes: 'bg-teal-50 text-teal-800 border-teal-300'
        };
      case 'picked up':
      case 'in transit':
        return {
          label: st,
          icon: Truck,
          classes: 'bg-blue-50 text-blue-800 border-blue-300'
        };
      case 'delivered':
        return {
          label: 'Delivered',
          icon: CheckCheck,
          classes: 'bg-emerald-100 text-emerald-900 border-emerald-400'
        };
      case 'cancelled':
        return {
          label: 'Cancelled',
          icon: XCircle,
          classes: 'bg-red-50 text-red-800 border-red-300'
        };
      case 'pending':
      default:
        return {
          label: 'Pending',
          icon: AlertCircle,
          classes: 'bg-slate-100 text-slate-700 border-slate-300'
        };
    }
  };

  const config = getStatusConfig(status);
  const Icon = config.icon;

  const sizeClass = size === 'sm' ? 'text-xs px-2.5 py-1' : 'text-sm px-3 py-1.5';

  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full font-bold border ${config.classes} ${sizeClass}`}>
      <Icon className="w-3.5 h-3.5 flex-shrink-0" />
      <span>{config.label}</span>
    </span>
  );
}
