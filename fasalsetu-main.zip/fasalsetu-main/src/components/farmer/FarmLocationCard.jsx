import React from 'react';
import { MapPin, CheckCircle2, Star, Trash2, Compass } from 'lucide-react';

export default function FarmLocationCard({
  location,
  onSetDefault,
  onDelete,
  onViewMap,
  canDelete = false
}) {
  const isDefault = Boolean(location.isDefault);

  return (
    <div className={`bg-white rounded-3xl border transition-all duration-200 p-6 flex flex-col justify-between space-y-4 shadow-xs ${
      isDefault ? 'border-emerald-500 ring-2 ring-emerald-500/20' : 'border-slate-200/90 hover:border-slate-300'
    }`}>
      
      {/* Top Header & Badges */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className={`p-3 rounded-2xl flex-shrink-0 ${
            isDefault ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'
          }`}>
            <MapPin className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-base font-bold text-slate-900 font-display">
                {location.name || 'Farm Location'}
              </h4>
              {isDefault && (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black tracking-wide uppercase">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Default Farm</span>
                </span>
              )}
            </div>

            <p className="text-xs text-slate-500 mt-0.5">
              {location.approximateLocation || `Near ${location.city || location.district}, ${location.state}`}
            </p>
          </div>
        </div>

        {/* Source Badge */}
        <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${
          location.source === 'device'
            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
            : location.source === 'manual'
            ? 'bg-blue-50 text-blue-700 border border-blue-200'
            : 'bg-amber-50 text-amber-700 border border-amber-200'
        }`}>
          {location.source || 'demo'}
        </span>
      </div>

      {/* Details Box */}
      <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/70 text-xs space-y-2">
        <p className="text-slate-700 font-medium line-clamp-2">
          {location.formattedAddress || `${location.village ? location.village + ', ' : ''}${location.city || ''} ${location.district || ''}, ${location.state || 'India'}`}
        </p>

        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-slate-500 pt-1 border-t border-slate-200/50">
          <span className="font-mono flex items-center gap-1">
            <Compass className="w-3 h-3 text-slate-400" />
            <span>GPS: {location.latitude?.toFixed(4)}°, {location.longitude?.toFixed(4)}°</span>
          </span>
          {location.accuracy && (
            <span className="text-slate-400">
              ±{location.accuracy}m accuracy
            </span>
          )}
        </div>
      </div>

      {/* Actions */}
      <div className="pt-2 flex items-center justify-between gap-2 border-t border-slate-100">
        <div className="flex items-center gap-2">
          {!isDefault && onSetDefault && (
            <button
              type="button"
              onClick={() => onSetDefault(location.id)}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 hover:bg-emerald-50 px-3 py-1.5 rounded-xl transition-colors flex items-center gap-1"
            >
              <Star className="w-3.5 h-3.5" />
              <span>Set as Default</span>
            </button>
          )}

          {onViewMap && (
            <button
              type="button"
              onClick={() => onViewMap(location)}
              className="text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 px-3 py-1.5 rounded-xl transition-colors"
            >
              View on Map
            </button>
          )}
        </div>

        {canDelete && onDelete && (
          <button
            type="button"
            onClick={() => onDelete(location.id)}
            className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-xl transition-colors"
            title="Delete this farm location"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>

    </div>
  );
}
