import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Package, 
  PlusCircle, 
  ShoppingBag, 
  IndianRupee, 
  UserCheck, 
  ArrowLeft, 
  MapPin, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle,
  LogOut
} from 'lucide-react';
import Logo from '../Logo';
import { useLocation } from '../../context/LocationContext';
import { useAuth } from '../../context/AuthContext';

export default function FarmerSidebar({ onNavigate, _isMobile = false }) {
  const { location, farmLocations } = useLocation();
  const { logout } = useAuth();

  const isLocationVerified = Boolean(location?.confirmed || location?.latitude);

  const navLinks = [
    { name: 'Dashboard', path: '/farmer/dashboard', icon: LayoutDashboard },
    { name: 'My Products', path: '/farmer/products', icon: Package },
    { name: 'Add Product', path: '/farmer/add-product', icon: PlusCircle, badge: 'New' },
    { name: 'Incoming Orders', path: '/farmer/orders', icon: ShoppingBag, badge: '6' },
    { name: 'Sales & Earnings', path: '/farmer/earnings', icon: IndianRupee },
    { name: 'Farm Locations', path: '/farmer/locations', icon: MapPin, badge: `${farmLocations?.length || 0}` },
    { name: 'Profile & Identity', path: '/farmer/profile', icon: UserCheck }
  ];

  return (
    <aside className="w-full h-full flex flex-col justify-between bg-slate-900 text-slate-300 border-r border-slate-800 p-5 select-none">
      
      {/* Top Brand & Portal Badge */}
      <div className="space-y-6">
        <div>
          <Logo variant="light" size="md" />
          <div className="mt-3 flex items-center justify-between px-3 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-800/60 text-emerald-300 text-xs font-bold">
            <span className="flex items-center gap-1.5">
              <span>🌾</span>
              <span>Farmer Operations Portal</span>
            </span>
            <span className="text-[9px] font-mono uppercase px-1.5 py-0.2 rounded bg-emerald-900 text-emerald-200">
              Demo
            </span>
          </div>
        </div>

        {/* Live GPS Verification Status Banner */}
        <div className={`p-3 rounded-2xl border text-xs space-y-1 transition-all ${
          isLocationVerified
            ? 'bg-emerald-950/40 border-emerald-800/80 text-emerald-300'
            : 'bg-amber-950/40 border-amber-800/80 text-amber-300'
        }`}>
          <div className="flex items-center justify-between font-bold">
            <span className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5" />
              <span>Farm Location</span>
            </span>
            <span className="text-[10px]">
              {isLocationVerified ? (
                <span className="flex items-center gap-1 text-emerald-400">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Verified</span>
                </span>
              ) : (
                <span className="flex items-center gap-1 text-amber-400">
                  <AlertCircle className="w-3 h-3" />
                  <span>Not Configured</span>
                </span>
              )}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 truncate">
            {location?.approximateLocation || location?.formattedAddress || 'Tap profile to set GPS'}
          </p>
        </div>

        {/* Navigation Items */}
        <nav className="space-y-1">
          {navLinks.map((link) => {
            const Icon = link.icon;
            return (
              <NavLink
                key={link.path}
                to={link.path}
                onClick={onNavigate}
                className={({ isActive }) => `
                  flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold transition-all duration-150
                  ${isActive 
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/30 font-bold' 
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/70'
                  }
                `}
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  <span>{link.name}</span>
                </div>
                {link.badge && (
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-900/80 text-emerald-300 border border-emerald-700/60">
                    {link.badge}
                  </span>
                )}
              </NavLink>
            );
          })}
        </nav>
      </div>

      {/* Bottom Actions */}
      <div className="pt-6 border-t border-slate-800 space-y-3">
        <Link
          to="/marketplace"
          onClick={onNavigate}
          className="flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-emerald-400 transition-colors px-2 py-1.5 rounded-xl hover:bg-slate-800/60"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Marketplace</span>
        </Link>

        <button
          type="button"
          onClick={() => {
            logout();
            if (onNavigate) onNavigate();
          }}
          className="w-full flex items-center gap-2 text-xs font-semibold text-rose-400 hover:text-rose-300 transition-colors px-2 py-1.5 rounded-xl hover:bg-rose-950/40 cursor-pointer text-left"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Logout Portal</span>
        </button>

        <div className="p-3 rounded-2xl bg-slate-800/60 border border-slate-700/60 text-[11px] text-slate-400 space-y-1">
          <div className="flex items-center gap-1 text-amber-400 font-bold">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Green Valley FPO</span>
          </div>
          <p className="text-[10px] text-slate-400">
            Smart India Hackathon Prototype Demo Account
          </p>
        </div>
      </div>

    </aside>
  );
}
