import React from 'react';
import {
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Area,
  AreaChart
} from 'recharts';

const MONTHLY_EARNINGS = [
  { month: 'Oct', earnings: 28500 },
  { month: 'Nov', earnings: 34200 },
  { month: 'Dec', earnings: 38900 },
  { month: 'Jan', earnings: 41200 },
  { month: 'Feb', earnings: 44500 },
  { month: 'Mar', earnings: 48500 }
];

export default function EarningsChart({ data = MONTHLY_EARNINGS }) {
  return (
    <div className="w-full h-64 sm:h-72">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
          <defs>
            <linearGradient id="earningsGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#10B981" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
          <XAxis 
            dataKey="month" 
            axisLine={false} 
            tickLine={false} 
            tick={{ fill: '#64748b', fontSize: 12, fontWeight: 600 }} 
          />
          <YAxis 
            axisLine={false} 
            tickLine={false} 
            tick={{ fill: '#64748b', fontSize: 11 }}
            tickFormatter={(val) => `₹${val / 1000}k`}
          />
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const item = payload[0].payload;
                return (
                  <div className="bg-slate-900 text-white px-3.5 py-2 rounded-xl shadow-xl border border-slate-800 text-xs space-y-1">
                    <p className="font-bold text-emerald-400">{item.month} Direct Payout</p>
                    <p className="text-base font-black">₹{item.earnings.toLocaleString('en-IN')}</p>
                    <p className="text-[10px] text-emerald-300 font-mono">100% Settled via UPI</p>
                  </div>
                );
              }
              return null;
            }}
          />
          <Area 
            type="monotone" 
            dataKey="earnings" 
            stroke="#059669" 
            strokeWidth={3} 
            fillOpacity={1} 
            fill="url(#earningsGradient)" 
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
