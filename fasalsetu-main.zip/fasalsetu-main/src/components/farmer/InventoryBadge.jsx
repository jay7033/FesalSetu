import React from 'react';

export default function InventoryBadge({ quantity = 0, unit = 'kg', showQuantity = true }) {
  const qty = Number(quantity);

  let status = 'Healthy stock';
  let badgeClass = 'bg-emerald-50 text-emerald-800 border-emerald-200/80';
  let dotClass = 'bg-emerald-500';

  if (qty <= 0) {
    status = 'Out of stock';
    badgeClass = 'bg-red-50 text-red-800 border-red-200';
    dotClass = 'bg-red-500';
  } else if (qty < 50) {
    status = 'Low stock';
    badgeClass = 'bg-amber-50 text-amber-800 border-amber-200';
    dotClass = 'bg-amber-500 animate-pulse';
  } else if (qty <= 100) {
    status = 'Medium stock';
    badgeClass = 'bg-blue-50 text-blue-800 border-blue-200';
    dotClass = 'bg-blue-500';
  }

  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${badgeClass}`}>
      <span className={`w-2 h-2 rounded-full ${dotClass}`} />
      <span>{status}</span>
      {showQuantity && (
        <span className="text-[10px] opacity-75 font-mono">
          ({qty} {unit})
        </span>
      )}
    </span>
  );
}
