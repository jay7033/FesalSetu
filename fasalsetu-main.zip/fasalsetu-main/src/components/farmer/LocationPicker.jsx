import React, { useState } from 'react';
import { 
  Compass, 
  Check, 
  CheckCircle2, 
  RefreshCw, 
  Edit3, 
  X,
  Building2,
  Lock
} from 'lucide-react';
import FarmMap from '../FarmMap';
import LocationPermission from './LocationPermission';
import { useLocation } from '../../context/LocationContext';
import { INDIAN_STATES } from '../../data/demoData';

export default function LocationPicker({
  onLocationConfirmed,
  initialLocation = null,
  title = '📍 Set Your Farm Location',
  subtitle = 'Detect live GPS coordinates or enter manual farm address.'
}) {
  const { 
    requestCurrentLocation, 
    setManualLocation, 
    loading, 
    error 
  } = useLocation();

  const [detectedLoc, setDetectedLoc] = useState(initialLocation);
  const [manualModalOpen, setManualModalOpen] = useState(false);
  const [manualForm, setManualForm] = useState({
    name: '',
    state: 'Uttar Pradesh',
    district: '',
    city: '',
    village: '',
    pincode: '',
    country: 'India'
  });

  const handleRequestGPS = async () => {
    try {
      const loc = await requestCurrentLocation();
      setDetectedLoc(loc);
    } catch {
      // error is handled inside context
    }
  };

  const handleManualSubmit = (e) => {
    e.preventDefault();
    if (!manualForm.state || !manualForm.district) return;

    const loc = setManualLocation({
      ...manualForm,
      name: manualForm.name || `${manualForm.city || manualForm.district} Farm Location`
    });

    setDetectedLoc(loc);
    setManualModalOpen(false);
  };

  const handleConfirm = () => {
    if (!detectedLoc) return;
    if (onLocationConfirmed) {
      onLocationConfirmed(detectedLoc);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* State A: Location not detected yet */}
      {!detectedLoc && (
        <LocationPermission
          title={title}
          subtitle={subtitle}
          onRequestLocation={handleRequestGPS}
          onManualSelect={() => setManualModalOpen(true)}
          loading={loading}
          error={error}
        />
      )}

      {/* State B: Location Detected & Ready for Visual Verification */}
      {detectedLoc && (
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm overflow-hidden space-y-6 p-6 sm:p-8 animate-in fade-in duration-300">
          
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                <CheckCircle2 className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
                  ✓ Location Detected
                </span>
                <h3 className="text-lg font-bold text-slate-900 font-display">
                  {detectedLoc.name || 'Detected Farm Location'}
                </h3>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleRequestGPS}
                disabled={loading}
                className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 border border-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                <span>DETECT AGAIN</span>
              </button>

              <button
                type="button"
                onClick={() => setManualModalOpen(true)}
                className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 border border-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>EDIT MANUALLY</span>
              </button>
            </div>
          </div>

          {/* Interactive MapLibre Preview */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-semibold flex items-center gap-1">
                <Compass className="w-3.5 h-3.5 text-emerald-600" />
                <span>Visual Farm Map Verification</span>
              </span>
              <span className="text-[11px] font-mono text-emerald-700 font-medium">
                {detectedLoc.latitude?.toFixed(4)}°N, {detectedLoc.longitude?.toFixed(4)}°E (±{detectedLoc.accuracy || 25}m)
              </span>
            </div>

            <div className="h-64 sm:h-72 w-full rounded-2xl overflow-hidden border border-slate-200/90 relative shadow-inner">
              <FarmMap
                latitude={detectedLoc.latitude}
                longitude={detectedLoc.longitude}
                accuracy={detectedLoc.accuracy}
                label={detectedLoc.name || 'Your Farm Location'}
                className="w-full h-full"
                zoom={14}
              />
            </div>
          </div>

          {/* Reverse-geocoded Address Breakdown */}
          <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200/80 space-y-4">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
              Approximate Location Details
            </span>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              <div className="p-3 bg-white rounded-xl border border-slate-200/60">
                <p className="text-[10px] text-slate-400 font-semibold uppercase">Village / Locality</p>
                <p className="text-xs font-bold text-slate-900 truncate mt-0.5">
                  {detectedLoc.village || detectedLoc.locality || '—'}
                </p>
              </div>

              <div className="p-3 bg-white rounded-xl border border-slate-200/60">
                <p className="text-[10px] text-slate-400 font-semibold uppercase">City / Town</p>
                <p className="text-xs font-bold text-slate-900 truncate mt-0.5">
                  {detectedLoc.city || '—'}
                </p>
              </div>

              <div className="p-3 bg-white rounded-xl border border-slate-200/60">
                <p className="text-[10px] text-slate-400 font-semibold uppercase">District</p>
                <p className="text-xs font-bold text-slate-900 truncate mt-0.5">
                  {detectedLoc.district || '—'}
                </p>
              </div>

              <div className="p-3 bg-white rounded-xl border border-slate-200/60">
                <p className="text-[10px] text-slate-400 font-semibold uppercase">State</p>
                <p className="text-xs font-bold text-slate-900 truncate mt-0.5">
                  {detectedLoc.state || 'India'}
                </p>
              </div>

              <div className="p-3 bg-white rounded-xl border border-slate-200/60">
                <p className="text-[10px] text-slate-400 font-semibold uppercase">Pincode</p>
                <p className="text-xs font-bold text-slate-900 truncate mt-0.5">
                  {detectedLoc.pincode || '—'}
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 font-medium pt-1">
              <strong>Formatted Address:</strong> {detectedLoc.formattedAddress || 'Standard farm gate origin'}
            </p>
          </div>

          {/* Privacy Note */}
          <div className="flex items-center gap-2 text-xs text-slate-500 bg-emerald-50/50 p-3 rounded-xl border border-emerald-100">
            <Lock className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span>
              Public marketplace cards will show approximate location: <strong>&quot;{detectedLoc.approximateLocation || `Near ${detectedLoc.city}, ${detectedLoc.state}`}&quot;</strong>. Precise GPS coordinates are kept private.
            </span>
          </div>

          {/* Confirm Button */}
          <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
            <button
              type="button"
              onClick={handleConfirm}
              className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-sm font-bold shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>CONFIRM FARM LOCATION</span>
            </button>
          </div>

        </div>
      )}

      {/* Manual Location Fallback Modal */}
      {manualModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="relative bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-6">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900 font-display">
                    Select Location Manually
                  </h3>
                  <p className="text-xs text-slate-500">
                    Use when GPS is unavailable or denied by browser.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setManualModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleManualSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Farm / Plot Name (Optional)
                </label>
                <input
                  type="text"
                  value={manualForm.name}
                  onChange={(e) => setManualForm({ ...manualForm, name: e.target.value })}
                  placeholder="e.g. East Valley Harvest Plot"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    State *
                  </label>
                  <select
                    value={manualForm.state}
                    onChange={(e) => setManualForm({ ...manualForm, state: e.target.value })}
                    required
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 font-medium bg-white"
                  >
                    {INDIAN_STATES.filter(s => s !== 'All').map((st) => (
                      <option key={st} value={st}>{st}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    District *
                  </label>
                  <input
                    type="text"
                    value={manualForm.district}
                    onChange={(e) => setManualForm({ ...manualForm, district: e.target.value })}
                    placeholder="e.g. Gautam Buddha Nagar"
                    required
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    City / Town / Tehsil
                  </label>
                  <input
                    type="text"
                    value={manualForm.city}
                    onChange={(e) => setManualForm({ ...manualForm, city: e.target.value })}
                    placeholder="e.g. Greater Noida"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 font-medium"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Village / Locality
                  </label>
                  <input
                    type="text"
                    value={manualForm.village}
                    onChange={(e) => setManualForm({ ...manualForm, village: e.target.value })}
                    placeholder="e.g. Dankaur"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Pincode
                  </label>
                  <input
                    type="text"
                    value={manualForm.pincode}
                    onChange={(e) => setManualForm({ ...manualForm, pincode: e.target.value })}
                    placeholder="e.g. 203201"
                    maxLength={6}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 font-medium"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Country
                  </label>
                  <input
                    type="text"
                    value={manualForm.country}
                    readOnly
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-100 text-slate-600 font-medium cursor-not-allowed"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setManualModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-xs cursor-pointer"
                >
                  Save Manual Location
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
}
