import React, { useState, useEffect } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import {
  Menu,
  X,
  ShoppingBag,
  Workflow,
  Sparkles,
  Truck,
  LogIn,
  LogOut,
  ArrowRight,
  MapPin,
  Tractor,
  Building2,
  UserCheck,
  Navigation,
  ShieldCheck
} from 'lucide-react';
import Logo from './Logo';
import Button from './Button';
import NotificationCenter from './dashboard/NotificationCenter';
import ConnectionStatusIndicator from './ConnectionStatusIndicator';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { totalUniqueItems } = useCart();
  const { isAuthenticated, user, role, logout, getDashboardPath } = useAuth();
  const navigate = useNavigate();

  const closeMobileMenu = () => setMobileMenuOpen(false);

  // Track scroll for styling
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLogout = () => {
    logout();
    closeMobileMenu();
    navigate('/login');
  };

  // Public Nav Links (Home accessed via Logo)
  const navLinks = [
    { name: 'How It Works', path: '/how-it-works', icon: Workflow },
    { name: 'Marketplace', path: '/marketplace', icon: ShoppingBag, badge: 'Direct' },
    { name: 'AI Insights', path: '/ai-insights', icon: Sparkles, badge: 'Predict' },
    { name: 'Logistics', path: '/logistics', icon: Truck, badge: 'EV' }
  ];

  const getPortalIcon = () => {
    switch (role) {
      case 'farmer':
        return Tractor;
      case 'fpo':
        return Building2;
      case 'bulk_buyer':
        return Truck;
      case 'logistics_head':
        return ShieldCheck;
      case 'delivery_assigner':
        return Navigation;
      case 'delivery_boy':
        return Truck;
      default:
        return ShoppingBag;
    }
  };

  const PortalIcon = getPortalIcon();

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${isScrolled
        ? 'bg-white/95 backdrop-blur-md shadow-sm border-b border-slate-200/80 py-3'
        : 'bg-white/85 backdrop-blur-md border-b border-slate-200/60 py-4'
        }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">

          {/* Logo */}
          <div className="flex items-center gap-4">
            <Logo size="md" />

            {/* Region Tag */}
            <div className="hidden xl:flex items-center gap-1 px-2 py-1 rounded-full bg-emerald-50/90 border border-emerald-200 text-[8px] font-semibold text-emerald-800">
              <MapPin className="w-2 h-2 text-emerald-600" />
              <span>Pan India</span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <NavLink
                  key={link.path}
                  to={link.path}
                  className={({ isActive }) => `
                    relative px-3.5 py-2 rounded-xl text-sm font-semibold transition-all duration-200 flex items-center gap-1.5
                    ${isActive
                      ? 'text-emerald-700 bg-emerald-50/90 shadow-xs border border-emerald-200/60'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
                    }
                  `}
                >
                  <Icon className="w-4 h-4 opacity-75" />
                  <span>{link.name}</span>
                  {link.badge && (
                    <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200/60">
                      {link.badge}
                    </span>
                  )}
                </NavLink>
              );
            })}
          </nav>

          {/* Right CTAs (Desktop) */}
          <div className="hidden md:flex items-center gap-3">
            {/* Live/Demo Connection Indicator */}
            <ConnectionStatusIndicator />

            {/* Cart Icon */}
            <Link
              to="/cart"
              className="relative p-2.5 rounded-xl text-slate-700 hover:text-emerald-700 hover:bg-slate-100 transition-colors flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-emerald-500"
              aria-label="View shopping cart"
            >
              <ShoppingBag className="w-5 h-5" />
              {totalUniqueItems > 0 && (
                <span className="absolute -top-1 -right-1 px-1.5 py-0.2 min-w-[18px] h-[18px] rounded-full bg-emerald-600 text-white text-[10px] font-black flex items-center justify-center shadow-xs animate-in zoom-in-50">
                  {totalUniqueItems}
                </span>
              )}
            </Link>

            {/* Authenticated State vs Logged-Out State */}
            {isAuthenticated ? (
              <div className="flex items-center gap-2">
                <NotificationCenter />
                <Button
                  to={getDashboardPath()}
                  variant="primary"
                  size="sm"
                  leftIcon={PortalIcon}
                >
                  My Portal
                </Button>

                <button
                  type="button"
                  onClick={handleLogout}
                  className="p-2 rounded-xl text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                  title={`Logout (${user?.name || role})`}
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Button
                  to="/login"
                  variant="ghost"
                  size="sm"
                  leftIcon={LogIn}
                >
                  Login
                </Button>

                <Button
                  to="/login"
                  variant="primary"
                  size="sm"
                  rightIcon={ArrowRight}
                >
                  Get Started
                </Button>
              </div>
            )}
          </div>

          {/* Mobile Actions (Cart + Login/Portal + Toggle) */}
          <div className="flex md:hidden items-center gap-2">
            <Link
              to="/cart"
              onClick={closeMobileMenu}
              className="relative p-2 rounded-lg text-slate-700 hover:bg-slate-100"
              aria-label="View shopping cart"
            >
              <ShoppingBag className="w-5 h-5 text-emerald-700" />
              {totalUniqueItems > 0 && (
                <span className="absolute -top-1 -right-1 px-1.5 py-0.2 min-w-[16px] h-[16px] rounded-full bg-emerald-600 text-white text-[9px] font-bold flex items-center justify-center">
                  {totalUniqueItems}
                </span>
              )}
            </Link>

            {isAuthenticated ? (
              <Link
                to={getDashboardPath()}
                onClick={closeMobileMenu}
                className="text-xs font-bold text-emerald-800 px-2.5 py-1.5 rounded-lg bg-emerald-100 border border-emerald-300 flex items-center gap-1"
              >
                <UserCheck className="w-3.5 h-3.5 text-emerald-700" />
                <span>My Portal</span>
              </Link>
            ) : (
              <Link
                to="/login"
                onClick={closeMobileMenu}
                className="text-xs font-semibold text-emerald-700 px-2.5 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200"
              >
                Login
              </Link>
            )}

            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl text-slate-700 hover:text-slate-900 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-colors"
              aria-expanded={mobileMenuOpen}
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-slate-200 bg-white/98 backdrop-blur-xl shadow-xl transition-all duration-300 animate-in fade-in slide-in-from-top-4">
          <div className="px-4 pt-3 pb-6 space-y-2">

            {/* Tag banner & Connection status */}
            <div className="flex items-center justify-between gap-2 px-3 py-2 rounded-lg bg-emerald-50 text-xs text-emerald-800 font-medium border border-emerald-200/70 mb-3">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                <span>Pan India</span>
              </div>
              <ConnectionStatusIndicator />
            </div>

            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <NavLink
                  key={link.path}
                  to={link.path}
                  onClick={closeMobileMenu}
                  className={({ isActive }) => `
                    flex items-center justify-between px-3.5 py-3 rounded-xl text-base font-semibold transition-colors
                    ${isActive
                      ? 'text-emerald-700 bg-emerald-50 border border-emerald-200'
                      : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
                    }
                  `}
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-slate-100 text-slate-700">
                      <Icon className="w-4 h-4" />
                    </div>
                    <span>{link.name}</span>
                  </div>
                  {link.badge && (
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                      {link.badge}
                    </span>
                  )}
                </NavLink>
              );
            })}

            <div className="pt-4 mt-4 border-t border-slate-100 space-y-2.5">
              {isAuthenticated ? (
                <>
                  <Button
                    to={getDashboardPath()}
                    onClick={closeMobileMenu}
                    variant="primary"
                    size="md"
                    className="w-full justify-center"
                    leftIcon={PortalIcon}
                  >
                    Open My Portal ({role})
                  </Button>
                  <button
                    type="button"
                    onClick={handleLogout}
                    className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-rose-600 hover:bg-rose-50 border border-rose-200 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Logout Session</span>
                  </button>
                </>
              ) : (
                <>
                  <Button
                    to="/login"
                    onClick={closeMobileMenu}
                    variant="outline"
                    size="md"
                    className="w-full justify-center"
                    leftIcon={LogIn}
                  >
                    Login to Portal
                  </Button>
                  <Button
                    to="/register"
                    onClick={closeMobileMenu}
                    variant="primary"
                    size="md"
                    className="w-full justify-center"
                    rightIcon={ArrowRight}
                  >
                    Create Account
                  </Button>
                </>
              )}
            </div>

          </div>
        </div>
      )}
    </header>
  );
}
