import React from 'react';
import { Link } from 'react-router-dom';

/**
 * Reusable Button component for FasalSetu
 * Supports React Router Link navigation or native button click
 */
export default function Button({
  children,
  to,
  variant = 'primary',
  size = 'md',
  className = '',
  leftIcon: LeftIcon,
  rightIcon: RightIcon,
  disabled = false,
  type = 'button',
  onClick,
  ...props
}) {
  const baseStyles = 'inline-flex items-center justify-center font-medium rounded-xl transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:opacity-60 disabled:cursor-not-allowed select-none active:scale-[0.98]';

  const sizeStyles = {
    sm: 'text-xs px-3.5 py-2 gap-1.5 font-semibold',
    md: 'text-sm px-5 py-2.5 gap-2 font-semibold',
    lg: 'text-base px-6 py-3.5 gap-2.5 font-bold shadow-sm'
  };

  const variantStyles = {
    primary: 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-700/20 hover:shadow-lg hover:shadow-emerald-700/30 focus-visible:ring-emerald-500 border border-emerald-500/50 hover:-translate-y-0.5',
    secondary: 'bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold shadow-md shadow-amber-500/20 hover:shadow-lg hover:shadow-amber-500/30 focus-visible:ring-amber-400 border border-amber-400/60 hover:-translate-y-0.5',
    outline: 'bg-white/90 hover:bg-slate-100 text-slate-700 hover:text-slate-900 border border-slate-300/90 shadow-sm focus-visible:ring-emerald-500 hover:-translate-y-0.5',
    outlineEmerald: 'bg-emerald-50/60 hover:bg-emerald-100/80 text-emerald-800 border border-emerald-300 shadow-sm focus-visible:ring-emerald-500 hover:-translate-y-0.5',
    ghost: 'text-slate-600 hover:text-slate-950 hover:bg-slate-100/80 focus-visible:ring-emerald-500',
    dark: 'bg-slate-900 hover:bg-slate-800 text-white shadow-md shadow-slate-950/20 focus-visible:ring-slate-700 border border-slate-800 hover:-translate-y-0.5'
  };

  const selectedSize = sizeStyles[size] || sizeStyles.md;
  const selectedVariant = variantStyles[variant] || variantStyles.primary;
  const combinedClasses = `${baseStyles} ${selectedSize} ${selectedVariant} ${className}`;

  const innerContent = (
    <>
      {LeftIcon && <LeftIcon className="w-4 h-4 flex-shrink-0" />}
      <span>{children}</span>
      {RightIcon && <RightIcon className="w-4 h-4 flex-shrink-0 transition-transform duration-200 group-hover:translate-x-0.5" />}
    </>
  );

  if (to && !disabled) {
    return (
      <Link to={to} className={`group ${combinedClasses}`} {...props}>
        {innerContent}
      </Link>
    );
  }

  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className={`group ${combinedClasses}`}
      {...props}
    >
      {innerContent}
    </button>
  );
}
