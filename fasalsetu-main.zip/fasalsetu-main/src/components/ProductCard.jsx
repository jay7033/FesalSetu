import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Clock, 
  ShoppingBag, 
  Check, 
  Sparkles, 
  ArrowRight,
  MapPin,
  Scale
} from 'lucide-react';


import ProductImage from './ProductImage';
import { useCart } from '../context/CartContext';
import { calculateDistance, formatDistance } from '../utils/distance';

export default function ProductCard({ product, buyerLocation = null }) {
  const { addItem } = useCart();
  const [isAdded, setIsAdded] = useState(false);

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    // Default add 5 units for kg items or 1 unit for others
    const defaultQty = product.unit === 'kg' ? 5 : 1;
    addItem(product, defaultQty);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 1800);
  };

  const isLowStock = product.quantityAvailable <= 50;

  // Calculate live distance from buyer if coordinates are available
  const computedDistanceKm = 
    buyerLocation && product.latitude && product.longitude
      ? calculateDistance(buyerLocation.latitude, buyerLocation.longitude, product.latitude, product.longitude)
      : null;

  const displayDistance = computedDistanceKm !== null 
    ? formatDistance(computedDistanceKm)
    : product.distance || 'Local Farm Gate';

  const displayLocation = product.approximateLocation || `Near ${product.location}, ${product.state || 'India'}`;


  return (
    <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xs hover:shadow-xl hover:border-emerald-300 transition-all duration-300 flex flex-col overflow-hidden group">
      
      {/* Image Container with Badges */}
      <div className="relative aspect-4/3 w-full overflow-hidden bg-slate-100">
        <ProductImage
          src={product.image}
          alt={product.name}
          category={product.category}
          containerClassName="w-full h-full"
          className="group-hover:scale-105 transition-transform duration-500"
        />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
          <div className="flex flex-wrap gap-1">
            {product.organic && (
              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-600 text-white shadow-sm flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>Organic</span>
              </span>
            )}
            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-white/95 text-slate-800 backdrop-blur-md shadow-sm border border-slate-200/60">
              {product.quality}
            </span>
            {product.isDemo ? (
              <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-slate-900/70 text-amber-300 backdrop-blur-md border border-amber-400/30">
                Sample Listing
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-800/80 text-emerald-200 backdrop-blur-md border border-emerald-400/40 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                Live Farmer
              </span>
            )}
          </div>

          {isLowStock && (
            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-500 text-white shadow-sm">
              Low Stock
            </span>
          )}
        </div>

        {/* Harvest Time Pill at Bottom of Image */}
        <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-[11px] font-medium text-white px-2.5 py-1 rounded-xl bg-slate-950/75 backdrop-blur-md">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3 text-emerald-400" />
            <span>{product.harvestDate}</span>
          </span>
          <span className="text-[10px] font-mono text-emerald-300 font-bold">
            {displayDistance}
          </span>
        </div>
      </div>

      {/* Card Body */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        
        {/* Title and Farmer Details */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500">
            <span className="flex items-center gap-1 text-emerald-700 truncate max-w-[70%]" title={displayLocation}>
              <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
              <span className="truncate">{displayLocation}</span>
            </span>
            <span className="text-slate-400 font-normal flex-shrink-0">
              {product.category}
            </span>
          </div>


          <Link to={`/product/${product.id}`} className="block group-hover:text-emerald-700 transition-colors">
            <h3 className="text-base font-bold text-slate-900 font-display line-clamp-1 leading-snug">
              {product.name}
            </h3>
          </Link>

          <p className="text-xs text-slate-600 flex items-center gap-1">
            <span className="font-semibold text-slate-800">{product.farmer}</span>
            <span className="text-slate-400">•</span>
            <span className="text-[11px] text-slate-500">{product.farmerType}</span>
          </p>
        </div>

        {/* Pricing & Stock Details */}
        <div className="pt-3 border-t border-slate-100 flex items-baseline justify-between">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-black text-slate-950 font-display">
                ₹{product.price}
              </span>
              <span className="text-xs font-semibold text-slate-500">
                /{product.unit}
              </span>
            </div>
            {product.typicalRetailPrice && (
              <p className="text-[11px] text-slate-400 line-through">
                Mandi / Retail: ₹{product.typicalRetailPrice}/{product.unit}
              </p>
            )}
          </div>

          <div className="text-right">
            <span className="text-[11px] font-bold text-slate-700 flex items-center justify-end gap-1">
              <Scale className="w-3 h-3 text-slate-400" />
              <span>{product.quantityAvailable} {product.unit}</span>
            </span>
            <p className="text-[10px] text-emerald-600 font-medium">
              Direct Farm Gate
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-1 grid grid-cols-2 gap-2">
          <Link
            to={`/product/${product.id}`}
            className="text-xs font-semibold py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200/80 text-slate-800 transition-colors text-center flex items-center justify-center gap-1"
          >
            <span>Details</span>
            <ArrowRight className="w-3 h-3 text-slate-500" />
          </Link>

          <button
            type="button"
            onClick={handleAddToCart}
            className={`text-xs font-bold py-2.5 px-3 rounded-xl transition-all duration-200 flex items-center justify-center gap-1.5 shadow-xs ${
              isAdded
                ? 'bg-emerald-700 text-white'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white hover:shadow-md'
            }`}
          >
            {isAdded ? (
              <>
                <Check className="w-3.5 h-3.5 text-white" />
                <span>Added!</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Add to Cart</span>
              </>
            )}
          </button>
        </div>

      </div>

    </div>
  );
}
