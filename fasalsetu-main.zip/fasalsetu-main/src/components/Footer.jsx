import React from 'react';
import { Link } from 'react-router-dom';
import { 
  MapPin, 
  ArrowUpRight, 
  ShieldCheck
} from 'lucide-react';
import Logo from './Logo';


export default function Footer() {
  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-800/80 pt-16 pb-12 relative overflow-hidden">
      {/* Subtle background glow */}
      <div className="absolute top-0 left-1/3 w-96 h-96 bg-emerald-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        
        {/* Top Grid: 6 structured columns */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 pb-12 border-b border-slate-800/80">
          
          {/* Brand Col (2 cols on lg) */}
          <div className="col-span-2 space-y-4">
            <Logo variant="light" size="lg" />
            
            <div className="space-y-1">
              <p className="text-emerald-400 font-bold text-sm tracking-wide">
                "Connecting Farms. Empowering Farmers."
              </p>
              <p className="text-slate-400 text-xs font-serif italic">
                "फसल से बाज़ार तक, सीधे और स्मार्ट तरीके से।"
              </p>
            </div>

            <p className="text-slate-400 text-xs leading-relaxed max-w-sm pt-1">
              FasalSetu is India's digital farm-to-market network connecting farmers, FPOs, consumers and bulk buyers through AI demand matching and smart logistics.
            </p>

            {/* Pan-India Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-950/60 border border-emerald-800/60 text-emerald-300 text-xs font-semibold">
              <MapPin className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
              <span>Pan-India Agricultural Network Model</span>
            </div>
          </div>

          {/* Col 2: Platform */}
          <div className="space-y-3">
            <h3 className="text-white font-bold text-xs uppercase tracking-wider font-display">
              Platform
            </h3>
            <ul className="space-y-2 text-xs">
              <li>
                <Link to="/marketplace" className="text-slate-400 hover:text-emerald-400 transition-colors inline-flex items-center gap-1 group">
                  <span>Marketplace</span>
                  <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-emerald-400" />
                </Link>
              </li>
              <li>
                <Link to="/how-it-works" className="text-slate-400 hover:text-emerald-400 transition-colors inline-flex items-center gap-1 group">
                  <span>How It Works</span>
                  <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-emerald-400" />
                </Link>
              </li>
              <li>
                <Link to="/ai-insights" className="text-slate-400 hover:text-emerald-400 transition-colors inline-flex items-center gap-1 group">
                  <span>AI Insights</span>
                  <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-emerald-400" />
                </Link>
              </li>
              <li>
                <Link to="/logistics" className="text-slate-400 hover:text-emerald-400 transition-colors inline-flex items-center gap-1 group">
                  <span>Smart Logistics</span>
                  <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-emerald-400" />
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 3: Solutions */}
          <div className="space-y-3">
            <h3 className="text-white font-bold text-xs uppercase tracking-wider font-display">
              Solutions
            </h3>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>Direct Farm-to-Fork</li>
              <li>FPO Aggregation Hubs</li>
              <li>B2B Institutional Supply</li>
              <li>Farm-Gate Fleet Dispatch</li>
              <li>Cold Chain Visibility</li>
            </ul>
          </div>

          {/* Col 4: For Farmers */}
          <div className="space-y-3">
            <h3 className="text-white font-bold text-xs uppercase tracking-wider font-display">
              For Farmers
            </h3>
            <ul className="space-y-2 text-xs">
              <li>
                <Link to="/login" className="text-slate-400 hover:text-emerald-400 transition-colors">
                  List Harvest
                </Link>
              </li>
              <li>
                <Link to="/login" className="text-slate-400 hover:text-emerald-400 transition-colors">
                  Farm Locations
                </Link>
              </li>
              <li>
                <Link to="/ai-insights" className="text-slate-400 hover:text-emerald-400 transition-colors">
                  Pricing Forecast
                </Link>
              </li>
              <li>
                <Link to="/how-it-works" className="text-slate-400 hover:text-emerald-400 transition-colors">
                  Escrow Payments
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 5: For Buyers & Resources */}
          <div className="space-y-3">
            <h3 className="text-white font-bold text-xs uppercase tracking-wider font-display">
              For Buyers
            </h3>
            <ul className="space-y-2 text-xs">
              <li>
                <Link to="/marketplace" className="text-slate-400 hover:text-emerald-400 transition-colors">
                  Fresh Farm Produce
                </Link>
              </li>
              <li>
                <Link to="/marketplace" className="text-slate-400 hover:text-emerald-400 transition-colors">
                  Bulk Procurement
                </Link>
              </li>
              <li>
                <Link to="/logistics" className="text-slate-400 hover:text-emerald-400 transition-colors">
                  Track Dispatches
                </Link>
              </li>
              <li>
                <div className="pt-2">
                  <div className="p-2 rounded-lg bg-emerald-950/40 border border-emerald-800/40 text-[10px] text-emerald-300 flex items-center gap-1.5 font-semibold">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Direct Farm Access</span>
                  </div>
                </div>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span>© {new Date().getFullYear()} FasalSetu. All rights reserved.</span>
            <span>•</span>
            <span className="text-emerald-400">Prototype Demo Version</span>
          </div>

          <div className="flex items-center gap-6">
            <Link to="/how-it-works" className="hover:text-slate-300 transition-colors">
              How It Works
            </Link>
            <Link to="/marketplace" className="hover:text-slate-300 transition-colors">
              Marketplace
            </Link>
            <Link to="/login" className="hover:text-slate-300 transition-colors">
              Farmer Login
            </Link>
          </div>
        </div>

      </div>
    </footer>
  );
}
