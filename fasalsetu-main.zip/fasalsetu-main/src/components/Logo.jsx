import React from 'react';
import { Link } from 'react-router-dom';

/**
 * FasalSetu Logo Component
 * Leaf/Crop + Bridge (Setu) + Tech Connection Concept
 * Pure SVG + Modern Typography
 */
export default function Logo({ 
  variant = 'default', 
  size = 'md', 
  showTagline = false,
  clickable = true 
}) {
  const isDark = variant === 'light'; // light text on dark backgrounds

  const sizeMap = {
    sm: {
      svg: 32,
      title: 'text-lg',
      tagline: 'text-[10px]',
      badge: 'text-[9px] px-1.5 py-0.5'
    },
    md: {
      svg: 40,
      title: 'text-2xl',
      tagline: 'text-xs',
      badge: 'text-[10px] px-2 py-0.5'
    },
    lg: {
      svg: 52,
      title: 'text-3xl',
      tagline: 'text-sm',
      badge: 'text-xs px-2.5 py-1'
    }
  };

  const currentSize = sizeMap[size] || sizeMap.md;

  const content = (
    <div className="flex items-center gap-3 group select-none">
      {/* SVG Emblem: Bridge (Setu) + Sprouting Leaf + Connection Nodes */}
      <div className="relative flex-shrink-0 transition-transform duration-300 group-hover:scale-105">
        <svg 
          width={currentSize.svg} 
          height={currentSize.svg} 
          viewBox="0 0 54 54" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
          className="drop-shadow-sm"
        >
          {/* Subtle tech background rounded frame */}
          <rect 
            x="1" 
            y="1" 
            width="52" 
            height="52" 
            rx="14" 
            className={isDark ? "fill-emerald-950/80 stroke-emerald-500/30" : "fill-emerald-900 stroke-emerald-700/40"} 
            strokeWidth="1.5"
          />

          {/* Connection grid / rays */}
          <line x1="12" y1="41" x2="42" y2="41" stroke="#34D399" strokeWidth="1" strokeOpacity="0.3" strokeDasharray="2 2" />

          {/* The Bridge (Setu) Arch: Spanning from Farm to City */}
          <path 
            d="M 9 40 C 18 28, 36 28, 45 40" 
            stroke="#FEF08A" 
            strokeWidth="3.5" 
            strokeLinecap="round"
          />

          {/* Pier supports under bridge */}
          <line x1="19" y1="35" x2="19" y2="41" stroke="#FEF08A" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.8" />
          <line x1="27" y1="33" x2="27" y2="41" stroke="#FEF08A" strokeWidth="2.5" strokeLinecap="round" strokeOpacity="0.9" />
          <line x1="35" y1="35" x2="35" y2="41" stroke="#FEF08A" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.8" />

          {/* Sprouting Crop / Leaf 1 (Left - Agriculture) */}
          <path 
            d="M 27 32 C 27 19, 15 16, 15 16 C 15 16 16 29, 27 32 Z" 
            fill="#10B981" 
            className="transition-all duration-300 group-hover:fill-emerald-400"
          />

          {/* Sprouting Crop / Leaf 2 (Right - Technology / Market growth) */}
          <path 
            d="M 27 32 C 27 16, 39 12, 39 12 C 39 12 40 27, 27 32 Z" 
            fill="#34D399" 
            className="transition-all duration-300 group-hover:fill-emerald-300"
          />

          {/* Central vein line */}
          <path 
            d="M 27 32 L 27 15" 
            stroke="#064E3B" 
            strokeWidth="1.2" 
            strokeLinecap="round"
          />

          {/* Tech Connection Hub Node: Golden sun / sensor dot */}
          <circle 
            cx="27" 
            cy="32" 
            r="3" 
            fill="#F59E0B" 
            stroke="#FFFBEB" 
            strokeWidth="1.5"
          />

          {/* Left origin point (Farm) */}
          <circle cx="10" cy="40" r="2" fill="#34D399" />
          {/* Right terminus point (Urban Market) */}
          <circle cx="44" cy="40" r="2" fill="#FBBF24" />
        </svg>

        {/* Ambient pulse glow behind logo */}
        <div className="absolute -inset-1 bg-emerald-500/20 rounded-full blur-md -z-10 group-hover:bg-emerald-500/35 transition-colors" />
      </div>

      {/* Brand Text */}
      <div className="flex flex-col">
        <div className="flex items-center gap-2">
          <span className={`font-extrabold tracking-tight font-display ${currentSize.title} ${isDark ? 'text-white' : 'text-slate-900'}`}>
            Fasal<span className="text-emerald-600 dark:text-emerald-400 bg-gradient-to-r from-emerald-600 to-teal-500 bg-clip-text text-transparent">Setu</span>
          </span>
          <span className={`inline-flex items-center font-semibold rounded-full uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-200/80 ${currentSize.badge}`}>
            AgriTech
          </span>
        </div>

        {showTagline && (
          <p className={`font-medium tracking-wide ${currentSize.tagline} ${isDark ? 'text-slate-300' : 'text-slate-500'}`}>
            Connecting Farms • Empowering Farmers
          </p>
        )}
      </div>
    </div>
  );

  if (clickable) {
    return (
      <Link to="/" className="inline-block focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded-lg">
        {content}
      </Link>
    );
  }

  return content;
}
