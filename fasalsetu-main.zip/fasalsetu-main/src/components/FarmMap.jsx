import React, { useEffect, useRef, useState } from 'react';
import * as maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { MapPin, Compass } from 'lucide-react';

export default function FarmMap({
  latitude,
  longitude,
  accuracy = 50,
  label = 'Farm Location',
  className = '',
  zoom = 13
}) {
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markerRef = useRef(null);
  const [mapError, setMapError] = useState(false);

  useEffect(() => {
    if (!latitude || !longitude || !mapContainerRef.current) return;

    try {
      // Free public tile style for OpenStreetMap / Demotiles
      const styleUrl = 
        import.meta.env.VITE_MAP_STYLE_URL || 
        'https://demotiles.maplibre.org/style.json';

      // Initialize map instance
      const map = new maplibregl.Map({
        container: mapContainerRef.current,
        style: styleUrl,
        center: [longitude, latitude],
        zoom: zoom,
        attributionControl: false
      });

      map.addControl(new maplibregl.NavigationControl({ showCompass: true }), 'top-right');

      map.on('load', () => {
        // Add custom HTML element for marker
        const el = document.createElement('div');
        el.className = 'farm-map-marker flex flex-col items-center cursor-pointer';
        el.innerHTML = `
          <div style="background-color: #047857; color: white; padding: 6px; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.3); border: 2px solid white; display: flex; align-items: center; justify-content: center;">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 2a8 8 0 0 0-8 8c0 5.4 7 11.5 7.7 12.1a1 1 0 0 0 1.4 0C13.8 21.5 21 15.4 21 10a8 8 0 0 0-8-8z"></path>
              <circle cx="12" cy="10" r="3"></circle>
            </svg>
          </div>
          <div style="background: rgba(15, 23, 42, 0.9); color: #34d399; font-size: 10px; font-weight: bold; padding: 2px 8px; border-radius: 6px; margin-top: 4px; white-space: nowrap; border: 1px solid rgba(52, 211, 153, 0.4);">
            ${label}
          </div>
        `;

        markerRef.current = new maplibregl.Marker({ element: el })
          .setLngLat([longitude, latitude])
          .addTo(map);
      });

      map.on('error', (e) => {
        console.warn('MapLibre tile error, falling back gracefully:', e);
        setMapError(true);
      });

      mapInstanceRef.current = map;

      return () => {
        map.remove();
      };
    } catch (err) {
      console.warn('MapLibre initialization fallback:', err);
      setTimeout(() => setMapError(true), 0);
    }
  }, [latitude, longitude, label, zoom]);

  // Update center & marker if lat/lon change dynamically
  useEffect(() => {
    if (mapInstanceRef.current && markerRef.current && latitude && longitude) {
      mapInstanceRef.current.flyTo({
        center: [longitude, latitude],
        zoom: zoom,
        essential: true
      });
      markerRef.current.setLngLat([longitude, latitude]);
    }
  }, [latitude, longitude, zoom]);

  if (!latitude || !longitude) {
    return (
      <div className={`rounded-2xl bg-slate-100 border border-slate-200 flex flex-col items-center justify-center p-8 text-center text-slate-400 ${className}`}>
        <Compass className="w-8 h-8 text-slate-300 mb-2 animate-pulse" />
        <p className="text-xs font-semibold">Coordinates not detected yet</p>
        <p className="text-[11px] text-slate-400 mt-0.5">Click 'Use My Current Location' to preview your farm on map</p>
      </div>
    );
  }

  return (
    <div className={`relative rounded-2xl overflow-hidden border border-slate-200/90 shadow-sm bg-slate-100 ${className}`}>
      {/* MapLibre DOM Node */}
      <div ref={mapContainerRef} className="w-full h-full min-h-[260px]" />

      {/* Fallback Graphic if WebGL or tiles are blocked */}
      {mapError && (
        <div className="absolute inset-0 bg-slate-900 text-white flex flex-col items-center justify-center p-6 text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-emerald-950 border border-emerald-500/50 flex items-center justify-center text-emerald-400">
            <MapPin className="w-6 h-6" />
          </div>
          <div className="space-y-0.5">
            <h4 className="text-sm font-bold">{label}</h4>
            <p className="text-xs text-emerald-400 font-mono">
              {latitude.toFixed(5)}° N, {longitude.toFixed(5)}° E
            </p>
            <p className="text-[11px] text-slate-400">
              GPS Verified • Accuracy: ~{accuracy}m radius
            </p>
          </div>
          <span className="text-[10px] text-slate-500 bg-slate-800 px-2 py-0.5 rounded">
            Coordinates locked & validated
          </span>
        </div>
      )}

      {/* Verification Badge Overlay */}
      <div className="absolute bottom-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-xl shadow-md border border-slate-200 text-xs flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping" />
        <span className="font-bold text-slate-800 font-mono">
          {latitude.toFixed(4)}°N, {longitude.toFixed(4)}°E
        </span>
        <span className="text-[10px] text-slate-400">
          (±{accuracy}m)
        </span>
      </div>
    </div>
  );
}
