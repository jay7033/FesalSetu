import React, { useState } from 'react';
import { Sprout, Apple, Wheat, Milk } from 'lucide-react';


export default function ProductImage({ 
  src, 
  alt = 'Farm Produce', 
  category = 'Vegetables', 
  className = '', 
  containerClassName = '' 
}) {
  const [imageFailed, setImageFailed] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  const getCategoryTheme = (cat) => {
    switch (cat?.toLowerCase()) {
      case 'fruits':
        return {
          bg: 'bg-amber-100',
          text: 'text-amber-800',
          border: 'border-amber-200',
          icon: Apple,
          label: 'Fresh Local Fruit'
        };
      case 'grains':
        return {
          bg: 'bg-amber-50',
          text: 'text-amber-700',
          border: 'border-amber-200',
          icon: Wheat,
          label: 'Direct Harvest Grain'
        };
      case 'pulses':
        return {
          bg: 'bg-orange-50',
          text: 'text-orange-700',
          border: 'border-orange-200',
          icon: Sprout,
          label: 'Farm Pulses & Legumes'
        };
      case 'dairy':
        return {
          bg: 'bg-teal-50',
          text: 'text-teal-700',
          border: 'border-teal-200',
          icon: Milk,
          label: 'Fresh Pure Dairy'
        };
      case 'vegetables':
      default:
        return {
          bg: 'bg-emerald-50',
          text: 'text-emerald-700',
          border: 'border-emerald-200',
          icon: Sprout,
          label: 'Farm Fresh Produce'
        };
    }
  };

  const theme = getCategoryTheme(category);
  const FallbackIcon = theme.icon;

  return (
    <div className={`relative overflow-hidden bg-slate-100 ${containerClassName}`}>
      {/* Fallback Vector Card (rendered underneath or on error) */}
      <div 
        className={`absolute inset-0 flex flex-col items-center justify-center p-4 text-center ${theme.bg} ${theme.text} transition-opacity duration-300 ${
          imageFailed || !isLoaded ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="w-12 h-12 rounded-2xl bg-white/80 border border-slate-200/60 shadow-xs flex items-center justify-center mb-2">
          <FallbackIcon className="w-6 h-6" />
        </div>
        <span className="text-xs font-bold tracking-tight line-clamp-1">{alt}</span>
        <span className="text-[10px] opacity-75 font-medium">{theme.label}</span>
      </div>

      {/* Main Image */}
      {!imageFailed && (
        <img
          src={src}
          alt={alt}
          loading="lazy"
          onLoad={() => setIsLoaded(true)}
          onError={() => setImageFailed(true)}
          className={`w-full h-full object-cover transition-all duration-300 ${
            isLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
          } ${className}`}
        />
      )}
    </div>
  );
}
