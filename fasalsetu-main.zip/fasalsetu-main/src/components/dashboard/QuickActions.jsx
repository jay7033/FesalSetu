import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export default function QuickActions({
  title = 'Quick Actions',
  subtitle = 'Frequently used portal workflows',
  actions = []
}) {
  return (
    <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
      <div>
        <h3 className="text-lg font-bold text-slate-900 font-display">{title}</h3>
        <p className="text-xs text-slate-500">{subtitle}</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {actions.map((action, idx) => {
          const Icon = action.icon;
          const content = (
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-emerald-300 hover:bg-emerald-50/40 transition-all flex flex-col justify-between h-full group">
              <div className="space-y-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${action.iconBg || 'bg-emerald-100 text-emerald-800'}`}>
                  {Icon && <Icon className="w-5 h-5" />}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900 group-hover:text-emerald-900">
                    {action.label}
                  </h4>
                  {action.description && (
                    <p className="text-[11px] text-slate-500 line-clamp-2 mt-0.5">
                      {action.description}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex items-center text-[10px] font-bold text-emerald-700 mt-3 pt-2 border-t border-slate-100 group-hover:translate-x-0.5 transition-transform">
                <span>Go</span>
                <ArrowRight className="w-3 h-3 ml-0.5" />
              </div>
            </div>
          );

          if (action.to) {
            return (
              <Link key={idx} to={action.to} className="block h-full">
                {content}
              </Link>
            );
          }

          return (
            <button
              key={idx}
              type="button"
              onClick={action.onClick}
              className="text-left w-full h-full cursor-pointer"
            >
              {content}
            </button>
          );
        })}
      </div>
    </div>
  );
}
