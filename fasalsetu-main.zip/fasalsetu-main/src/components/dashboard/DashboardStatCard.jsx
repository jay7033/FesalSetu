import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

const ACCENT_STYLES = {
  emerald: {
    bg: 'bg-emerald-50/80',
    iconBg: 'bg-emerald-100 text-emerald-700',
    border: 'border-emerald-100/60',
    trend: 'text-emerald-700 bg-emerald-50 border-emerald-200'
  },
  blue: {
    bg: 'bg-blue-50/80',
    iconBg: 'bg-blue-100 text-blue-700',
    border: 'border-blue-100/60',
    trend: 'text-blue-700 bg-blue-50 border-blue-200'
  },
  teal: {
    bg: 'bg-teal-50/80',
    iconBg: 'bg-teal-100 text-teal-700',
    border: 'border-teal-100/60',
    trend: 'text-teal-700 bg-teal-50 border-teal-200'
  },
  amber: {
    bg: 'bg-amber-50/80',
    iconBg: 'bg-amber-100 text-amber-700',
    border: 'border-amber-100/60',
    trend: 'text-amber-700 bg-amber-50 border-amber-200'
  },
  purple: {
    bg: 'bg-purple-50/80',
    iconBg: 'bg-purple-100 text-purple-700',
    border: 'border-purple-100/60',
    trend: 'text-purple-700 bg-purple-50 border-purple-200'
  },
  slate: {
    bg: 'bg-slate-50/80',
    iconBg: 'bg-slate-100 text-slate-700',
    border: 'border-slate-100/60',
    trend: 'text-slate-700 bg-slate-50 border-slate-200'
  }
};

export default function DashboardStatCard({
  title,
  value,
  subtext,
  change,
  trend = 'up',
  icon: Icon,
  accent = 'emerald',
  className = ''
}) {
  const styles = ACCENT_STYLES[accent] || ACCENT_STYLES.emerald;
  const isPositive = trend === 'up';

  return (
    <div
      className={`bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden flex flex-col justify-between gap-3 ${className}`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-1">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
            {title}
          </span>
          <div className="text-2xl sm:text-3xl font-black text-slate-950 font-display tracking-tight">
            {value}
          </div>
        </div>

        {Icon && (
          <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${styles.iconBg}`}>
            <Icon className="w-5 h-5" />
          </div>
        )}
      </div>

      <div className="flex items-center justify-between gap-2 text-xs pt-2 border-t border-slate-100/80">
        <span className="text-slate-500 truncate">{subtext}</span>

        {change && (
          <span
            className={`inline-flex items-center gap-1 font-bold text-[11px] px-2 py-0.5 rounded-full border flex-shrink-0 ${styles.trend}`}
          >
            {isPositive ? (
              <TrendingUp className="w-3 h-3" />
            ) : (
              <TrendingDown className="w-3 h-3" />
            )}
            <span>{change}</span>
          </span>
        )}
      </div>
    </div>
  );
}
