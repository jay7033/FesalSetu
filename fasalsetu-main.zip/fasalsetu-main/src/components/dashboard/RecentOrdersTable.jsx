import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import StatusBadge from './StatusBadge';

export default function RecentOrdersTable({
  orders = [],
  title = 'Recent Orders',
  subtitle = 'Live order tracking synchronized across portals',
  viewAllLink,
  counterpartyLabel = 'Buyer',
  onStatusChange,
  showActions = true,
  maxItems = 5
}) {
  const displayedOrders = orders.slice(0, maxItems);

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
      <div className="flex items-center justify-between pb-2 border-b border-slate-100">
        <div>
          <h3 className="text-lg font-bold text-slate-900 font-display">
            {title}
          </h3>
          <p className="text-xs text-slate-500">{subtitle}</p>
        </div>

        {viewAllLink && (
          <Link
            to={viewAllLink}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 hover:underline flex items-center gap-1"
          >
            <span>All ({orders.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        )}
      </div>

      {displayedOrders.length === 0 ? (
        <div className="py-8 text-center text-slate-500 text-xs">
          No orders logged yet.
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-100">
                <th className="pb-2.5 font-bold">Order ID</th>
                <th className="pb-2.5 font-bold">Produce</th>
                <th className="pb-2.5 font-bold">{counterpartyLabel}</th>
                <th className="pb-2.5 font-bold">Quantity</th>
                <th className="pb-2.5 font-bold">Amount</th>
                <th className="pb-2.5 font-bold">Status</th>
                <th className="pb-2.5 font-bold">Date</th>
                {showActions && <th className="pb-2.5 font-bold text-right">Action</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {displayedOrders.map((ord) => (
                <tr key={ord.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 font-mono font-bold text-emerald-800">
                    {ord.id}
                  </td>
                  <td className="py-3">
                    <p className="font-bold text-slate-900 truncate max-w-[160px]">
                      {ord.product || ord.items?.[0]?.name || 'Fresh Produce'}
                    </p>
                    <p className="text-[10px] text-slate-400">
                      {ord.paymentStatus || 'Escrow Secured'}
                    </p>
                  </td>
                  <td className="py-3 text-slate-600">
                    <p className="truncate max-w-[140px] font-medium text-slate-800">
                      {counterpartyLabel === 'Buyer' ? ord.buyerName || ord.buyer : ord.farmerName || ord.fpoName || 'Local Producer'}
                    </p>
                    <p className="text-[10px] text-slate-400 truncate max-w-[140px]">
                      {ord.location || ord.buyerLocation || 'Noida Cluster'}
                    </p>
                  </td>
                  <td className="py-3 font-medium text-slate-700">
                    {ord.quantity} {ord.unit || 'kg'}
                  </td>
                  <td className="py-3 font-mono font-bold text-slate-950">
                    ₹{ord.amount || ord.total || 0}
                  </td>
                  <td className="py-3">
                    <StatusBadge status={ord.status} size="sm" />
                  </td>
                  <td className="py-3 text-[11px] text-slate-500 whitespace-nowrap">
                    {ord.date || 'Today'}
                  </td>
                  {showActions && (
                    <td className="py-3 text-right">
                      {onStatusChange ? (
                        <div className="relative inline-block text-left">
                          <select
                            value={ord.status}
                            onChange={(e) => onStatusChange(ord.id, e.target.value)}
                            className="text-[11px] font-bold py-1 px-2 rounded-lg border border-slate-200 bg-white text-slate-700 hover:border-emerald-300 focus:outline-emerald-500 cursor-pointer"
                          >
                            <option value="Pending">Pending</option>
                            <option value="Confirmed">Confirmed</option>
                            <option value="Preparing">Preparing</option>
                            <option value="Ready for Pickup">Ready for Pickup</option>
                            <option value="In Transit">In Transit</option>
                            <option value="Delivered">Delivered</option>
                            <option value="Cancelled">Cancelled</option>
                          </select>
                        </div>
                      ) : (
                        <span className="text-[11px] text-emerald-700 font-bold hover:underline cursor-pointer">
                          View Details
                        </span>
                      )}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
