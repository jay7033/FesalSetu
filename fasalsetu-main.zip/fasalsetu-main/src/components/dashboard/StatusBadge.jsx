import React from 'react';
import { 
  Clock, 
  CheckCircle2, 
  Truck, 
  Package, 
  XCircle, 
  AlertCircle,
  ShieldCheck,
  Radio
} from 'lucide-react';

const STATUS_CONFIGS = {
  // Order statuses
  'Pending': {
    bg: 'bg-amber-50',
    text: 'text-amber-800',
    border: 'border-amber-200',
    icon: Clock,
    label: 'Pending'
  },
  'Confirmed': {
    bg: 'bg-blue-50',
    text: 'text-blue-800',
    border: 'border-blue-200',
    icon: ShieldCheck,
    label: 'Confirmed'
  },
  'Preparing': {
    bg: 'bg-indigo-50',
    text: 'text-indigo-800',
    border: 'border-indigo-200',
    icon: Package,
    label: 'Preparing'
  },
  'Ready for Pickup': {
    bg: 'bg-purple-50',
    text: 'text-purple-800',
    border: 'border-purple-200',
    icon: Package,
    label: 'Ready for Pickup'
  },
  'Picked Up': {
    bg: 'bg-cyan-50',
    text: 'text-cyan-800',
    border: 'border-cyan-200',
    icon: Truck,
    label: 'Picked Up'
  },
  'In Transit': {
    bg: 'bg-amber-50',
    text: 'text-amber-800',
    border: 'border-amber-200',
    icon: Truck,
    label: 'In Transit'
  },
  'Out for Delivery': {
    bg: 'bg-teal-50',
    text: 'text-teal-800',
    border: 'border-teal-200',
    icon: Truck,
    label: 'Out for Delivery'
  },
  'Delivered': {
    bg: 'bg-emerald-50',
    text: 'text-emerald-800',
    border: 'border-emerald-200',
    icon: CheckCircle2,
    label: 'Delivered'
  },
  'Cancelled': {
    bg: 'bg-rose-50',
    text: 'text-rose-800',
    border: 'border-rose-200',
    icon: XCircle,
    label: 'Cancelled'
  },

  // Member / Entity statuses
  'Active': {
    bg: 'bg-emerald-50',
    text: 'text-emerald-800',
    border: 'border-emerald-200',
    icon: CheckCircle2,
    label: 'Active'
  },
  'Inactive': {
    bg: 'bg-slate-100',
    text: 'text-slate-600',
    border: 'border-slate-200',
    icon: AlertCircle,
    label: 'Inactive'
  },
  'Primary Hub': {
    bg: 'bg-emerald-50',
    text: 'text-emerald-900',
    border: 'border-emerald-300',
    icon: Radio,
    label: 'Primary Hub'
  },
  'Operational': {
    bg: 'bg-blue-50',
    text: 'text-blue-800',
    border: 'border-blue-200',
    icon: CheckCircle2,
    label: 'Operational'
  }
};

export default function StatusBadge({ status, size = 'md', className = '' }) {
  const config = STATUS_CONFIGS[status] || {
    bg: 'bg-slate-100',
    text: 'text-slate-700',
    border: 'border-slate-200',
    icon: AlertCircle,
    label: status || 'Unknown'
  };

  const Icon = config.icon;

  const sizeClasses = size === 'sm'
    ? 'text-[11px] px-2 py-0.5 gap-1'
    : 'text-xs px-2.5 py-1 gap-1.5 font-semibold';

  return (
    <span
      className={`inline-flex items-center rounded-full font-medium border ${config.bg} ${config.text} ${config.border} ${sizeClasses} ${className}`}
    >
      <Icon className={size === 'sm' ? 'w-3 h-3' : 'w-3.5 h-3.5'} />
      <span>{config.label}</span>
    </span>
  );
}
