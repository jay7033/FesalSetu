import React from 'react';
import { MapPin, CheckCircle2, AlertCircle } from 'lucide-react';

import NotificationCenter from './NotificationCenter';

export default function DashboardHeader({
  greeting,
  userName,
  roleBadge = '🌾 Producer Portal',
  locationType = 'Location',
  locationText = 'Noida, Uttar Pradesh',
  isLocationVerified = true,
  children
}) {
  return (
    <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
      <div className="space-y-2 z-10">
        <div className="flex flex-wrap items-center gap-2">
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
            {roleBadge}
          </span>
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-50 text-amber-800 border border-amber-200">
            PROTOTYPE DEMO
          </span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-black text-slate-950 font-display tracking-tight">
          {greeting || (userName ? `Welcome, ${userName}` : 'Welcome')}
        </h1>

        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600">
          <span className="flex items-center gap-1 text-emerald-800 font-semibold">
            <MapPin className="w-4 h-4 text-emerald-600" />
            <span>
              <strong className="text-slate-500 font-normal mr-1">{locationType}:</strong>
              {locationText}
            </span>
          </span>
          <span>•</span>
          <span className="text-emerald-700 font-semibold flex items-center gap-1">
            {isLocationVerified ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Verified Location</span>
              </>
            ) : (
              <>
                <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                <span>Location Setup Recommended</span>
              </>
            )}
          </span>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3 z-10">
        <NotificationCenter />
        {children}
      </div>

      {/* Decorative subtle ambient backdrop glow */}
      <div className="absolute right-0 bottom-0 translate-x-10 translate-y-10 w-64 h-64 bg-emerald-100/30 rounded-full blur-2xl pointer-events-none -z-0" />
    </div>
  );
}
