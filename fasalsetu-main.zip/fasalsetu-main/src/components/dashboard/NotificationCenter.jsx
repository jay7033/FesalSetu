import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Bell, ExternalLink } from 'lucide-react';
import { useNotifications } from '../../context/NotificationContext';
import { useAuth } from '../../context/AuthContext';

export default function NotificationCenter() {
  const { role } = useAuth();
  const { getNotificationsForRole, unreadCountForRole, markAsRead, markAllAsRead } = useNotifications();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  const notifications = getNotificationsForRole(role);
  const unreadCount = unreadCountForRole(role);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getTargetOrderLink = (notif) => {
    if (!notif.orderId) return null;
    if (role === 'consumer') return `/consumer/orders/${notif.orderId}`;
    if (role === 'bulk_buyer') return `/bulk-buyer/orders/${notif.orderId}`;
    if (role === 'farmer') return '/farmer/orders';
    if (role === 'fpo') return '/fpo/dashboard?tab=orders';
    return '/';
  };

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
        aria-label="Notifications"
      >
        <Bell className="w-5 h-5" />
        {unreadCount > 0 && (
          <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-emerald-600 text-white text-[10px] font-bold flex items-center justify-center animate-pulse">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl bg-white shadow-2xl border border-slate-200 z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-100">
          <div className="p-3.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-900 font-display">Notifications</span>
              {unreadCount > 0 && (
                <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                  {unreadCount} new
                </span>
              )}
            </div>

            {unreadCount > 0 && (
              <button
                type="button"
                onClick={() => markAllAsRead(role)}
                className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 cursor-pointer"
              >
                Mark all read
              </button>
            )}
          </div>

          <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 text-xs">
            {notifications.length === 0 ? (
              <div className="p-6 text-center text-slate-400">
                No notifications right now
              </div>
            ) : (
              notifications.slice(0, 8).map((n) => {
                const targetLink = getTargetOrderLink(n);

                return (
                  <div
                    key={n.id}
                    className={`p-3.5 hover:bg-slate-50 transition-colors space-y-1 ${
                      !n.read ? 'bg-emerald-50/40' : ''
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <h5 className="font-bold text-slate-900 text-xs">{n.title}</h5>
                      <span className="text-[10px] text-slate-400 whitespace-nowrap">{n.timeAgo}</span>
                    </div>

                    <p className="text-[11px] text-slate-600 leading-relaxed">{n.message}</p>

                    <div className="flex items-center justify-between pt-1">
                      {targetLink ? (
                        <Link
                          to={targetLink}
                          onClick={() => {
                            markAsRead(n.id);
                            setIsOpen(false);
                          }}
                          className="text-[10px] font-bold text-emerald-700 hover:underline flex items-center gap-1"
                        >
                          <span>View Order</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </Link>
                      ) : <span />}

                      {!n.read && (
                        <button
                          type="button"
                          onClick={() => markAsRead(n.id)}
                          className="text-[10px] text-slate-400 hover:text-slate-600 cursor-pointer"
                        >
                          Mark read
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
}
