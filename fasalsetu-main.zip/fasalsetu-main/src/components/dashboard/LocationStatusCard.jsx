import React from 'react';
import { Link } from 'react-router-dom';
import { 
  MapPin, 
  CheckCircle2, 
  AlertCircle, 
  Navigation, 
  Compass, 
  Loader2,
  ShieldCheck
} from 'lucide-react';
import Button from '../Button';

export default function LocationStatusCard({
  typeLabel = 'Farm Location',
  locationName,
  approximateAddress,
  isVerified = true,
  source = 'Device GPS',
  accuracy,
  coordinates,
  updateLink,
  viewLink,
  onUseCurrentLocation,
  isDetectingGPS = false
}) {
  return (
    <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
      <div className="flex items-start gap-4 z-10">
        <div
          className={`p-3.5 rounded-2xl flex-shrink-0 ${
            isVerified
              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
              : 'bg-amber-50 text-amber-700 border border-amber-200'
          }`}
        >
          <MapPin className="w-6 h-6" />
        </div>

        <div className="space-y-1.5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-black uppercase tracking-wider text-slate-500">
              📍 {typeLabel}
            </span>

            {isVerified ? (
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                <span>Verified Location</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">
                <AlertCircle className="w-3 h-3 text-amber-600" />
                <span>Location Setup Recommended</span>
              </span>
            )}

            <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-200">
              <ShieldCheck className="w-3 h-3 text-slate-400" />
              <span>Exact Coordinates Kept Private</span>
            </span>
          </div>

          <h3 className="text-lg sm:text-xl font-bold text-slate-900 font-display">
            {locationName || approximateAddress || 'Location Not Configured'}
          </h3>

          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
            {approximateAddress && (
              <span className="font-medium text-slate-700">{approximateAddress}</span>
            )}
            {source && (
              <>
                <span>•</span>
                <span className="capitalize font-medium text-slate-500">
                  Source: <strong className="text-slate-800 uppercase text-[10px]">{source}</strong>
                </span>
              </>
            )}
            {accuracy && (
              <>
                <span>•</span>
                <span className="text-slate-500">
                  Accuracy: <strong className="text-emerald-700">±{Math.round(accuracy)}m</strong>
                </span>
              </>
            )}
            {coordinates && (
              <>
                <span>•</span>
                <span className="font-mono text-[11px] text-emerald-700 font-semibold">
                  {coordinates.latitude?.toFixed(4)}°N, {coordinates.longitude?.toFixed(4)}°E (Internal)
                </span>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3 z-10">
        {onUseCurrentLocation && (
          <button
            type="button"
            onClick={onUseCurrentLocation}
            disabled={isDetectingGPS}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 transition-colors disabled:opacity-60 cursor-pointer"
          >
            {isDetectingGPS ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-700" />
                <span>Locating...</span>
              </>
            ) : (
              <>
                <Navigation className="w-3.5 h-3.5 text-emerald-700" />
                <span>Use My Current Location</span>
              </>
            )}
          </button>
        )}

        {viewLink && (
          <Link
            to={viewLink}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 shadow-xs transition-colors"
          >
            <Compass className="w-3.5 h-3.5 text-slate-500" />
            <span>View Location</span>
          </Link>
        )}

        {updateLink && (
          <Button
            to={updateLink}
            variant="primary"
            size="sm"
          >
            Update Location
          </Button>
        )}
      </div>

      {/* Decorative ambient backdrop */}
      <div className="absolute right-0 bottom-0 translate-x-12 translate-y-12 w-48 h-48 bg-emerald-50/50 rounded-full blur-2xl pointer-events-none -z-0" />
    </div>
  );
}
