import React from 'react';
import { PackageOpen } from 'lucide-react';
import Button from '../Button';

export default function EmptyState({
  icon: Icon = PackageOpen,
  title = 'No items found',
  description = 'There is currently no data available in this view.',
  actionLabel,
  actionLink,
  onAction,
  className = ''
}) {
  return (
    <div
      className={`bg-white rounded-3xl p-8 sm:p-12 border border-slate-200/90 shadow-xs text-center flex flex-col items-center justify-center space-y-4 ${className}`}
    >
      <div className="w-14 h-14 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400">
        <Icon className="w-7 h-7" />
      </div>

      <div className="space-y-1 max-w-sm">
        <h4 className="text-base font-bold text-slate-900 font-display">{title}</h4>
        <p className="text-xs text-slate-500 leading-relaxed">{description}</p>
      </div>

      {(actionLabel && (actionLink || onAction)) && (
        <div className="pt-2">
          {actionLink ? (
            <Button to={actionLink} variant="primary" size="sm">
              {actionLabel}
            </Button>
          ) : (
            <Button onClick={onAction} variant="primary" size="sm">
              {actionLabel}
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
