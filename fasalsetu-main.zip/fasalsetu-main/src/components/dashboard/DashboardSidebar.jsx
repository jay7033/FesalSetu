import React, { useState } from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Package, 
  PlusCircle, 
  MapPin, 
  FileText, 
  TrendingUp, 
  User, 
  Store, 
  LogOut, 
  Users, 
  Warehouse, 
  ShoppingBag, 
  Heart, 
  Building2, 
  Menu, 
  X,
  Scale,
  Truck
} from 'lucide-react';
import Logo from '../Logo';
import { useAuth } from '../../context/AuthContext';

export default function DashboardSidebar({ role = 'farmer', activeTab, onSelectTab }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate(`/login?role=${role}`);
  };

  // Build role-specific menu items adhering strictly to Section 10
  const getNavItems = () => {
    switch (role) {
      case 'farmer':
        return [
          { label: 'Dashboard', icon: LayoutDashboard, to: '/farmer/dashboard', exact: true },
          { label: 'Products', icon: Package, to: '/farmer/products' },
          { label: 'Add Product', icon: PlusCircle, to: '/farmer/add-product' },
          { label: 'Farm Locations', icon: MapPin, to: '/farmer/locations' },
          { label: 'Orders', icon: FileText, to: '/farmer/orders' },
          { label: 'Earnings', icon: TrendingUp, to: '/farmer/earnings' },
          { label: 'Profile', icon: User, to: '/farmer/profile' },
          { label: 'Marketplace', icon: Store, to: '/marketplace' }
        ];

      case 'fpo':
        return [
          { label: 'Dashboard', icon: LayoutDashboard, tab: 'overview', to: '/fpo/dashboard' },
          { label: 'Farmers', icon: Users, tab: 'farmers' },
          { label: 'Farm Locations', icon: MapPin, tab: 'locations' },
          { label: 'Produce', icon: Package, tab: 'produce' },
          { label: 'Inventory', icon: Warehouse, tab: 'inventory' },
          { label: 'Orders', icon: FileText, tab: 'orders' },
          { label: 'Sales', icon: TrendingUp, tab: 'sales' },
          { label: 'Logistics', icon: Truck, tab: 'logistics' },
          { label: 'Profile', icon: User, tab: 'profile' },
          { label: 'Marketplace', icon: Store, to: '/marketplace' }
        ];

      case 'consumer':
        return [
          { label: 'Dashboard', icon: LayoutDashboard, to: '/consumer/dashboard', exact: true },
          { label: 'Marketplace', icon: Store, to: '/marketplace' },
          { label: 'My Orders', icon: FileText, to: '/consumer/orders' },
          { label: 'Saved Products', icon: Heart, tab: 'saved', to: '/consumer/dashboard' },
          { label: 'My Cart', icon: ShoppingBag, to: '/cart' },
          { label: 'Delivery Location', icon: MapPin, tab: 'location', to: '/consumer/dashboard' },
          { label: 'Profile', icon: User, tab: 'profile', to: '/consumer/dashboard' }
        ];

      case 'bulk_buyer':
        return [
          { label: 'Dashboard', icon: LayoutDashboard, to: '/bulk-buyer/dashboard', exact: true },
          { label: 'Find Produce', icon: Store, to: '/marketplace' },
          { label: 'Suppliers', icon: Building2, tab: 'suppliers', to: '/bulk-buyer/dashboard' },
          { label: 'Bulk Orders', icon: FileText, to: '/bulk-buyer/orders' },
          { label: 'Logistics & Fleet', icon: Truck, tab: 'logistics', to: '/bulk-buyer/dashboard' },
          { label: 'Procurement', icon: Scale, tab: 'procurement', to: '/bulk-buyer/dashboard' },
          { label: 'Saved Suppliers', icon: Heart, tab: 'saved', to: '/bulk-buyer/dashboard' },
          { label: 'Locations', icon: MapPin, tab: 'locations', to: '/bulk-buyer/dashboard' },
          { label: 'Profile', icon: User, tab: 'profile', to: '/bulk-buyer/dashboard' }
        ];

      default:
        return [];
    }
  };

  const navItems = getNavItems();

  const roleMeta = {
    farmer: { title: 'Farmer Portal', badge: '🌾 Producer' },
    fpo: { title: 'FPO Cluster Portal', badge: '🏢 Cooperative' },
    consumer: { title: 'Consumer Portal', badge: '🛒 Household' },
    bulk_buyer: { title: 'Bulk Buyer Portal', badge: '🚛 B2B Procurement' }
  }[role] || { title: 'Dashboard', badge: 'Portal' };

  const sidebarContent = (
    <div className="flex flex-col h-full justify-between p-4 bg-white border-r border-slate-200">
      <div className="space-y-6">
        {/* Brand Header */}
        <div className="px-2 pt-2">
          <Logo size="md" />
          <div className="mt-3 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-800 font-display">
              {roleMeta.title}
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
              {roleMeta.badge}
            </span>
          </div>
        </div>

        {/* Navigation links */}
        <nav className="space-y-1">
          {navItems.map((item, idx) => {
            const Icon = item.icon;

            // Direct route navigation item
            if (item.to && !item.tab) {
              const isActive = item.exact 
                ? location.pathname === item.to 
                : location.pathname.startsWith(item.to);

              return (
                <NavLink
                  key={idx}
                  to={item.to}
                  onClick={() => setMobileOpen(false)}
                  className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-colors ${
                    isActive
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  <span>{item.label}</span>
                </NavLink>
              );
            }

            // Tab navigation within the role dashboard
            const isTabActive = activeTab === item.tab || (!activeTab && item.tab === 'overview');

            return (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  if (item.to && location.pathname !== item.to) {
                    navigate(item.to);
                  }
                  if (onSelectTab && item.tab) {
                    onSelectTab(item.tab);
                  }
                  setMobileOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-colors text-left cursor-pointer ${
                  isTabActive
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* User profile snippet & Logout button */}
      <div className="pt-4 border-t border-slate-200 space-y-3">
        <div className="flex items-center gap-3 px-2">
          <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs">
            {user?.name?.[0]?.toUpperCase() || 'U'}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-bold text-slate-900 truncate">
              {user?.name || user?.entityName || 'Active User'}
            </p>
            <p className="text-[10px] text-slate-500 capitalize">
              Role: {role.replace('_', ' ')}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleLogout}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold text-rose-600 hover:bg-rose-50 border border-transparent hover:border-rose-200 transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile Sticky Bar */}
      <div className="lg:hidden flex items-center justify-between p-4 bg-white border-b border-slate-200 sticky top-0 z-40">
        <Logo size="sm" />
        <button
          type="button"
          onClick={() => setMobileOpen(!mobileOpen)}
          className="p-2 rounded-lg text-slate-700 hover:bg-slate-100"
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Drawer Backdrop */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Mobile Drawer */}
      <aside
        className={`lg:hidden fixed top-0 bottom-0 left-0 w-64 z-50 bg-white transform transition-transform duration-300 ease-in-out ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {sidebarContent}
      </aside>

      {/* Desktop Sticky Sidebar */}
      <aside className="hidden lg:block w-64 flex-shrink-0 h-screen sticky top-0">
        {sidebarContent}
      </aside>
    </>
  );
}
