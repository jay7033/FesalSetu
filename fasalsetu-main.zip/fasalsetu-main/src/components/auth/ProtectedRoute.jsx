import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth, getRoleDashboardPath } from '../../context/AuthContext';
import { Loader2 } from 'lucide-react';

/**
 * ProtectedRoute: Enforces authentication and role-based portal protection.
 * - If not authenticated: redirects to /login?role={primaryAllowedRole}&redirect={pathname}
 * - If authenticated but role not allowed: redirects to the user's OWN role dashboard.
 */
export default function ProtectedRoute({ allowedRoles = [], children }) {
  const { isAuthenticated, user, role, isLoading } = useAuth();
  const location = useLocation();

  // 1. Loading state during session restoration
  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 gap-3">
        <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
        <p className="text-xs font-semibold text-slate-500 font-display">
          Verifying FasalSetu Credentials...
        </p>
      </div>
    );
  }

  // 2. Unauthenticated check -> Redirect to /login with target role parameter
  if (!isAuthenticated || !user) {
    const targetRole = allowedRoles[0] || 'farmer';
    const redirectParam = encodeURIComponent(location.pathname + location.search);
    return (
      <Navigate
        to={`/login?role=${targetRole}&redirect=${redirectParam}`}
        replace
      />
    );
  }

  // 3. Role Authorization Matrix Check
  // If user role is NOT in allowedRoles, redirect to their OWN role's dashboard
  if (allowedRoles.length > 0 && !allowedRoles.includes(role)) {
    const ownDashboardPath = getRoleDashboardPath(role);
    return <Navigate to={ownDashboardPath} replace />;
  }

  // 4. Authorized -> Render children
  return children;
}
