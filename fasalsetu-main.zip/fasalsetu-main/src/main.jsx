import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import './index.css';
import App from './App.jsx';
import { AuthProvider } from './context/AuthContext';
import { LocationProvider } from './context/LocationContext';
import { ProductProvider } from './context/ProductContext';
import { CartProvider } from './context/CartContext';
import { NotificationProvider } from './context/NotificationContext';
import { OrderProvider } from './context/OrderContext';
import { FPOProvider } from './context/FPOContext';
import { BuyerProvider } from './context/BuyerContext';
import { LogisticsProvider } from './context/LogisticsContext';
import { AIProvider } from './context/AIContext';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <LocationProvider>
          <ProductProvider>
            <CartProvider>
              <NotificationProvider>
                <OrderProvider>
                  <FPOProvider>
                    <BuyerProvider>
                      <LogisticsProvider>
                        <AIProvider>
                          <App />
                        </AIProvider>
                      </LogisticsProvider>
                    </BuyerProvider>
                  </FPOProvider>
                </OrderProvider>
              </NotificationProvider>
            </CartProvider>
          </ProductProvider>
        </LocationProvider>
      </AuthProvider>
    </BrowserRouter>
  </StrictMode>,
);
