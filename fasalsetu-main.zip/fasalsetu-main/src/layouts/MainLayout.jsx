import React, { useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { MapPin, Sparkles } from 'lucide-react';

export default function MainLayout() {
  const { pathname } = useLocation();

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 selection:bg-emerald-500 selection:text-white">
      
      {/* Top Banner for Hackathon Context */}
      <div className="bg-gradient-to-r from-emerald-900 via-slate-900 to-emerald-950 text-emerald-200 text-xs py-2 px-4 border-b border-emerald-800/40">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400 text-slate-950 uppercase tracking-wider">
              SIH Prototype
            </span>
            <span className="font-medium text-slate-200 hidden sm:inline">
              FasalSetu — AI-Powered Hyperlocal Agricultural Marketplace
            </span>
            <span className="font-medium text-slate-200 sm:hidden">
              FasalSetu AgriTech
            </span>
          </div>

          <div className="flex items-center gap-3 text-[11px] text-emerald-300 font-medium">
            <div className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-amber-400" />
              <span>Noida & Greater Noida, UP</span>
            </div>
            <span className="text-emerald-700 hidden md:inline">•</span>
            <span className="hidden md:inline-flex items-center gap-1 text-emerald-400 font-normal">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>Unified Agri-Commerce Platform</span>
            </span>
          </div>
        </div>
      </div>

      {/* Main Sticky Navbar */}
      <Navbar />

      {/* Page Content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Global Footer */}
      <Footer />

    </div>
  );
}
