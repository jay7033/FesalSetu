import React from 'react';
import { Outlet, useSearchParams } from 'react-router-dom';
import DashboardSidebar from '../components/dashboard/DashboardSidebar';

export default function ConsumerLayout() {
  const [searchParams, setSearchParams] = useSearchParams();
  const currentTab = searchParams.get('tab') || 'overview';

  const handleSelectTab = (tab) => {
    setSearchParams({ tab });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col lg:flex-row">
      {/* Unified Consumer Sidebar */}
      <DashboardSidebar 
        role="consumer" 
        activeTab={currentTab} 
        onSelectTab={handleSelectTab} 
      />

      {/* Main Content */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto overflow-y-auto">
        <Outlet context={{ activeTab: currentTab, setActiveTab: handleSelectTab }} />
      </main>
    </div>
  );
}
