import React from 'react';
import { Outlet, useSearchParams } from 'react-router-dom';
import DashboardSidebar from '../components/dashboard/DashboardSidebar';

export default function FPOLayout() {
  const [searchParams, setSearchParams] = useSearchParams();
  const currentTab = searchParams.get('tab') || 'overview';

  const handleSelectTab = (tab) => {
    setSearchParams({ tab });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col lg:flex-row">
      {/* Responsive unified Sidebar for FPO */}
      <DashboardSidebar 
        role="fpo" 
        activeTab={currentTab} 
        onSelectTab={handleSelectTab} 
      />

      {/* Main Content Area */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto overflow-y-auto">
        <Outlet context={{ activeTab: currentTab, setActiveTab: handleSelectTab }} />
      </main>
    </div>
  );
}
