import React, { useState } from 'react';
import { Outlet, Link } from 'react-router-dom';
import { 
  Menu, 
  X, 
  MapPin, 
  Store,
  ExternalLink,
  Plus
} from 'lucide-react';
import FarmerSidebar from '../components/farmer/FarmerSidebar';
import Logo from '../components/Logo';
import Button from '../components/Button';
import { useLocation } from '../context/LocationContext';

export default function FarmerLayout() {
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);
  const { location } = useLocation();

  const isLocationSet = Boolean(location?.confirmed || location?.latitude);

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col md:flex-row text-slate-900 selection:bg-emerald-500 selection:text-white">
      
      {/* Mobile Top App Bar */}
      <header className="md:hidden sticky top-0 z-40 bg-slate-900 text-white px-4 py-3 border-b border-slate-800 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setMobileDrawerOpen(true)}
            className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 focus:outline-none"
            aria-label="Open portal navigation"
          >
            <Menu className="w-6 h-6" />
          </button>
          <Logo variant="light" size="sm" clickable={false} />
        </div>

        <div className="flex items-center gap-2">
          <Link
            to="/marketplace"
            className="text-xs font-semibold text-emerald-400 bg-emerald-950/80 px-2.5 py-1 rounded-lg border border-emerald-800 flex items-center gap-1"
          >
            <Store className="w-3.5 h-3.5" />
            <span>Store</span>
          </Link>
          <Link
            to="/farmer/add-product"
            className="p-2 rounded-lg bg-emerald-600 text-white"
            aria-label="Add new produce"
          >
            <Plus className="w-4 h-4" />
          </Link>
        </div>
      </header>

      {/* Mobile Slide-out Drawer */}
      {mobileDrawerOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
          <div 
            className="fixed inset-0" 
            onClick={() => setMobileDrawerOpen(false)} 
          />
          <div className="relative w-72 max-w-[85vw] h-full z-10">
            <FarmerSidebar onNavigate={() => setMobileDrawerOpen(false)} isMobile />
            <button
              type="button"
              onClick={() => setMobileDrawerOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* Desktop Fixed Sidebar (w-72) */}
      <div className="hidden md:block w-72 flex-shrink-0 h-screen sticky top-0 z-30">
        <FarmerSidebar />
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        
        {/* Top Operational Bar (Desktop) */}
        <header className="hidden md:flex items-center justify-between px-8 py-4 bg-white border-b border-slate-200/80 sticky top-0 z-20 shadow-2xs">
          <div className="flex items-center gap-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold">
              <MapPin className="w-3.5 h-3.5 text-emerald-600" />
              <span>{location?.approximateLocation || 'Pan-India Farm Location System'}</span>
            </div>

            <span className="text-xs text-slate-400">
              {isLocationSet ? '✓ Live GPS Location Synced' : '⚠ Location not set (using default cluster)'}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <Button
              to="/farmer/add-product"
              variant="primary"
              size="sm"
              leftIcon={Plus}
            >
              Add New Product
            </Button>

            <Link
              to="/marketplace"
              target="_blank"
              rel="noreferrer"
              className="p-2 rounded-xl text-slate-600 hover:text-emerald-700 hover:bg-slate-100 transition-colors flex items-center gap-1.5 text-xs font-semibold"
              title="View Public Marketplace"
            >
              <span>Marketplace</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </Link>
          </div>
        </header>

        {/* Page Body */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          <Outlet />
        </main>

        {/* Footer info banner */}
        <footer className="px-6 py-4 bg-white border-t border-slate-200/80 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>FasalSetu Pan-India Farmer Portal • Prototype Demo Mode</span>
          <span className="text-emerald-700 font-medium">Smart India Hackathon 2024 / 2025</span>
        </footer>

      </div>

    </div>
  );
}
