import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

// Layouts
import MainLayout from './layouts/MainLayout';
import FarmerLayout from './layouts/FarmerLayout';
import FPOLayout from './layouts/FPOLayout';
import ConsumerLayout from './layouts/ConsumerLayout';
import BulkBuyerLayout from './layouts/BulkBuyerLayout';

// Auth Components & Pages
import ProtectedRoute from './components/auth/ProtectedRoute';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';

// Public & Buyer Pages
import Home from './pages/Home';
import HowItWorks from './pages/HowItWorks';
import Marketplace from './pages/Marketplace';
import ProductDetails from './pages/ProductDetails';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import AIInsights from './pages/AIInsights';
// Logistics & Operations Pages
import Logistics from './pages/Logistics';
import ZoneOperations from './pages/logistics/ZoneOperations';
import DeliveryBoyDashboard from './pages/delivery/DeliveryBoyDashboard';

// Farmer Portal Pages
import FarmerDashboard from './pages/farmer/FarmerDashboard';
import FarmerProducts from './pages/farmer/FarmerProducts';
import AddProduct from './pages/farmer/AddProduct';
import FarmerOrders from './pages/farmer/FarmerOrders';
import FarmerEarnings from './pages/farmer/FarmerEarnings';
import FarmLocations from './pages/farmer/FarmLocations';
import AddFarmLocation from './pages/farmer/AddFarmLocation';
import FarmerProfile from './pages/farmer/FarmerProfile';

// FPO Portal Page
import FPODashboard from './pages/fpo/FPODashboard';

// Consumer Portal Pages
import ConsumerDashboard from './pages/consumer/ConsumerDashboard';
import ConsumerOrders from './pages/consumer/ConsumerOrders';
import ConsumerOrderDetails from './pages/consumer/ConsumerOrderDetails';

// Bulk Buyer Portal Pages
import BulkBuyerDashboard from './pages/bulkBuyer/BulkBuyerDashboard';
import BulkBuyerOrders from './pages/bulkBuyer/BulkBuyerOrders';
import BulkBuyerOrderDetails from './pages/bulkBuyer/BulkBuyerOrderDetails';

export default function App() {
  return (
    <Routes>
      {/* =========================================================================
          PUBLIC ROUTES
          ========================================================================= */}
      <Route path="/" element={<MainLayout />}>
        <Route index element={<Home />} />
        <Route path="how-it-works" element={<HowItWorks />} />
        <Route path="marketplace" element={<Marketplace />} />
        <Route path="product/:id" element={<ProductDetails />} />
        <Route path="cart" element={<Cart />} />
        <Route path="checkout" element={<Checkout />} />
        <Route path="ai-insights" element={<AIInsights />} />
        <Route path="logistics" element={<Logistics />} />
        
        {/* Hierarchical Regional Logistics & Delivery Partner Operations */}
        <Route
          path="logistics/zone"
          element={
            <ProtectedRoute allowedRoles={['delivery_assigner', 'logistics_head']}>
              <ZoneOperations />
            </ProtectedRoute>
          }
        />
        <Route
          path="delivery/dashboard"
          element={
            <ProtectedRoute allowedRoles={['delivery_boy', 'delivery_assigner', 'logistics_head']}>
              <DeliveryBoyDashboard />
            </ProtectedRoute>
          }
        />
        
        {/* Auth routes */}
        <Route path="login" element={<Login />} />
        <Route path="register" element={<Register />} />
        <Route path="register/:role" element={<Register />} />
      </Route>

      {/* =========================================================================
          PROTECTED ROUTE 1: FARMER PORTAL (Role: 'farmer')
          ========================================================================= */}
      <Route
        path="/farmer"
        element={
          <ProtectedRoute allowedRoles={['farmer']}>
            <FarmerLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/farmer/dashboard" replace />} />
        <Route path="dashboard" element={<FarmerDashboard />} />
        <Route path="products" element={<FarmerProducts />} />
        <Route path="add-product" element={<AddProduct />} />
        <Route path="orders" element={<FarmerOrders />} />
        <Route path="earnings" element={<FarmerEarnings />} />
        <Route path="locations" element={<FarmLocations />} />
        <Route path="locations/new" element={<AddFarmLocation />} />
        <Route path="profile" element={<FarmerProfile />} />
      </Route>

      {/* =========================================================================
          PROTECTED ROUTE 2: FPO PORTAL (Role: 'fpo')
          ========================================================================= */}
      <Route
        path="/fpo"
        element={
          <ProtectedRoute allowedRoles={['fpo']}>
            <FPOLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/fpo/dashboard" replace />} />
        <Route path="dashboard" element={<FPODashboard />} />
      </Route>

      {/* =========================================================================
          PROTECTED ROUTE 3: CONSUMER PORTAL (Role: 'consumer')
          ========================================================================= */}
      <Route
        path="/consumer"
        element={
          <ProtectedRoute allowedRoles={['consumer']}>
            <ConsumerLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/consumer/dashboard" replace />} />
        <Route path="dashboard" element={<ConsumerDashboard />} />
        <Route path="orders" element={<ConsumerOrders />} />
        <Route path="orders/:orderId" element={<ConsumerOrderDetails />} />
      </Route>

      {/* =========================================================================
          PROTECTED ROUTE 4: BULK BUYER PORTAL (Role: 'bulk_buyer')
          ========================================================================= */}
      <Route
        path="/bulk-buyer"
        element={
          <ProtectedRoute allowedRoles={['bulk_buyer']}>
            <BulkBuyerLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/bulk-buyer/dashboard" replace />} />
        <Route path="dashboard" element={<BulkBuyerDashboard />} />
        <Route path="orders" element={<BulkBuyerOrders />} />
        <Route path="orders/:orderId" element={<BulkBuyerOrderDetails />} />
      </Route>

      {/* =========================================================================
          FALLBACK / CATCH-ALL
          ========================================================================= */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
