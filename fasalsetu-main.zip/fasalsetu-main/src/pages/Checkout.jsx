import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  MapPin, 
  Navigation, 
  ShoppingBag, 
  Truck, 
  CreditCard, 
  Banknote, 
  ShieldCheck, 
  ArrowRight, 
  AlertCircle, 
  Loader2,
  ChevronLeft,
  Store
} from 'lucide-react';
import Button from '../components/Button';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useLocation } from '../context/LocationContext';
import { useOrders } from '../context/OrderContext';
import { calculateDistance, formatDistance } from '../utils/distance';

export default function Checkout() {
  const navigate = useNavigate();
  const { 
    cartItems, 
    subtotal, 
    totalSavings, 
    deliveryFee, 
    clearCart 
  } = useCart();
  
  const { isAuthenticated, user } = useAuth();
  const { location, requestDeviceLocation, isLocating } = useLocation();
  const { createOrder } = useOrders();

  // If user is not authenticated, redirect to login with return URL
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login?role=consumer&redirect=%2Fcheckout', { replace: true });
    }
  }, [isAuthenticated, navigate]);

  // Delivery Location State
  const [deliveryAddress, setDeliveryAddress] = useState(
    'Flat 402, Prateek Fedora, Sector 62, Noida, Gautam Buddha Nagar, Uttar Pradesh - 201309'
  );
  const [showAddressInput, setShowAddressInput] = useState(false);
  const [customAddressInput, setCustomAddressInput] = useState('');

  // Delivery & Payment Options
  const [deliveryType, setDeliveryType] = useState('delivery'); // 'delivery' | 'pickup'
  const [paymentMethod, setPaymentMethod] = useState('cod'); // 'cod' | 'demo_online'
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);

  // Buyer reference coordinates for distance calculation
  const buyerLat = location?.latitude || 28.6139;
  const buyerLon = location?.longitude || 77.3592;

  // Farm origin reference (e.g. Dankaur hub)
  const farmLat = cartItems[0]?.latitude || 28.352;
  const farmLon = cartItems[0]?.longitude || 77.550;

  const approxDistanceKm = calculateDistance(buyerLat, buyerLon, farmLat, farmLon);
  const formattedDistance = approxDistanceKm ? formatDistance(approxDistanceKm) : 'Approx. 24 km away';

  // Prototype Delivery Estimator
  const getDeliveryEstimate = (km, type) => {
    if (type === 'pickup') return 'Ready for pickup in 2-3 hours';
    if (!km || km < 25) return 'Same-Day Evening Delivery (Within 4-6 Hours)';
    if (km <= 100) return 'Next-Day Morning Delivery (1-2 Days)';
    if (km <= 300) return 'Express Agrilogistics (2-3 Days)';
    return 'Regional Transport (3-5 Days)';
  };

  const deliveryEstimate = getDeliveryEstimate(approxDistanceKm, deliveryType);

  const handleUseGPS = async () => {
    try {
      const result = await requestDeviceLocation();
      if (result?.formattedAddress) {
        setDeliveryAddress(result.formattedAddress);
      } else if (result?.approximateLocation) {
        setDeliveryAddress(result.approximateLocation);
      }
    } catch (e) {
      console.error('GPS Detection failed:', e);
    }
  };

  const handlePlaceOrder = async (e) => {
    e.preventDefault();
    if (cartItems.length === 0) return;
    if (isSubmitting) return;

    setErrorMsg(null);
    setIsSubmitting(true);

    try {
      const formattedItems = cartItems.map((it) => ({
        productId: it.id,
        name: it.name,
        quantity: it.quantity,
        unit: it.unit,
        price: it.price,
        farmerId: it.farmerId || 'farmer_1',
        farmerName: it.farmer || 'Local Producer',
        fpoId: it.fpoId,
        farmLocation: it.farmLocation || it.location || 'Western UP Cluster',
        subtotal: it.price * it.quantity
      }));

      const finalDeliveryFee = deliveryType === 'pickup' ? 0 : deliveryFee;
      const finalGrandTotal = subtotal + finalDeliveryFee;

      const newOrder = await createOrder({
        buyerId: user?.id || 'consumer_1',
        buyerName: user?.name || 'Consumer Household',
        buyerRole: 'consumer',
        product: cartItems.length === 1 ? cartItems[0].name : `${cartItems[0].name} + ${cartItems.length - 1} more`,
        items: formattedItems,
        quantity: cartItems.reduce((acc, c) => acc + c.quantity, 0),
        unit: 'items',
        subtotal,
        deliveryFee: finalDeliveryFee,
        savings: totalSavings,
        total: finalGrandTotal,
        amount: finalGrandTotal,
        deliveryType,
        deliveryEstimate,
        approxDistance: formattedDistance,
        buyerLocation: {
          address: deliveryAddress,
          city: 'Noida',
          district: 'Gautam Buddha Nagar',
          state: 'Uttar Pradesh'
        },
        location: deliveryAddress,
        paymentMethod: paymentMethod === 'demo_online' ? 'Demo Online Payment' : 'Cash on Delivery',
        paymentStatus: paymentMethod === 'demo_online' ? 'Paid (Escrow Secured)' : 'Pending COD'
      });

      // Clear the cart
      clearCart();

      // Navigate to order details
      navigate(`/consumer/orders/${newOrder.id}`, { replace: true });
    } catch (err) {
      console.error('Order creation error:', err);
      setErrorMsg('Failed to process order. Please try again.');
      setIsSubmitting(false);
    }
  };

  // If cart is empty
  if (cartItems.length === 0) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-4 text-center max-w-md mx-auto space-y-4">
        <div className="w-16 h-16 rounded-3xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
          <ShoppingBag className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-black text-slate-900 font-display">Your Cart is Empty</h2>
        <p className="text-xs text-slate-500 leading-relaxed">
          Add fresh produce directly from farmers and FPOs on the marketplace before proceeding to checkout.
        </p>
        <Button to="/marketplace" variant="primary" size="md" leftIcon={Store}>
          Explore Marketplace
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto space-y-6">
        
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between">
          <Link
            to="/cart"
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-emerald-700 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Back to Cart</span>
          </Link>

          <span className="text-xs font-bold text-slate-500">
            Secure Hyperlocal Checkout
          </span>
        </div>

        {/* Page Title */}
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-950 font-display tracking-tight">
            Checkout & Order Confirmation
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Direct purchase from farm gate. Transparent pricing with zero broker markups.
          </p>
        </div>

        {/* 5-Step Checkout Visual Progress Indicator */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-xs">
          <div className="flex items-center justify-between max-w-2xl mx-auto text-center">
            {[
              { num: '01', label: 'Address', active: true, done: true },
              { num: '02', label: 'Delivery', active: true, done: true },
              { num: '03', label: 'Payment', active: true, done: false },
              { num: '04', label: 'Review', active: false, done: false },
              { num: '05', label: 'Confirmation', active: false, done: false }
            ].map((step, idx) => (
              <React.Fragment key={step.num}>
                <div className="flex flex-col items-center gap-1">
                  <div className={`w-7 h-7 rounded-full text-xs font-mono font-bold flex items-center justify-center transition-colors ${
                    step.done 
                      ? 'bg-emerald-600 text-white shadow-xs' 
                      : step.active 
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                      : 'bg-slate-100 text-slate-400 border border-slate-200'
                  }`}>
                    {step.num}
                  </div>
                  <span className={`text-[10px] font-semibold hidden sm:inline ${
                    step.done || step.active ? 'text-slate-800' : 'text-slate-400'
                  }`}>
                    {step.label}
                  </span>
                </div>
                {idx < 4 && (
                  <div className={`flex-1 h-0.5 mx-2 ${
                    step.done ? 'bg-emerald-500' : 'bg-slate-200'
                  }`} />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        {errorMsg && (
          <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handlePlaceOrder}>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left Column: Checkout Steps 1 to 4 (7 cols) */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* STEP 1: DELIVERY LOCATION */}
              <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-emerald-600 text-white text-xs font-bold flex items-center justify-center">
                      1
                    </span>
                    <h3 className="text-base font-bold text-slate-900 font-display">
                      Delivery Location
                    </h3>
                  </div>
                  <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Doorstep Drop
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-emerald-700 flex-shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                        Deliver To
                      </span>
                      <p className="text-xs font-bold text-slate-900 leading-relaxed">
                        {deliveryAddress}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        Accuracy: <span className="text-emerald-700 font-bold">±15m GPS verified</span> • Coordinates kept private
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-200/60">
                    <button
                      type="button"
                      onClick={handleUseGPS}
                      disabled={isLocating}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-emerald-800 bg-emerald-100/80 hover:bg-emerald-200 border border-emerald-300 transition-colors disabled:opacity-60 cursor-pointer"
                    >
                      {isLocating ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-700" />
                          <span>Detecting GPS...</span>
                        </>
                      ) : (
                        <>
                          <Navigation className="w-3.5 h-3.5 text-emerald-700" />
                          <span>Use My Current Location</span>
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => setShowAddressInput(!showAddressInput)}
                      className="px-3 py-1.5 rounded-xl text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 transition-colors cursor-pointer"
                    >
                      Change Location
                    </button>
                  </div>
                </div>

                {showAddressInput && (
                  <div className="p-4 rounded-2xl bg-white border border-slate-300 space-y-3">
                    <label className="block text-xs font-bold text-slate-700">
                      Enter Delivery Address in Noida / Greater Noida:
                    </label>
                    <textarea
                      rows={2}
                      value={customAddressInput}
                      onChange={(e) => setCustomAddressInput(e.target.value)}
                      placeholder="e.g. Sector 78, Noida, Uttar Pradesh"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-emerald-500"
                    />
                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setShowAddressInput(false)}
                        className="px-3 py-1.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (customAddressInput.trim()) {
                            setDeliveryAddress(customAddressInput.trim());
                            setShowAddressInput(false);
                          }
                        }}
                        className="px-3 py-1.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
                      >
                        Update
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* STEP 2: ORDER ITEMS */}
              <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-emerald-600 text-white text-xs font-bold flex items-center justify-center">
                      2
                    </span>
                    <h3 className="text-base font-bold text-slate-900 font-display">
                      Produce Items ({cartItems.length})
                    </h3>
                  </div>
                  <span className="text-xs font-bold text-slate-500">
                    Direct Farm Sourcing
                  </span>
                </div>

                <div className="divide-y divide-slate-100">
                  {cartItems.map((item) => (
                    <div key={item.id} className="py-3.5 flex items-center justify-between gap-4">
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-12 h-12 rounded-xl object-cover border border-slate-200 flex-shrink-0"
                        />
                        <div className="min-w-0">
                          <h4 className="text-xs font-bold text-slate-900 truncate">
                            {item.name}
                          </h4>
                          <p className="text-[11px] text-slate-500">
                            Producer: <strong className="text-emerald-800">{item.farmer}</strong>
                          </p>
                          <p className="text-[10px] text-slate-400">
                            📍 {item.farmLocation || item.location}
                          </p>
                        </div>
                      </div>

                      <div className="text-right flex-shrink-0">
                        <p className="text-xs font-bold text-slate-900">
                          {item.quantity} {item.unit} × ₹{item.price}
                        </p>
                        <p className="text-xs font-black text-slate-950 font-display">
                          ₹{item.price * item.quantity}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* STEP 3: DELIVERY INFORMATION & FULFILLMENT TYPE */}
              <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-emerald-600 text-white text-xs font-bold flex items-center justify-center">
                      3
                    </span>
                    <h3 className="text-base font-bold text-slate-900 font-display">
                      Delivery Information
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                    EV Green Logistics
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <label
                    className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-start gap-3 ${
                      deliveryType === 'delivery'
                        ? 'bg-emerald-50/70 border-emerald-300'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <input
                      type="radio"
                      name="deliveryType"
                      value="delivery"
                      checked={deliveryType === 'delivery'}
                      onChange={() => setDeliveryType('delivery')}
                      className="mt-1 text-emerald-600 focus:ring-emerald-500"
                    />
                    <div className="space-y-1">
                      <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                        <Truck className="w-4 h-4 text-emerald-700" />
                        <span>Home Delivery</span>
                      </span>
                      <p className="text-[11px] text-slate-500">
                        {deliveryEstimate}
                      </p>
                      <span className="text-[10px] font-bold text-emerald-800">
                        {deliveryFee === 0 ? 'FREE Delivery' : `₹${deliveryFee} EV Delivery Fee`}
                      </span>
                    </div>
                  </label>

                  <label
                    className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-start gap-3 ${
                      deliveryType === 'pickup'
                        ? 'bg-emerald-50/70 border-emerald-300'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <input
                      type="radio"
                      name="deliveryType"
                      value="pickup"
                      checked={deliveryType === 'pickup'}
                      onChange={() => setDeliveryType('pickup')}
                      className="mt-1 text-emerald-600 focus:ring-emerald-500"
                    />
                    <div className="space-y-1">
                      <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                        <Store className="w-4 h-4 text-emerald-700" />
                        <span>Self Pickup from Farm/Hub</span>
                      </span>
                      <p className="text-[11px] text-slate-500">
                        Collect directly from Dankaur FPO staging hub
                      </p>
                      <span className="text-[10px] font-bold text-emerald-800">
                        Zero Delivery Fee
                      </span>
                    </div>
                  </label>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1 text-slate-600">
                  <div className="flex items-center justify-between">
                    <span>Farm-to-Doorstep Distance:</span>
                    <strong className="text-slate-800">{formattedDistance}</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Estimated Turnaround:</span>
                    <strong className="text-emerald-700">{deliveryEstimate}</strong>
                  </div>
                  <p className="text-[10px] text-slate-400 italic pt-1 border-t border-slate-200/60">
                    * Calculated via Haversine distance model. Prototype estimation.
                  </p>
                </div>
              </div>

              {/* STEP 4: PAYMENT OPTIONS */}
              <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-emerald-600 text-white text-xs font-bold flex items-center justify-center">
                      4
                    </span>
                    <h3 className="text-base font-bold text-slate-900 font-display">
                      Payment Method
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200">
                    Prototype Payment
                  </span>
                </div>

                <div className="space-y-3">
                  <label
                    className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-start gap-3.5 ${
                      paymentMethod === 'cod'
                        ? 'bg-emerald-50/70 border-emerald-300'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="cod"
                      checked={paymentMethod === 'cod'}
                      onChange={() => setPaymentMethod('cod')}
                      className="mt-1 text-emerald-600 focus:ring-emerald-500"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <Banknote className="w-4 h-4 text-emerald-700" />
                        <h4 className="text-xs font-bold text-slate-900">
                          Cash on Delivery (Pay upon arrival)
                        </h4>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Inspect produce freshness before making cash or UPI payment directly to the delivery partner.
                      </p>
                    </div>
                  </label>

                  <label
                    className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-start gap-3.5 ${
                      paymentMethod === 'demo_online'
                        ? 'bg-emerald-50/70 border-emerald-300'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="demo_online"
                      checked={paymentMethod === 'demo_online'}
                      onChange={() => setPaymentMethod('demo_online')}
                      className="mt-1 text-emerald-600 focus:ring-emerald-500"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <CreditCard className="w-4 h-4 text-emerald-700" />
                        <h4 className="text-xs font-bold text-slate-900">
                          Demo Online Payment (Escrow Simulation)
                        </h4>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Instant simulation of UPI/Escrow payment without third-party gateway charges.
                      </p>
                    </div>
                  </label>
                </div>
              </div>

            </div>

            {/* Right Column: Order Summary & Place Order CTA (5 cols) */}
            <div className="lg:col-span-5 sticky top-24 space-y-6">
              <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h3 className="text-base font-bold text-slate-900 font-display">
                    Final Order Summary
                  </h3>
                  <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Direct Farm Price
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>Items Subtotal ({cartItems.length} items)</span>
                    <span className="font-mono font-bold text-slate-900">₹{subtotal}</span>
                  </div>

                  <div className="flex justify-between text-slate-600">
                    <span>Delivery Fee</span>
                    <span className="font-mono font-bold text-slate-900">
                      {deliveryType === 'pickup' ? (
                        <span className="text-emerald-700">₹0 (Self Pickup)</span>
                      ) : deliveryFee === 0 ? (
                        <span className="text-emerald-700">FREE</span>
                      ) : (
                        `₹${deliveryFee}`
                      )}
                    </span>
                  </div>

                  {totalSavings > 0 && (
                    <div className="flex justify-between text-emerald-700 font-semibold bg-emerald-50 p-2.5 rounded-xl border border-emerald-200">
                      <span>Total Farm-Gate Savings</span>
                      <span className="font-mono font-bold">-₹{totalSavings}</span>
                    </div>
                  )}

                  <div className="pt-3 border-t border-slate-200 flex justify-between items-baseline">
                    <div>
                      <span className="text-sm font-bold text-slate-900 block">Total Amount</span>
                      <span className="text-[10px] text-slate-400">All local taxes included</span>
                    </div>
                    <span className="text-2xl font-black text-slate-950 font-display">
                      ₹{subtotal + (deliveryType === 'pickup' ? 0 : deliveryFee)}
                    </span>
                  </div>
                </div>

                {/* Direct Farmer Guarantee */}
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 text-[11px] text-slate-600 flex items-start gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                  <p>
                    <strong>100% Direct Payout:</strong> Your payment is routed directly to verified farmers with zero intermediary mandi commission deductions.
                  </p>
                </div>

                <Button
                  type="submit"
                  variant="primary"
                  size="lg"
                  disabled={isSubmitting}
                  className="w-full justify-center shadow-md cursor-pointer"
                  rightIcon={isSubmitting ? Loader2 : ArrowRight}
                >
                  {isSubmitting ? 'Placing Order...' : 'PLACE ORDER'}
                </Button>

                <p className="text-center text-[10px] text-slate-400">
                  By clicking Place Order you agree to FasalSetu prototype terms.
                </p>
              </div>
            </div>

          </div>
        </form>

      </div>
    </div>
  );
}
