import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { 
  Tractor, 
  Building2, 
  ShoppingBag, 
  Truck, 
  ArrowRight, 
  Lock, 
  Mail, 
  Phone, 
  User, 
  MapPin, 
  AlertCircle 
} from 'lucide-react';
import Logo from '../../components/Logo';
import { useAuth, getRoleDashboardPath } from '../../context/AuthContext';
import { INDIAN_STATES } from '../../data/demoData';

const ROLES = [
  { id: 'farmer', label: 'Farmer', icon: Tractor, desc: 'Individual farmer growing produce' },
  { id: 'fpo', label: 'FPO / Cooperative', icon: Building2, desc: 'Farmer Producer Organization cluster' },
  { id: 'consumer', label: 'Consumer', icon: ShoppingBag, desc: 'Household procuring fresh produce' },
  { id: 'bulk_buyer', label: 'Bulk Buyer', icon: Truck, desc: 'Society or commercial B2B procurement' }
];

export default function Register() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { signup, isAuthenticated, role: userRole } = useAuth();

  const roleParam = searchParams.get('role');

  const [selectedRole, setSelectedRole] = useState(() => {
    if (roleParam && ['farmer', 'fpo', 'consumer', 'bulk_buyer'].includes(roleParam)) {
      return roleParam;
    }
    return 'farmer';
  });
  const [prevRoleParam, setPrevRoleParam] = useState(roleParam);

  if (roleParam !== prevRoleParam) {
    setPrevRoleParam(roleParam);
    if (roleParam && ['farmer', 'fpo', 'consumer', 'bulk_buyer'].includes(roleParam)) {
      setSelectedRole(roleParam);
    }
  }

  useEffect(() => {
    if (isAuthenticated && userRole) {
      navigate(getRoleDashboardPath(userRole), { replace: true });
    }
  }, [isAuthenticated, userRole, navigate]);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    entityName: '',
    location: '',
    state: 'Uttar Pradesh',
    // Role-specific extras
    farmSize: '5 Acres',
    primaryCrops: 'Tomato, Potato, Wheat',
    fpoRegNo: '',
    memberCount: '150',
    businessType: 'Retail Aggregator',
    societyName: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [successNotice, setSuccessNotice] = useState(null);

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccessNotice(null);

    const cleanEmail = (formData.email || '').trim().toLowerCase();
    if (cleanEmail.startsWith('testing@')) {
      setError('Supabase Auth flags "testing@" addresses as reserved test emails. Please use a standard email address like yourname@gmail.com.');
      return;
    }

    setIsSubmitting(true);

    try {
      const newUser = await signup({
        ...formData,
        email: cleanEmail,
        role: selectedRole
      });

      if (newUser?.needsEmailConfirmation) {
        setSuccessNotice('Registration successful! A confirmation email has been sent. Please verify your email to log in (or disable "Confirm email" in Supabase Dashboard to log in immediately).');
        setIsSubmitting(false);
        return;
      }

      navigate(getRoleDashboardPath(selectedRole), { replace: true });
    } catch (err) {
      setError(err.message || 'Registration failed');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-slate-50 relative">
      <div className="max-w-xl w-full space-y-6">
        
        {/* Brand */}
        <div className="text-center space-y-2">
          <div className="flex justify-center mb-2">
            <Logo size="md" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 font-display">
            Create FasalSetu Account
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Register your role in India&apos;s direct farm-to-buyer ecosystem.
          </p>
        </div>

        {/* Role Selector */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
            Select Your Role
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {ROLES.map((r) => {
              const Icon = r.icon;
              const isSelected = selectedRole === r.id;
              return (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => setSelectedRole(r.id)}
                  className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1.5 cursor-pointer ${
                    isSelected
                      ? 'border-emerald-600 bg-emerald-50/80 text-emerald-900 ring-2 ring-emerald-500/20'
                      : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-xs font-bold">{r.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-5 text-xs">
          
          {error && (
            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {successNotice && (
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-start gap-2 leading-relaxed">
              <span className="text-base">✅</span>
              <div>
                <p className="font-bold">Account Created</p>
                <p className="text-emerald-700 mt-0.5">{successNotice}</p>
                <Link to="/login" className="inline-block mt-2 font-bold text-emerald-800 underline hover:text-emerald-950">
                  Proceed to Login →
                </Link>
              </div>
            </div>
          )}

          {/* Full Name & Entity Name */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Contact Person Name *
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                  placeholder="e.g. Ramesh Kumar"
                  className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                {selectedRole === 'farmer' ? 'Farm / Holding Name' : selectedRole === 'fpo' ? 'FPO Name *' : selectedRole === 'bulk_buyer' ? 'Company / Society Name *' : 'Household / Society'}
              </label>
              <input
                type="text"
                required={selectedRole !== 'consumer'}
                value={formData.entityName}
                onChange={(e) => handleChange('entityName', e.target.value)}
                placeholder={selectedRole === 'farmer' ? 'e.g. Green Valley Farm' : 'e.g. Kisan Samriddhi FPO'}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 font-medium"
              />
            </div>
          </div>

          {/* Email & Phone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Email Address *
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => handleChange('email', e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Mobile Number *
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => handleChange('phone', e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 font-medium"
                />
              </div>
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Create Password *
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={formData.password}
                onChange={(e) => handleChange('password', e.target.value)}
                placeholder="••••••••••••"
                className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 font-medium"
              />
            </div>
          </div>

          {/* State & City */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Indian State *
              </label>
              <select
                value={formData.state}
                onChange={(e) => handleChange('state', e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 font-medium bg-white"
              >
                {INDIAN_STATES.filter(s => s !== 'All').map(st => (
                  <option key={st} value={st}>{st}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                City / District / Region *
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={formData.location}
                  onChange={(e) => handleChange('location', e.target.value)}
                  placeholder="e.g. Greater Noida"
                  className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 font-medium"
                />
              </div>
            </div>
          </div>

          {/* Submit */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
            >
              {isSubmitting ? (
                <span>Creating Account...</span>
              ) : (
                <>
                  <span>CREATE {selectedRole.toUpperCase().replace('_', ' ')} ACCOUNT</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">Already have an account?</span>
            <Link
              to={`/login?role=${selectedRole}`}
              className="font-bold text-emerald-700 hover:text-emerald-800 hover:underline"
            >
              Login Here →
            </Link>
          </div>

        </form>

      </div>
    </div>
  );
}
