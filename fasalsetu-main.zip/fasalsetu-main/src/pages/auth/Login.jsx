import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { 
  Tractor, 
  Building2, 
  ShoppingBag, 
  Truck, 
  ArrowRight, 
  Lock, 
  Mail, 
  Sparkles,
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import Logo from '../../components/Logo';
import { useAuth, DEMO_ACCOUNTS, getRoleDashboardPath } from '../../context/AuthContext';

const ROLES = [
  {
    id: 'farmer',
    label: "I'm a Farmer",
    icon: Tractor,
    title: 'Farmer Login',
    badge: '🌾 Producer',
    desc: 'List fresh produce, manage farm GPS origins, and track direct orders.',
    demoEmail: DEMO_ACCOUNTS.farmer.email,
    demoPassword: 'demo-farmer-password',
    color: 'emerald'
  },
  {
    id: 'fpo',
    label: "I'm an FPO",
    icon: Building2,
    title: 'FPO Management Login',
    badge: '🏢 Cooperative',
    desc: 'Aggregate multi-farm production, manage member KYC, and coordinate dispatches.',
    demoEmail: DEMO_ACCOUNTS.fpo.email,
    demoPassword: 'demo-fpo-password',
    color: 'emerald'
  },
  {
    id: 'consumer',
    label: "I'm a Consumer",
    icon: ShoppingBag,
    title: 'Consumer Login',
    badge: '🛒 Household',
    desc: 'Procure farm-fresh vegetables and fruits with 4-6 hour morning delivery.',
    demoEmail: DEMO_ACCOUNTS.consumer.email,
    demoPassword: 'demo-consumer-password',
    color: 'teal'
  },
  {
    id: 'bulk_buyer',
    label: "I'm a Bulk Buyer",
    icon: Truck,
    title: 'Bulk Buyer & B2B Login',
    badge: '🚛 Commercial',
    desc: 'Institutional procurement for apartment societies, retail chains, and hotels.',
    demoEmail: DEMO_ACCOUNTS.bulk_buyer.email,
    demoPassword: 'demo-buyer-password',
    color: 'blue'
  },
  {
    id: 'logistics_head',
    label: 'Logistics Head',
    icon: Truck,
    title: 'Regional Logistics Command Login',
    badge: '🗺️ Regional Command',
    desc: 'Supervise regional logistics, operational zones, assigners, and delivery fleets.',
    demoEmail: DEMO_ACCOUNTS.logistics_head.email,
    demoPassword: 'demo-head-password',
    color: 'emerald'
  },
  {
    id: 'delivery_assigner',
    label: 'Zone Assigner',
    icon: Building2,
    title: 'Zone Coordinator & Assigner Login',
    badge: '📍 Zone Operations',
    desc: 'Coordinate local delivery boys, monitor unassigned tasks, and manage exceptions.',
    demoEmail: DEMO_ACCOUNTS.delivery_assigner.email,
    demoPassword: 'demo-assigner-password',
    color: 'teal'
  },
  {
    id: 'delivery_boy',
    label: 'Delivery Boy',
    icon: Tractor,
    title: 'Delivery Partner Login',
    badge: '⚡ Rapid Fleet',
    desc: 'View personal delivery orders, navigate waypoints, and confirm pickups/dropoffs.',
    demoEmail: DEMO_ACCOUNTS.delivery_boy.email,
    demoPassword: 'demo-delivery-password',
    color: 'blue'
  }
];

const VALID_ROLES = ['farmer', 'fpo', 'consumer', 'bulk_buyer', 'logistics_head', 'delivery_assigner', 'delivery_boy'];

export default function Login() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { login, isAuthenticated, role: userRole } = useAuth();

  const roleParam = searchParams.get('role');
  const redirectParam = searchParams.get('redirect');

  // Selected role tab
  const [selectedRole, setSelectedRole] = useState(() => {
    if (roleParam && VALID_ROLES.includes(roleParam)) {
      return roleParam;
    }
    return 'farmer';
  });
  const [prevRoleParam, setPrevRoleParam] = useState(roleParam);

  if (roleParam !== prevRoleParam) {
    setPrevRoleParam(roleParam);
    if (roleParam && VALID_ROLES.includes(roleParam)) {
      setSelectedRole(roleParam);
    }
  }

  // If already authenticated with this role, redirect directly
  useEffect(() => {
    if (isAuthenticated && userRole) {
      const destination = redirectParam ? decodeURIComponent(redirectParam) : getRoleDashboardPath(userRole);
      navigate(destination, { replace: true });
    }
  }, [isAuthenticated, userRole, redirectParam, navigate]);

  const activeRoleConfig = ROLES.find((r) => r.id === selectedRole) || ROLES[0];

  // Form State
  const [emailOrPhone, setEmailOrPhone] = useState(activeRoleConfig.demoEmail);
  const [password, setPassword] = useState('demo-password-123');
  const [error, setError] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Synchronize demo email when role tab switches
  const handleRoleSelect = (roleId) => {
    setSelectedRole(roleId);
    setError(null);
    const cfg = ROLES.find((r) => r.id === roleId);
    if (cfg) {
      setEmailOrPhone(cfg.demoEmail);
      setPassword('demo-password-123');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      await login(emailOrPhone, password, selectedRole);
      const destination = redirectParam ? decodeURIComponent(redirectParam) : getRoleDashboardPath(selectedRole);
      navigate(destination, { replace: true });
    } catch (err) {
      setError(err.message || 'Login failed. Please verify credentials.');
      setIsSubmitting(false);
    }
  };

  const handleUseDemoCredentials = (roleId) => {
    const cfg = ROLES.find((r) => r.id === roleId);
    if (cfg) {
      setEmailOrPhone(cfg.demoEmail);
      setPassword(cfg.demoPassword);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-slate-50 relative overflow-hidden">
      
      {/* Subtle Background Glows */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-96 h-96 bg-emerald-100/60 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-10 right-10 w-80 h-80 bg-blue-100/40 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-xl w-full space-y-6">
        
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="flex justify-center mb-2">
            <Logo size="lg" />
          </div>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Role-Based Portal Access</span>
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 font-display tracking-tight">
            Welcome to FasalSetu
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 max-w-sm mx-auto">
            Choose how you want to continue to access your personalized portal and operations dashboard.
          </p>
        </div>

        {/* Prototype Authentication Notice */}
        <div className="p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200/90 text-amber-900 text-xs flex items-center justify-between gap-2 shadow-xs">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-amber-700 flex-shrink-0" />
            <span><strong>Prototype Authentication:</strong> Use preconfigured demo accounts or register a new one.</span>
          </div>
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider bg-amber-200/60 text-amber-900 px-2 py-0.5 rounded">
            Demo Access
          </span>
        </div>

        {/* =========================================================================
            STEP 1: CHOOSE YOUR ROLE (4 Options)
            ========================================================================= */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-xs space-y-4">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Select Your Account Role
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {ROLES.map((role) => {
              const Icon = role.icon;
              const isSelected = selectedRole === role.id;

              return (
                <button
                  key={role.id}
                  type="button"
                  onClick={() => handleRoleSelect(role.id)}
                  className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-2 cursor-pointer ${
                    isSelected
                      ? 'border-emerald-600 bg-emerald-50/80 text-emerald-900 ring-2 ring-emerald-500/20 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className={`p-2 rounded-xl ${
                    isSelected ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'
                  }`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-bold leading-tight">
                    {role.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* =========================================================================
            STEP 2: ROLE LOGIN FORM
            ========================================================================= */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-sm space-y-6">
          
          <div className="flex items-start justify-between pb-3 border-b border-slate-100">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 font-mono">
                {activeRoleConfig.badge}
              </span>
              <h2 className="text-xl font-bold text-slate-900 font-display">
                {activeRoleConfig.title}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {activeRoleConfig.desc}
              </p>
            </div>

            <button
              type="button"
              onClick={() => handleUseDemoCredentials(selectedRole)}
              className="text-[11px] font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-3 py-1.5 rounded-xl transition-colors cursor-pointer"
            >
              Fill Demo Login
            </button>
          </div>

          {error && (
            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            
            <div className="space-y-1">
              <label className="block font-bold text-slate-700">
                Email Address or Mobile Number
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={emailOrPhone}
                  onChange={(e) => setEmailOrPhone(e.target.value)}
                  placeholder="e.g. farmer@fasalsetu.demo or +91 98765 43210"
                  className="w-full pl-10 pr-4 py-3 rounded-2xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 text-xs font-medium"
                />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block font-bold text-slate-700">
                  Password
                </label>
                <span className="text-[11px] text-slate-400">Any demo password</span>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-10 pr-4 py-3 rounded-2xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 text-xs font-medium"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-xs sm:text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
              >
                {isSubmitting ? (
                  <span>Authenticating...</span>
                ) : (
                  <>
                    <span>LOGIN AS {activeRoleConfig.label.toUpperCase().replace("I'M A ", "")}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>

          </form>

          {/* Quick Registration Link */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">Don&apos;t have an account?</span>
            <Link
              to={`/register?role=${selectedRole}`}
              className="font-bold text-emerald-700 hover:text-emerald-800 hover:underline"
            >
              Create {activeRoleConfig.label.replace("I'm a ", "")} Account →
            </Link>
          </div>

        </div>

      </div>

    </div>
  );
}
