import React, { useState } from 'react';
import { 
  Sparkles, 
  RotateCw, 
  Clock, 
  Search, 
  AlertCircle, 
  ChevronRight,
  Truck,
  FileText,
  Printer,
  Database,
  Layers
} from 'lucide-react';
import { useAI } from '../context/AIContext';
import DemandTrendBadge from '../components/ai/DemandTrendBadge';
import SupplyStatusBadge from '../components/ai/SupplyStatusBadge';
import ForecastConfidence from '../components/ai/ForecastConfidence';
import ForecastChart from '../components/ai/ForecastChart';
import DemandHeatmap from '../components/ai/DemandHeatmap';
import ForecastDetailModal from '../components/ai/ForecastDetailModal';
import SmartMatchCard from '../components/ai/SmartMatchCard';
import SupplyChainHealthCard from '../components/ai/SupplyChainHealthCard';

export default function AIInsights() {
  const { 
    forecasts, 
    regionalDemand, 
    supplyDemandGaps,
    smartMatches,
    redistributionOpportunities,
    supplyChainHealth,
    kpis, 
    loading, 
    refreshing, 
    lastUpdated, 
    error, 
    refreshForecasts,
    dataComposition
  } = useAI();

  const [activeTab, setActiveTab] = useState('demand'); // 'demand', 'gaps', 'matches', 'redistribution', 'scorecard'
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedRegion, setSelectedRegion] = useState('All');
  const [activeModalForecast, setActiveModalForecast] = useState(null);
  const [showReportModal, setShowReportModal] = useState(false);

  // Filtered forecasts
  const filteredForecasts = forecasts.filter((f) => {
    const matchesSearch = f.cropName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || f.category === selectedCategory;
    const matchesRegion = selectedRegion === 'All' || f.primaryDistrict === selectedRegion;
    return matchesSearch && matchesCategory && matchesRegion;
  });

  // Filtered gaps
  const filteredGaps = supplyDemandGaps.filter((g) => {
    const matchesSearch = g.cropName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRegion = selectedRegion === 'All' || g.district === selectedRegion;
    return matchesSearch && matchesRegion;
  });

  const uniqueDistricts = Array.from(new Set(forecasts.map((f) => f.primaryDistrict).filter(Boolean)));
  const uniqueCategories = ['All', 'Vegetables', 'Grains', 'Fruits', 'Spices'];

  const formattedLastUpdated = lastUpdated
    ? new Date(lastUpdated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : 'Just now';

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* =========================================================================
            1. PAGE HEADER & REPORT TRIGGER
            ========================================================================= */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800">
                <Sparkles className="w-3.5 h-3.5" />
                Smart Supply Chain Intelligence
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1">
                <Clock className="w-3 h-3" />
                Updated: Today, {formattedLastUpdated}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              AI Supply-Chain Intelligence Center
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-300 mt-1 max-w-2xl">
              Coordinating harvest supply, regional demand, procurement bundles, and fleet logistics across Pan-India corridors.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowReportModal(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 transition-all"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Intelligence Report</span>
            </button>

            <button
              onClick={refreshForecasts}
              disabled={refreshing || loading}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold border transition-all ${
                refreshing || loading
                  ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed dark:bg-slate-800 dark:border-slate-700'
                  : 'bg-primary hover:bg-primary-dark text-white border-transparent shadow-sm'
              }`}
            >
              <RotateCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
              <span>{refreshing ? 'Computing Intelligence...' : 'Refresh Intelligence'}</span>
            </button>
          </div>
        </div>

        {/* Error notification */}
        {error && (
          <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 flex items-center gap-3 text-amber-800 dark:text-amber-300 text-xs">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Hybrid Data Composition Transparency Banner */}
        {dataComposition && (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 flex items-center justify-center text-emerald-700 dark:text-emerald-400 shrink-0">
                <Database className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900 dark:text-white">
                    Hybrid Intelligence Pipeline
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                    {dataComposition.hasLiveData ? 'Live + Baseline Merged' : 'Baseline Verified'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  {dataComposition.label}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 sm:gap-3 text-[11px] self-end sm:self-center">
              <span className="px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 font-semibold flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                {dataComposition.liveProducts} Live Products
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800 font-semibold flex items-center gap-1.5">
                <Layers className="w-3 h-3 text-amber-600" />
                {dataComposition.demoProducts} Baseline Samples
              </span>
            </div>
          </div>
        )}

        {/* =========================================================================
            2. SUPPLY CHAIN HEALTH SCORECARD
            ========================================================================= */}
        <SupplyChainHealthCard health={supplyChainHealth} />

        {/* =========================================================================
            3. TAB NAVIGATION (Demand, Gaps, Matches, Redistribution, Regional Heatmap)
            ========================================================================= */}
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('demand')}
            className={`px-4 py-2 rounded-xl transition-all ${
              activeTab === 'demand'
                ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            AI Demand Forecasts ({forecasts.length})
          </button>
          <button
            onClick={() => setActiveTab('gaps')}
            className={`px-4 py-2 rounded-xl transition-all ${
              activeTab === 'gaps'
                ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            Supply-Demand Gaps ({supplyDemandGaps.length})
          </button>
          <button
            onClick={() => setActiveTab('matches')}
            className={`px-4 py-2 rounded-xl transition-all ${
              activeTab === 'matches'
                ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            Smart Matches ({smartMatches.length})
          </button>
          <button
            onClick={() => setActiveTab('redistribution')}
            className={`px-4 py-2 rounded-xl transition-all ${
              activeTab === 'redistribution'
                ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            🚚 Logistics & Redistribution ({redistributionOpportunities.length})
          </button>
        </div>

        {/* =========================================================================
            TAB CONTENT: 1. DEMAND FORECASTS
            ========================================================================= */}
        {activeTab === 'demand' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ForecastChart forecasts={forecasts} />
              <DemandHeatmap regionalData={regionalDemand} />
            </div>

            {/* Demand Table */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
              <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Live Agricultural Demand Matrix
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Granular supply-demand ratios with transparent confidence ratings
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Search produce..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-8 pr-3 py-1.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 w-44"
                    />
                  </div>
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="px-3 py-1.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    {uniqueCategories.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>

                  {uniqueDistricts.length > 0 && (
                    <select
                      value={selectedRegion}
                      onChange={(e) => setSelectedRegion(e.target.value)}
                      className="px-3 py-1.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    >
                      <option value="All">All Regions</option>
                      {uniqueDistricts.map((d) => (
                        <option key={d} value={d}>{d}</option>
                      ))}
                    </select>
                  )}
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
                  <thead className="bg-slate-50 dark:bg-slate-800/60 text-[11px] uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-100 dark:border-slate-800">
                    <tr>
                      <th className="py-3 px-4 font-semibold">Product</th>
                      <th className="py-3 px-4 font-semibold">Region</th>
                      <th className="py-3 px-4 font-semibold">Demand Trend</th>
                      <th className="py-3 px-4 font-semibold">Supply Status</th>
                      <th className="py-3 px-4 font-semibold text-right">Available Supply</th>
                      <th className="py-3 px-4 font-semibold text-right">Forecast Demand</th>
                      <th className="py-3 px-4 font-semibold">Confidence</th>
                      <th className="py-3 px-4 font-semibold text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredForecasts.map((forecast, idx) => (
                      <tr
                        key={idx}
                        onClick={() => setActiveModalForecast(forecast)}
                        className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 cursor-pointer transition-colors"
                      >
                        <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white">
                          {forecast.cropName}
                          <span className="block text-[10px] font-normal text-slate-400">
                            {forecast.category}
                          </span>
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="font-medium text-slate-800 dark:text-slate-200">
                            {forecast.primaryDistrict}
                          </span>
                          <span className="block text-[10px] text-slate-400">
                            {forecast.primaryState}
                          </span>
                        </td>
                        <td className="py-3.5 px-4">
                          <DemandTrendBadge
                            classification={forecast.classification}
                            growthPercent={forecast.growthPercent}
                            size="sm"
                          />
                        </td>
                        <td className="py-3.5 px-4">
                          <SupplyStatusBadge status={forecast.supplyStatus} size="sm" />
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono font-medium">
                          {forecast.availableSupply.toLocaleString()} kg
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400">
                          ~{forecast.forecastQuantity.toLocaleString()} kg
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="w-28">
                            <ForecastConfidence
                              score={forecast.confidenceScore}
                              tier={forecast.confidenceTier}
                              showBar={true}
                            />
                          </div>
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveModalForecast(forecast);
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-colors"
                            title="Inspect AI Logic"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB CONTENT: 2. SUPPLY-DEMAND GAPS
            ========================================================================= */}
        {activeTab === 'gaps' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/50">
                <div className="text-xs text-rose-600 dark:text-rose-400 font-semibold mb-1">Potential Shortages</div>
                <div className="text-2xl font-black text-rose-700 dark:text-rose-300">
                  {supplyDemandGaps.filter(g => g.status === 'Potential Shortage').length} Regions
                </div>
                <div className="text-[11px] text-rose-600/80 mt-1">High procurement deficit signals</div>
              </div>
              <div className="p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-900/50">
                <div className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold mb-1">Potential Surpluses</div>
                <div className="text-2xl font-black text-indigo-700 dark:text-indigo-300">
                  {supplyDemandGaps.filter(g => g.status === 'Potential Surplus').length} Regions
                </div>
                <div className="text-[11px] text-indigo-600/80 mt-1">Prime for inter-regional redistribution</div>
              </div>
              <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800">
                <div className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold mb-1">Balanced Corridors</div>
                <div className="text-2xl font-black text-emerald-700 dark:text-emerald-300">
                  {supplyDemandGaps.filter(g => g.status === 'Balanced').length} Regions
                </div>
                <div className="text-[11px] text-emerald-600/80 mt-1">Stable supply-consumption equilibrium</div>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-4">
                Regional Gap Analysis Matrix
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredGaps.map((gap, idx) => (
                  <div key={idx} className="p-4 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-bold text-slate-900 dark:text-white text-sm">{gap.cropName}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          gap.status === 'Potential Shortage'
                            ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                            : gap.status === 'Potential Surplus'
                            ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300'
                            : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                        }`}>
                          {gap.status}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 mb-3">{gap.district}, {gap.state}</div>

                      <div className="grid grid-cols-2 gap-2 text-xs mb-3">
                        <div className="p-2 rounded bg-white dark:bg-slate-900">
                          <span className="text-slate-400 block text-[10px]">Forecast Demand</span>
                          <span className="font-bold text-slate-800 dark:text-slate-200">{gap.forecastDemand.toLocaleString('en-IN')} kg</span>
                        </div>
                        <div className="p-2 rounded bg-white dark:bg-slate-900">
                          <span className="text-slate-400 block text-[10px]">Available Supply</span>
                          <span className="font-bold text-slate-800 dark:text-slate-200">{gap.availableSupply.toLocaleString('en-IN')} kg</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-[11px] text-slate-600 dark:text-slate-400 border-t border-slate-200 dark:border-slate-700/60 pt-2">
                      {gap.explanation}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB CONTENT: 3. SMART MATCHES
            ========================================================================= */}
        {activeTab === 'matches' && (
          <div className="space-y-6">
            <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 text-xs text-emerald-900 dark:text-emerald-200 flex items-start gap-2.5">
              <Sparkles className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Automated Farmer–Buyer Compatibility Engine</span>
                <p className="mt-0.5 text-emerald-800 dark:text-emerald-300">
                  Scores compatibility using centralized prototype weights: Quantity (25%), Distance (20%), Quality (20%), Price (15%), Freshness (10%), and Demand Relevance (10%).
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {smartMatches.map((match, idx) => (
                <SmartMatchCard key={idx} match={match} />
              ))}
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB CONTENT: 4. REDISTRIBUTION & LOGISTICS
            ========================================================================= */}
        {activeTab === 'redistribution' && (
          <div className="space-y-6">
            <div className="p-4 rounded-2xl bg-blue-50/70 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/40 text-xs text-blue-900 dark:text-blue-200 flex items-start gap-2.5">
              <Truck className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Hyperlocal Fleet Integration</span>
                <p className="mt-0.5 text-blue-800 dark:text-blue-300">
                  Matches regional crop surpluses with nearby deficit centers, cross-checking available vehicle capacity on active scheduled routes.
                </p>
              </div>
            </div>

            {redistributionOpportunities.length === 0 ? (
              <div className="text-center py-12 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl">
                <Truck className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <div className="text-sm font-bold text-slate-700 dark:text-slate-300">No Imbalanced Corridors Detected</div>
                <div className="text-xs text-slate-500 mt-1">Current regional supply and demand are currently within balanced parameters.</div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {redistributionOpportunities.map((plan, idx) => (
                  <div key={idx} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300 border border-blue-200">
                          Consolidation Opportunity
                        </span>
                        <h4 className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                          {plan.cropName}: {plan.originRegion} → {plan.destinationRegion}
                        </h4>
                      </div>
                      <div className="text-right">
                        <div className="text-xs text-slate-400">Transfer Load</div>
                        <div className="text-base font-bold text-emerald-600">~{plan.transferableQuantity.toLocaleString('en-IN')} kg</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-xs mb-4 text-center">
                      <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/50">
                        <div className="text-slate-400 text-[10px]">Corridor Distance</div>
                        <div className="font-bold text-slate-800 dark:text-slate-200">~{plan.distanceKm} km</div>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/50">
                        <div className="text-slate-400 text-[10px]">Vehicle Class</div>
                        <div className="font-bold text-slate-800 dark:text-slate-200">{plan.recommendedVehicle}</div>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/50">
                        <div className="text-slate-400 text-[10px]">Existing Route</div>
                        <div className="font-bold text-primary">{plan.existingRouteAvailable ? plan.existingRouteNumber : 'New Dispatch'}</div>
                      </div>
                    </div>

                    <div className="bg-slate-50 dark:bg-slate-800/30 rounded-xl p-3 mb-4">
                      <div className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Redistribution Rationale:</div>
                      <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-400">
                        {plan.explanationBullets.map((bullet, bIdx) => (
                          <li key={bIdx} className="flex items-start gap-1.5">
                            <span className="text-primary">•</span>
                            <span>{bullet}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="text-xs text-slate-500 italic">
                      *Decision-support recommendation only. FasalSetu does not automatically transfer inventory.
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* =========================================================================
          REPORT MODAL
          ========================================================================= */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full p-6 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">FasalSetu Smart Supply Chain Report</h3>
                <p className="text-xs text-slate-500">Generated on {new Date().toLocaleDateString('en-IN')} at {new Date().toLocaleTimeString()}</p>
              </div>
              <button
                onClick={() => window.print()}
                className="px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 hover:bg-slate-50"
              >
                <Printer className="w-3.5 h-3.5" /> Print Report
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800">
                <div className="font-bold mb-1">1. Demand Summary:</div>
                <div>Active products tracked: {kpis.productsAnalyzed}. Demand signals rising: {kpis.demandSignals}.</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800">
                <div className="font-bold mb-1">2. Supply-Demand Gaps:</div>
                <div>Potential Shortages: {kpis.potentialShortages}. Potential Surpluses: {kpis.potentialSurpluses}.</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800">
                <div className="font-bold mb-1">3. Fleet & Redistribution:</div>
                <div>Active corridors evaluated: {redistributionOpportunities.length}. Logistics health: {supplyChainHealth?.logisticsEfficiency}%.</div>
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t">
              <button
                onClick={() => setShowReportModal(false)}
                className="px-4 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl text-xs font-semibold"
              >
                Close Report
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Detail Modal */}
      {activeModalForecast && (
        <ForecastDetailModal
          forecast={activeModalForecast}
          onClose={() => setActiveModalForecast(null)}
        />
      )}
    </div>
  );
}
