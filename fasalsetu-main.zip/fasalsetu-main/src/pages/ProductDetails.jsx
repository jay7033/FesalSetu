import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  MapPin, 
  Clock, 
  Sparkles, 
  ShoppingBag, 
  Check, 
  ArrowLeft, 
  ShieldCheck, 
  Truck, 
  Scale, 
  TrendingDown,
  ChevronRight
} from 'lucide-react';
import ProductImage from '../components/ProductImage';
import ProductCard from '../components/ProductCard';
import { useCart } from '../context/CartContext';
import { useProducts } from '../context/ProductContext';
import { useLocation } from '../context/LocationContext';
import { calculateDistance, formatDistance } from '../utils/distance';

export default function ProductDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addItem } = useCart();
  const { products } = useProducts();
  const { buyerLocation } = useLocation();

  const product = products.find((p) => p.id === id) || products[0];

  const defaultStep = product.unit === 'kg' ? 5 : 1;
  const [selectedQuantity, setSelectedQuantity] = useState(defaultStep);
  const [isAdded, setIsAdded] = useState(false);

  const presets = product.unit === 'kg' ? [5, 10, 25, 50, 100] : [1, 2, 5, 10, 20];

  const handleAddToCart = () => {
    addItem(product, selectedQuantity);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  // Price calculations for Transparent Pricing section
  const typicalRetail = product.typicalRetailPrice || Math.round(product.price * 1.38);
  const fasalSetuPrice = product.price;
  const buyerSaving = Math.max(0, typicalRetail - fasalSetuPrice);
  const farmerDirectPrice = product.price; // 100% of price goes to farmer direct

  // Dynamic distance calculation if buyerLocation exists
  const computedDistanceKm = 
    buyerLocation && product.latitude && product.longitude
      ? calculateDistance(buyerLocation.latitude, buyerLocation.longitude, product.latitude, product.longitude)
      : null;

  const displayDistance = computedDistanceKm !== null 
    ? formatDistance(computedDistanceKm)
    : product.distance || 'Direct Farm Gate';

  const displayLocation = product.approximateLocation || `Near ${product.location}, ${product.state || 'India'}`;

  // Related products from same category or location
  const relatedProducts = products.filter(
    (p) => p.id !== product.id && (p.category === product.category || p.location === product.location)
  ).slice(0, 3);

  return (
    <div className="bg-slate-50 min-h-screen pb-24">
      
      {/* Breadcrumb Navigation */}
      <div className="bg-white border-b border-slate-200/80 py-3.5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Link to="/" className="hover:text-emerald-700 transition-colors">
              Home
            </Link>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
            <Link to="/marketplace" className="hover:text-emerald-700 transition-colors">
              Marketplace
            </Link>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
            <span className="font-semibold text-slate-900 truncate">
              {product.name}
            </span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        
        {/* Back Link */}
        <button
          type="button"
          onClick={() => navigate('/marketplace')}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 hover:text-emerald-800 mb-6 hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Marketplace</span>
        </button>

        {/* Main Product Showcase Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Left: Large Product Image & Key Badges (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="relative rounded-3xl overflow-hidden border border-slate-200/90 shadow-md bg-white aspect-4/3 sm:aspect-square">
              <ProductImage
                src={product.image}
                alt={product.name}
                category={product.category}
                containerClassName="w-full h-full"
              />

              {/* Badges Overlay */}
              <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none">
                <div className="flex flex-wrap gap-1.5">
                  {product.organic && (
                    <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-600 text-white shadow-md flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                      <span>Certified Organic</span>
                    </span>
                  )}
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-white/95 text-slate-900 shadow-md backdrop-blur-md border border-slate-200">
                    {product.quality} Grade
                  </span>
                </div>

                {product.isDemo ? (
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-950/80 text-amber-300 backdrop-blur-md font-mono border border-amber-400/30">
                    Sample Listing
                  </span>
                ) : (
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-950/80 text-emerald-300 backdrop-blur-md font-mono border border-emerald-400/30 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    Live Farm Batch
                  </span>
                )}
              </div>

              {/* Bottom origin strip */}
              <div className="absolute bottom-4 left-4 right-4 p-3 rounded-2xl bg-slate-950/80 backdrop-blur-md text-white flex items-center justify-between text-xs">
                <span className="flex items-center gap-1.5 truncate max-w-[70%]">
                  <MapPin className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span className="font-semibold truncate">{displayLocation}</span>
                </span>
                <span className="font-mono text-emerald-300 text-[11px] font-bold">
                  {displayDistance}
                </span>
              </div>
            </div>

            {/* Quick Dispatch Highlights */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 flex items-center gap-3">
                <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-slate-800">Harvest Time</p>
                  <p className="text-slate-500 text-[11px]">{product.harvestDate}</p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 flex items-center gap-3">
                <div className="p-2 rounded-xl bg-amber-50 text-amber-700">
                  <Truck className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-slate-800">Direct Transit</p>
                  <p className="text-slate-500 text-[11px]">Direct farm-to-door network</p>
                </div>
              </div>
            </div>

          </div>

          {/* Right: Product Details, Pricing, Quantity & Add to Cart (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Header / Producer info */}
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-emerald-700">
                <span className="px-2.5 py-0.5 rounded-md bg-emerald-50 border border-emerald-200">
                  {product.category}
                </span>
                <span>•</span>
                <span>{product.farmerType}</span>
                <span>•</span>
                {product.isDemo ? (
                  <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 text-[11px] font-semibold border border-amber-200">
                    Sample Catalog
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 text-[11px] font-semibold border border-emerald-200 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                    Live User Listing
                  </span>
                )}
              </div>

              <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-950 font-display tracking-tight">
                {product.name}
              </h1>

              <div className="flex flex-wrap items-center gap-3 text-sm text-slate-600 pt-1">
                <span className="font-bold text-slate-900">{product.farmer}</span>
                <span className="text-slate-300">•</span>
                <span className="flex items-center gap-1 text-slate-600">
                  <MapPin className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                  <span>{displayLocation}</span>
                </span>
                <span className="text-slate-300">•</span>
                <span className="flex items-center gap-1 text-emerald-700 font-semibold text-xs">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Verified Producer</span>
                </span>
              </div>
            </div>

            {/* Price Box */}
            <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Direct Farm-Gate Price
                </span>
                <div className="flex items-baseline gap-2 mt-0.5">
                  <span className="text-4xl font-black text-slate-950 font-display">
                    ₹{product.price}
                  </span>
                  <span className="text-base font-semibold text-slate-600">
                    per {product.unit}
                  </span>
                </div>
                <p className="text-xs text-emerald-700 font-semibold mt-1">
                  Save ₹{buyerSaving}/{product.unit} vs typical Mandi retail price
                </p>
              </div>

              <div className="sm:text-right border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-100">
                <span className="text-xs font-semibold text-slate-500">Available Batch Stock</span>
                <div className="text-xl font-bold text-slate-900 flex items-center sm:justify-end gap-1.5 mt-0.5">
                  <Scale className="w-4 h-4 text-emerald-600" />
                  <span>{product.quantityAvailable} {product.unit}</span>
                </div>
                <span className="inline-block mt-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  Ready for Immediate Morning Dispatch
                </span>
              </div>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Harvest & Produce Description
              </h3>
              <p className="text-slate-700 text-sm sm:text-base leading-relaxed">
                {product.description}
              </p>
            </div>

            {/* Quantity Selector & Add to Cart */}
            <div className="p-6 rounded-3xl bg-emerald-50/60 border border-emerald-200/80 space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-wider text-emerald-950">
                  Select Order Quantity ({product.unit})
                </label>
                <span className="text-xs text-emerald-800 font-medium">
                  Min order: {defaultStep} {product.unit}
                </span>
              </div>

              {/* Quantity Presets */}
              <div className="flex flex-wrap gap-2">
                {presets.map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setSelectedQuantity(preset)}
                    className={`text-xs px-3.5 py-2 rounded-xl font-bold transition-all ${
                      selectedQuantity === preset
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'bg-white text-slate-700 hover:bg-emerald-100/60 border border-slate-200'
                    }`}
                  >
                    {preset} {product.unit}
                  </button>
                ))}
              </div>

              {/* Stepper + Total estimate */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 pt-2 border-t border-emerald-200/60">
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setSelectedQuantity(Math.max(defaultStep, selectedQuantity - defaultStep))}
                    className="w-10 h-10 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 font-bold text-lg flex items-center justify-center"
                  >
                    -
                  </button>
                  <span className="text-base font-black text-slate-900 font-mono w-16 text-center">
                    {selectedQuantity} {product.unit}
                  </span>
                  <button
                    type="button"
                    onClick={() => setSelectedQuantity(Math.min(product.quantityAvailable, selectedQuantity + defaultStep))}
                    className="w-10 h-10 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 font-bold text-lg flex items-center justify-center"
                  >
                    +
                  </button>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-3">
                  <div className="text-right">
                    <p className="text-[10px] text-slate-500 uppercase font-semibold">Total Cost</p>
                    <p className="text-xl font-black text-slate-950 font-display">
                      ₹{selectedQuantity * product.price}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={handleAddToCart}
                    className={`py-3.5 px-6 rounded-2xl font-bold text-sm transition-all duration-200 flex items-center justify-center gap-2 shadow-md ${
                      isAdded
                        ? 'bg-emerald-800 text-white'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white hover:shadow-lg'
                    }`}
                  >
                    {isAdded ? (
                      <>
                        <Check className="w-5 h-5 text-white" />
                        <span>Added to Cart!</span>
                      </>
                    ) : (
                      <>
                        <ShoppingBag className="w-5 h-5" />
                        <span>ADD TO CART</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* =========================================================================
                PRICE TRANSPARENCY SECTION
                ========================================================================= */}
            <div className="bg-white rounded-3xl border border-slate-200/90 p-6 space-y-4 shadow-xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700">
                    <TrendingDown className="w-4 h-4" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 font-display">
                    Transparent Pricing
                  </h3>
                </div>

                {/* Important Disclaimer badge */}
                <span className="text-[10px] font-semibold text-amber-800 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
                  Illustrative prototype values
                </span>
              </div>

              {/* Breakdown Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80">
                  <p className="text-[10px] text-slate-500 font-semibold uppercase">Typical Retail</p>
                  <p className="text-lg font-bold text-slate-400 line-through mt-0.5">
                    ₹{typicalRetail}/{product.unit}
                  </p>
                  <p className="text-[10px] text-slate-400 mt-1">Multi-broker mandi</p>
                </div>

                <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200">
                  <p className="text-[10px] text-emerald-800 font-bold uppercase">FasalSetu Price</p>
                  <p className="text-xl font-black text-emerald-700 mt-0.5">
                    ₹{fasalSetuPrice}/{product.unit}
                  </p>
                  <p className="text-[10px] text-emerald-700 mt-1">Direct from farmer</p>
                </div>

                <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200">
                  <p className="text-[10px] text-amber-800 font-bold uppercase">Buyer Saving</p>
                  <p className="text-xl font-black text-amber-700 mt-0.5">
                    ₹{buyerSaving}/{product.unit}
                  </p>
                  <p className="text-[10px] text-amber-700 mt-1">Zero intermediary fee</p>
                </div>

                <div className="p-3.5 rounded-2xl bg-teal-50 border border-teal-200">
                  <p className="text-[10px] text-teal-800 font-bold uppercase">Farmer Direct</p>
                  <p className="text-xl font-black text-teal-800 mt-0.5">
                    ₹{farmerDirectPrice}/{product.unit}
                  </p>
                  <p className="text-[10px] text-teal-700 mt-1">100% farm-gate transfer</p>
                </div>
              </div>

              <p className="text-[11px] text-slate-500 italic">
                * Note: Illustrative prototype values demonstrating economic benefit for direct farm-to-consumer clusters.
              </p>
            </div>

            {/* =========================================================================
                WHY BUY DIRECT? (3 BENEFITS)
                🌾 Better farmer price realization
                💰 Fairer buyer pricing
                📍 Farm-Gate Traceability
                ========================================================================= */}
            <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-7 space-y-4 shadow-md">
              <h3 className="text-base font-bold font-display text-emerald-400 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Why Buy Direct on FasalSetu?</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-1.5">
                  <div className="text-xl">🌾</div>
                  <h4 className="text-xs font-bold text-white">
                    Better farmer price realization
                  </h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Farmers keep the full crop value without multi-tier APMC brokerage deductions.
                  </p>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-1.5">
                  <div className="text-xl">💰</div>
                  <h4 className="text-xs font-bold text-white">
                    Fairer buyer pricing
                  </h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Buyers pay direct wholesale rates by bypassing 4-6 layers of middlemen.
                  </p>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-1.5">
                  <div className="text-xl">📍</div>
                  <h4 className="text-xs font-bold text-white">
                    Farm-Gate Freshness
                  </h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Rapid harvest-to-table transit schedules preserving natural nutritional value and freshness.
                  </p>
                </div>
              </div>
            </div>

          </div>

        </div>

        {/* Related Local Produce */}
        {relatedProducts.length > 0 && (
          <div className="mt-16 pt-12 border-t border-slate-200 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">
                  Regional Harvest
                </span>
                <h2 className="text-2xl font-bold text-slate-900 font-display">
                  More Produce from {product.location} & Nearby Hubs
                </h2>
              </div>

              <Link
                to="/marketplace"
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 hover:underline"
              >
                <span>View all marketplace</span>
                <ChevronRight className="w-4 h-4" />
              </Link>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {relatedProducts.map((p) => (
                <ProductCard key={p.id} product={p} buyerLocation={buyerLocation} />
              ))}
            </div>
          </div>
        )}

      </div>

    </div>
  );
}
