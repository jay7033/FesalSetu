import React, { useState } from 'react';
import { useOutletContext, Link } from 'react-router-dom';
import { 
  Truck, 
  Building2, 
  Scale, 
  Clock, 
  Store, 
  PlusCircle, 
  MapPin, 
  ShieldCheck, 
  Star, 
  TrendingDown, 
  FileText,
  Package,
  AlertCircle,
  Sparkles
} from 'lucide-react';
import DashboardHeader from '../../components/dashboard/DashboardHeader';
import DashboardStatCard from '../../components/dashboard/DashboardStatCard';
import StatusBadge from '../../components/dashboard/StatusBadge';
import QuickActions from '../../components/dashboard/QuickActions';
import Button from '../../components/Button';
import ShipmentStatus from '../../components/logistics/ShipmentStatus';
import RouteSummary from '../../components/logistics/RouteSummary';
import ProcurementRecommendationCard from '../../components/ai/ProcurementRecommendationCard';
import { useAuth } from '../../context/AuthContext';
import { useBuyer } from '../../context/BuyerContext';
import { useOrders } from '../../context/OrderContext';
import { useAI } from '../../context/AIContext';
import { useLogistics } from '../../context/LogisticsContext';

export default function BulkBuyerDashboard() {
  const { user } = useAuth();
  const context = useOutletContext();
  const activeTab = context?.activeTab || 'overview';
  const setActiveTab = context?.setActiveTab || (() => {});

  const {
    bulkProduceCrops,
    suppliersList,
    priceComparisonData,
    preferredLocations,
    addPreferredLocation,
    removePreferredLocation
  } = useBuyer();

  const { orders, createOrder } = useOrders();
  const { getBuyerInsights, getProcurementPlan } = useAI();
  const { shipments, routes } = useLogistics();

  const buyerSignals = getBuyerInsights(preferredLocations);
  const samplePlan = getProcurementPlan({
    cropName: 'Desi Tomato',
    quantity: 1500,
    targetPrice: 28,
    buyerLocation: { latitude: 28.5355, longitude: 77.3910, city: 'Noida' }
  });

  const [showLocationModal, setShowLocationModal] = useState(false);
  const [newCity, setNewCity] = useState('');
  const [newState, setNewState] = useState('Uttar Pradesh');

  const [showOrderModal, setShowOrderModal] = useState(false);
  const [selectedCropForOrder, setSelectedCropForOrder] = useState(null);
  const [orderQuantity, setOrderQuantity] = useState('500');
  const [orderSuccessMsg, setOrderSuccessMsg] = useState(null);

  const buyerName = user?.entityName || user?.name || 'FreshMart Retail & Institutional';

  const isDemo = !user || user.isDemo || user.email === 'bulk@fasalsetu.demo';
  const bulkOrders = orders.filter((o) => {
    if (isDemo) return o.buyerRole === 'bulk_buyer';
    return o.buyerId === user?.id || (o.buyerRole === 'bulk_buyer' && !o.isDemo);
  });

  const handleAddLocation = (e) => {
    e.preventDefault();
    if (!newCity) return;
    addPreferredLocation({
      city: newCity,
      state: newState,
      distance: 'Regional Corridor'
    });
    setNewCity('');
    setShowLocationModal(false);
  };

  const [orderError, setOrderError] = useState(null);
  const [selectedSupplierId, setSelectedSupplierId] = useState('sup_1');
  const [bulkDeliveryType, setBulkDeliveryType] = useState('delivery');
  const [isSubmittingOrder, setIsSubmittingOrder] = useState(false);

  const handlePlaceBulkOrder = async (e) => {
    e.preventDefault();
    if (!selectedCropForOrder || isSubmittingOrder) return;
    setOrderError(null);
    setIsSubmittingOrder(true);

    const qty = Number(orderQuantity) || 0;
    // Extract numerical MOQ from string e.g. "500 kg" -> 500
    const moqMatch = selectedCropForOrder.minOrder ? selectedCropForOrder.minOrder.match(/\d+/) : null;
    const moq = moqMatch ? Number(moqMatch[0]) : 500;

    if (qty < moq) {
      setOrderError(`Minimum order quantity for ${selectedCropForOrder.crop} is ${moq} kg.`);
      setIsSubmittingOrder(false);
      return;
    }

    try {
      const supplier = suppliersList.find((s) => s.id === selectedSupplierId) || suppliersList[0];
      const estRate = 28;
      const subtotal = qty * estRate;
      const freightFee = bulkDeliveryType === 'pickup' ? 0 : 750;

      await createOrder({
        buyerId: user?.id || 'bulk_buyer_1',
        buyerName: buyerName,
        buyerRole: 'bulk_buyer',
        farmerId: supplier.type.includes('Farmer') ? supplier.id : undefined,
        farmerName: supplier.name,
        fpoId: supplier.type.includes('FPO') ? supplier.id : undefined,
        fpoName: supplier.name,
        product: selectedCropForOrder.crop,
        quantity: qty,
        unit: 'kg',
        amount: subtotal + freightFee,
        subtotal: subtotal,
        deliveryFee: freightFee,
        total: subtotal + freightFee,
        deliveryType: bulkDeliveryType,
        deliveryEstimate: bulkDeliveryType === 'pickup' ? 'Ready for FPO yard pickup in 4 hrs' : 'Dedicated Freight (Within 24-48 Hours)',
        location: supplier.location,
        buyerLocation: {
          address: 'Noida Sector 62 Distribution Center, Gautam Buddha Nagar, Uttar Pradesh',
          city: 'Noida',
          district: 'Gautam Buddha Nagar',
          state: 'Uttar Pradesh'
        },
        paymentMethod: 'Commercial Bank Wire (Escrow Secured)',
        paymentStatus: 'Escrow Secured'
      });

      setOrderSuccessMsg(`Procurement order placed for ${qty.toLocaleString()} kg ${selectedCropForOrder.crop}!`);
      setShowOrderModal(false);
      setTimeout(() => setOrderSuccessMsg(null), 3000);
    } catch (err) {
      setOrderError(err.message || 'Failed to place procurement order.');
    } finally {
      setIsSubmittingOrder(false);
    }
  };

  const quickActionsList = [
    {
      label: 'Find Bulk Produce',
      icon: Store,
      to: '/marketplace',
      description: 'Explore active farm-gate batches on marketplace',
      iconBg: 'bg-emerald-100 text-emerald-800'
    },
    {
      label: 'Create Bulk Order',
      icon: PlusCircle,
      onClick: () => {
        setSelectedCropForOrder(bulkProduceCrops[0]);
        setShowOrderModal(true);
      },
      description: 'Direct procurement PO with FPO aggregation',
      iconBg: 'bg-blue-100 text-blue-800'
    },
    {
      label: 'Suppliers',
      icon: Building2,
      onClick: () => setActiveTab('suppliers'),
      description: `View ${suppliersList.length} verified farm/FPO partners`,
      iconBg: 'bg-purple-100 text-purple-800'
    },
    {
      label: 'Procurement Orders',
      icon: FileText,
      onClick: () => setActiveTab('orders'),
      description: `Track ${bulkOrders.length} commercial dispatches`,
      iconBg: 'bg-teal-100 text-teal-800'
    },
    {
      label: 'Fleet & Logistics',
      icon: Truck,
      onClick: () => setActiveTab('logistics'),
      description: 'Live tracking of in-transit consignments & dispatch',
      iconBg: 'bg-emerald-100 text-emerald-800'
    },
    {
      label: 'Update Location',
      icon: MapPin,
      onClick: () => setShowLocationModal(true),
      description: 'Configure regional preferred sourcing hubs',
      iconBg: 'bg-amber-100 text-amber-800'
    }
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      
      {/* Toast Notification */}
      {orderSuccessMsg && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-xl border border-slate-800 text-xs font-bold flex items-center gap-2 animate-bounce">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>{orderSuccessMsg}</span>
        </div>
      )}

      {/* Top Header adhering strictly to Section 8 */}
      <DashboardHeader
        greeting={`Welcome, ${buyerName}`}
        roleBadge="🚛 Bulk Procurement Portal"
        locationType="Preferred sourcing location"
        locationText={preferredLocations.map((l) => `${l.city}, ${l.state}`).join(' | ')}
        isLocationVerified={true}
      >
        <Button
          to="/marketplace"
          variant="primary"
          size="md"
          leftIcon={Store}
        >
          Find Bulk Produce
        </Button>
      </DashboardHeader>

      {/* 5 Core KPI Metrics Cards adhering to Section 8 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 sm:gap-5">
        <DashboardStatCard
          title="Active Orders"
          value="8"
          subtext="In transit / packing"
          change="On Schedule"
          icon={Truck}
          accent="blue"
        />
        <DashboardStatCard
          title="Pending Requests"
          value="4"
          subtext="Quotations awaiting FPO"
          change="High Volume"
          icon={Clock}
          accent="amber"
        />
        <DashboardStatCard
          title="Total Procurement"
          value="₹12.8L"
          subtext="YTD institutional volume"
          change="+34% YoY"
          icon={Scale}
          accent="emerald"
        />
        <DashboardStatCard
          title="Quantity Purchased"
          value="84.5 Tonnes"
          subtext="Clean farm-gate dispatch"
          change="Grade-A"
          icon={Package}
          accent="teal"
        />
        <DashboardStatCard
          title="Suppliers"
          value="23"
          subtext="Verified farmers & FPOs"
          change="Pan-India"
          icon={Building2}
          accent="purple"
        />
      </div>

      {/* View Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-1">
        {[
          { id: 'overview', label: 'Procurement Overview' },
          { id: 'ai-signals', label: '🌾 AI Procurement Signals' },
          { id: 'availability', label: 'Bulk Produce Availability' },
          { id: 'suppliers', label: `Suppliers (${suppliersList.length})` },
          { id: 'pricing', label: 'Price Comparison' },
          { id: 'orders', label: `Procurement Orders (${bulkOrders.length})` },
          { id: 'logistics', label: `Fleet & Logistics (${shipments?.length || 0})` },
          { id: 'locations', label: `Preferred Locations (${preferredLocations.length})` }
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === tab.id
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* AI Procurement Signals Section */}
      {(activeTab === 'overview' || activeTab === 'ai-signals') && (
        <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950 rounded-3xl p-6 sm:p-7 text-white shadow-sm border border-indigo-900/50 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-indigo-400 mb-1">
                <Sparkles className="w-4 h-4" />
                <span>AI PROCUREMENT INTELLIGENCE</span>
              </div>
              <h3 className="text-lg font-bold font-display text-white">
                Upcoming Demand & Sourcing Signals
              </h3>
              <p className="text-xs text-slate-400">
                Predictive opportunities to source large batches directly from producer clusters
              </p>
            </div>

            <span className="text-[11px] font-semibold text-indigo-300 bg-indigo-950/60 border border-indigo-800/60 px-3 py-1 rounded-full self-start sm:self-auto">
              AI-Assisted Sourcing
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {buyerSignals.map((sig, idx) => (
              <div
                key={idx}
                className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-3 hover:bg-white/10 transition-colors flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-1 mb-2">
                    <h4 className="text-base font-bold text-white">{sig.cropName}</h4>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800">
                      {sig.demandClassification}
                    </span>
                  </div>

                  <div className="flex items-center gap-1 text-xs text-slate-400 mb-3">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>{sig.region}, {sig.state}</span>
                  </div>

                  <div className="space-y-1.5 py-2 border-y border-white/5 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 text-[11px]">Available Supply:</span>
                      <span className="font-mono font-bold text-white">{sig.availableSupplyFormatted}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 text-[11px]">Suggested Sourcing:</span>
                      <span className="font-mono font-bold text-amber-300">{sig.suggestedProcurementFormatted}</span>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-300 leading-relaxed mt-2.5">
                    {sig.procurementAdvisory}
                  </p>
                </div>

                <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[10px] text-slate-400">
                  <span>Confidence: {sig.confidenceScore}%</span>
                  <span className="text-[10px] text-slate-500 italic">Not guaranteed</span>
                </div>
              </div>
            ))}
          </div>

          {/* Smart Procurement Center: Multi-Supplier Aggregation */}
          {samplePlan && samplePlan.status === 'OPTIMIZED' && (
            <div className="pt-4 border-t border-white/10">
              <div className="text-xs font-bold uppercase tracking-wider text-indigo-300 mb-3">
                Smart Sourcing Bundle Optimization
              </div>
              <ProcurementRecommendationCard
                plan={samplePlan}
                onReviewPO={() => {
                  setSelectedCropForOrder({ name: samplePlan.cropName, price: 28, id: 'crop-1' });
                  setOrderQuantity(String(samplePlan.requiredQuantity));
                  setShowOrderModal(true);
                }}
              />
            </div>
          )}
        </div>
      )}

      {/* Section 8 Requirement: Bulk Produce Availability (Wheat, Rice, Potato, Onion, Tomato, Maize, Pulses) */}
      {(activeTab === 'overview' || activeTab === 'availability') && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Bulk Produce Availability
              </h3>
              <p className="text-xs text-slate-500">
                Multi-tonne harvest availability ready for direct contract purchase
              </p>
            </div>
            <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
              Direct Farm-Gate Lots
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {bulkProduceCrops.map((crop) => (
              <div
                key={crop.id}
                className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-emerald-300 transition-all space-y-3 flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-200/70 text-slate-700">
                      {crop.category}
                    </span>
                    <span className="text-xs font-mono font-bold text-emerald-700">
                      {crop.priceRange}
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-900">{crop.crop}</h4>

                  <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold block">Available</span>
                      <span className="font-bold text-slate-900">{crop.availableTonnes} Tonnes</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold block">Min. Order</span>
                      <span className="font-bold text-slate-700">{crop.minOrder}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between gap-2">
                  <span className="text-[11px] text-slate-500 font-medium">
                    {crop.suppliersCount} suppliers
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedCropForOrder(crop);
                      setShowOrderModal(true);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors cursor-pointer"
                  >
                    Create PO
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Section 8 Requirement: Supplier Overview */}
      {(activeTab === 'overview' || activeTab === 'suppliers') && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Verified Supplier Overview
              </h3>
              <p className="text-xs text-slate-500">
                Farmers & FPOs with protected GPS farm origins and volume ratings
              </p>
            </div>
            <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full">
              {suppliersList.length} Connected Producers
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-100">
                  <th className="pb-2.5 font-bold">Supplier</th>
                  <th className="pb-2.5 font-bold">Location Origin</th>
                  <th className="pb-2.5 font-bold">Primary Produce</th>
                  <th className="pb-2.5 font-bold">Available Volume</th>
                  <th className="pb-2.5 font-bold">Price Band</th>
                  <th className="pb-2.5 font-bold">Distance</th>
                  <th className="pb-2.5 font-bold">Rating</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {suppliersList.map((sup) => (
                  <tr key={sup.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3">
                      <p className="font-bold text-slate-900">{sup.name}</p>
                      <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.2 rounded border border-emerald-200">
                        {sup.type}
                      </span>
                    </td>
                    <td className="py-3 text-slate-600">
                      <p className="font-medium text-slate-800">{sup.location}</p>
                      <p className="text-[10px] text-slate-400">{sup.state}</p>
                    </td>
                    <td className="py-3 font-medium text-slate-700">
                      {sup.produce}
                    </td>
                    <td className="py-3 font-mono font-bold text-slate-950">
                      {sup.availableQty}
                    </td>
                    <td className="py-3 font-mono font-semibold text-emerald-700">
                      {sup.price}
                    </td>
                    <td className="py-3 text-slate-600">
                      📍 {sup.distance}
                    </td>
                    <td className="py-3">
                      <span className="inline-flex items-center gap-1 font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200 text-[11px]">
                        <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                        <span>{sup.rating}</span>
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Section 8 Requirement: Price Comparison Matrix */}
      {(activeTab === 'overview' || activeTab === 'pricing') && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Farm-Gate vs Wholesale & Retail Price Comparison
              </h3>
              <p className="text-xs text-slate-500">
                Quantified procurement cost savings by eliminating intermediary commission tiers
              </p>
            </div>
            <span className="text-[10px] font-mono text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 font-bold">
              Prototype Comparative Analytics
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-100">
                  <th className="pb-2.5 font-bold">Produce</th>
                  <th className="pb-2.5 font-bold">Direct Farm-Gate</th>
                  <th className="pb-2.5 font-bold">Wholesale Mandi</th>
                  <th className="pb-2.5 font-bold">Supermarket Retail</th>
                  <th className="pb-2.5 font-bold">B2B Savings %</th>
                  <th className="pb-2.5 font-bold text-right">Estimated Savings/Ton</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {priceComparisonData.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 font-bold text-slate-900">
                      {item.produce}
                    </td>
                    <td className="py-3 font-mono font-bold text-emerald-700">
                      ₹{item.farmPrice}/{item.unit}
                    </td>
                    <td className="py-3 font-mono text-slate-600">
                      ₹{item.mandiPrice}/{item.unit}
                    </td>
                    <td className="py-3 font-mono text-slate-400 line-through">
                      ₹{item.retailPrice}/{item.unit}
                    </td>
                    <td className="py-3">
                      <span className="inline-flex items-center gap-1 font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                        <TrendingDown className="w-3 h-3 text-emerald-600" />
                        <span>{item.savingsPct}% Saved</span>
                      </span>
                    </td>
                    <td className="py-3 font-mono font-bold text-emerald-800 text-right">
                      {item.savingsPerTon}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Section 8 Requirement: Procurement Orders */}
      {(activeTab === 'overview' || activeTab === 'orders') && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Procurement Orders
              </h3>
              <p className="text-xs text-slate-500">
                Institutional purchase orders placed with farmers and FPO clusters
              </p>
            </div>
            <Button
              onClick={() => {
                setSelectedCropForOrder(bulkProduceCrops[0]);
                setShowOrderModal(true);
              }}
              variant="primary"
              size="sm"
              leftIcon={PlusCircle}
            >
              New Procurement PO
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-100">
                  <th className="pb-2.5 font-bold">PO Number</th>
                  <th className="pb-2.5 font-bold">Supplier</th>
                  <th className="pb-2.5 font-bold">Produce</th>
                  <th className="pb-2.5 font-bold">Quantity</th>
                  <th className="pb-2.5 font-bold">Order Value</th>
                  <th className="pb-2.5 font-bold">Status</th>
                  <th className="pb-2.5 font-bold">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {bulkOrders.map((po) => (
                  <tr key={po.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 font-mono font-bold text-emerald-800">
                      {po.id}
                    </td>
                    <td className="py-3 font-medium text-slate-900">
                      {po.farmerName || po.fpoName || 'Kisan Vikas Producer Co. Ltd.'}
                    </td>
                    <td className="py-3 font-bold text-slate-800">
                      {po.product}
                    </td>
                    <td className="py-3 font-mono font-medium">
                      {po.quantity} {po.unit}
                    </td>
                    <td className="py-3 font-mono font-bold text-slate-950">
                      ₹{po.amount || po.total}
                    </td>
                    <td className="py-3">
                      <StatusBadge status={po.status} size="sm" />
                    </td>
                    <td className="py-3 text-slate-500 text-[11px]">
                      {po.date || 'Today'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Section 8 Requirement: Preferred Sourcing Locations */}
      {(activeTab === 'overview' || activeTab === 'locations') && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Preferred Sourcing Locations
              </h3>
              <p className="text-xs text-slate-500">
                Designated agricultural origin belts for institutional sourcing
              </p>
            </div>
            <Button
              onClick={() => setShowLocationModal(true)}
              variant="outline"
              size="sm"
              leftIcon={MapPin}
            >
              + Add Hub
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {preferredLocations.map((loc) => (
              <div
                key={loc.id}
                className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3"
              >
                <div>
                  <h4 className="text-sm font-bold text-slate-900">{loc.city}</h4>
                  <p className="text-xs text-slate-500">{loc.state} • {loc.distance}</p>
                </div>
                {preferredLocations.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removePreferredLocation(loc.id)}
                    className="text-slate-400 hover:text-rose-600 font-bold p-1 cursor-pointer"
                    title="Remove hub"
                  >
                    ✕
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Section: Hyperlocal Logistics & Incoming Fleet */}
      {(activeTab === 'overview' || activeTab === 'logistics') && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900 font-display">
                  Fleet Shipments & Hyperlocal Dispatch
                </h3>
                <p className="text-xs text-slate-500">
                  Consolidated multi-supplier transit tracking and estimated delivery ETAs
                </p>
              </div>
            </div>
            <Link
              to="/logistics"
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 hover:underline inline-flex items-center gap-1"
            >
              Open Logistics Command Center →
            </Link>
          </div>

          {/* Active Shipments */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Active Consignments
            </h4>
            {shipments && shipments.length > 0 ? (
              <div className="space-y-4">
                {shipments.slice(0, 3).map((shipment) => (
                  <ShipmentStatus key={shipment.id} shipment={shipment} />
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 py-3">No active consignments currently in transit.</p>
            )}
          </div>

          {/* Connected Routes */}
          {routes && routes.length > 0 && (
            <div className="pt-4 border-t border-slate-100 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Associated Fleet Routes
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {routes.slice(0, 2).map((route) => (
                  <RouteSummary key={route.id} route={route} />
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Quick Actions adhering to Section 8 */}
      <QuickActions
        title="Quick Actions"
        subtitle="Frequently used B2B procurement actions"
        actions={quickActionsList}
      />

      {/* Modal: Create Bulk PO */}
      {showOrderModal && selectedCropForOrder && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-slate-200 space-y-5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div>
                <span className="text-[10px] font-mono text-emerald-700 font-bold uppercase block">
                  B2B Direct Sourcing
                </span>
                <h3 className="text-base font-bold text-slate-900 font-display">
                  Create Procurement Order
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowOrderModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handlePlaceBulkOrder} className="space-y-4 text-xs">
              {orderError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                  <span>{orderError}</span>
                </div>
              )}

              <div>
                <div className="flex justify-between items-baseline mb-1">
                  <label className="block font-bold text-slate-700">Selected Produce</label>
                  <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                    MOQ: {selectedCropForOrder.minOrder || '500 kg'}
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 font-bold text-slate-900 flex justify-between items-center">
                  <span>{selectedCropForOrder.crop}</span>
                  <span className="text-emerald-700 font-mono text-xs">{selectedCropForOrder.priceRange}</span>
                </div>
              </div>

              {/* Bulk Quantity Presets */}
              <div>
                <label className="block font-bold text-slate-700 mb-1.5">
                  Bulk Quantity Presets
                </label>
                <div className="grid grid-cols-5 gap-1.5 mb-2">
                  {[
                    { label: '500 kg', val: '500' },
                    { label: '1 Tonne', val: '1000' },
                    { label: '2 Tonnes', val: '2000' },
                    { label: '5 Tonnes', val: '5000' },
                    { label: '10 Tonnes', val: '10000' }
                  ].map((preset) => (
                    <button
                      key={preset.val}
                      type="button"
                      onClick={() => {
                        setOrderQuantity(preset.val);
                        setOrderError(null);
                      }}
                      className={`py-1.5 px-1 rounded-lg text-[10px] font-bold border text-center transition-colors cursor-pointer ${
                        orderQuantity === preset.val
                          ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="100"
                    step="50"
                    required
                    value={orderQuantity}
                    onChange={(e) => {
                      setOrderQuantity(e.target.value);
                      setOrderError(null);
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-blue-500 font-mono font-bold"
                  />
                  <span className="text-slate-500 font-bold">kg</span>
                </div>
                <span className="text-[11px] text-slate-500 mt-1 block">
                  Est. Base Rate: ₹28/kg • Produce Value: ₹{((Number(orderQuantity) || 0) * 28).toLocaleString('en-IN')}
                </span>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Select Supplier Partner</label>
                <select
                  value={selectedSupplierId}
                  onChange={(e) => setSelectedSupplierId(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs focus:outline-blue-500 bg-white"
                >
                  {suppliersList.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.type} • {s.price} • {s.distance})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Freight / Fulfillment Mode</label>
                <div className="grid grid-cols-2 gap-2">
                  <label className={`p-2.5 rounded-xl border text-xs cursor-pointer flex items-center gap-2 ${
                    bulkDeliveryType === 'delivery' ? 'bg-blue-50 border-blue-300 font-bold text-blue-900' : 'bg-slate-50 border-slate-200'
                  }`}>
                    <input
                      type="radio"
                      name="bulkDelivery"
                      checked={bulkDeliveryType === 'delivery'}
                      onChange={() => setBulkDeliveryType('delivery')}
                    />
                    <span>Dedicated Freight (+₹750)</span>
                  </label>
                  <label className={`p-2.5 rounded-xl border text-xs cursor-pointer flex items-center gap-2 ${
                    bulkDeliveryType === 'pickup' ? 'bg-blue-50 border-blue-300 font-bold text-blue-900' : 'bg-slate-50 border-slate-200'
                  }`}>
                    <input
                      type="radio"
                      name="bulkDelivery"
                      checked={bulkDeliveryType === 'pickup'}
                      onChange={() => setBulkDeliveryType('pickup')}
                    />
                    <span>Self-Pickup from Yard (₹0)</span>
                  </label>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-amber-50/60 border border-amber-200 text-amber-900 text-[11px] space-y-1">
                <span className="font-bold block text-amber-950">Prototype Commercial Terms</span>
                <p className="text-amber-800">
                  Mandi / market fees, quality inspection, and statutory terms are subject to applicable rules and bilateral buyer-supplier agreement.
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowOrderModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  Cancel
                </button>
                <Button 
                  type="submit" 
                  variant="primary" 
                  size="sm"
                  disabled={isSubmittingOrder}
                >
                  {isSubmittingOrder ? 'Creating Purchase Order...' : 'Confirm Purchase Order'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add Preferred Location */}
      {showLocationModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900 font-display">
                Add Preferred Sourcing Location
              </h3>
              <button
                type="button"
                onClick={() => setShowLocationModal(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddLocation} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">City / District *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Aligarh"
                  value={newCity}
                  onChange={(e) => setNewCity(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 focus:outline-emerald-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">State</label>
                <input
                  type="text"
                  value={newState}
                  onChange={(e) => setNewState(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 focus:outline-emerald-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowLocationModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  Cancel
                </button>
                <Button type="submit" variant="primary" size="sm">
                  Add Sourcing Hub
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
