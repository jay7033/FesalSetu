import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Truck, 
  Store, 
  ArrowRight, 
  Search
} from 'lucide-react';
import StatusBadge from '../../components/dashboard/StatusBadge';
import EmptyState from '../../components/dashboard/EmptyState';
import Button from '../../components/Button';
import { useOrders } from '../../context/OrderContext';

const STATUS_FILTERS = [
  'All',
  'Pending',
  'Confirmed',
  'Preparing',
  'In Transit',
  'Delivered',
  'Cancelled'
];

export default function BulkBuyerOrders() {
  const { orders } = useOrders();
  const [activeFilter, setActiveFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const bulkOrders = orders.filter((o) => o.buyerRole === 'bulk_buyer');

  const filteredOrders = bulkOrders.filter((po) => {
    const matchesFilter = activeFilter === 'All' || po.status.toLowerCase() === activeFilter.toLowerCase();
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch = !q ||
      po.id.toLowerCase().includes(q) ||
      (po.product && po.product.toLowerCase().includes(q)) ||
      (po.farmerName && po.farmerName.toLowerCase().includes(q)) ||
      (po.fpoName && po.fpoName.toLowerCase().includes(q));
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-700">
              Commercial B2B Procurement
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200 font-bold">
              Institutional Purchase Orders
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-950 font-display tracking-tight">
            Procurement Orders
          </h1>
          <p className="text-slate-500 text-xs sm:text-sm mt-0.5">
            Direct institutional contract purchases placed with farmers and FPO clusters.
          </p>
        </div>

        <Button
          to="/marketplace"
          variant="primary"
          size="sm"
          leftIcon={Store}
        >
          Find Bulk Produce
        </Button>
      </div>

      {/* Filter Tabs & Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex flex-wrap gap-1.5 p-1 rounded-2xl bg-white border border-slate-200 w-full sm:w-auto overflow-x-auto">
          {STATUS_FILTERS.map((filter) => (
            <button
              key={filter}
              type="button"
              onClick={() => setActiveFilter(filter)}
              className={`text-xs px-3.5 py-1.5 rounded-xl font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeFilter === filter
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by PO Number or crop..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 focus:outline-blue-500"
          />
        </div>
      </div>

      {/* Orders List / Empty State */}
      {filteredOrders.length === 0 ? (
        <EmptyState
          icon={Truck}
          title="No procurement orders found"
          description="Find agricultural produce directly from verified farmers and FPOs on the B2B marketplace."
          actionLabel="Find Bulk Produce"
          actionLink="/marketplace"
        />
      ) : (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-100">
                  <th className="pb-3 font-bold">PO Number</th>
                  <th className="pb-3 font-bold">Supplier / Producer</th>
                  <th className="pb-3 font-bold">Produce</th>
                  <th className="pb-3 font-bold">Quantity</th>
                  <th className="pb-3 font-bold">Total Value</th>
                  <th className="pb-3 font-bold">Delivery / Freight</th>
                  <th className="pb-3 font-bold">Status</th>
                  <th className="pb-3 font-bold text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredOrders.map((po) => (
                  <tr key={po.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3.5 font-mono font-bold text-blue-800">
                      #{po.id}
                    </td>
                    <td className="py-3.5">
                      <p className="font-bold text-slate-900">
                        {po.farmerName || po.fpoName || 'Kisan Vikas Producer Co. Ltd.'}
                      </p>
                      <p className="text-[10px] text-slate-400">
                        {po.location || 'Western UP Cluster'}
                      </p>
                    </td>
                    <td className="py-3.5 font-bold text-slate-800">
                      {po.product || 'Agricultural Produce'}
                    </td>
                    <td className="py-3.5 font-mono font-medium text-slate-800">
                      {po.quantity} {po.unit || 'kg'}
                    </td>
                    <td className="py-3.5 font-mono font-bold text-slate-950">
                      ₹{po.total || po.amount}
                    </td>
                    <td className="py-3.5 text-slate-600 capitalize">
                      {po.deliveryType === 'pickup' ? 'Self Pickup' : 'Commercial Freight'}
                    </td>
                    <td className="py-3.5">
                      <StatusBadge status={po.status} size="sm" />
                    </td>
                    <td className="py-3.5 text-right">
                      <Link
                        to={`/bulk-buyer/orders/${po.id}`}
                        className="inline-flex items-center gap-1 text-xs font-bold text-blue-700 hover:text-blue-900 hover:underline"
                      >
                        <span>PO Details</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
}
