import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  ChevronLeft, 
  Printer, 
  AlertCircle,
  ShieldCheck
} from 'lucide-react';
import StatusBadge from '../../components/dashboard/StatusBadge';
import Button from '../../components/Button';
import { useOrders } from '../../context/OrderContext';
import Logo from '../../components/Logo';

export default function BulkBuyerOrderDetails() {
  const { orderId } = useParams();
  const { getOrderById, cancelOrder } = useOrders();

  const order = getOrderById(orderId);

  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelReason, setCancelReason] = useState('Procurement schedule adjustment');
  const [cancelError, setCancelError] = useState(null);

  if (!order) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-4 text-center max-w-md mx-auto space-y-4">
        <AlertCircle className="w-12 h-12 text-slate-400" />
        <h2 className="text-xl font-bold text-slate-900 font-display">PO Not Found</h2>
        <p className="text-xs text-slate-500">
          The requested Purchase Order #{orderId} could not be located in our records.
        </p>
        <Button to="/bulk-buyer/orders" variant="outline" size="sm">
          Return to Procurement Orders
        </Button>
      </div>
    );
  }

  const isCancellable = order.status === 'Pending' || order.status === 'Confirmed';

  const handlePrint = () => {
    window.print();
  };

  const handleConfirmCancel = () => {
    setCancelError(null);
    const res = cancelOrder(order.id, cancelReason);
    if (res.success) {
      setShowCancelModal(false);
    } else {
      setCancelError(res.error || 'Failed to cancel order.');
    }
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto print:max-w-none print:m-0 print:p-0">
      
      {/* Top Controls (Hidden on Print) */}
      <div className="flex items-center justify-between print:hidden">
        <Link
          to="/bulk-buyer/orders"
          className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-blue-700 transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Back to All POs</span>
        </Link>

        <div className="flex items-center gap-2">
          {isCancellable && (
            <button
              type="button"
              onClick={() => setShowCancelModal(true)}
              className="px-3.5 py-2 rounded-xl text-xs font-bold text-rose-600 hover:bg-rose-50 border border-rose-200 transition-colors cursor-pointer"
            >
              Cancel PO
            </button>
          )}

          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 shadow-xs transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4 text-slate-600" />
            <span>Print / Save Summary</span>
          </button>
        </div>
      </div>

      {/* Formal B2B Purchase Order Document */}
      <div className="bg-white rounded-3xl p-8 sm:p-10 border border-slate-200 shadow-sm space-y-8 print:border-none print:shadow-none print:p-0">
        
        {/* PO Document Header */}
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-6 pb-6 border-b border-slate-200">
          <div className="space-y-2">
            <Logo size="md" />
            <p className="text-xs text-slate-500 font-display">
              FasalSetu Hyperlocal B2B Agricultural Procurement Exchange
            </p>
            <span className="inline-block text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200">
              COMMERCIAL PURCHASE ORDER
            </span>
          </div>

          <div className="text-left sm:text-right space-y-1 text-xs">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Purchase Order</span>
            <h2 className="text-2xl font-mono font-black text-blue-900">
              #{order.id}
            </h2>
            <p className="text-slate-600">Date: <strong>{order.date || '06 Sep 2026'}</strong></p>
            <div className="pt-1">
              <StatusBadge status={order.status} size="sm" />
            </div>
          </div>
        </div>

        {/* Counterparty Information: Buyer & Supplier */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 p-6 rounded-2xl bg-slate-50 border border-slate-200/80 text-xs">
          <div className="space-y-1.5">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">
              Procuring Entity (Buyer)
            </span>
            <h4 className="text-sm font-bold text-slate-900">
              {order.buyerName || 'FreshMart Retail & Institutional'}
            </h4>
            <p className="text-slate-600">Role: Commercial Bulk Buyer Partner</p>
            <p className="text-slate-600">
              Delivery Hub: {order.buyerLocation?.address || order.location || 'Noida Distribution Center'}
            </p>
            <p className="text-slate-500 text-[11px]">GSTIN: 07AABCF1234F1Z5 (Verified)</p>
          </div>

          <div className="space-y-1.5">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">
              Supplying Cooperative (Farmer / FPO)
            </span>
            <h4 className="text-sm font-bold text-slate-900">
              {order.farmerName || order.fpoName || 'Kisan Vikas Producer Co. Ltd.'}
            </h4>
            <p className="text-slate-600">Aggregation Hub: {order.location || 'Dankaur Center, Western UP'}</p>
            <p className="text-slate-500 text-[11px]">Co-op Reg: U01409UP2022PTC168924</p>
            <p className="text-emerald-700 font-semibold flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Direct Farm-Gate Contracted</span>
            </p>
          </div>
        </div>

        {/* Produce Line Items Table */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            Procurement Schedule & Produce Items
          </h3>

          <table className="w-full text-left text-xs border border-slate-200 rounded-2xl overflow-hidden">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase text-[10px]">
              <tr>
                <th className="p-3 font-bold">Item / Produce</th>
                <th className="p-3 font-bold">Grade & Origin</th>
                <th className="p-3 font-bold text-right">Quantity</th>
                <th className="p-3 font-bold text-right">Unit Price</th>
                <th className="p-3 font-bold text-right">Subtotal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {(order.items || []).length > 0 ? (
                order.items.map((it, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50">
                    <td className="p-3 font-bold text-slate-900">
                      {it.name || it.product}
                    </td>
                    <td className="p-3 text-slate-600">
                      Grade-A Harvest ({it.farmLocation || 'Western UP Cluster'})
                    </td>
                    <td className="p-3 font-mono font-bold text-right text-slate-900">
                      {it.quantity} {it.unit || 'kg'}
                    </td>
                    <td className="p-3 font-mono text-right text-slate-700">
                      ₹{it.price || Math.round((order.subtotal || order.amount) / (it.quantity || 1))} / {it.unit || 'kg'}
                    </td>
                    <td className="p-3 font-mono font-bold text-right text-slate-950">
                      ₹{it.subtotal || order.subtotal || order.amount}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td className="p-3 font-bold text-slate-900">
                    {order.product || 'Agricultural Produce Lot'}
                  </td>
                  <td className="p-3 text-slate-600">
                    Consolidated Cooperative Batch
                  </td>
                  <td className="p-3 font-mono font-bold text-right text-slate-900">
                    {order.quantity} {order.unit || 'kg'}
                  </td>
                  <td className="p-3 font-mono text-right text-slate-700">
                    ₹{Math.round((order.subtotal || order.amount) / (order.quantity || 1))} / {order.unit || 'kg'}
                  </td>
                  <td className="p-3 font-mono font-bold text-right text-slate-950">
                    ₹{order.subtotal || order.amount}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Commercial Terms & Total Calculation */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4 border-t border-slate-200 items-start text-xs">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">
                Prototype Commercial Terms
              </h4>
              <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 font-bold">
                Prototype Terms
              </span>
            </div>
            <div className="space-y-1.5 text-slate-600">
              <p>• <strong>Mandi / Market Fee:</strong> To be determined according to applicable rules.</p>
              <p>• <strong>Quality / Moisture:</strong> Subject to buyer-supplier agreement and inspection.</p>
              <p>• <strong>Logistics / Freight:</strong> {order.deliveryType === 'pickup' ? 'Ex-Works / Self-Pickup from FPO Yard (as agreed between buyer and supplier).' : 'As agreed between buyer and supplier.'}</p>
              <p>• <strong>Legal / Tax Terms:</strong> Applicable statutory requirements will govern the final transaction.</p>
            </div>
          </div>

          <div className="space-y-2 p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <div className="flex justify-between text-slate-600">
              <span>Produce Subtotal</span>
              <span className="font-mono font-bold text-slate-900">₹{order.subtotal || order.amount}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Freight / Transit Charges</span>
              <span className="font-mono font-bold text-slate-900">
                {order.deliveryType === 'pickup' || order.deliveryFee === 0 ? '₹0 (Zero Charge)' : `₹${order.deliveryFee}`}
              </span>
            </div>
            <div className="pt-2 border-t border-slate-200 flex justify-between items-baseline">
              <span className="text-sm font-bold text-slate-900">Total Contract Value</span>
              <span className="text-2xl font-black text-blue-950 font-display">
                ₹{order.total || order.amount}
              </span>
            </div>
          </div>
        </div>

        {/* Signatures & Stamp Section for Print */}
        <div className="pt-8 border-t border-slate-200 grid grid-cols-2 gap-8 text-xs">
          <div className="space-y-6">
            <span className="text-slate-400 text-[10px] uppercase font-bold block">Authorized Signatory (Supplier)</span>
            <div className="border-b border-slate-300 w-48 pb-1">
              <span className="font-display font-bold text-slate-800">Kisan Vikas Producer Co. Ltd.</span>
            </div>
            <p className="text-[10px] text-slate-400">Date: {order.date || 'Today'}</p>
          </div>

          <div className="space-y-6 text-right sm:text-left">
            <span className="text-slate-400 text-[10px] uppercase font-bold block">Authorized Signatory (Buyer)</span>
            <div className="border-b border-slate-300 w-48 pb-1">
              <span className="font-display font-bold text-slate-800">{order.buyerName || 'FreshMart'}</span>
            </div>
            <p className="text-[10px] text-slate-400">Date: {order.date || 'Today'}</p>
          </div>
        </div>

      </div>

      {/* Cancellation Modal Dialog */}
      {showCancelModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center flex-shrink-0">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 font-display">
                  Cancel Purchase Order #{order.id}?
                </h3>
                <p className="text-xs text-slate-500">
                  The supplier will be notified and reserved harvest lots will be released.
                </p>
              </div>
            </div>

            {cancelError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                {cancelError}
              </div>
            )}

            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700">
                Cancellation Reason:
              </label>
              <select
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-800 focus:outline-blue-500"
              >
                <option value="Procurement schedule adjustment">Procurement schedule adjustment</option>
                <option value="Supplier quotation altered">Supplier quotation altered</option>
                <option value="Storage warehouse capacity issue">Storage warehouse capacity issue</option>
                <option value="Duplicate purchase order placed">Duplicate purchase order placed</option>
              </select>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowCancelModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                Keep PO Active
              </button>
              <button
                type="button"
                onClick={handleConfirmCancel}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 transition-colors cursor-pointer"
              >
                Cancel PO
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
