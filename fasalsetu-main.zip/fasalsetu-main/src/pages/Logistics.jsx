import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { 
  RotateCw, 
  Zap, 
  CheckCircle2, 
  ArrowLeft, 
  AlertTriangle, 
  ArrowRight, 
  Phone
} from 'lucide-react';
import { useLogistics } from '../context/LogisticsContext';
import { useAuth } from '../context/AuthContext';
import RouteMap from '../components/logistics/RouteMap';
import RouteSummary from '../components/logistics/RouteSummary';
import RouteStopCard from '../components/logistics/RouteStopCard';
import CapacityIndicator from '../components/logistics/CapacityIndicator';
import { VEHICLE_PROFILES } from '../services/logistics/logisticsUtils';
import { PAN_INDIA_NETWORK_ZONES } from '../data/demoData';
import { hierarchicalLogisticsService } from '../services/logistics/hierarchicalLogisticsService';

export default function Logistics() {
  const [searchParams] = useSearchParams();
  const { user } = useAuth();
  
  // Regional context
  const regionParam = searchParams.get('region')?.toLowerCase() || 'north';
  const activeNetworkZone = PAN_INDIA_NETWORK_ZONES[regionParam] || PAN_INDIA_NETWORK_ZONES.north;

  const {
    routes,
    createRoutePlan
  } = useLogistics();

  // Regional Command Center state
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [regionalKPI, setRegionalKPI] = useState(null);
  const [zones, setZones] = useState([]);
  const [allDeliveryBoys, setAllDeliveryBoys] = useState([]);
  
  // Navigation & Drill-down Tabs
  const [activeTab, setActiveTab] = useState('zones'); // 'zones', 'assigners', 'delivery_boys', 'routes', 'planner'
  const [selectedZoneFilter, setSelectedZoneFilter] = useState('ALL');
  const [rebalanceModalOpen, setRebalanceModalOpen] = useState(false);
  const [actionSuccessMsg, setActionSuccessMsg] = useState(null);

  // Existing route planner state
  const [selectedVehicleType, setSelectedVehicleType] = useState('Small Truck');
  const [selectedRoute, setSelectedRoute] = useState(null);
  const [plannerSuccessMsg, setPlannerSuccessMsg] = useState(null);

  // Demo fulfillments ready for collection planning
  const [availableFulfillments, setAvailableFulfillments] = useState([
    {
      id: 'ful-1',
      orderId: 'FS1025',
      supplierName: 'Ramesh Kumar',
      farmLocation: { approximateLocation: 'Green Valley Farms, Dankaur', latitude: 28.35, longitude: 77.53 },
      cropName: 'Desi Tomato',
      quantity: 180,
      selected: true
    },
    {
      id: 'ful-2',
      orderId: 'FS1026',
      supplierName: 'Kisan Samriddhi FPO',
      farmLocation: { approximateLocation: 'Kisan Samriddhi Center, Jewar', latitude: 28.18, longitude: 77.55 },
      cropName: 'Organic Potato',
      quantity: 350,
      selected: true
    },
    {
      id: 'ful-3',
      orderId: 'FS1027',
      supplierName: 'Choudhary Farms',
      farmLocation: { approximateLocation: 'Dadri Agricultural Yard', latitude: 28.55, longitude: 77.55 },
      cropName: 'Fresh Cauliflower',
      quantity: 120,
      selected: false
    }
  ]);

  // Load Regional Data
  const loadRegionalData = useCallback(async (isRefresh = false) => {
    try {
      if (isRefresh) setRefreshing(true);
      const [fetchedKPI, fetchedZones, fetchedBoys] = await Promise.all([
        hierarchicalLogisticsService.getRegionalKPISummary(regionParam),
        hierarchicalLogisticsService.getZones(regionParam),
        hierarchicalLogisticsService.getDeliveryBoys({ regionId: regionParam })
      ]);

      setRegionalKPI(fetchedKPI);
      setZones(fetchedZones);
      setAllDeliveryBoys(fetchedBoys);
    } catch (err) {
      console.error('Failed to load regional command center data:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [regionParam]);

  useEffect(() => {
    loadRegionalData();
  }, [loadRegionalData]);

  // Handle Dynamic Zone Rebalancing Action (Moving a boy from Zone B to Zone A)
  const handleRebalanceZone = async (boyId, targetZoneId) => {
    try {
      await hierarchicalLogisticsService.reassignDeliveryBoyZone(boyId, targetZoneId);
      setActionSuccessMsg('Dynamic Balancing: Delivery partner reassigned to overloaded zone. Workload stabilized.');
      setRebalanceModalOpen(false);
      await loadRegionalData();
      setTimeout(() => setActionSuccessMsg(null), 4000);
    } catch (err) {
      console.error('Rebalance failed:', err);
    }
  };

  // Filter delivery boys by zone
  const filteredBoys = useMemo(() => {
    if (selectedZoneFilter === 'ALL') return allDeliveryBoys;
    return allDeliveryBoys.filter((b) => b.zoneId === selectedZoneFilter);
  }, [allDeliveryBoys, selectedZoneFilter]);

  // Regional Map Stops combining zone centers and active route waypoints
  const regionalMapStops = useMemo(() => {
    const stops = [];
    zones.forEach((z, idx) => {
      stops.push({
        sequenceNumber: idx + 1,
        stopType: 'HUB',
        approximateAddress: z.name,
        latitude: z.centerLat,
        longitude: z.centerLng,
        producerName: `${z.assigner?.name || 'Assigner'} (${z.teamSize} boys)`
      });
    });
    return stops;
  }, [zones]);

  // Route planner logic
  const toggleFulfillmentSelect = (id) => {
    setAvailableFulfillments((prev) =>
      prev.map((f) => (f.id === id ? { ...f, selected: !f.selected } : f))
    );
  };

  const selectedBatch = availableFulfillments.filter((f) => f.selected);
  const selectedLoadKg = selectedBatch.reduce((acc, f) => acc + f.quantity, 0);
  const currentProfile = VEHICLE_PROFILES[selectedVehicleType] || VEHICLE_PROFILES['Small Truck'];
  const isOverCapacity = selectedLoadKg > currentProfile.capacityKg;

  const handleCreateRoute = () => {
    if (selectedBatch.length === 0 || isOverCapacity) return;

    const newRoute = createRoutePlan({
      fulfillments: selectedBatch,
      origin: { name: 'Yamuna Fleet Hub', city: 'Greater Noida', latitude: 28.35, longitude: 77.53 },
      destination: { name: 'Noida Central Delivery Hub', city: 'Noida', latitude: 28.62, longitude: 77.36 },
      vehicleType: selectedVehicleType
    });

    setSelectedRoute(newRoute);
    setPlannerSuccessMsg(`Route ${newRoute.routeNumber} planned successfully with ${newRoute.stops.length} stops!`);
    setTimeout(() => {
      setPlannerSuccessMsg(null);
      setActiveTab('routes');
    }, 2000);
  };

  const currentRoute = selectedRoute || routes[0] || null;

  if (loading && !regionalKPI) {
    return (
      <div className="min-h-[70vh] bg-slate-50 dark:bg-slate-950 py-16 px-4 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-500 border border-emerald-500/30 flex items-center justify-center mx-auto animate-spin">
            <RotateCw className="w-6 h-6" />
          </div>
          <p className="text-sm font-semibold text-slate-600 dark:text-slate-300">
            Initializing Regional Logistics Command Center...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* =========================================================================
            1. REGIONAL LOGISTICS HEAD COMMAND CENTER HEADER
            ========================================================================= */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950 text-white border border-emerald-500/40 rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <Link
                  to="/#built-for-bharat"
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 text-xs font-bold transition-colors border border-slate-700 cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Network</span>
                </Link>
                <span className="text-[10px] font-mono uppercase tracking-wider px-2.5 py-1 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-700/60 font-bold">
                  Regional Command Center
                </span>
                <span className="text-[10px] font-mono uppercase tracking-wider px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                  {activeNetworkZone?.name || 'North India'}
                </span>
              </div>
              
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white font-display tracking-tight">
                {activeNetworkZone?.name?.toUpperCase() || 'NORTH INDIA'} LOGISTICS COMMAND
              </h1>
              
              <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
                Supervising Officer: <strong className="text-white font-semibold">{user?.name || 'Vikramaditya Singhania'}</strong> (Chief Regional Logistics Head). Geographic hierarchical supervision across <strong>{regionalKPI?.totalZones || 6} Operational Zones</strong> and <strong>{regionalKPI?.totalDeliveryBoys || 100} Delivery Boys</strong>.
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <button
                onClick={() => loadRegionalData(true)}
                disabled={refreshing}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-700 bg-slate-800/80 hover:bg-slate-800 text-xs font-bold text-slate-200 shadow-xs cursor-pointer"
              >
                <RotateCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-emerald-400' : ''}`} />
                <span>{refreshing ? 'Syncing...' : 'Sync Region'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Dynamic Zone Balancing Alert Banner */}
        {regionalKPI?.overloadedZones && regionalKPI.overloadedZones.length > 0 && (
          <div className="p-4 sm:p-5 rounded-2xl bg-amber-500/10 border-2 border-amber-500/40 text-amber-900 dark:text-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm animate-in fade-in">
            <div className="flex items-start sm:items-center gap-3">
              <div className="p-2 rounded-xl bg-amber-500/20 text-amber-500 shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold font-display">
                  Dynamic Zone Workload Imbalance Detected
                </h4>
                <p className="text-xs text-amber-800 dark:text-amber-300 mt-0.5">
                  <strong>{regionalKPI.overloadedZones[0].name}</strong> is currently experiencing high delivery workload ({regionalKPI.overloadedZones[0].workloadRatio || 1.6} orders/boy).
                </p>
              </div>
            </div>

            <button
              onClick={() => setRebalanceModalOpen(true)}
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold shadow-xs cursor-pointer shrink-0"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Balance Zone Workload</span>
            </button>
          </div>
        )}

        {/* Action success alert */}
        {actionSuccessMsg && (
          <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-xs flex items-center justify-between animate-in fade-in">
            <div className="flex items-center gap-2 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>{actionSuccessMsg}</span>
            </div>
            <button onClick={() => setActionSuccessMsg(null)} className="text-xs underline text-emerald-700 cursor-pointer">
              Dismiss
            </button>
          </div>
        )}

        {/* =========================================================================
            2. EXECUTIVE SUPERVISION KPI STRIP
            ========================================================================= */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3.5">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
            <span className="text-[10px] font-bold font-mono text-slate-400 uppercase block mb-1">
              Operational Zones
            </span>
            <div className="text-2xl font-black text-slate-900 dark:text-white font-display">
              {regionalKPI?.totalZones || 6}
            </div>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">100% active coverage</span>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
            <span className="text-[10px] font-bold font-mono text-slate-400 uppercase block mb-1">
              Zone Assigners
            </span>
            <div className="text-2xl font-black text-slate-900 dark:text-white font-display">
              {regionalKPI?.totalAssigners || 6}
            </div>
            <span className="text-[10px] text-slate-500">1 coordinator / zone</span>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
            <span className="text-[10px] font-bold font-mono text-slate-400 uppercase block mb-1">
              Delivery Fleet
            </span>
            <div className="text-2xl font-black text-slate-900 dark:text-white font-display">
              {regionalKPI?.totalDeliveryBoys || 100}
            </div>
            <span className="text-[10px] text-emerald-600 font-mono font-semibold">
              {regionalKPI?.availableBoys || 68} available
            </span>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
            <span className="text-[10px] font-bold font-mono text-blue-500 uppercase block mb-1">
              Active In Transit
            </span>
            <div className="text-2xl font-black text-blue-600 dark:text-blue-400 font-display">
              {regionalKPI?.inTransit || 18}
            </div>
            <span className="text-[10px] text-slate-500">Live parcel routes</span>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
            <span className="text-[10px] font-bold font-mono text-amber-500 uppercase block mb-1">
              Unassigned
            </span>
            <div className="text-2xl font-black text-amber-600 dark:text-amber-400 font-display">
              {regionalKPI?.unassigned || 1}
            </div>
            <span className="text-[10px] text-slate-500">Zone review queue</span>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
            <span className="text-[10px] font-bold font-mono text-emerald-500 uppercase block mb-1">
              Delivered Today
            </span>
            <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 font-display">
              {regionalKPI?.todayDelivered || 85}
            </div>
            <span className="text-[10px] text-emerald-600 font-semibold font-mono">
              {regionalKPI?.completionRatePercent || 92}% success
            </span>
          </div>
        </div>

        {/* =========================================================================
            3. HIERARCHICAL NAVIGATION TABS
            ========================================================================= */}
        <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 overflow-x-auto pb-1">
          {[
            { id: 'zones', label: `Operational Zones (${zones.length})` },
            { id: 'assigners', label: `Zone Coordinators (${zones.length})` },
            { id: 'delivery_boys', label: `Regional Delivery Boys (${allDeliveryBoys.length})` },
            { id: 'routes', label: `Arterial Routes & Corridors (${routes.length})` },
            { id: 'planner', label: '⚡ Collection Route Planner' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* =========================================================================
            TAB 1: OPERATIONAL ZONES & BALANCING
            ========================================================================= */}
        {activeTab === 'zones' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {zones.map((zone) => (
                <div
                  key={zone.id}
                  className={`bg-white dark:bg-slate-900 border rounded-3xl p-6 shadow-sm space-y-4 hover:border-emerald-500/50 transition-all ${
                    zone.status === 'HIGH_WORKLOAD' || zone.status === 'OVERLOADED'
                      ? 'border-amber-400/80 dark:border-amber-600/80 shadow-amber-500/5'
                      : 'border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-mono font-bold text-xs">
                        {zone.code?.slice(-1) || 'A'}
                      </span>
                      <div>
                        <h3 className="text-sm font-bold text-slate-900 dark:text-white font-display">
                          {zone.name}
                        </h3>
                        <p className="text-[10px] font-mono text-slate-400">
                          Radius: {zone.radiusKm} km • Lat: {zone.centerLat}, Lng: {zone.centerLng}
                        </p>
                      </div>
                    </div>

                    <span className={`text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                      zone.status === 'BALANCED'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                    }`}>
                      {zone.status}
                    </span>
                  </div>

                  <p className="text-xs text-slate-500 leading-relaxed">
                    {zone.description}
                  </p>

                  {/* Operational Metrics */}
                  <div className="grid grid-cols-3 gap-2 p-3 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800 text-center">
                    <div>
                      <span className="text-[9px] font-mono text-slate-400 uppercase block">Fleet</span>
                      <span className="text-sm font-black text-slate-900 dark:text-white font-display">
                        {zone.teamSize} boys
                      </span>
                    </div>
                    <div>
                      <span className="text-[9px] font-mono text-blue-500 uppercase block">Active</span>
                      <span className="text-sm font-black text-blue-600 dark:text-blue-400 font-display">
                        {zone.activeDeliveriesCount || 0} tasks
                      </span>
                    </div>
                    <div>
                      <span className="text-[9px] font-mono text-amber-500 uppercase block">Unassigned</span>
                      <span className="text-sm font-black text-amber-600 dark:text-amber-400 font-display">
                        {zone.unassignedDeliveriesCount || 0}
                      </span>
                    </div>
                  </div>

                  {/* Assigner & Actions */}
                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Coordinator:</span>
                      <strong className="text-slate-800 dark:text-slate-200">
                        {zone.assigner?.name || 'Assigned Coordinator'}
                      </strong>
                    </div>

                    <Link
                      to="/logistics/zone"
                      className="inline-flex items-center gap-1 font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
                    >
                      <span>Manage Zone</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>
              ))}
            </div>

            {/* Regional Map Preview */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white font-display">
                    Regional GIS Command & Zone Network
                  </h3>
                  <p className="text-xs text-slate-500">
                    Live MapLibre representation of North Region operational zone centers and active waypoint nodes
                  </p>
                </div>
                <span className="text-xs font-mono text-emerald-600 font-bold bg-emerald-50 dark:bg-emerald-950 px-3 py-1 rounded-xl">
                  6 Zones Active
                </span>
              </div>

              <RouteMap stops={regionalMapStops} zoom={10} className="h-80 sm:h-96" />
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 2: ZONE COORDINATORS & ASSIGNERS
            ========================================================================= */}
        {activeTab === 'assigners' && (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-6">
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white font-display">
                Zone Coordinators Supervision
              </h3>
              <p className="text-xs text-slate-500">
                Delivery Assigners responsible for localized zone team management, unassigned triage, and driver dispatch
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {zones.map((zone) => (
                <div
                  key={zone.id}
                  className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                      {zone.code} Coordinator
                    </span>
                    <span className="text-xs text-slate-400 font-mono">100% active</span>
                  </div>

                  <div>
                    <h4 className="text-base font-bold text-slate-900 dark:text-white font-display">
                      {zone.assigner?.name || 'Coordinator'}
                    </h4>
                    <p className="text-xs text-slate-500">{zone.assigner?.email}</p>
                    <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                      <Phone className="w-3 h-3" />
                      <span>{zone.assigner?.phone}</span>
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Team Managed:</span>
                      <strong className="text-slate-800 dark:text-slate-200">{zone.teamSize} boys</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Avg Assignment:</span>
                      <strong className="text-emerald-600 font-mono">1.8 mins</strong>
                    </div>
                  </div>

                  <div className="pt-2 flex items-center justify-between text-xs">
                    <span className="text-slate-500">Zone: <strong>{zone.name.split('-')[1]}</strong></span>
                    <Link
                      to="/logistics/zone"
                      className="font-bold text-emerald-600 hover:underline flex items-center gap-1"
                    >
                      <span>Inspect Zone</span>
                      <ArrowRight className="w-3 h-3" />
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 3: REGIONAL DELIVERY BOYS (100 FLEET)
            ========================================================================= */}
        {activeTab === 'delivery_boys' && (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white font-display">
                  Regional Delivery Fleet ({allDeliveryBoys.length} Delivery Partners)
                </h3>
                <p className="text-xs text-slate-500">
                  Partitioned across 6 operational zones in North Region
                </p>
              </div>

              {/* Zone Filter Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                <button
                  onClick={() => setSelectedZoneFilter('ALL')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                    selectedZoneFilter === 'ALL'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  All Zones ({allDeliveryBoys.length})
                </button>
                {zones.map((z) => (
                  <button
                    key={z.id}
                    onClick={() => setSelectedZoneFilter(z.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                      selectedZoneFilter === z.id
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {z.code} ({allDeliveryBoys.filter((b) => b.zoneId === z.id).length})
                  </button>
                ))}
              </div>
            </div>

            {/* Boys Roster Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 max-h-[640px] overflow-y-auto pr-1">
              {filteredBoys.map((boy) => {
                const assignedZone = zones.find((z) => z.id === boy.zoneId);
                return (
                  <div
                    key={boy.id}
                    className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 dark:text-white">
                          {boy.name}
                        </span>
                        <span className={`w-2 h-2 rounded-full ${
                          boy.status === 'AVAILABLE' ? 'bg-emerald-500' : boy.status === 'ON_DELIVERY' ? 'bg-blue-500' : 'bg-slate-400'
                        }`} />
                      </div>

                      <span className={`text-[9px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                        boy.status === 'AVAILABLE'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : boy.status === 'ON_DELIVERY'
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                          : 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-400'
                      }`}>
                        {boy.status}
                      </span>
                    </div>

                    <div className="text-slate-500 text-[11px] space-y-0.5">
                      <p className="font-mono">
                        {boy.vehicleType} • {boy.vehicleCapacityKg}kg • {boy.vehicleNumber}
                      </p>
                      <p className="text-slate-400">
                        Assigned Zone: <strong className="text-slate-700 dark:text-slate-300">{assignedZone?.name?.split('-')[0] || 'Zone'}</strong>
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px]">
                      <span className="font-mono text-slate-400">
                        {boy.activeTasksCount || 0} active • {boy.completedToday || 4} done
                      </span>
                      <span className="font-bold text-emerald-600">
                        ⭐ {boy.rating}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 4: ARTERIAL TRUNK ROUTES & MAPLIBRE MAP (EXISTING FLEET MAP)
            ========================================================================= */}
        {activeTab === 'routes' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Route Summary & Stops */}
            <div className="lg:col-span-6 space-y-6">
              <RouteSummary route={currentRoute} />

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    Waypoints & Stops Sequence
                  </h4>
                  <span className="text-xs text-slate-500 font-mono">
                    {currentRoute?.stops?.length || 0} stops
                  </span>
                </div>

                <div className="space-y-2.5">
                  {currentRoute?.stops?.map((stop, idx) => (
                    <RouteStopCard key={idx} stop={stop} />
                  ))}
                </div>
              </div>
            </div>

            {/* Right: Route Map */}
            <div className="lg:col-span-6 space-y-6">
              <div className="sticky top-6 space-y-4">
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold font-mono uppercase tracking-wider text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                      <span>🌾</span>
                      <span>NORTH INDIA ARTERIAL LOGISTICS CORRIDOR</span>
                    </span>
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                      Live Telemetry
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Exploring Northern Farm-to-Market Network
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                    Punjab • Haryana • Uttar Pradesh
                  </p>
                </div>

                <RouteMap stops={currentRoute?.stops || []} className="shadow-sm" />

                {routes.length > 1 && (
                  <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-2">
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                      Switch Route:
                    </span>
                    <div className="grid grid-cols-2 gap-2">
                      {routes.map((r) => (
                        <button
                          key={r.id}
                          onClick={() => setSelectedRoute(r)}
                          className={`p-2.5 rounded-xl border text-left text-xs font-semibold transition-colors cursor-pointer ${
                            currentRoute?.id === r.id
                              ? 'bg-emerald-50 border-emerald-300 text-emerald-800 dark:bg-emerald-950/40 dark:border-emerald-800 dark:text-emerald-300'
                              : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50'
                          }`}
                        >
                          <span className="font-mono block">{r.routeNumber}</span>
                          <span className="text-[10px] text-slate-400 font-normal">
                            {r.stops?.length || 0} stops • {r.totalDistanceKm} km
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 5: COLLECTION ROUTE PLANNER
            ========================================================================= */}
        {activeTab === 'planner' && (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
            <div>
              <span className="text-xs font-semibold text-emerald-600 uppercase font-mono tracking-wider">
                Multi-Stop Fleet Dispatch
              </span>
              <h3 className="text-2xl font-bold text-slate-900 dark:text-white font-display mt-1">
                Plan Farm Collection Route
              </h3>
              <p className="text-xs text-slate-500 max-w-2xl mt-1">
                Select available farm pickups to consolidate into a single optimized vehicle route.
              </p>
            </div>

            {plannerSuccessMsg && (
              <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>{plannerSuccessMsg}</span>
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              <div className="lg:col-span-7 space-y-3">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  Available Farm Collections:
                </span>
                {availableFulfillments.map((ful) => (
                  <div
                    key={ful.id}
                    onClick={() => toggleFulfillmentSelect(ful.id)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                      ful.selected
                        ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-900 dark:text-white">
                          Order #{ful.orderId}
                        </span>
                        <span className="text-xs text-slate-500">• {ful.supplierName}</span>
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                        {ful.farmLocation.approximateLocation}
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-bold text-emerald-600 block">
                        {ful.quantity} kg
                      </span>
                      <span className="text-[10px] text-slate-400">{ful.cropName}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="lg:col-span-5 space-y-5 bg-slate-50 dark:bg-slate-950/50 p-6 rounded-3xl border border-slate-200 dark:border-slate-800">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                    Assigned Vehicle Type:
                  </label>
                  <select
                    value={selectedVehicleType}
                    onChange={(e) => setSelectedVehicleType(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white"
                  >
                    {Object.keys(VEHICLE_PROFILES).map((v) => (
                      <option key={v} value={v}>{v} ({VEHICLE_PROFILES[v].capacityKg} kg cap)</option>
                    ))}
                  </select>
                </div>

                <CapacityIndicator
                  currentLoadKg={selectedLoadKg}
                  capacityKg={currentProfile.capacityKg}
                  vehicleType={selectedVehicleType}
                />

                <button
                  onClick={handleCreateRoute}
                  disabled={selectedBatch.length === 0 || isOverCapacity}
                  className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs cursor-pointer disabled:opacity-50"
                >
                  Generate Optimized Route Plan
                </button>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* =========================================================================
          DYNAMIC BALANCING ACTION MODAL
          ========================================================================= */}
      {rebalanceModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5 shadow-2xl animate-in zoom-in-95">
            <div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-amber-600 font-bold">
                Dynamic Fleet Balancing
              </span>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white font-display mt-0.5">
                Rebalance Zone A (Greater Noida West)
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Zone A has 20+ active deliveries. Reassign a delivery partner from a neighboring balanced zone (Zone B or Zone C) to restore equilibrium.
              </p>
            </div>

            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                Recommended Partners for Temporary Zone Shift:
              </span>
              {allDeliveryBoys
                .filter((b) => b.zoneId === 'zone-north-b' && b.status === 'AVAILABLE')
                .slice(0, 3)
                .map((boy) => (
                  <button
                    key={boy.id}
                    onClick={() => handleRebalanceZone(boy.id, 'zone-north-a')}
                    className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-emerald-500 bg-slate-50 dark:bg-slate-950 text-left flex items-center justify-between cursor-pointer transition-colors text-xs"
                  >
                    <div>
                      <span className="font-bold text-slate-900 dark:text-white block">
                        {boy.name}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        From Zone B (Noida Sec 62) • {boy.vehicleType} • ⭐ {boy.rating}
                      </span>
                    </div>
                    <span className="px-3 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[11px]">
                      Shift to Zone A →
                    </span>
                  </button>
                ))}
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setRebalanceModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 dark:text-slate-300 cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
