import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  Users, 
  Truck, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  MapPin, 
  Sparkles, 
  RefreshCw, 
  Phone
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { hierarchicalLogisticsService } from '../../services/logistics/hierarchicalLogisticsService';
import RouteMap from '../../components/logistics/RouteMap';

export default function ZoneOperations() {
  const { user } = useAuth();
  const zoneId = user?.zoneId || 'zone-north-a';

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [zoneSummary, setZoneSummary] = useState(null);
  const [selectedTask, setSelectedTask] = useState(null);
  const [assignModalOpen, setAssignModalOpen] = useState(false);
  const [escalateModalOpen, setEscalateModalOpen] = useState(false);
  const [actionSuccessMsg, setActionSuccessMsg] = useState(null);
  const [taskFilter, setTaskFilter] = useState('ALL'); // ALL, UNASSIGNED, IN_TRANSIT, DELIVERED

  const loadData = useCallback(async (isRefresh = false) => {
    try {
      if (isRefresh) setRefreshing(true);
      const summary = await hierarchicalLogisticsService.getZoneKPISummary(zoneId);
      setZoneSummary(summary);
    } catch (err) {
      console.error('Failed to load zone operations:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [zoneId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Handle Manual Assignment
  const handleAssignTask = async (boyId) => {
    if (!selectedTask) return;
    try {
      await hierarchicalLogisticsService.assignTaskManual(
        selectedTask.id,
        boyId,
        user?.id || 'usr-assigner-north-a',
        `Manually assigned by Zone Coordinator ${user?.name || 'Raj Kumar'}`
      );
      setActionSuccessMsg(`Task #${selectedTask.orderNumber} successfully assigned!`);
      setAssignModalOpen(false);
      setSelectedTask(null);
      await loadData();
      setTimeout(() => setActionSuccessMsg(null), 3500);
    } catch (err) {
      console.error('Manual assignment failed:', err);
    }
  };

  // Handle Smart Auto-Assignment trigger
  const handleAutoAssign = async (task) => {
    try {
      setRefreshing(true);
      const res = await hierarchicalLogisticsService.autoAssignOrderTask(task);
      if (res.success) {
        setActionSuccessMsg(`Auto-assigned to ${res.assignedBoy.name} (Score: ${res.score}%)`);
      } else {
        setActionSuccessMsg(`Auto-assignment note: ${res.reason}`);
      }
      await loadData();
      setTimeout(() => setActionSuccessMsg(null), 4000);
    } catch (err) {
      console.error('Auto-assignment failed:', err);
    } finally {
      setRefreshing(false);
    }
  };

  // Handle Escalation to Regional Head
  const handleEscalate = () => {
    setActionSuccessMsg(`Incident reported directly to Vikramaditya Singhania (Regional Logistics Head). Priority flag active.`);
    setEscalateModalOpen(false);
    setTimeout(() => setActionSuccessMsg(null), 4000);
  };

  const filteredTasks = useMemo(() => {
    if (!zoneSummary?.tasks) return [];
    if (taskFilter === 'ALL') return zoneSummary.tasks;
    return zoneSummary.tasks.filter((t) => t.status === taskFilter);
  }, [zoneSummary, taskFilter]);

  // Map stops from zone tasks
  const mapStops = useMemo(() => {
    if (!zoneSummary?.tasks) return [];
    return zoneSummary.tasks.map((t, idx) => ({
      sequenceNumber: idx + 1,
      stopType: t.status === 'DELIVERED' ? 'DELIVERY' : 'PICKUP',
      approximateAddress: t.pickupLocation?.name || t.deliveryLocation?.name || 'Zone Waypoint',
      latitude: t.pickupLocation?.lat || zoneSummary.zone?.centerLat,
      longitude: t.pickupLocation?.lng || zoneSummary.zone?.centerLng,
      producerName: t.deliveryBoyName || 'Pending Assignment'
    }));
  }, [zoneSummary]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950">
        <div className="flex flex-col items-center gap-2">
          <RefreshCw className="w-8 h-8 text-emerald-600 animate-spin" />
          <p className="text-xs font-bold text-slate-500 font-display">Loading Zone Operations...</p>
        </div>
      </div>
    );
  }

  const zone = zoneSummary?.zone || {};

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* =========================================================================
            1. ZONE HEADER & COORDINATOR META
            ========================================================================= */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800">
                <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                {zone.code || 'ZONE_A'} Coordinator
              </span>
              <span className="text-xs text-slate-500 font-mono">
                North Region • Operational Radius {zone.radiusKm || 12} km
              </span>
              <span className={`text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                zone.status === 'BALANCED'
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-300 dark:bg-emerald-950 dark:text-emerald-300'
                  : 'bg-amber-50 text-amber-700 border-amber-300 dark:bg-amber-950 dark:text-amber-300'
              }`}>
                {zone.status || 'BALANCED'}
              </span>
            </div>
            
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white font-display tracking-tight">
              {zone.name || 'Zone A - Greater Noida West'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-2xl leading-relaxed">
              Assigned Coordinator: <strong className="text-slate-900 dark:text-white">{zone.assigner?.name || user?.name || 'Raj Kumar'}</strong> ({zone.assigner?.email || user?.email || 'assigner.north.a@fasalsetu.demo'}). Local dispatch, real-time workload balancing, and delivery exceptions.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => loadData(true)}
              disabled={refreshing}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white hover:bg-slate-50 dark:bg-slate-800 dark:hover:bg-slate-750 text-xs font-bold text-slate-700 dark:text-slate-200 shadow-xs cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-emerald-600' : ''}`} />
              <span>{refreshing ? 'Syncing...' : 'Sync Zone'}</span>
            </button>

            <button
              onClick={() => setEscalateModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold shadow-xs cursor-pointer"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Escalate to Head</span>
            </button>
          </div>
        </div>

        {/* Action success alert */}
        {actionSuccessMsg && (
          <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-xs flex items-center justify-between animate-in fade-in">
            <div className="flex items-center gap-2 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>{actionSuccessMsg}</span>
            </div>
            <button onClick={() => setActionSuccessMsg(null)} className="text-xs underline text-emerald-700 cursor-pointer">
              Dismiss
            </button>
          </div>
        )}

        {/* =========================================================================
            2. ZONE OPERATIONS KPIS
            ========================================================================= */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
              <span className="text-xs font-bold font-mono uppercase">Zone Team</span>
              <Users className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-2xl font-black text-slate-900 dark:text-white font-display">
              {zoneSummary?.teamSize || 0}
            </div>
            <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold mt-1">
              {zoneSummary?.availableBoys || 0} available right now
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
              <span className="text-xs font-bold font-mono uppercase">In Transit</span>
              <Truck className="w-4 h-4 text-blue-600" />
            </div>
            <div className="text-2xl font-black text-slate-900 dark:text-white font-display">
              {zoneSummary?.activeDeliveriesCount || 0}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              {zoneSummary?.onDeliveryBoys || 0} delivery boys en-route
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
              <span className="text-xs font-bold font-mono uppercase">Unassigned</span>
              <AlertTriangle className="w-4 h-4 text-amber-500" />
            </div>
            <div className="text-2xl font-black text-amber-600 dark:text-amber-400 font-display">
              {zoneSummary?.unassignedCount || 0}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Require auto / manual dispatch
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
              <span className="text-xs font-bold font-mono uppercase">Delayed</span>
              <Clock className="w-4 h-4 text-rose-500" />
            </div>
            <div className="text-2xl font-black text-slate-900 dark:text-white font-display">
              {zoneSummary?.delayedCount || 0}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Escalation threshold monitored
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs col-span-2 lg:col-span-1">
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
              <span className="text-xs font-bold font-mono uppercase">Delivered Today</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            </div>
            <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 font-display">
              {zoneSummary?.deliveredTodayCount || 0}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              100% farm-gate direct
            </p>
          </div>
        </div>

        {/* =========================================================================
            3. TWO COLUMN LAYOUT: ZONE DELIVERIES BOARD & DELIVERY BOYS ROSTER
            ========================================================================= */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* LEFT 7 COLS: ZONE DELIVERIES & TASK BOARD */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white font-display">
                    Zone Deliveries & Tasks
                  </h3>
                  <p className="text-xs text-slate-500">
                    Live parcels and farm-to-consumer collections in {zone.name}
                  </p>
                </div>

                <div className="flex items-center gap-1.5 overflow-x-auto">
                  {['ALL', 'UNASSIGNED', 'IN_TRANSIT', 'DELIVERED'].map((filter) => (
                    <button
                      key={filter}
                      onClick={() => setTaskFilter(filter)}
                      className={`px-3 py-1.5 rounded-xl text-[11px] font-bold transition-colors cursor-pointer whitespace-nowrap ${
                        taskFilter === filter
                          ? 'bg-slate-900 text-white dark:bg-emerald-600'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300'
                      }`}
                    >
                      {filter}
                    </button>
                  ))}
                </div>
              </div>

              {/* Tasks List */}
              <div className="space-y-3">
                {filteredTasks.length === 0 ? (
                  <div className="py-12 text-center text-slate-400 text-xs">
                    No delivery tasks matching filter "{taskFilter}".
                  </div>
                ) : (
                  filteredTasks.map((task) => (
                    <div
                      key={task.id}
                      className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-emerald-500/50 transition-all bg-slate-50/50 dark:bg-slate-950/40 space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-slate-900 dark:text-white">
                            #{task.orderNumber || task.orderId}
                          </span>
                          <span className={`text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                            task.priority === 'EXPRESS'
                              ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                              : task.priority === 'HIGH'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              : 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                          }`}>
                            {task.priority || 'NORMAL'}
                          </span>
                        </div>

                        <span className={`text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                          task.status === 'DELIVERED'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : task.status === 'UNASSIGNED'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                        }`}>
                          {task.status}
                        </span>
                      </div>

                      {/* Route Waypoints */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800">
                          <span className="text-[10px] font-mono text-emerald-600 font-bold uppercase block">
                            Pickup
                          </span>
                          <span className="font-semibold text-slate-800 dark:text-slate-200 block truncate">
                            {task.pickupLocation?.name || 'Farm Gate'}
                          </span>
                          <span className="text-[11px] text-slate-400 truncate block">
                            {task.pickupLocation?.address || 'Dankaur Link'}
                          </span>
                        </div>

                        <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800">
                          <span className="text-[10px] font-mono text-purple-600 font-bold uppercase block">
                            Delivery
                          </span>
                          <span className="font-semibold text-slate-800 dark:text-slate-200 block truncate">
                            {task.deliveryLocation?.name || 'Customer Residence'}
                          </span>
                          <span className="text-[11px] text-slate-400 truncate block">
                            {task.deliveryLocation?.address || 'Sector 16C, Greater Noida'}
                          </span>
                        </div>
                      </div>

                      {/* Payload & Assignment Footnote */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-slate-200/60 dark:border-slate-800 text-xs">
                        <div className="text-slate-500 text-[11px]">
                          <span>Assigned To: </span>
                          <strong className="text-slate-800 dark:text-slate-200">
                            {task.deliveryBoyName || 'Unassigned'}
                          </strong>
                          {task.totalWeightKg && (
                            <span className="ml-2 font-mono text-slate-400">({task.totalWeightKg} kg)</span>
                          )}
                        </div>

                        <div className="flex items-center gap-2">
                          {task.status === 'UNASSIGNED' && (
                            <button
                              onClick={() => handleAutoAssign(task)}
                              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] cursor-pointer shadow-xs"
                            >
                              <Sparkles className="w-3 h-3" />
                              <span>Auto-Assign</span>
                            </button>
                          )}
                          <button
                            onClick={() => {
                              setSelectedTask(task);
                              setAssignModalOpen(true);
                            }}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 font-bold text-[11px] text-slate-700 dark:text-slate-200 cursor-pointer"
                          >
                            <span>Reassign</span>
                          </button>
                        </div>
                      </div>

                      {task.assignmentReason && (
                        <p className="text-[10px] text-slate-400 italic bg-white dark:bg-slate-900/50 p-2 rounded-lg border border-slate-100 dark:border-slate-800/60">
                          ℹ️ {task.assignmentReason}
                        </p>
                      )}
                    </div>
                  ))
                )}
              </div>

            </div>
          </div>

          {/* RIGHT 5 COLS: ZONE DELIVERY BOYS ROSTER & MAP */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Zone Map Preview */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900 dark:text-white font-display">
                  Zone GIS Coverage
                </span>
                <span className="text-[10px] font-mono text-emerald-600 font-bold uppercase">
                  MapLibre Active
                </span>
              </div>
              <RouteMap stops={mapStops} zoom={11} className="h-60" />
            </div>

            {/* Delivery Boys List in this zone */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white font-display">
                    Zone Delivery Boys ({zoneSummary?.boys?.length || 0})
                  </h3>
                  <p className="text-xs text-slate-500">
                    Active delivery team assigned to {zone.name}
                  </p>
                </div>
              </div>

              <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1">
                {zoneSummary?.boys?.map((boy) => (
                  <div
                    key={boy.id}
                    className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/40 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="space-y-0.5 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 dark:text-white truncate">
                          {boy.name}
                        </span>
                        <span className={`w-2 h-2 rounded-full ${
                          boy.status === 'AVAILABLE' ? 'bg-emerald-500' : boy.status === 'ON_DELIVERY' ? 'bg-blue-500' : 'bg-slate-400'
                        }`} />
                      </div>
                      <p className="text-[11px] text-slate-500 font-mono">
                        {boy.vehicleType} • {boy.vehicleCapacityKg}kg cap • ⭐ {boy.rating}
                      </p>
                      <p className="text-[10px] text-slate-400 flex items-center gap-1">
                        <Phone className="w-2.5 h-2.5" />
                        <span>{boy.phone}</span>
                      </p>
                    </div>

                    <div className="text-right shrink-0">
                      <span className={`text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-full block mb-1 ${
                        boy.status === 'AVAILABLE'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : boy.status === 'ON_DELIVERY'
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                          : 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-400'
                      }`}>
                        {boy.status}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {boy.activeTasksCount || 0} active task{(boy.activeTasksCount || 0) !== 1 ? 's' : ''}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>

      </div>

      {/* =========================================================================
          MANUAL REASSIGNMENT MODAL
          ========================================================================= */}
      {assignModalOpen && selectedTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5 shadow-2xl animate-in zoom-in-95">
            <div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-600 font-bold">
                Manual Assignment Console
              </span>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white font-display mt-0.5">
                Assign #{selectedTask.orderNumber || selectedTask.orderId}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Select an available delivery boy in {zone.name}.
              </p>
            </div>

            <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
              {zoneSummary?.boys?.map((boy) => (
                <button
                  key={boy.id}
                  onClick={() => handleAssignTask(boy.id)}
                  className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-emerald-500 bg-slate-50 dark:bg-slate-950 text-left flex items-center justify-between cursor-pointer transition-colors"
                >
                  <div>
                    <span className="text-xs font-bold text-slate-900 dark:text-white block">
                      {boy.name}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {boy.vehicleType} • {boy.vehicleCapacityKg}kg • {boy.status}
                    </span>
                  </div>
                  <span className="text-xs text-emerald-600 font-bold">
                    Select →
                  </span>
                </button>
              ))}
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setAssignModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          ESCALATE TO REGIONAL HEAD MODAL
          ========================================================================= */}
      {escalateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-950 flex items-center justify-center text-amber-600">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white font-display">
                Escalate Bottleneck to Regional Head
              </h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                This will trigger an operational alert directly on Vikramaditya Singhania's Regional Command Center requesting dynamic zone rebalancing or neighboring fleet allocation.
              </p>
            </div>

            <div className="flex justify-end gap-2 pt-4 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setEscalateModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 dark:text-slate-300 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleEscalate}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold shadow-xs cursor-pointer"
              >
                Confirm Escalation
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
