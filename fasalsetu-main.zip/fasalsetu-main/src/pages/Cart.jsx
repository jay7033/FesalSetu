import React from 'react';
import { Link } from 'react-router-dom';
import { 
  ShoppingBag, 
  Trash2, 
  Plus, 
  Minus, 
  ArrowRight, 
  ArrowLeft, 
  MapPin, 
  Sparkles, 
  ShieldCheck, 
  Truck, 
  Leaf
} from 'lucide-react';
import ProductImage from '../components/ProductImage';
import Button from '../components/Button';
import { useCart } from '../context/CartContext';

export default function Cart() {
  const { 

    cartItems, 
    removeItem, 
    increaseQuantity, 
    decreaseQuantity, 
    clearCart,
    subtotal, 
    totalSavings,
    deliveryFee, 
    grandTotal, 
    totalQuantity 
  } = useCart();

  if (cartItems.length === 0) {
    return (
      <div className="bg-slate-50 min-h-[75vh] flex items-center justify-center py-16 px-4">
        <div className="max-w-md w-full bg-white rounded-3xl border border-slate-200/90 p-8 sm:p-10 text-center space-y-5 shadow-sm">
          <div className="w-20 h-20 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center mx-auto text-emerald-600">
            <ShoppingBag className="w-10 h-10" />
          </div>

          <div className="space-y-1.5">
            <h2 className="text-2xl font-extrabold text-slate-900 font-display">
              Your Cart is Empty
            </h2>
            <p className="text-slate-500 text-sm leading-relaxed">
              You haven't added any direct farm produce yet. Explore verified harvest lots directly from farmers and FPOs across India.
            </p>
          </div>

          <div className="pt-2">
            <Button
              to="/marketplace"
              variant="primary"
              size="lg"
              className="w-full justify-center"
              rightIcon={ArrowRight}
            >
              Explore Farm Marketplace
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 min-h-screen py-10 sm:py-14">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 mb-8 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 uppercase tracking-wider">
              <Leaf className="w-3.5 h-3.5" />
              <span>Direct Farm Procurement</span>
            </div>
            <h1 className="text-3xl font-black text-slate-950 font-display tracking-tight mt-1">
              Your Farm Basket
            </h1>
            <p className="text-slate-500 text-xs mt-0.5">
              {cartItems.length} item{cartItems.length > 1 ? 's' : ''} ({totalQuantity} units total) direct from verified farm producers
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={clearCart}
              className="text-xs font-semibold text-red-600 hover:text-red-700 flex items-center gap-1.5 hover:underline"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Cart</span>
            </button>

            <Link
              to="/marketplace"
              className="text-xs font-semibold text-slate-600 hover:text-emerald-700 flex items-center gap-1 hover:underline"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Continue Shopping</span>
            </Link>
          </div>
        </div>

        {/* Content Grid: Left Items + Right Summary */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Cart Items List (8 cols) */}
          <div className="lg:col-span-8 space-y-4">
            {cartItems.map((item) => {
              const itemSubtotal = item.price * item.quantity;
              const step = item.unit === 'kg' ? 5 : 1;

              return (
                <div 
                  key={item.id}
                  className="bg-white rounded-3xl border border-slate-200/90 p-4 sm:p-6 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:border-emerald-200 transition-colors"
                >
                  {/* Image & Product Name */}
                  <div className="flex items-center gap-4 flex-1 min-w-0">
                    <div className="w-20 h-20 rounded-2xl overflow-hidden bg-slate-100 flex-shrink-0 border border-slate-200/60">
                      <ProductImage
                        src={item.image}
                        alt={item.name}
                        category={item.category}
                        containerClassName="w-full h-full"
                      />
                    </div>

                    <div className="min-w-0 space-y-1">
                      <Link 
                        to={`/product/${item.id}`}
                        className="font-bold text-slate-900 text-base font-display hover:text-emerald-700 transition-colors truncate block"
                      >
                        {item.name}
                      </Link>

                      <p className="text-xs text-slate-500 flex items-center gap-1.5 truncate">
                        <span className="font-medium text-slate-700">{item.farmer}</span>
                        <span>•</span>
                        <span className="flex items-center gap-0.5 text-emerald-700">
                          <MapPin className="w-3 h-3" />
                          <span>{item.location}</span>
                        </span>
                      </p>

                      <div className="flex items-center gap-2 pt-0.5">
                        <span className="text-xs font-black text-slate-900 font-display">
                          ₹{item.price}/{item.unit}
                        </span>
                        {item.organic && (
                          <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                            Organic
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Quantity Stepper & Subtotal */}
                  <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-100">
                    
                    {/* Stepper */}
                    <div className="flex items-center gap-2 bg-slate-50 p-1.5 rounded-2xl border border-slate-200">
                      <button
                        type="button"
                        onClick={() => decreaseQuantity(item.id, step)}
                        aria-label="Decrease quantity"
                        className="w-8 h-8 rounded-xl bg-white text-slate-700 hover:bg-slate-100 font-bold text-base flex items-center justify-center border border-slate-200 shadow-xs"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>

                      <span className="text-xs font-black text-slate-900 font-mono w-14 text-center">
                        {item.quantity} {item.unit}
                      </span>

                      <button
                        type="button"
                        onClick={() => increaseQuantity(item.id, step)}
                        aria-label="Increase quantity"
                        className="w-8 h-8 rounded-xl bg-white text-slate-700 hover:bg-slate-100 font-bold text-base flex items-center justify-center border border-slate-200 shadow-xs"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Item Total */}
                    <div className="text-right min-w-[70px]">
                      <p className="text-xs text-slate-400 uppercase font-semibold text-[10px]">Total</p>
                      <p className="text-base font-black text-slate-950 font-display">
                        ₹{itemSubtotal}
                      </p>
                    </div>

                    {/* Remove button */}
                    <button
                      type="button"
                      onClick={() => removeItem(item.id)}
                      aria-label="Remove item"
                      className="p-2 text-slate-400 hover:text-red-600 rounded-xl hover:bg-red-50 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                  </div>
                </div>
              );
            })}

            {/* Farm direct note banner */}
            <div className="p-4 rounded-3xl bg-emerald-50/70 border border-emerald-200/80 flex items-start gap-3 text-xs text-emerald-900">
              <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Zero Mandi Commission Guarantee: </span>
                <span>Your order connects directly to local FPOs with zero commission deductions. Farmers receive the listed price directly.</span>
              </div>
            </div>
          </div>

          {/* Right: Order Summary (4 cols) */}
          <div className="lg:col-span-4 sticky top-24 space-y-4">
            <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-6 space-y-6">
              <h2 className="text-lg font-black text-slate-950 font-display pb-3 border-b border-slate-100">
                Order Summary
              </h2>

              {/* Cost Rows */}
              <div className="space-y-3 text-sm">
                <div className="flex items-center justify-between text-slate-600">
                  <span>Farm Subtotal</span>
                  <span className="font-bold text-slate-900 font-mono">₹{subtotal}</span>
                </div>

                <div className="flex items-center justify-between text-slate-600">
                  <span className="flex items-center gap-1">
                    <Truck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Local EV Transit</span>
                  </span>
                  <span className="font-bold font-mono">
                    {deliveryFee === 0 ? (
                      <span className="text-emerald-700 uppercase text-xs">FREE</span>
                    ) : (
                      `₹${deliveryFee}`
                    )}
                  </span>
                </div>

                {deliveryFee > 0 && (
                  <p className="text-[11px] text-slate-500 bg-slate-50 p-2 rounded-xl border border-slate-100">
                    Add ₹{500 - subtotal} more to unlock <strong>FREE EV Delivery</strong> across Noida sectors!
                  </p>
                )}

                {totalSavings > 0 && (
                  <div className="flex items-center justify-between text-emerald-700 bg-emerald-50 px-3 py-2 rounded-xl border border-emerald-200 font-semibold text-xs">
                    <span className="flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Estimated Middlemen Savings</span>
                    </span>
                    <span className="font-mono font-bold">₹{totalSavings}</span>
                  </div>
                )}

                <div className="pt-3 border-t border-slate-200 flex items-baseline justify-between">
                  <div>
                    <span className="text-base font-bold text-slate-900 font-display">Total Amount</span>
                    <p className="text-[10px] text-slate-400">All local taxes & farm gate handling included</p>
                  </div>
                  <span className="text-2xl font-black text-slate-950 font-display">
                    ₹{grandTotal}
                  </span>
                </div>
              </div>

              {/* Proceed to Checkout */}
              <div className="space-y-2">
                <Button
                  to="/checkout"
                  variant="primary"
                  size="lg"
                  className="w-full justify-center"
                  rightIcon={ArrowRight}
                >
                  PROCEED TO CHECKOUT
                </Button>

                <p className="text-[10px] text-slate-400 text-center">
                  Hyperlocal logistics & checkout preview will confirm your delivery address.
                </p>
              </div>

              {/* Prototype Disclaimer */}
              <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500 space-y-1">
                <p className="font-semibold text-amber-800">
                  📍 Hyperlocal Delivery Zone:
                </p>
                <p className="text-slate-400">
                  Covers Noida Sectors (50, 62, 78, 137, 150) and Greater Noida (Pari Chowk, Alpha, Beta).
                </p>
              </div>

            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
