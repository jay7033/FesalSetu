import React from 'react';
import { useLocation } from 'react-router-dom';
import { 
  ShoppingBag, 
  Sparkles, 
  Truck, 
  LogIn, 
  ArrowLeft, 
  Clock, 
  CheckCircle2, 
  Zap,
  Layers
} from 'lucide-react';
import Button from '../components/Button';


export default function Placeholder({ pageType }) {
  const location = useLocation();

  const configs = {
    marketplace: {
      title: 'Hyperlocal Crop Marketplace',
      module: 'Marketplace Engine',
      icon: ShoppingBag,
      tag: 'Coming Soon',
      color: 'emerald',
      description: 'The real-time marketplace catalogue connecting farmers in Jewar, Dankaur, and Dadri with verified buyers across Noida societies.',
      features: [
        'Live farm-gate pricing with zero intermediary fee',
        'Direct procurement bids & group-buying contracts for apartments',
        'Transparent batch harvest timestamps & farmer profiles',
        'Multi-lingual mobile order interface (Hindi & English)'
      ]
    },
    aiInsights: {
      title: 'AI Predictive Demand Engine',
      module: 'AI & Predictive Analytics',
      icon: Sparkles,
      tag: 'Coming Soon',
      color: 'purple',
      description: 'Predictive intelligence analyzing Noida retail consumption rates, price trends, and weather forecasting to guide sowing and harvesting.',
      features: [
        'Sector-level daily demand forecasting for high-perishables',
        'Price trend forecasting based on Mandi vs Farm-gate indices',
        'Post-harvest spoilage risk mitigation scorecards',
        'Smart SMS and WhatsApp harvesting advisories for FPOs'
      ]
    },
    logistics: {
      title: 'Smart Logistics & Route Optimization',
      module: 'Hyperlocal Fleet Engine',
      icon: Truck,
      tag: 'Coming Soon',
      color: 'blue',
      description: 'Route clustering algorithms optimizing morning farm pickups along Yamuna Expressway for swift, refrigerated EV delivery.',
      features: [
        'Dynamic multi-farm aggregation routes along Yamuna Expressway',
        'EV 3-wheeler cluster assignment for zero-emission transit',
        'Temperature & freshness transit tracking badges',
        'Turnaround target: Under 5 hours from harvest to kitchen'
      ]
    },
    login: {
      title: 'Farmer & Buyer Access Portal',
      module: 'Secure Authentication',
      icon: LogIn,
      tag: 'Coming Soon',
      color: 'amber',
      description: 'Secure, OTP-based phone authentication for farmers, FPO managers, and society bulk buyers with tailored role-based dashboards.',
      features: [
        'Phone number OTP login designed for rural mobile accessibility',
        'Kisan Aadhaar & FPO verification workflows',
        'Bulk buyer business verification for Noida societies',
        'Direct bank account linking via UPI for instant payouts'
      ]
    },
    checkout: {
      title: 'Hyperlocal Checkout & Dispatch',
      module: 'Logistics & Dispatch',
      icon: Truck,
      tag: 'Coming Soon',
      color: 'emerald',
      description: 'Zero-commission direct checkout with automated UPI settlement to farmers and EV delivery dispatch across Noida and Greater Noida.',
      features: [
        'Instant UPI payments settled directly to farmer accounts',
        'Noida apartment society delivery cluster selection',
        'Preferred morning harvest delivery window (6:00 AM - 10:00 AM)',
        'GPS live route tracker along Yamuna Expressway'
      ]
    }
  };

  // Determine current config from prop or path
  let currentKey = pageType;
  if (!currentKey) {
    if (location.pathname.includes('marketplace')) currentKey = 'marketplace';
    else if (location.pathname.includes('ai-insights')) currentKey = 'aiInsights';
    else if (location.pathname.includes('logistics')) currentKey = 'logistics';
    else if (location.pathname.includes('login')) currentKey = 'login';
    else if (location.pathname.includes('checkout')) currentKey = 'checkout';
    else currentKey = 'marketplace';
  }


  const config = configs[currentKey] || configs.marketplace;
  const Icon = config.icon;

  return (
    <div className="min-h-[75vh] flex items-center justify-center py-16 px-4 sm:px-6 lg:px-8 bg-slate-50 relative overflow-hidden">
      
      {/* Background ambient elements */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-96 h-96 bg-emerald-100/60 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-10 right-10 w-72 h-72 bg-amber-100/50 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-2xl w-full text-center space-y-8">
        
        {/* Status Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-100/90 border border-emerald-300 text-emerald-800 text-xs font-bold tracking-wide uppercase shadow-xs">
          <Clock className="w-3.5 h-3.5 text-emerald-600 animate-spin" style={{ animationDuration: '6s' }} />
          <span>Upcoming Feature</span>
        </div>

        {/* Hero Icon */}
        <div className="mx-auto w-20 h-20 rounded-2xl bg-white shadow-lg border border-slate-200/80 flex items-center justify-center relative group">
          <div className="p-4 rounded-xl bg-emerald-50 text-emerald-600">
            <Icon className="w-10 h-10" />
          </div>
          <span className="absolute -top-2 -right-2 px-2 py-0.5 rounded-md bg-amber-500 text-white font-mono text-[10px] font-bold shadow-xs">
            FasalSetu Core
          </span>
        </div>

        {/* Title & Description */}
        <div className="space-y-3">
          <span className="text-xs font-semibold tracking-wider text-slate-500 uppercase">
            {config.module}
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-display">
            {config.title}
          </h1>
          <p className="text-slate-600 text-base sm:text-lg max-w-xl mx-auto leading-relaxed">
            {config.description}
          </p>
        </div>

        {/* Planned Features in Roadmap */}
        <div className="bg-white/90 backdrop-blur-md rounded-2xl p-6 border border-slate-200/80 shadow-sm text-left">
          <div className="flex items-center gap-2 pb-3 mb-4 border-b border-slate-100 text-xs font-bold uppercase tracking-wider text-slate-500">
            <Layers className="w-4 h-4 text-emerald-600" />
            <span>Architecture Roadmap for this module</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {config.features.map((feature, idx) => (
              <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                <span>{feature}</span>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Buttons */}
        {currentKey === 'login' ? (
          <div className="space-y-4 pt-2">
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-left space-y-2">
              <span className="text-xs font-bold text-emerald-900 uppercase tracking-wider">
                Direct Prototype Access
              </span>
              <p className="text-xs text-emerald-800">
                You can explore the full Pan-India Farmer & FPO portal directly using the preconfigured demo account.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <Button
                to="/login?role=farmer"
                variant="primary"
                size="lg"
                className="w-full sm:w-auto justify-center"
              >
                🚜 Login to Farmer Portal
              </Button>

              <Button
                to="/marketplace"
                variant="outline"
                size="lg"
                className="w-full sm:w-auto justify-center"
              >
                🛍️ Browse Marketplace
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <Button
              to="/"
              variant="outline"
              size="md"
              leftIcon={ArrowLeft}
            >
              Back to Home
            </Button>

            <Button
              to="/how-it-works"
              variant="primary"
              size="md"
              rightIcon={Zap}
            >
              Explore How It Works
            </Button>
          </div>
        )}

        {/* Notice */}
        <p className="text-xs text-slate-400">
          📍 Pan-India Deployment Architecture • SIH FasalSetu Engine
        </p>

      </div>
    </div>
  );
}
