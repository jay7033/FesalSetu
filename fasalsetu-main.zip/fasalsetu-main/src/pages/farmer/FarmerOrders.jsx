import React, { useState } from 'react';
import { 
  ShoppingBag, 
  MapPin, 
  Clock, 
  Check, 
  Package, 
  CheckCircle2, 
  Search, 
  RotateCcw,
  Truck,
  AlertCircle
} from 'lucide-react';
import StatusBadge from '../../components/dashboard/StatusBadge';
import { useOrders } from '../../context/OrderContext';
import { useAuth } from '../../context/AuthContext';

const STATUS_FILTERS = [
  'All',
  'Pending',
  'Confirmed',
  'Preparing',
  'Ready for Pickup',
  'Picked Up',
  'In Transit',
  'Delivered',
  'Cancelled'
];

export default function FarmerOrders() {
  const { orders, updateOrderStatus, resetOrders } = useOrders();
  const { user } = useAuth();
  const isDemo = !user || user.isDemo || user.email === 'farmer@fasalsetu.demo';

  const [activeTab, setActiveTab] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [actionError, setActionError] = useState(null);

  // Filter orders where farmer is supplier or general orders
  const farmerOrders = orders.filter((ord) => {
    if (isDemo) return true;
    return ord.farmerId === user?.id || ord.farmerName === user?.name || !ord.isDemo;
  });

  const filteredOrders = farmerOrders.filter((ord) => {
    const matchesTab = activeTab === 'All' || ord.status.toLowerCase() === activeTab.toLowerCase();
    const q = searchTerm.toLowerCase().trim();
    const matchesSearch = !q || 
      ord.id.toLowerCase().includes(q) ||
      (ord.product && ord.product.toLowerCase().includes(q)) ||
      (ord.buyer && ord.buyer.toLowerCase().includes(q)) ||
      (ord.buyerName && ord.buyerName.toLowerCase().includes(q)) ||
      (ord.location && ord.location.toLowerCase().includes(q));
    return matchesTab && matchesSearch;
  });

  const handleStatusChange = (orderId, targetStatus) => {
    setActionError(null);
    const res = updateOrderStatus(orderId, targetStatus);
    if (!res.success) {
      setActionError(res.error);
      setTimeout(() => setActionError(null), 4000);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
              Producer Fulfillment Portal
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold">
              Shared OrderContext
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-950 font-display tracking-tight">
            Incoming Orders & Dispatches
          </h1>
          <p className="text-slate-500 text-xs sm:text-sm mt-0.5">
            Direct buyer procurement requests from housing societies, consumers, and commercial bulk partners.
          </p>
        </div>

        <button
          type="button"
          onClick={resetOrders}
          className="text-xs font-semibold text-slate-500 hover:text-emerald-700 flex items-center gap-1.5 self-start sm:self-auto hover:underline cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Demo Orders</span>
        </button>
      </div>

      {actionError && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
          <span>{actionError}</span>
        </div>
      )}

      {/* Filter Tabs & Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Status Filter Tabs */}
        <div className="flex flex-wrap gap-1.5 p-1 rounded-2xl bg-white border border-slate-200 w-full sm:w-auto overflow-x-auto">
          {STATUS_FILTERS.map((tab) => (
            <button
              key={tab}
              type="button"
              onClick={() => setActiveTab(tab)}
              className={`text-xs px-3.5 py-1.5 rounded-xl font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeTab === tab
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search orders, crops, buyers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 focus:outline-emerald-500"
          />
        </div>
      </div>

      {/* Orders Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {filteredOrders.length === 0 ? (
          <div className="lg:col-span-2 bg-white rounded-3xl p-12 text-center border border-slate-200 text-slate-400 space-y-2">
            <ShoppingBag className="w-10 h-10 mx-auto opacity-40 text-emerald-600" />
            <p className="text-sm font-bold text-slate-700">No orders match the selected filter</p>
            <p className="text-xs">Select "All" to view all incoming orders.</p>
          </div>
        ) : (
          filteredOrders.map((ord) => (
            <div 
              key={ord.id}
              className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-xs hover:shadow-md transition-all duration-200 flex flex-col justify-between space-y-5"
            >
              <div className="space-y-4">
                
                {/* Order Top Bar */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-mono font-black text-emerald-800">
                      #{ord.id}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {ord.date || 'Today'}
                    </span>
                  </div>
                  <StatusBadge status={ord.status} size="sm" />
                </div>

                {/* Visual Order Lifecycle Mini-Tracker */}
                {ord.status !== 'Cancelled' && (
                  <div className="py-1">
                    <div className="flex items-center justify-between text-[9px] font-mono font-semibold text-slate-400 mb-1">
                      <span className={['Pending', 'Confirmed', 'Preparing', 'Ready for Pickup', 'Picked Up', 'In Transit', 'Delivered'].includes(ord.status) ? 'text-emerald-700 font-bold' : ''}>Ordered</span>
                      <span className={['Preparing', 'Ready for Pickup', 'Picked Up', 'In Transit', 'Delivered'].includes(ord.status) ? 'text-emerald-700 font-bold' : ''}>Packed</span>
                      <span className={['In Transit', 'Delivered'].includes(ord.status) ? 'text-emerald-700 font-bold' : ''}>Transit</span>
                      <span className={ord.status === 'Delivered' ? 'text-emerald-700 font-bold' : ''}>Delivered</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden flex">
                      <div 
                        className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                        style={{
                          width: ord.status === 'Pending' ? '15%'
                               : ord.status === 'Confirmed' ? '30%'
                               : ord.status === 'Preparing' ? '50%'
                               : ord.status === 'Ready for Pickup' ? '65%'
                               : ord.status === 'Picked Up' ? '75%'
                               : ord.status === 'In Transit' ? '88%'
                               : ord.status === 'Delivered' ? '100%'
                               : '10%'
                        }}
                      />
                    </div>
                  </div>
                )}

                {/* Product & Quantity */}
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="text-base font-bold text-slate-950 font-display">
                      {ord.product || ord.items?.[0]?.name || 'Fresh Farm Produce'}
                    </h3>
                    <p className="text-xs font-semibold text-emerald-700 mt-0.5">
                      Quantity: {ord.quantity} {ord.unit || 'kg'}
                    </p>
                    {ord.buyerRole && (
                      <span className="inline-block mt-1 text-[10px] font-bold px-2 py-0.2 rounded bg-slate-100 text-slate-600 uppercase">
                        {ord.buyerRole === 'bulk_buyer' ? 'B2B Bulk Buyer' : 'Household Consumer'}
                      </span>
                    )}
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Total Value</span>
                    <p className="text-xl font-black text-slate-950 font-display">
                      ₹{(ord.total || ord.amount || 0).toLocaleString('en-IN')}
                    </p>
                  </div>
                </div>

                {/* Buyer & Destination */}
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800">{ord.buyerName || ord.buyer}</span>
                    <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded">
                      {ord.paymentStatus}
                    </span>
                  </div>
                  <p className="text-slate-500 flex items-center gap-1 text-[11px]">
                    <MapPin className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                    <span>Destination: {ord.location || ord.buyerLocation?.address || 'Noida Hub'}</span>
                  </p>
                </div>

              </div>

              {/* Sequential Status Action Buttons (Section 12 strict progression) */}
              <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                <span className="text-[11px] text-slate-400">
                  Current Stage: <strong className="text-slate-700">{ord.status}</strong>
                </span>

                <div className="flex items-center gap-2">
                  {ord.status === 'Pending' && (
                    <>
                      <button
                        type="button"
                        onClick={() => handleStatusChange(ord.id, 'Confirmed')}
                        className="px-3.5 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700 shadow-xs cursor-pointer"
                      >
                        CONFIRM ORDER
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStatusChange(ord.id, 'Cancelled')}
                        className="px-3 py-1.5 rounded-xl border border-rose-200 text-rose-700 text-xs font-bold hover:bg-rose-50 cursor-pointer"
                      >
                        Reject
                      </button>
                    </>
                  )}

                  {ord.status === 'Confirmed' && (
                    <button
                      type="button"
                      onClick={() => handleStatusChange(ord.id, 'Preparing')}
                      className="px-3.5 py-1.5 rounded-xl bg-amber-500 text-slate-950 text-xs font-bold hover:bg-amber-600 shadow-xs flex items-center gap-1 cursor-pointer"
                    >
                      <Package className="w-3.5 h-3.5" />
                      <span>START PREPARING</span>
                    </button>
                  )}

                  {ord.status === 'Preparing' && (
                    <button
                      type="button"
                      onClick={() => handleStatusChange(ord.id, 'Ready for Pickup')}
                      className="px-3.5 py-1.5 rounded-xl bg-teal-600 text-white text-xs font-bold hover:bg-teal-700 shadow-xs flex items-center gap-1 cursor-pointer"
                    >
                      <Clock className="w-3.5 h-3.5" />
                      <span>READY FOR PICKUP</span>
                    </button>
                  )}

                  {ord.status === 'Ready for Pickup' && (
                    <button
                      type="button"
                      onClick={() => handleStatusChange(ord.id, 'Picked Up')}
                      className="px-3.5 py-1.5 rounded-xl bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 shadow-xs flex items-center gap-1 cursor-pointer"
                    >
                      <Truck className="w-3.5 h-3.5" />
                      <span>DISPATCH / PICKED UP</span>
                    </button>
                  )}

                  {ord.status === 'Picked Up' && (
                    <button
                      type="button"
                      onClick={() => handleStatusChange(ord.id, 'In Transit')}
                      className="px-3.5 py-1.5 rounded-xl bg-cyan-600 text-white text-xs font-bold hover:bg-cyan-700 shadow-xs flex items-center gap-1 cursor-pointer"
                    >
                      <Truck className="w-3.5 h-3.5" />
                      <span>IN TRANSIT</span>
                    </button>
                  )}

                  {ord.status === 'In Transit' && (
                    <button
                      type="button"
                      onClick={() => handleStatusChange(ord.id, 'Delivered')}
                      className="px-3.5 py-1.5 rounded-xl bg-emerald-700 text-white text-xs font-bold hover:bg-emerald-800 shadow-xs flex items-center gap-1 cursor-pointer"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>CONFIRM DELIVERED</span>
                    </button>
                  )}

                  {ord.status === 'Delivered' && (
                    <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span>Completed & Settled</span>
                    </span>
                  )}

                  {ord.status === 'Cancelled' && (
                    <span className="text-xs font-semibold text-rose-600">
                      Cancelled
                    </span>
                  )}
                </div>
              </div>

            </div>
          ))
        )}
      </div>

    </div>
  );
}
