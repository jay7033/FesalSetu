import React from 'react';
import { Link } from 'react-router-dom';
import { 
  IndianRupee, 
  Package, 
  Clock, 
  TrendingUp, 
  Scale, 
  PlusCircle,
  FileText,
  Truck
} from 'lucide-react';
import StatCard from '../../components/farmer/StatCard';
import SalesChart from '../../components/farmer/SalesChart';
import EarningsChart from '../../components/farmer/EarningsChart';
import InventoryBadge from '../../components/farmer/InventoryBadge';
import Button from '../../components/Button';
import DashboardHeader from '../../components/dashboard/DashboardHeader';
import LocationStatusCard from '../../components/dashboard/LocationStatusCard';
import RecentOrdersTable from '../../components/dashboard/RecentOrdersTable';
import QuickActions from '../../components/dashboard/QuickActions';
import PickupSchedule from '../../components/logistics/PickupSchedule';
import OpportunityCard from '../../components/ai/OpportunityCard';
import { useProducts } from '../../context/ProductContext';
import { useLocation } from '../../context/LocationContext';
import { useOrders } from '../../context/OrderContext';
import { useAI } from '../../context/AIContext';
import { useLogistics } from '../../context/LogisticsContext';
import { useAuth } from '../../context/AuthContext';
import { isDemoRecord } from '../../services/hybridDataService';
import { INITIAL_DEMO_FARMER } from '../../data/demoData';

export default function FarmerDashboard() {
  const { user, isDemo } = useAuth();
  const { products } = useProducts();
  const { farmLocations, defaultFarmLocation, location } = useLocation();
  const { orders, updateOrderStatus } = useOrders();
  const { getFarmerOpportunityScores } = useAI();
  const { pickups, updatePickupStatus } = useLogistics();

  const farmerName = user?.name || (isDemo ? INITIAL_DEMO_FARMER.name : 'Farmer');

  // Products belonging to this authenticated farmer
  const farmerProducts = products.filter((p) => {
    if (user?.id && (p.seller_profile_id === user.id || p.sellerProfileId === user.id)) return true;
    if (isDemo) {
      return p.farmer === farmerName || p.farmer === 'Ramesh Kumar' || p.source === 'farmer-added';
    }
    return p.farmer === farmerName && !isDemoRecord(p);
  });

  // Orders belonging to this authenticated farmer
  const farmerOrders = orders.filter((o) => {
    if (user?.id && (o.farmerId === user.id || o.sellerProfileId === user.id)) return true;
    if (isDemo) return o.isDemo || !o.farmerId;
    return false;
  });

  const activeFarm = defaultFarmLocation || location;
  const isLocationVerified = Boolean(activeFarm?.confirmed || activeFarm?.latitude);
  const activeLocation =
    activeFarm?.approximateLocation ||
    [activeFarm?.locality || activeFarm?.village || activeFarm?.city, activeFarm?.district, activeFarm?.state]
      .filter(Boolean)
      .join(', ') ||
    'Dankaur, Greater Noida, UP';

  const farmerOpportunityScores = getFarmerOpportunityScores(farmerProducts);
  const primaryOpportunity = farmerOpportunityScores[0] || {
    cropName: 'Desi Tomato',
    score: 84,
    demandLevel: 'HIGH',
    supplyLevel: 'LOW',
    suggestedListing: '120–180 kg',
    recommendation: 'Local demand is rising (+18%). Consider listing 120–180 kg.',
    productionSignal: 'Positive (High Demand Signal)',
    confidenceScore: 78,
    explanations: [
      'Demand increased 18% over the previous period.',
      'Nearby inventory is below forecast demand.',
      '3 verified buyers are currently seeking this category.'
    ]
  };

  // Dynamic calculations from farmer's own orders
  const pendingOrdersCount = farmerOrders.filter(
    (o) => o.status === 'Confirmed' || o.status === 'Preparing' || o.status === 'Pending'
  ).length;

  const totalDeliveredSum = farmerOrders
    .filter((o) => o.status === 'Delivered')
    .reduce((acc, curr) => acc + (curr.amount || curr.total || 0), 0);

  const totalSalesFormatted = isDemo && totalDeliveredSum === 0
    ? '₹48,500'
    : `₹${totalDeliveredSum.toLocaleString('en-IN')}`;

  // Inventory Health calculation
  const inventoryHealth = {
    healthy: farmerProducts.filter((p) => (p.quantity || p.stock || 50) > 100).length,
    medium: farmerProducts.filter((p) => {
      const q = p.quantity || p.stock || 50;
      return q >= 20 && q <= 100;
    }).length,
    low: farmerProducts.filter((p) => {
      const q = p.quantity || p.stock || 50;
      return q > 0 && q < 20;
    }).length,
    outOfStock: farmerProducts.filter((p) => (p.quantity || p.stock || 50) === 0).length
  };

  const quickActionsList = [
    {
      label: '+ Add Product',
      icon: PlusCircle,
      to: '/farmer/add-product',
      description: 'List new harvest batch with farm-gate price',
      iconBg: 'bg-emerald-100 text-emerald-800'
    },
    {
      label: 'Manage Products',
      icon: Package,
      to: '/farmer/products',
      description: `View and update all ${farmerProducts.length} active listings`,
      iconBg: 'bg-blue-100 text-blue-800'
    },
    {
      label: 'Farm Locations',
      icon: TrendingUp,
      to: '/farmer/locations',
      description: `Manage ${farmLocations.length} registered farm parcels`,
      iconBg: 'bg-amber-100 text-amber-800'
    },
    {
      label: 'Orders',
      icon: FileText,
      to: '/farmer/orders',
      description: `Manage dispatches (${orders.length} orders total)`,
      iconBg: 'bg-purple-100 text-purple-800'
    },
    {
      label: 'Earnings',
      icon: IndianRupee,
      to: '/farmer/earnings',
      description: 'Direct payout ledger and UPI settlements',
      iconBg: 'bg-emerald-100 text-emerald-800'
    }
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      
      {/* Top Header & Greeting adhering to Section 5 */}
      <DashboardHeader
        greeting={`Good morning, ${farmerName}`}
        roleBadge="🌾 Producer Portal"
        locationType="Farm Location"
        locationText={activeLocation}
        isLocationVerified={isLocationVerified}
      >
        <Button
          to="/farmer/add-product"
          variant="primary"
          size="md"
          leftIcon={PlusCircle}
        >
          Add Product
        </Button>
      </DashboardHeader>

      {/* Farm Location Status Card */}
      <LocationStatusCard
        typeLabel="Verified Farm Location"
        locationName={isLocationVerified ? (activeFarm?.name || activeLocation) : 'No Primary Farm Location Set'}
        approximateAddress={`Near ${activeLocation}`}
        isVerified={isLocationVerified}
        source={activeFarm?.source || 'Device GPS'}
        accuracy={activeFarm?.accuracy || 14}
        coordinates={activeFarm?.latitude ? { latitude: activeFarm.latitude, longitude: activeFarm.longitude } : null}
        viewLink="/farmer/locations"
        updateLink="/farmer/locations/new"
        role="farmer"
      />

      {/* 5 Core KPI Metrics Cards adhering to Section 5 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 sm:gap-5">
        <StatCard
          title="Total Sales"
          value={totalSalesFormatted}
          subtext="Gross GMV this month"
          change="+18.4%"
          icon={IndianRupee}
          accent="emerald"
        />
        <StatCard
          title="Active Products"
          value={farmerProducts.length || 8}
          subtext="Live on Marketplace"
          change="Real-time"
          icon={Package}
          accent="blue"
        />
        <StatCard
          title="Pending Orders"
          value={pendingOrdersCount}
          subtext="Awaiting dispatch"
          change="High priority"
          icon={Clock}
          accent="amber"
        />
        <StatCard
          title="Total Earnings"
          value="₹42,300"
          subtext="Net payout to bank account"
          change="0% Brokerage"
          icon={TrendingUp}
          accent="emerald"
        />
        <StatCard
          title="Products Sold"
          value="1,240 kg"
          subtext="Delivered across urban clusters"
          change="99.2% fresh"
          icon={Scale}
          accent="purple"
        />
      </div>

      {/* Analytics Charts: 7-day Sales & 6-month Earnings */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* 7-day Sales Chart (6 cols) */}
        <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Sales Overview (Last 7 Days)
              </h3>
              <p className="text-xs text-slate-500">
                Daily order volume & farm-gate realizations
              </p>
            </div>
            <span className="text-[10px] font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-bold">
              7-Day Trends
            </span>
          </div>

          <SalesChart />

          <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
            <span>Peak Day: <strong>Saturday (420 kg / ₹9,800)</strong></span>
            <span className="text-emerald-700 font-semibold">Direct Buyer Settlements</span>
          </div>
        </div>

        {/* 6-month Earnings Chart (6 cols) */}
        <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Earnings Trend (Last 6 Months)
              </h3>
              <p className="text-xs text-slate-500">
                Consistent monthly direct-to-farm bank credit
              </p>
            </div>
            <span className="text-[10px] font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-bold">
              6-Month Ledger
            </span>
          </div>

          <EarningsChart />

          <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
            <span>Average Monthly: <strong>₹32,500</strong></span>
            <span className="text-emerald-700 font-semibold">+24% YoY Growth</span>
          </div>
        </div>

      </div>

      {/* Inventory Health & AI Intelligence */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Inventory Health Widget (6 cols) */}
        <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-5">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Inventory Health Status
              </h3>
              <p className="text-xs text-slate-500">Real-time harvest stock classification</p>
            </div>
            <Link
              to="/farmer/products"
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 hover:underline"
            >
              Manage Products →
            </Link>
          </div>

          {/* 4 Health Status Bars */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200">
              <span className="text-xs font-bold text-emerald-800 uppercase block">Healthy</span>
              <span className="text-2xl font-black text-emerald-950 font-display">{inventoryHealth.healthy || 4}</span>
              <span className="text-[10px] text-emerald-700 block mt-0.5">&gt; 100 kg stock</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-blue-50 border border-blue-200">
              <span className="text-xs font-bold text-blue-800 uppercase block">Medium</span>
              <span className="text-2xl font-black text-blue-950 font-display">{inventoryHealth.medium || 3}</span>
              <span className="text-[10px] text-blue-700 block mt-0.5">20 – 100 kg</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200">
              <span className="text-xs font-bold text-amber-800 uppercase block">Low</span>
              <span className="text-2xl font-black text-amber-950 font-display">{inventoryHealth.low || 1}</span>
              <span className="text-[10px] text-amber-700 block mt-0.5">&lt; 20 kg stock</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-100 border border-slate-200">
              <span className="text-xs font-bold text-slate-700 uppercase block">Out of Stock</span>
              <span className="text-2xl font-black text-slate-900 font-display">{inventoryHealth.outOfStock || 0}</span>
              <span className="text-[10px] text-slate-500 block mt-0.5">Needs harvest</span>
            </div>
          </div>

          {/* Sample Product Batch List */}
          <div className="space-y-3 pt-2">
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <h4 className="text-xs font-bold text-slate-900 truncate">Desi Country Tomatoes</h4>
                <p className="text-[11px] text-slate-500">₹26/kg • 500 kg in field vault</p>
              </div>
              <InventoryBadge quantity={500} unit="kg" />
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <h4 className="text-xs font-bold text-slate-900 truncate">Kufri Jyoti Potatoes</h4>
                <p className="text-[11px] text-slate-500">₹20/kg • 800 kg available</p>
              </div>
              <InventoryBadge quantity={800} unit="kg" />
            </div>
          </div>
        </div>

        {/* AI Demand Outlook Section (6 cols) */}
        <div className="lg:col-span-6 space-y-4">
          <OpportunityCard opportunity={primaryOpportunity} />
        </div>

      </div>

      {/* Hyperlocal Farm Pickups & Collection Dispatch */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Farm Gate Pickups & Fleet Dispatch
              </h3>
              <p className="text-xs text-slate-500">
                Scheduled truck collections aligned with consolidated buyer routes
              </p>
            </div>
          </div>
          <Link
            to="/logistics"
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 hover:underline inline-flex items-center gap-1"
          >
            Open Logistics Hub →
          </Link>
        </div>

        {pickups && pickups.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {pickups.slice(0, 3).map((pickup) => (
              <PickupSchedule
                key={pickup.id}
                schedule={pickup}
                onMarkReady={(id) => updatePickupStatus(id, 'READY')}
              />
            ))}
          </div>
        ) : (
          <p className="text-xs text-slate-400 py-4 text-center">
            No pending pickups scheduled for today. New dispatches will appear once orders are confirmed.
          </p>
        )}
      </div>

      {/* Shared Live Recent Orders Table */}
      <RecentOrdersTable
        orders={farmerOrders}
        title="Recent Orders"
        subtitle="Live orders synchronized with Consumer & Bulk Buyer portals"
        viewAllLink="/farmer/orders"
        counterpartyLabel="Buyer"
        onStatusChange={updateOrderStatus}
        showActions={true}
        maxItems={5}
      />

      {/* Quick Actions Component adhering to Section 5 */}
      <QuickActions
        title="Quick Actions"
        subtitle="Frequently used farmer workflows"
        actions={quickActionsList}
      />

    </div>
  );
}
