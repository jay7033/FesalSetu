import React, { useState } from 'react';
import { 
  MapPin, 
  PlusCircle, 
  Sparkles, 
  X
} from 'lucide-react';
import FarmLocationCard from '../../components/farmer/FarmLocationCard';
import FarmMap from '../../components/FarmMap';
import Button from '../../components/Button';
import { useLocation } from '../../context/LocationContext';

export default function FarmLocations() {
  const { 
    farmLocations, 
    setDefaultFarmLocation, 
    deleteFarmLocation 
  } = useLocation();

  const [inspectLocation, setInspectLocation] = useState(null);

  return (
    <div className="space-y-8 max-w-6xl">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200/80">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-100 text-emerald-800">
              <MapPin className="w-5 h-5" />
            </span>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-950 font-display tracking-tight">
              Farm Locations
            </h1>
          </div>
          <p className="text-slate-600 text-xs sm:text-sm">
            Manage the farms and production locations connected to your FasalSetu account.
          </p>
        </div>

        <Button
          to="/farmer/locations/new"
          variant="primary"
          size="md"
          leftIcon={PlusCircle}
        >
          + ADD FARM LOCATION
        </Button>
      </div>

      {/* Info banner for FPOs */}
      <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 text-xs text-emerald-950 flex items-start gap-3">
        <Sparkles className="w-4 h-4 text-emerald-700 flex-shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-bold">Multiple Farm Support for Farmers & FPOs</p>
          <p className="text-emerald-800/90 leading-relaxed text-[11px]">
            Each listed produce batch can be linked to a specific farm plot. Your default farm is automatically pre-selected when listing fresh harvest. Public buyers only see the approximate region, protecting exact GPS coordinates.
          </p>
        </div>
      </div>

      {/* Grid of Farm Locations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {farmLocations.map((loc) => (
          <FarmLocationCard
            key={loc.id}
            location={loc}
            onSetDefault={setDefaultFarmLocation}
            onDelete={deleteFarmLocation}
            onViewMap={(locationToView) => setInspectLocation(locationToView)}
            canDelete={farmLocations.length > 1}
          />
        ))}
      </div>

      {/* Map Inspector Modal */}
      {inspectLocation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="relative bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl space-y-4">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-emerald-600" />
                <h3 className="text-lg font-bold text-slate-900 font-display">
                  {inspectLocation.name}
                </h3>
              </div>

              <button
                type="button"
                onClick={() => setInspectLocation(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="h-72 w-full rounded-2xl overflow-hidden border border-slate-200 shadow-inner">
              <FarmMap
                latitude={inspectLocation.latitude}
                longitude={inspectLocation.longitude}
                accuracy={inspectLocation.accuracy}
                label={inspectLocation.name}
                className="w-full h-full"
                zoom={14}
              />
            </div>

            <div className="text-xs text-slate-600 space-y-1">
              <p><strong>Address:</strong> {inspectLocation.formattedAddress}</p>
              <p className="font-mono text-[11px] text-emerald-700">
                GPS: {inspectLocation.latitude?.toFixed(4)}°N, {inspectLocation.longitude?.toFixed(4)}°E (±{inspectLocation.accuracy || 25}m)
              </p>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setInspectLocation(null)}
                className="px-5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold"
              >
                Close Map
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Empty State */}
      {farmLocations.length === 0 && (
        <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-4">
          <MapPin className="w-12 h-12 text-slate-400 mx-auto" />
          <h3 className="text-lg font-bold text-slate-800">No Farm Locations Configured</h3>
          <p className="text-slate-500 text-xs max-w-sm mx-auto">
            You must register at least one farm location before listing produce on the marketplace.
          </p>
          <Button to="/farmer/locations/new" variant="primary" size="md">
            Set Farm Location
          </Button>
        </div>
      )}

    </div>
  );
}
