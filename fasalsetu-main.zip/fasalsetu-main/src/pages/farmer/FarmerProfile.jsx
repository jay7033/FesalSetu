import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  MapPin, 
  Navigation, 
  Compass, 
  Check, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  Save, 
  Building2, 
  Lock
} from 'lucide-react';
import FarmMap from '../../components/FarmMap';
import { useLocation } from '../../context/LocationContext';
import { useAuth } from '../../context/AuthContext';
import { INITIAL_DEMO_FARMER, INDIAN_STATES } from '../../data/demoData';

const PROFILE_STORAGE_KEY = 'fasalsetu_farmer_profile_v1';

export default function FarmerProfile() {
  const { user } = useAuth();
  const isDemo = !user || user.isDemo || user.email === 'farmer@fasalsetu.demo';

  const { 
    location, 
    loading: locationLoading, 
    error: locationError, 
    requestCurrentLocation, 
    confirmLocation, 
    setManualLocation 
  } = useLocation();

  // Farmer Profile State
  const [profile, setProfile] = useState(() => {
    try {
      const saved = localStorage.getItem(PROFILE_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
      if (user && !isDemo) {
        return {
          name: user.name || 'Registered Producer',
          farmerType: user.role === 'fpo' ? 'FPO' : 'Individual Farmer',
          contactName: user.name || '',
          phone: user.phone || '',
          email: user.email || '',
          farmSize: '50 Acres',
          primaryCrops: 'Seasonal Vegetables, Grains',
          establishedYear: '2022',
          fpoRegistrationNumber: ''
        };
      }
      return INITIAL_DEMO_FARMER;
    } catch (e) {
      console.error(e);
      return INITIAL_DEMO_FARMER;
    }
  });

  const [syncedUserId, setSyncedUserId] = useState(user?.id);
  if (user?.id !== syncedUserId) {
    setSyncedUserId(user?.id);
    if (!isDemo && user) {
      setProfile((prev) => ({
        ...prev,
        name: user.name || prev.name,
        email: user.email || prev.email,
        phone: user.phone || prev.phone,
        farmerType: user.role === 'fpo' ? 'FPO' : (prev.farmerType || 'Individual Farmer')
      }));
    }
  }

  const [isManualModalOpen, setIsManualModalOpen] = useState(false);
  const [manualFormData, setManualFormData] = useState({
    village: location?.village || '',
    locality: location?.locality || '',
    city: location?.city || 'Greater Noida',
    district: location?.district || 'Gautam Buddha Nagar',
    state: location?.state || 'Uttar Pradesh',
    pincode: location?.pincode || '203201',
    country: 'India'
  });

  const [isSaved, setIsSaved] = useState(false);
  const [locationSavedNotice, setLocationSavedNotice] = useState(false);

  const handleProfileChange = (field, value) => {
    setProfile((prev) => ({ ...prev, [field]: value }));
  };

  const handleSaveProfile = (e) => {
    e.preventDefault();
    try {
      localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profile));
      setIsSaved(true);
      setTimeout(() => setIsSaved(false), 2000);
    } catch (err) {
      console.error(err);
    }
  };

  const handleDetectLocation = async () => {
    try {
      await requestCurrentLocation();
    } catch (err) {
      console.warn('Geolocation request failed or was denied:', err.message);
    }
  };

  const handleConfirmLocation = () => {
    confirmLocation();
    setLocationSavedNotice(true);
    setTimeout(() => setLocationSavedNotice(false), 2500);
  };

  const handleSaveManualLocation = (e) => {
    e.preventDefault();
    setManualLocation(manualFormData);
    setIsManualModalOpen(false);
    setLocationSavedNotice(true);
    setTimeout(() => setLocationSavedNotice(false), 2500);
  };

  const isLocationDetected = Boolean(location?.latitude && location?.longitude);
  const isLocationConfirmed = Boolean(location?.confirmed);

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12">
      
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
              Producer Identity & GPS
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold">
              Pan-India Model
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-950 font-display tracking-tight">
            Farm Profile & Location Intelligence
          </h1>
          <p className="text-slate-500 text-xs sm:text-sm mt-0.5">
            Configure your farm entity, primary crops, and exact GPS coordinates for distance-based buyer matching.
          </p>
        </div>

        {isSaved && (
          <div className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm animate-in fade-in">
            <Check className="w-4 h-4" />
            <span>Profile Saved!</span>
          </div>
        )}
      </div>

      {/* =========================================================================
          LOCATION SECTION (Large Location Card)
          📍 FARM LOCATION
          Status: Location not set / Location detected / Verified
          Buttons: [USE MY CURRENT LOCATION], [CONFIRM LOCATION], [DETECT AGAIN], [EDIT MANUALLY]
          MapLibre Visual Verification Map
          ========================================================================= */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs space-y-6">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-emerald-50 text-emerald-700 border border-emerald-200">
              <MapPin className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-slate-950 font-display">
                📍 Farm Location Intelligence
              </h2>
              <p className="text-xs text-slate-500">
                Precision GPS coordinates with privacy protection for Pan-India buyer matching
              </p>
            </div>
          </div>

          <div className="self-start sm:self-auto">
            {isLocationConfirmed ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-900 border border-emerald-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                <span>✓ Location Verified</span>
              </span>
            ) : isLocationDetected ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300 animate-pulse">
                <AlertCircle className="w-4 h-4 text-amber-700" />
                <span>Detection Pending Confirmation</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-600 border border-slate-200">
                <span>Location Not Set</span>
              </span>
            )}
          </div>
        </div>

        {/* Location Detection Actions */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={handleDetectLocation}
            disabled={locationLoading}
            className="py-3.5 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm shadow-md hover:shadow-lg flex items-center gap-2 transition-all disabled:opacity-50"
          >
            {locationLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Acquiring Device GPS...</span>
              </>
            ) : (
              <>
                <Navigation className="w-4 h-4" />
                <span>USE MY CURRENT LOCATION</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => setIsManualModalOpen(true)}
            className="py-3.5 px-5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs sm:text-sm transition-colors flex items-center gap-2"
          >
            <Compass className="w-4 h-4" />
            <span>SELECT LOCATION MANUALLY</span>
          </button>

          <Link
            to="/farmer/locations"
            className="py-3.5 px-5 rounded-2xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-xs sm:text-sm border border-emerald-200 transition-colors flex items-center gap-2"
          >
            <Building2 className="w-4 h-4 text-emerald-700" />
            <span>MANAGE LOCATIONS</span>
          </Link>

          {isLocationDetected && (
            <button
              type="button"
              onClick={handleDetectLocation}
              className="p-3.5 rounded-2xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
              title="Detect Again"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Error Notification if any */}
        {locationError && (
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Geolocation Notice</p>
              <p className="mt-0.5">{locationError}</p>
              <button
                type="button"
                onClick={() => setIsManualModalOpen(true)}
                className="mt-2 text-emerald-800 font-bold underline block"
              >
                Click here to set location manually →
              </button>
            </div>
          </div>
        )}

        {/* Location Notice on Confirmation */}
        {locationSavedNotice && (
          <div className="p-3.5 rounded-2xl bg-emerald-100/90 text-emerald-900 text-xs font-bold flex items-center gap-2 border border-emerald-300 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-700" />
            <span>Farm GPS location successfully saved and linked to all your harvest batches!</span>
          </div>
        )}

        {/* Map & Geocoded Address Display */}
        {isLocationDetected && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-2">
            
            {/* MapLibre Map (7 cols) */}
            <div className="lg:col-span-7 space-y-2">
              <FarmMap
                latitude={location.latitude}
                longitude={location.longitude}
                accuracy={location.accuracy}
                label={profile.name || 'Farm Location'}
                className="h-72 w-full"
              />
              <p className="text-[11px] text-slate-400 italic">
                * MapLibre visual verification. Use the navigation controls to zoom into your farm parcel.
              </p>
            </div>

            {/* Address Details & Confirmation (5 cols) */}
            <div className="lg:col-span-5 bg-slate-50 rounded-3xl p-5 border border-slate-200/90 space-y-4 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Detected Location
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-200 text-slate-700">
                    Source: {location.source || 'device'}
                  </span>
                </div>

                {/* Coordinate readout */}
                <div className="p-3 rounded-2xl bg-white border border-slate-200 text-xs font-mono space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Latitude:</span>
                    <span className="font-bold text-slate-900">{location.latitude.toFixed(5)}° N</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Longitude:</span>
                    <span className="font-bold text-slate-900">{location.longitude.toFixed(5)}° E</span>
                  </div>
                  {location.accuracy && (
                    <div className="flex justify-between text-[11px]">
                      <span className="text-slate-400">Accuracy radius:</span>
                      <span className="text-emerald-700 font-semibold">±{location.accuracy} meters</span>
                    </div>
                  )}
                </div>

                {/* Reverse-geocoded fields */}
                <div className="space-y-1.5 text-xs text-slate-700">
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500">Village / Locality:</span>
                    <span className="font-semibold">{location.village || location.locality || 'Rural Farm Belt'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500">City / Town:</span>
                    <span className="font-semibold">{location.city || 'Greater Noida'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500">District:</span>
                    <span className="font-semibold">{location.district || 'Gautam Buddha Nagar'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500">State:</span>
                    <span className="font-semibold">{location.state || 'Uttar Pradesh'}</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-slate-500">Pincode:</span>
                    <span className="font-mono font-semibold">{location.pincode || '203201'}</span>
                  </div>
                </div>

                {/* Approximate public string preview */}
                <div className="p-2.5 rounded-xl bg-emerald-50/70 border border-emerald-200/80 text-xs text-emerald-900">
                  <span className="font-bold">Public Marketplace Display: </span>
                  <span className="italic">"{location.approximateLocation || `Near ${location.city}, ${location.state}`}"</span>
                </div>
              </div>

              {/* Confirmation CTA */}
              <div className="pt-2 flex flex-col gap-2">
                {!isLocationConfirmed ? (
                  <button
                    type="button"
                    onClick={handleConfirmLocation}
                    className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md flex items-center justify-center gap-2 transition-all"
                  >
                    <Check className="w-4 h-4" />
                    <span>CONFIRM THIS LOCATION</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setIsManualModalOpen(true)}
                    className="w-full py-2.5 rounded-2xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 font-semibold text-xs transition-colors"
                  >
                    Edit Location Details
                  </button>
                )}
              </div>
            </div>

          </div>
        )}

        {/* Privacy Note */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-start gap-3">
          <Lock className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <span className="font-bold text-slate-900">Farmer Privacy Guarantee: </span>
            <span>Your exact GPS coordinates are never displayed publicly. The marketplace only shows approximate regional proximity (e.g. <em>"Near Dankaur, Uttar Pradesh"</em>) to protect farm safety while enabling buyer distance matching.</span>
          </div>
        </div>

      </div>

      {/* =========================================================================
          FARMER & FPO PROFILE FORM
          ========================================================================= */}
      <form onSubmit={handleSaveProfile} className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs space-y-6">
        <h2 className="text-lg font-bold text-slate-950 font-display pb-3 border-b border-slate-100 flex items-center gap-2">
          <Building2 className="w-5 h-5 text-emerald-600" />
          <span>Organization & Farming Operation Details</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 text-xs">
          {/* Farmer/FPO Name */}
          <div className="space-y-1">
            <label className="font-bold text-slate-700">Farmer / FPO Entity Name</label>
            <input
              type="text"
              required
              value={profile.name}
              onChange={(e) => handleProfileChange('name', e.target.value)}
              className="w-full p-3 rounded-2xl border border-slate-200 text-sm font-semibold focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Farmer Type */}
          <div className="space-y-1">
            <label className="font-bold text-slate-700">Producer Entity Type</label>
            <select
              value={profile.farmerType}
              onChange={(e) => handleProfileChange('farmerType', e.target.value)}
              className="w-full p-3 rounded-2xl border border-slate-200 text-sm font-semibold focus:ring-2 focus:ring-emerald-500"
            >
              <option value="FPO">FPO (Farmer Producer Organization)</option>
              <option value="Individual Farmer">Individual Progressive Farmer</option>
              <option value="Farmer Cooperative">Farmer Cooperative Society</option>
              <option value="Farmer Group">Self-Help Farmer Group</option>
            </select>
          </div>

          {/* Contact Person */}
          <div className="space-y-1">
            <label className="font-bold text-slate-700">Contact Person / Lead Representative</label>
            <input
              type="text"
              value={profile.contactName || ''}
              onChange={(e) => handleProfileChange('contactName', e.target.value)}
              className="w-full p-3 rounded-2xl border border-slate-200 text-sm focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Phone */}
          <div className="space-y-1">
            <label className="font-bold text-slate-700">Phone Number</label>
            <input
              type="tel"
              value={profile.phone || ''}
              onChange={(e) => handleProfileChange('phone', e.target.value)}
              className="w-full p-3 rounded-2xl border border-slate-200 text-sm font-mono focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Email */}
          <div className="space-y-1">
            <label className="font-bold text-slate-700">Email Address</label>
            <input
              type="email"
              value={profile.email || ''}
              onChange={(e) => handleProfileChange('email', e.target.value)}
              className="w-full p-3 rounded-2xl border border-slate-200 text-sm focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Farm Size */}
          <div className="space-y-1">
            <label className="font-bold text-slate-700">Total Farm Acreage / Member Count</label>
            <input
              type="text"
              value={profile.farmSize || ''}
              onChange={(e) => handleProfileChange('farmSize', e.target.value)}
              placeholder="e.g. 450 Acres (38 Associated Farms)"
              className="w-full p-3 rounded-2xl border border-slate-200 text-sm focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Primary Crops */}
          <div className="sm:col-span-2 space-y-1">
            <label className="font-bold text-slate-700">Primary Harvest Crops</label>
            <input
              type="text"
              value={profile.primaryCrops || ''}
              onChange={(e) => handleProfileChange('primaryCrops', e.target.value)}
              placeholder="e.g. Tomato, Potato, Wheat, Mustard, Cauliflower"
              className="w-full p-3 rounded-2xl border border-slate-200 text-sm focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Description */}
          <div className="sm:col-span-2 space-y-1">
            <label className="font-bold text-slate-700">Organization Overview & Mission</label>
            <textarea
              rows="3"
              value={profile.description || ''}
              onChange={(e) => handleProfileChange('description', e.target.value)}
              className="w-full p-3 rounded-2xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100 flex items-center justify-end">
          <button
            type="submit"
            className="px-6 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md hover:shadow-lg flex items-center gap-2 transition-all"
          >
            <Save className="w-4 h-4" />
            <span>SAVE PROFILE</span>
          </button>
        </div>
      </form>

      {/* =========================================================================
          MANUAL LOCATION FALLBACK MODAL
          ========================================================================= */}
      {isManualModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl border border-slate-200 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Compass className="w-5 h-5 text-emerald-600" />
                <h3 className="text-lg font-bold text-slate-900 font-display">
                  Select Location Manually
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsManualModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveManualLocation} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-700">State <span className="text-red-500">*</span></label>
                <select
                  required
                  value={manualFormData.state}
                  onChange={(e) => setManualFormData({ ...manualFormData, state: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-slate-200 font-semibold"
                >
                  {INDIAN_STATES.filter((s) => s !== 'All India').map((st) => (
                    <option key={st} value={st}>{st}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">District <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    required
                    value={manualFormData.district}
                    onChange={(e) => setManualFormData({ ...manualFormData, district: e.target.value })}
                    placeholder="e.g. Gautam Buddha Nagar"
                    className="w-full p-2.5 rounded-xl border border-slate-200"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">City / Town / Tehsil</label>
                  <input
                    type="text"
                    required
                    value={manualFormData.city}
                    onChange={(e) => setManualFormData({ ...manualFormData, city: e.target.value })}
                    placeholder="e.g. Greater Noida"
                    className="w-full p-2.5 rounded-xl border border-slate-200"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Village / Locality</label>
                  <input
                    type="text"
                    value={manualFormData.village}
                    onChange={(e) => setManualFormData({ ...manualFormData, village: e.target.value })}
                    placeholder="e.g. Dankaur Rural"
                    className="w-full p-2.5 rounded-xl border border-slate-200"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Pincode</label>
                  <input
                    type="text"
                    value={manualFormData.pincode}
                    onChange={(e) => setManualFormData({ ...manualFormData, pincode: e.target.value })}
                    placeholder="e.g. 203201"
                    className="w-full p-2.5 rounded-xl border border-slate-200 font-mono"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsManualModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                >
                  Set Manual Location
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
