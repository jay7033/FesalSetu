import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Check, 
  AlertCircle, 
  ArrowLeft,
  MapPin,
  PlusCircle,
  ShieldCheck,
  Building2
} from 'lucide-react';
import { useProducts } from '../../context/ProductContext';
import { useLocation } from '../../context/LocationContext';
import { useAuth } from '../../context/AuthContext';
import { CATEGORIES, QUALITY_OPTIONS, INITIAL_DEMO_FARMER } from '../../data/demoData';
import Button from '../../components/Button';

const PRESET_IMAGES = [
  { label: 'Tomatoes', url: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=600&q=80' },
  { label: 'Potatoes', url: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=600&q=80' },
  { label: 'Onions', url: 'https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?auto=format&fit=crop&w=600&q=80' },
  { label: 'Wheat', url: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=600&q=80' },
  { label: 'Mustard Oil', url: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=600&q=80' },
  { label: 'Milk / Dairy', url: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=600&q=80' },
  { label: 'Cauliflower', url: 'https://images.unsplash.com/photo-1568584711075-3d021a7c3ca3?auto=format&fit=crop&w=600&q=80' },
  { label: 'Spinach', url: 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&w=600&q=80' }
];

export default function AddProduct() {
  const navigate = useNavigate();
  const { addProduct } = useProducts();
  const { farmLocations, defaultFarmLocation } = useLocation();
  const { user } = useAuth();
  const isDemo = !user || user.isDemo || user.email === 'farmer@fasalsetu.demo';

  const [selectedFarmId, setSelectedFarmId] = useState(
    () => defaultFarmLocation?.id || (farmLocations[0]?.id || '')
  );

  const [formData, setFormData] = useState({
    name: '',
    hindiName: '',
    category: 'Vegetables',
    quantityAvailable: '',
    unit: 'kg',
    price: '',
    harvestDate: 'Today, 6:00 AM',
    quality: 'Premium',
    organic: false,
    description: '',
    image: PRESET_IMAGES[0].url
  });

  const [touched, setTouched] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState(false);

  // Form Validation
  const errors = {};
  if (!formData.name.trim()) errors.name = 'Product name is required';
  if (!formData.category) errors.category = 'Category is required';
  if (!formData.quantityAvailable || Number(formData.quantityAvailable) <= 0) {
    errors.quantityAvailable = 'Quantity must be greater than 0';
  }
  if (!formData.price || Number(formData.price) <= 0) {
    errors.price = 'Price must be greater than 0';
  }
  if (!formData.harvestDate.trim()) errors.harvestDate = 'Harvest date/time is required';
  if (!selectedFarmId) errors.farm = 'Please select a registered farm location';

  const isValid = Object.keys(errors).length === 0 && farmLocations.length > 0;

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleBlur = (field) => {
    setTouched((prev) => ({ ...prev, [field]: true }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!isValid) return;

    setIsSubmitting(true);

    const chosenFarm = farmLocations.find((f) => f.id === selectedFarmId) || defaultFarmLocation;
    const farmerName = (!isDemo && user?.name) ? user.name : INITIAL_DEMO_FARMER.name;
    const farmerType = (!isDemo && user?.role === 'fpo') ? 'FPO' : INITIAL_DEMO_FARMER.farmerType;

    addProduct({
      ...formData,
      quantityAvailable: Number(formData.quantityAvailable),
      price: Number(formData.price),
      farmLocationId: chosenFarm.id,
      farmer: farmerName,
      farmerId: user?.id || null,
      farmerType: farmerType,
      location: chosenFarm.city || chosenFarm.district || 'Farm Gate',
      state: chosenFarm.state,
      latitude: chosenFarm.latitude,
      longitude: chosenFarm.longitude,
      approximateLocation: chosenFarm.approximateLocation || `Near ${chosenFarm.city}, ${chosenFarm.state}`,
      distance: 'Direct Farm Gate',
      source: chosenFarm.source || 'device'
    }, user?.id);

    setSuccessMessage(true);

    setTimeout(() => {
      navigate('/farmer/products');
    }, 1200);
  };

  // If no farm locations configured, block listing
  if (farmLocations.length === 0) {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <Link
          to="/farmer/products"
          className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 hover:underline"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to My Products</span>
        </Link>

        <div className="bg-white rounded-3xl border border-amber-200 p-8 sm:p-10 text-center space-y-4 shadow-sm">
          <div className="w-16 h-16 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center mx-auto text-amber-600">
            <MapPin className="w-8 h-8" />
          </div>

          <div className="space-y-1">
            <h2 className="text-xl font-bold text-slate-900 font-display">
              Farm Location Required Before Listing Produce
            </h2>
            <p className="text-slate-600 text-sm max-w-md mx-auto">
              Please set your farm location before listing produce. Every listed product automatically inherits your verified farm origin so buyers can calculate distance.
            </p>
          </div>

          <div className="pt-2">
            <Button
              to="/farmer/locations/new"
              variant="primary"
              size="lg"
              leftIcon={PlusCircle}
            >
              SET FARM LOCATION
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const selectedFarm = farmLocations.find((f) => f.id === selectedFarmId) || defaultFarmLocation;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs flex items-center justify-between">
        <div>
          <button
            type="button"
            onClick={() => navigate('/farmer/products')}
            className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 mb-2 hover:underline"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to My Products</span>
          </button>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-950 font-display tracking-tight">
            List Fresh Agricultural Produce
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Add freshly harvested crop batches directly to the Pan-India FasalSetu marketplace.
          </p>
        </div>

        <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>Zero Mandi Cut</span>
        </div>
      </div>

      {/* Success alert banner */}
      {successMessage && (
        <div className="p-4 rounded-2xl bg-emerald-100 border border-emerald-300 text-emerald-950 flex items-center gap-3 animate-in zoom-in-95">
          <Check className="w-5 h-5 text-emerald-700 flex-shrink-0" />
          <div>
            <p className="text-xs font-bold">Produce Successfully Listed!</p>
            <p className="text-[11px] text-emerald-800">Your batch is now live in both your Farmer Portal and the Public Marketplace.</p>
          </div>
        </div>
      )}

      {/* Main Form */}
      <form onSubmit={handleSubmit} className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-8">
        
        {/* Section 1: Produce Identity */}
        <div className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-wider text-emerald-700 border-b border-slate-100 pb-2 flex items-center gap-2">
            <span>01</span>
            <span>Produce Information</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Product Name */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">
                Produce Name (English) <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                onBlur={() => handleBlur('name')}
                placeholder="e.g. Fresh Red Hybrid Tomato"
                className={`w-full p-3 rounded-2xl border text-sm focus:outline-none focus:ring-2 ${
                  touched.name && errors.name 
                    ? 'border-red-300 ring-red-200' 
                    : 'border-slate-200 focus:ring-emerald-500'
                }`}
              />
              {touched.name && errors.name && (
                <p className="text-[11px] text-red-600 font-semibold">{errors.name}</p>
              )}
            </div>

            {/* Hindi Name */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">
                Hindi / Local Name (Optional)
              </label>
              <input
                type="text"
                value={formData.hindiName}
                onChange={(e) => handleChange('hindiName', e.target.value)}
                placeholder="e.g. देसी टमाटर (Desi Tamatar)"
                className="w-full p-3 rounded-2xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Category */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">
                Agricultural Category <span className="text-red-500">*</span>
              </label>
              <select
                value={formData.category}
                onChange={(e) => handleChange('category', e.target.value)}
                className="w-full p-3 rounded-2xl border border-slate-200 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                {CATEGORIES.filter((c) => c !== 'All').map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            {/* Quality Grade */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">
                Quality Grade
              </label>
              <select
                value={formData.quality}
                onChange={(e) => handleChange('quality', e.target.value)}
                className="w-full p-3 rounded-2xl border border-slate-200 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                {QUALITY_OPTIONS.filter((q) => q !== 'All').map((grade) => (
                  <option key={grade} value={grade}>{grade} Grade</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Section 2: Farm Origin & Location Inheritance */}
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h2 className="text-sm font-bold uppercase tracking-wider text-emerald-700 flex items-center gap-2">
              <span>02</span>
              <span>Farm Origin & Production Location</span>
            </h2>

            <Link
              to="/farmer/locations"
              className="text-xs font-semibold text-emerald-700 hover:underline flex items-center gap-1"
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>Manage Farms ({farmLocations.length})</span>
            </Link>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700">
              Select Farm Location <span className="text-red-500">*</span>
            </label>

            <select
              value={selectedFarmId}
              onChange={(e) => setSelectedFarmId(e.target.value)}
              className="w-full p-3 rounded-2xl border border-slate-200 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              {farmLocations.map((farm) => (
                <option key={farm.id} value={farm.id}>
                  {farm.name} — {farm.approximateLocation} {farm.isDefault ? '(Default)' : ''}
                </option>
              ))}
            </select>

            {/* Selected farm summary pill */}
            {selectedFarm && (
              <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 text-xs flex items-center justify-between">
                <span className="flex items-center gap-2 text-emerald-950 font-medium">
                  <MapPin className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  <span>Marketplace will show: <strong>{selectedFarm.approximateLocation}</strong></span>
                </span>
                <span className="text-[10px] font-mono text-emerald-700 font-bold bg-white px-2 py-0.5 rounded-md border border-emerald-200">
                  {selectedFarm.source?.toUpperCase()} GPS
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Section 3: Pricing, Stock & Harvest */}
        <div className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-wider text-emerald-700 border-b border-slate-100 pb-2 flex items-center gap-2">
            <span>03</span>
            <span>Pricing, Stock & Harvest Timing</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Price */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">
                Farm Gate Price (₹) <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">₹</span>
                <input
                  type="number"
                  min="1"
                  step="any"
                  required
                  value={formData.price}
                  onChange={(e) => handleChange('price', e.target.value)}
                  onBlur={() => handleBlur('price')}
                  placeholder="e.g. 30"
                  className={`w-full pl-8 pr-3 p-3 rounded-2xl border text-sm font-bold font-mono focus:outline-none focus:ring-2 ${
                    touched.price && errors.price
                      ? 'border-red-300 ring-red-200'
                      : 'border-slate-200 focus:ring-emerald-500'
                  }`}
                />
              </div>
              {touched.price && errors.price && (
                <p className="text-[11px] text-red-600 font-semibold">{errors.price}</p>
              )}
            </div>

            {/* Quantity Available */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">
                Quantity Available <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                min="1"
                required
                value={formData.quantityAvailable}
                onChange={(e) => handleChange('quantityAvailable', e.target.value)}
                onBlur={() => handleBlur('quantityAvailable')}
                placeholder="e.g. 150"
                className={`w-full p-3 rounded-2xl border text-sm font-bold font-mono focus:outline-none focus:ring-2 ${
                  touched.quantityAvailable && errors.quantityAvailable
                    ? 'border-red-300 ring-red-200'
                    : 'border-slate-200 focus:ring-emerald-500'
                }`}
              />
              {touched.quantityAvailable && errors.quantityAvailable && (
                <p className="text-[11px] text-red-600 font-semibold">{errors.quantityAvailable}</p>
              )}
            </div>

            {/* Unit */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">
                Measurement Unit
              </label>
              <select
                value={formData.unit}
                onChange={(e) => handleChange('unit', e.target.value)}
                className="w-full p-3 rounded-2xl border border-slate-200 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                <option value="kg">kg (Kilogram)</option>
                <option value="L">L (Liter)</option>
                <option value="bunch">bunch</option>
                <option value="piece">piece</option>
                <option value="quintal">quintal (100 kg)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Harvest Date */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">
                Harvest Date / Time <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={formData.harvestDate}
                onChange={(e) => handleChange('harvestDate', e.target.value)}
                placeholder="e.g. Today, 5:30 AM"
                className="w-full p-3 rounded-2xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Organic Toggle */}
            <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-emerald-950">Organic Certified</p>
                <p className="text-[11px] text-emerald-800">Chemical-free produce</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.organic}
                  onChange={(e) => handleChange('organic', e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
              </label>
            </div>
          </div>
        </div>

        {/* Section 4: Visuals & Description */}
        <div className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-wider text-emerald-700 border-b border-slate-100 pb-2 flex items-center gap-2">
            <span>04</span>
            <span>Visuals & Buyer Description</span>
          </h2>

          {/* Preset Image Chooser */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700">
              Select High-Resolution Preset Photo
            </label>
            <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
              {PRESET_IMAGES.map((img) => (
                <button
                  key={img.label}
                  type="button"
                  onClick={() => handleChange('image', img.url)}
                  className={`relative aspect-square rounded-xl overflow-hidden border-2 transition-all ${
                    formData.image === img.url
                      ? 'border-emerald-600 ring-2 ring-emerald-500/30 scale-95'
                      : 'border-slate-200 hover:border-slate-400'
                  }`}
                >
                  <img src={img.url} alt={img.label} className="w-full h-full object-cover" />
                  <span className="absolute bottom-0 inset-x-0 bg-black/60 text-[9px] text-white font-medium text-center py-0.5 truncate px-1">
                    {img.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Custom Image URL */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700">
              Or Custom Image URL
            </label>
            <input
              type="url"
              value={formData.image}
              onChange={(e) => handleChange('image', e.target.value)}
              placeholder="https://..."
              className="w-full p-3 rounded-2xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
            />
          </div>

          {/* Description */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700">
              Produce Description & Harvest Notes
            </label>
            <textarea
              rows={3}
              value={formData.description}
              onChange={(e) => handleChange('description', e.target.value)}
              placeholder="Freshly harvested morning batch. Crisp texture, naturally ripened without carbide..."
              className="w-full p-3 rounded-2xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>

        {/* Submit Bar */}
        <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <AlertCircle className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span>Listing automatically appears in both Farmer Portal and Pan-India Marketplace.</span>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => navigate('/farmer/products')}
              className="px-5 py-3 rounded-2xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!isValid || isSubmitting}
              className="flex-1 sm:flex-none px-8 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs sm:text-sm font-bold shadow-md hover:shadow-lg transition-all disabled:opacity-50 disabled:pointer-events-none flex items-center justify-center gap-2 cursor-pointer"
            >
              {isSubmitting ? (
                <span>Publishing to Marketplace...</span>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>LIST PRODUCT</span>
                </>
              )}
            </button>
          </div>
        </div>

      </form>

    </div>
  );
}
