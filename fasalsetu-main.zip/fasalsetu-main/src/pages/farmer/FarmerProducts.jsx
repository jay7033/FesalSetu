import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Plus, 
  Search, 
  X, 
  AlertTriangle, 
  Building2
} from 'lucide-react';
import Button from '../../components/Button';
import ProductTable from '../../components/farmer/ProductTable';
import { useProducts } from '../../context/ProductContext';
import { useLocation } from '../../context/LocationContext';
import { useAuth } from '../../context/AuthContext';
import { INITIAL_DEMO_FARMER, QUALITY_OPTIONS } from '../../data/demoData';

export default function FarmerProducts() {
  const { products, updateProduct, deleteProduct } = useProducts();
  const { farmLocations } = useLocation();
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');

  // Edit Modal State
  const [editingProduct, setEditingProduct] = useState(null);
  const [editFormData, setEditFormData] = useState({
    price: '',
    quantityAvailable: '',
    quality: 'Premium',
    organic: false,
    description: '',
    farmLocationId: ''
  });

  // Delete Confirmation State
  const [productToDelete, setProductToDelete] = useState(null);

  const isDemo = !user || user.isDemo || user.email === 'farmer@fasalsetu.demo';

  // Filter products belonging to this farmer
  // Demo farmer: shows baseline demo listings + local additions
  // Real farmer: strictly shows listings created by this authenticated user
  const myProducts = products.filter((p) => {
    if (isDemo) {
      return (
        p.farmer === INITIAL_DEMO_FARMER.name ||
        p.farmer === user?.name ||
        p.farmerId === user?.id ||
        p.source === 'farmer-added'
      );
    }
    return (
      (user?.id && (p.farmerId === user.id || p.seller_profile_id === user.id)) ||
      (user?.name && p.farmer === user.name)
    );
  });

  const displayedProducts = myProducts.filter((p) => {
    if (!searchTerm.trim()) return true;
    const q = searchTerm.toLowerCase();
    return (
      p.name.toLowerCase().includes(q) ||
      p.hindiName?.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.location.toLowerCase().includes(q)
    );
  });

  const handleOpenEdit = (prod) => {
    setEditingProduct(prod);
    setEditFormData({
      price: prod.price,
      quantityAvailable: prod.quantityAvailable,
      quality: prod.quality || 'Premium',
      organic: prod.organic || false,
      description: prod.description || '',
      farmLocationId: prod.farmLocationId || (farmLocations[0]?.id || '')
    });
  };

  const handleSaveEdit = (e) => {
    e.preventDefault();
    if (!editingProduct) return;

    const chosenFarm = farmLocations.find((f) => f.id === editFormData.farmLocationId);

    const updates = {
      price: Number(editFormData.price),
      quantityAvailable: Number(editFormData.quantityAvailable),
      quality: editFormData.quality,
      organic: Boolean(editFormData.organic),
      description: editFormData.description
    };

    if (chosenFarm) {
      updates.farmLocationId = chosenFarm.id;
      updates.latitude = chosenFarm.latitude;
      updates.longitude = chosenFarm.longitude;
      updates.approximateLocation = chosenFarm.approximateLocation || `Near ${chosenFarm.city}, ${chosenFarm.state}`;
      updates.location = chosenFarm.city || chosenFarm.district || 'Farm Gate';
      updates.state = chosenFarm.state;
    }

    updateProduct(editingProduct.id, updates);
    setEditingProduct(null);
  };

  const handleConfirmDelete = () => {
    if (productToDelete) {
      deleteProduct(productToDelete.id);
      setProductToDelete(null);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Page Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-950 font-display tracking-tight">
            My Products & Inventory
          </h1>
          <p className="text-slate-500 text-xs sm:text-sm mt-1">
            Manage your harvest listings, adjust farm-gate pricing, and monitor stock levels in real time.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            to="/farmer/locations"
            className="px-4 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors flex items-center gap-1.5"
          >
            <Building2 className="w-4 h-4 text-emerald-600" />
            <span>Farms ({farmLocations.length})</span>
          </Link>

          <Button
            to="/farmer/add-product"
            variant="primary"
            size="md"
            leftIcon={Plus}
          >
            List New Produce
          </Button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Filter produce by name, category..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white border border-slate-200 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-xs"
          />
        </div>

        <div className="text-xs text-slate-500 font-medium self-end sm:self-auto">
          Showing <strong>{displayedProducts.length}</strong> active batches in your inventory
        </div>
      </div>

      {/* Reusable Product Table */}
      <ProductTable
        products={displayedProducts}
        onEdit={handleOpenEdit}
        onDelete={(prodId) => {
          const prod = products.find((p) => p.id === prodId);
          setProductToDelete(prod);
        }}
        farmLocations={farmLocations}
      />

      {/* =========================================================================
          EDIT PRODUCT MODAL
          ========================================================================= */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="relative bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl space-y-6">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-slate-900 font-display">
                  Edit Produce Listing
                </h3>
                <p className="text-xs text-slate-500">{editingProduct.name}</p>
              </div>

              <button
                type="button"
                onClick={() => setEditingProduct(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4 text-xs">
              
              {/* Farm Location Selection */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Origin Farm Location
                </label>
                <select
                  value={editFormData.farmLocationId}
                  onChange={(e) => setEditFormData({ ...editFormData, farmLocationId: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
                >
                  {farmLocations.map((farm) => (
                    <option key={farm.id} value={farm.id}>
                      {farm.name} — {farm.approximateLocation} {farm.isDefault ? '(Default)' : ''}
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-slate-400 mt-1">
                  Changing farm location automatically updates marketplace approximate distance.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {/* Price */}
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Price (₹ / {editingProduct.unit})
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    required
                    value={editFormData.price}
                    onChange={(e) => setEditFormData({ ...editFormData, price: e.target.value })}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {/* Quantity */}
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Quantity Available ({editingProduct.unit})
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={editFormData.quantityAvailable}
                    onChange={(e) => setEditFormData({ ...editFormData, quantityAvailable: e.target.value })}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Quality & Organic */}
              <div className="grid grid-cols-2 gap-3 items-center">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Quality Grade
                  </label>
                  <select
                    value={editFormData.quality}
                    onChange={(e) => setEditFormData({ ...editFormData, quality: e.target.value })}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
                  >
                    {QUALITY_OPTIONS.filter((q) => q !== 'All').map((grade) => (
                      <option key={grade} value={grade}>{grade} Grade</option>
                    ))}
                  </select>
                </div>

                <div className="pt-5">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editFormData.organic}
                      onChange={(e) => setEditFormData({ ...editFormData, organic: e.target.checked })}
                      className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                    />
                    <span className="font-semibold text-slate-800">Certified Organic</span>
                  </label>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={editFormData.description}
                  onChange={(e) => setEditFormData({ ...editFormData, description: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="px-4 py-2.5 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-xs cursor-pointer"
                >
                  Save Changes
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* =========================================================================
          DELETE CONFIRMATION MODAL
          ========================================================================= */}
      {productToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="relative bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl space-y-4 text-center">
            
            <div className="w-14 h-14 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <div className="space-y-1">
              <h3 className="text-base font-bold text-slate-900 font-display">
                Remove &quot;{productToDelete.name}&quot;?
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                This will immediately withdraw the produce batch from both your inventory and the public marketplace.
              </p>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setProductToDelete(null)}
                className="flex-1 py-2.5 px-4 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
              >
                Keep Listing
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="flex-1 py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-xs font-bold text-white shadow-xs transition-colors cursor-pointer"
              >
                Delete Batch
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
