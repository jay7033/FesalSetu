import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, CheckCircle2 } from 'lucide-react';
import LocationPicker from '../../components/farmer/LocationPicker';
import { useLocation } from '../../context/LocationContext';

export default function AddFarmLocation() {
  const navigate = useNavigate();
  const { addFarmLocation } = useLocation();
  const [success, setSuccess] = useState(false);

  const handleLocationConfirmed = (loc) => {
    addFarmLocation(loc);
    setSuccess(true);
    setTimeout(() => {
      navigate('/farmer/locations');
    }, 1200);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      
      {/* Back Link */}
      <Link
        to="/farmer/locations"
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 hover:text-emerald-800 hover:underline"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Farm Locations</span>
      </Link>

      {/* Success Notification */}
      {success && (
        <div className="p-4 rounded-2xl bg-emerald-100 border border-emerald-300 text-emerald-950 flex items-center gap-3 animate-in zoom-in-95">
          <CheckCircle2 className="w-5 h-5 text-emerald-700 flex-shrink-0" />
          <div>
            <p className="text-xs font-bold">Farm Location Successfully Saved!</p>
            <p className="text-[11px] text-emerald-800">Redirecting to your farm locations list...</p>
          </div>
        </div>
      )}

      {/* Location Picker Workflow */}
      <LocationPicker
        title="📍 Set Your Farm Location"
        subtitle="Detect live GPS coordinates with HTML5 Geolocation or choose your district manually."
        onLocationConfirmed={handleLocationConfirmed}
      />

    </div>
  );
}
