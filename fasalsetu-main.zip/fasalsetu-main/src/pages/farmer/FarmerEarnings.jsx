import React from 'react';
import { 
  IndianRupee, 
  TrendingUp, 
  Calendar, 
  Clock, 
  Download, 
  ShieldCheck
} from 'lucide-react';
import StatCard from '../../components/farmer/StatCard';
import EarningsChart from '../../components/farmer/EarningsChart';
import { PRODUCT_EARNINGS } from '../../data/demoData';

export default function FarmerEarnings() {
  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
              Financial Transparency
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200">
              Prototype Demo Values
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-950 font-display tracking-tight">
            Earnings & Payout Ledger
          </h1>
          <p className="text-slate-500 text-xs sm:text-sm mt-0.5">
            Real-time tracking of direct farm-gate payments settled via automated UPI transfers with zero mandi brokerage deductions.
          </p>
        </div>

        <button
          type="button"
          onClick={() => alert('Demo Feature: Prototype payout statement exported. Final statutory terms governed by applicable regulations.')}
          className="px-4 py-2.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-2 transition-colors self-start sm:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>Export Statement</span>
        </button>
      </div>

      {/* 4 KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard
          title="Total Earnings"
          value="₹42,300"
          subtext="Net realization across all orders"
          change="+15.2%"
          icon={IndianRupee}
          accent="emerald"
        />
        <StatCard
          title="This Month"
          value="₹18,400"
          subtext="Current month disbursements"
          change="On track"
          icon={Calendar}
          accent="blue"
        />
        <StatCard
          title="Last Month"
          value="₹23,900"
          subtext="Previous settlement cycle"
          change="Paid out"
          icon={TrendingUp}
          accent="purple"
        />
        <StatCard
          title="Pending Payout"
          value="₹6,200"
          subtext="Scheduled morning transfer"
          change="T+0 Settlement"
          icon={Clock}
          accent="amber"
        />
      </div>

      {/* 2-Column Section: Monthly Trend Chart + Product-Level Earnings */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left: Monthly Trend Chart (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Monthly Net Realization Trend
              </h3>
              <p className="text-xs text-slate-500">6-Month progression of direct farmer payouts</p>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
              Avg. +18% MoM
            </span>
          </div>

          <EarningsChart />

          <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-100">
            <span>Direct UPI Settlement to SBI Account (A/C **8821)</span>
            <span className="text-emerald-600 font-bold">Zero APMC Deductions</span>
          </div>
        </div>

        {/* Right: Product-Level Breakdown (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-5">
          <div className="pb-2 border-b border-slate-100">
            <h3 className="text-lg font-bold text-slate-900 font-display">
              Earnings by Crop Category
            </h3>
            <p className="text-xs text-slate-500">Net revenue contribution per produce line</p>
          </div>

          <div className="space-y-4">
            {PRODUCT_EARNINGS.map((item) => {
              const pct = Math.round((item.amount / 42300) * 100);

              return (
                <div key={item.product} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-800">{item.product}</span>
                    <span className="font-mono font-bold text-slate-950">
                      ₹{item.amount.toLocaleString('en-IN')} <span className="text-slate-400 font-normal">({pct}%)</span>
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                    <div 
                      className="h-full rounded-full transition-all duration-500" 
                      style={{ width: `${pct}%`, backgroundColor: item.fill }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Zero Middlemen Guarantee Card */}
          <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-2 text-xs">
            <div className="flex items-center gap-2 font-bold text-emerald-900">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              <span>Direct Bank Realization Formula</span>
            </div>
            <p className="text-[11px] text-emerald-800/90 leading-relaxed">
              Traditional Mandi system leaves only 35-45% of consumer rupee for growers. On FasalSetu, 100% of listed farm-gate price goes directly into your cooperative account.
            </p>
          </div>
        </div>

      </div>

    </div>
  );
}
