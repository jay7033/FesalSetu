import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  Truck, 
  MapPin, 
  Phone, 
  CheckCircle2, 
  AlertTriangle, 
  Navigation, 
  RotateCw 
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { hierarchicalLogisticsService } from '../../services/logistics/hierarchicalLogisticsService';
import RouteMap from '../../components/logistics/RouteMap';

export default function DeliveryBoyDashboard() {
  const { user } = useAuth();
  const boyId = user?.id || 'db-north-001';

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [tasks, setTasks] = useState([]);
  const [boyProfile, setBoyProfile] = useState(null);
  const [activeTask, setActiveTask] = useState(null);
  const [actionSuccessMsg, setActionSuccessMsg] = useState(null);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [exceptionText, setExceptionText] = useState('');

  const loadData = useCallback(async (isRefresh = false) => {
    try {
      if (isRefresh) setRefreshing(true);
      const [fetchedTasks, fetchedBoys] = await Promise.all([
        hierarchicalLogisticsService.getDeliveryTasks({ deliveryBoyId: boyId }),
        hierarchicalLogisticsService.getDeliveryBoys()
      ]);

      const profile = fetchedBoys.find((b) => b.id === boyId || b.email === user?.email) || {
        id: boyId,
        name: user?.name || 'Ravi Kumar',
        vehicleType: 'EV_SCOOTER',
        vehicleNumber: 'UP-16-FS-1001',
        vehicleCapacityKg: 35,
        status: 'AVAILABLE',
        rating: 4.88,
        completedToday: 5
      };

      setBoyProfile(profile);
      setTasks(fetchedTasks);

      // Current active task (first non-delivered task)
      const current = fetchedTasks.find((t) => !['DELIVERED', 'CANCELLED'].includes(t.status)) || null;
      setActiveTask(current);
    } catch (err) {
      console.error('Failed to load delivery boy dashboard:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [boyId, user]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Status transition step
  const handleTransitionStatus = async (newStatus) => {
    if (!activeTask) return;
    try {
      setRefreshing(true);
      await hierarchicalLogisticsService.updateTaskStatus(activeTask.id, newStatus);
      setActionSuccessMsg(`Task #${activeTask.orderNumber} transitioned to ${newStatus.replace('_', ' ')}!`);
      await loadData();
      setTimeout(() => setActionSuccessMsg(null), 3500);
    } catch (err) {
      console.error('Failed to update task:', err);
    } finally {
      setRefreshing(false);
    }
  };

  // Report exception
  const handleReportProblem = async () => {
    if (!activeTask || !exceptionText.trim()) return;
    try {
      await hierarchicalLogisticsService.updateTaskStatus(
        activeTask.id, 
        'DELAYED', 
        `Exception reported: ${exceptionText}`
      );
      setActionSuccessMsg('Exception flagged to Zone Coordinator and Regional Head.');
      setReportModalOpen(false);
      setExceptionText('');
      await loadData();
      setTimeout(() => setActionSuccessMsg(null), 4000);
    } catch (err) {
      console.error('Failed to report problem:', err);
    }
  };

  // Metrics calculation
  const metrics = useMemo(() => {
    const assigned = tasks.length;
    const pickupPending = tasks.filter((t) => t.status === 'ASSIGNED' || t.status === 'PICKUP_PENDING').length;
    const inTransit = tasks.filter((t) => t.status === 'PICKED_UP' || t.status === 'IN_TRANSIT' || t.status === 'OUT_FOR_DELIVERY').length;
    const delivered = tasks.filter((t) => t.status === 'DELIVERED').length;
    const earnings = delivered * 65 + 150; // Demo daily wage calculation

    return { assigned, pickupPending, inTransit, delivered, earnings };
  }, [tasks]);

  // Waypoints for RouteMap
  const mapStops = useMemo(() => {
    if (!activeTask) return [];
    return [
      {
        sequenceNumber: 1,
        stopType: 'ORIGIN',
        approximateAddress: activeTask.pickupLocation?.name || 'Farm Gate',
        latitude: activeTask.pickupLocation?.lat || 28.35,
        longitude: activeTask.pickupLocation?.lng || 77.53,
        producerName: activeTask.pickupLocation?.contactPerson || 'Farmer'
      },
      {
        sequenceNumber: 2,
        stopType: 'DELIVERY',
        approximateAddress: activeTask.deliveryLocation?.name || 'Customer Address',
        latitude: activeTask.deliveryLocation?.lat || 28.58,
        longitude: activeTask.deliveryLocation?.lng || 77.45,
        buyerName: activeTask.deliveryLocation?.contactPerson || 'Buyer'
      }
    ];
  }, [activeTask]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950">
        <div className="flex flex-col items-center gap-2">
          <RotateCw className="w-8 h-8 text-emerald-600 animate-spin" />
          <p className="text-xs font-bold text-slate-500 font-display">Loading Delivery Partner Portal...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-6">
        
        {/* =========================================================================
            1. HEADER & PARTNER PROFILE
            ========================================================================= */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-7 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800">
                <Truck className="w-3.5 h-3.5" />
                Delivery Partner
              </span>
              <span className="text-xs text-slate-500 font-mono">
                Zone A • Vehicle: {boyProfile?.vehicleNumber || 'UP-16-FS-1001'}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold uppercase">
                ⭐ {boyProfile?.rating || 4.88}
              </span>
            </div>
            
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white font-display tracking-tight">
              {boyProfile?.name || 'Ravi Kumar'}
            </h1>
            <p className="text-xs text-slate-500">
              {boyProfile?.vehicleType?.replace('_', ' ') || 'EV SCOOTER'} • {boyProfile?.vehicleCapacityKg || 35} kg capacity • Zone A Coordinator: Raj Kumar
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => loadData(true)}
              disabled={refreshing}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white hover:bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 shadow-xs cursor-pointer"
            >
              <RotateCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-emerald-600' : ''}`} />
              <span>{refreshing ? 'Refreshing...' : 'Refresh'}</span>
            </button>
          </div>
        </div>

        {/* Action success alert */}
        {actionSuccessMsg && (
          <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-xs flex items-center justify-between animate-in fade-in">
            <div className="flex items-center gap-2 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>{actionSuccessMsg}</span>
            </div>
            <button onClick={() => setActionSuccessMsg(null)} className="text-xs underline text-emerald-700 cursor-pointer">
              Dismiss
            </button>
          </div>
        )}

        {/* =========================================================================
            2. MY TODAY METRICS
            ========================================================================= */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
            <span className="text-[11px] font-bold font-mono text-slate-400 uppercase block mb-1">
              Assigned Today
            </span>
            <div className="text-2xl font-black text-slate-900 dark:text-white font-display">
              {metrics.assigned}
            </div>
            <span className="text-[10px] text-slate-400">Total assigned deliveries</span>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
            <span className="text-[11px] font-bold font-mono text-amber-500 uppercase block mb-1">
              Pickup Pending
            </span>
            <div className="text-2xl font-black text-amber-600 dark:text-amber-400 font-display">
              {metrics.pickupPending}
            </div>
            <span className="text-[10px] text-slate-400">At farm-gate origin</span>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
            <span className="text-[11px] font-bold font-mono text-blue-500 uppercase block mb-1">
              In Transit
            </span>
            <div className="text-2xl font-black text-blue-600 dark:text-blue-400 font-display">
              {metrics.inTransit}
            </div>
            <span className="text-[10px] text-slate-400">En route to buyer</span>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
            <span className="text-[11px] font-bold font-mono text-emerald-500 uppercase block mb-1">
              Delivered Today
            </span>
            <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 font-display">
              {metrics.delivered}
            </div>
            <span className="text-[10px] text-emerald-600 font-semibold font-mono">₹{metrics.earnings} earned</span>
          </div>
        </div>

        {/* =========================================================================
            3. MY CURRENT TASK (HERO ACTIVE CARD)
            ========================================================================= */}
        {activeTask ? (
          <div className="bg-white dark:bg-slate-900 border-2 border-emerald-500/80 rounded-3xl p-6 sm:p-8 shadow-xl shadow-emerald-950/5 relative overflow-hidden space-y-6">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-emerald-600 text-white">
                    ACTIVE TASK
                  </span>
                  <span className="text-xs font-mono font-bold text-slate-900 dark:text-white">
                    Order #{activeTask.orderNumber || activeTask.orderId}
                  </span>
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                    {activeTask.priority || 'HIGH'} PRIORITY
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white font-display mt-1">
                  {activeTask.items?.[0]?.cropName || 'Fresh Agricultural Produce'} ({activeTask.totalWeightKg || 30} kg)
                </h2>
              </div>

              <span className="text-xs font-mono font-bold uppercase tracking-wider px-3 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">
                Status: {activeTask.status?.replace('_', ' ')}
              </span>
            </div>

            {/* Waypoints Sequence */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Pickup Waypoint */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase font-bold text-emerald-600 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5" />
                    1. FARM-GATE PICKUP
                  </span>
                  <span className="text-[11px] font-mono text-slate-400">
                    ETA: {activeTask.estimatedPickupTime || '09:30 AM'}
                  </span>
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    {activeTask.pickupLocation?.name || 'Yamuna Farm Collection Yard'}
                  </h4>
                  <p className="text-xs text-slate-500">
                    {activeTask.pickupLocation?.address || 'Dankaur Link Road, Greater Noida'}
                  </p>
                </div>
                <div className="pt-2 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
                  <span className="font-medium">
                    Contact: {activeTask.pickupLocation?.contactPerson || 'Farmer Representative'}
                  </span>
                  <a
                    href={`tel:${activeTask.pickupLocation?.phone || '+919876543210'}`}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 font-bold text-[11px]"
                  >
                    <Phone className="w-3 h-3" />
                    <span>Call</span>
                  </a>
                </div>
              </div>

              {/* Delivery Waypoint */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase font-bold text-purple-600 flex items-center gap-1">
                    <Navigation className="w-3.5 h-3.5" />
                    2. BUYER DESTINATION
                  </span>
                  <span className="text-[11px] font-mono text-slate-400">
                    Est. Drop: {activeTask.estimatedDeliveryTime || '11:15 AM'}
                  </span>
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    {activeTask.deliveryLocation?.name || 'Gaur City 2 - Tower G'}
                  </h4>
                  <p className="text-xs text-slate-500">
                    {activeTask.deliveryLocation?.address || 'Sector 16C, Greater Noida West'}
                  </p>
                </div>
                <div className="pt-2 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
                  <span className="font-medium">
                    Contact: {activeTask.deliveryLocation?.contactPerson || 'Priya Sharma'}
                  </span>
                  <a
                    href={`tel:${activeTask.deliveryLocation?.phone || '+919922233445'}`}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-purple-50 text-purple-700 dark:bg-purple-950 dark:text-purple-300 font-bold text-[11px]"
                  >
                    <Phone className="w-3 h-3" />
                    <span>Call</span>
                  </a>
                </div>
              </div>

            </div>

            {/* Embedded Waypoint Map Preview */}
            <div className="rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800">
              <RouteMap stops={mapStops} zoom={12} className="h-48 sm:h-56" />
            </div>

            {/* Action Buttons Stepper */}
            <div className="p-4 rounded-2xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-700 dark:text-slate-300">
                  Step Through Delivery Milestones:
                </span>
                <button
                  onClick={() => setReportModalOpen(true)}
                  className="text-amber-600 dark:text-amber-400 font-bold hover:underline flex items-center gap-1 text-[11px] cursor-pointer"
                >
                  <AlertTriangle className="w-3 h-3" />
                  <span>Report Problem</span>
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <button
                  onClick={() => handleTransitionStatus('PICKUP_PENDING')}
                  disabled={activeTask.status !== 'ASSIGNED'}
                  className={`p-2.5 rounded-xl font-bold text-xs transition-colors cursor-pointer text-center ${
                    activeTask.status === 'ASSIGNED'
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  1. Start Pickup
                </button>

                <button
                  onClick={() => handleTransitionStatus('PICKED_UP')}
                  disabled={activeTask.status !== 'PICKUP_PENDING'}
                  className={`p-2.5 rounded-xl font-bold text-xs transition-colors cursor-pointer text-center ${
                    activeTask.status === 'PICKUP_PENDING'
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  2. Picked Up
                </button>

                <button
                  onClick={() => handleTransitionStatus('IN_TRANSIT')}
                  disabled={activeTask.status !== 'PICKED_UP'}
                  className={`p-2.5 rounded-xl font-bold text-xs transition-colors cursor-pointer text-center ${
                    activeTask.status === 'PICKED_UP'
                      ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-xs'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  3. Start Delivery
                </button>

                <button
                  onClick={() => handleTransitionStatus('DELIVERED')}
                  disabled={!['IN_TRANSIT', 'OUT_FOR_DELIVERY'].includes(activeTask.status)}
                  className={`p-2.5 rounded-xl font-bold text-xs transition-colors cursor-pointer text-center ${
                    ['IN_TRANSIT', 'OUT_FOR_DELIVERY'].includes(activeTask.status)
                      ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black shadow-md'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  4. Mark Delivered ✓
                </button>
              </div>
            </div>

          </div>
        ) : (
          <div className="p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white font-display">
              No Pending Active Tasks
            </h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              You're currently available in Zone A. You will automatically receive a new task as soon as a farm pickup is scheduled.
            </p>
          </div>
        )}

        {/* =========================================================================
            4. RECENT TASK HISTORY
            ========================================================================= */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white font-display">
            My Delivery History
          </h3>

          <div className="space-y-2.5">
            {tasks.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-6">No tasks assigned yet.</p>
            ) : (
              tasks.map((task) => (
                <div
                  key={task.id}
                  className="p-3.5 rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 flex items-center justify-between text-xs"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-slate-900 dark:text-white">
                        #{task.orderNumber || task.orderId}
                      </span>
                      <span className="text-slate-500">
                        {task.items?.[0]?.cropName || 'Produce'} ({task.totalWeightKg || 25}kg)
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 truncate">
                      {task.pickupLocation?.name} → {task.deliveryLocation?.name}
                    </p>
                  </div>

                  <span className={`text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-full ${
                    task.status === 'DELIVERED'
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                      : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                  }`}>
                    {task.status}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

      {/* =========================================================================
          REPORT PROBLEM MODAL
          ========================================================================= */}
      {reportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-7 max-w-md w-full space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-950 flex items-center justify-center text-amber-600">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white font-display">
                Report Delivery Issue
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Describe the reason (e.g. farm gate closed, vehicle breakdown, recipient unavailable).
              </p>
            </div>

            <textarea
              rows={3}
              value={exceptionText}
              onChange={(e) => setExceptionText(e.target.value)}
              placeholder="e.g. Heavy transit delay near Pari Chowk due to road maintenance..."
              className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-white focus:outline-emerald-500"
            />

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setReportModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 dark:text-slate-300 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleReportProblem}
                disabled={!exceptionText.trim()}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold shadow-xs cursor-pointer disabled:opacity-50"
              >
                Submit Report
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
