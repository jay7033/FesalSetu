import React, { useState } from 'react';
import { Link, useOutletContext } from 'react-router-dom';
import { 
  ShoppingBag, 
  MapPin, 
  Heart, 
  Store, 
  Clock, 
  CheckCircle2, 
  ArrowRight, 
  Plus, 
  FileText, 
  Truck, 
  Sparkles
} from 'lucide-react';
import DashboardHeader from '../../components/dashboard/DashboardHeader';
import DashboardStatCard from '../../components/dashboard/DashboardStatCard';
import StatusBadge from '../../components/dashboard/StatusBadge';
import QuickActions from '../../components/dashboard/QuickActions';
import LocationStatusCard from '../../components/dashboard/LocationStatusCard';
import Button from '../../components/Button';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { useProducts } from '../../context/ProductContext';
import { useOrders } from '../../context/OrderContext';
import { useBuyer } from '../../context/BuyerContext';
import { useLocation } from '../../context/LocationContext';
import { useAI } from '../../context/AIContext';

export default function ConsumerDashboard() {
  const { user } = useAuth();
  const context = useOutletContext();
  const activeTab = context?.activeTab || 'overview';
  const setActiveTab = context?.setActiveTab || (() => {});

  const { totalUniqueItems, addToCart } = useCart();
  const { products } = useProducts();
  const { orders } = useOrders();
  const { savedProductIds, toggleSaveProduct, isProductSaved } = useBuyer();
  const { location, requestDeviceLocation, isLocating } = useLocation();
  const { getConsumerRecommendations } = useAI();

  const [deliveryAddress, setDeliveryAddress] = useState('Noida Sector 62, Gautam Buddha Nagar, Uttar Pradesh');
  const [showAddressModal, setShowAddressModal] = useState(false);
  const [newAddressInput, setNewAddressInput] = useState('');
  const [activeTrackingOrder, setActiveTrackingOrder] = useState(null);
  const [addedNotification, setAddedNotification] = useState(null);

  const consumerName = user?.name || 'Pooja Sharma';

  // Calculate distance for nearby produce mock calculation
  const getProductDistance = (prod, index) => {
    if (prod.distance) return prod.distance;
    return `${12 + (index * 4)} km away`;
  };

  const nearbyProducts = products.slice(0, 4);
  const aiRecommendations = getConsumerRecommendations();
  const recommendedProducts = aiRecommendations.slice(0, 4);
  const savedProducts = products.filter((p) => isProductSaved(p.id));

  const isDemo = !user || user.isDemo || user.email === 'consumer@fasalsetu.demo';
  const consumerOrders = orders.filter((o) => {
    if (isDemo) return o.buyerRole === 'consumer';
    return o.buyerId === user?.id || (o.buyerRole === 'consumer' && !o.isDemo);
  });
  const activeOrders = consumerOrders.filter(
    (o) => o.status !== 'Delivered' && o.status !== 'Cancelled'
  );
  const deliveredOrders = consumerOrders.filter((o) => o.status === 'Delivered');

  const handleAddToCart = (product) => {
    addToCart(product, 1);
    setAddedNotification(`${product.name} added to cart!`);
    setTimeout(() => setAddedNotification(null), 2500);
  };

  const handleUseCurrentLocation = async () => {
    try {
      const result = await requestDeviceLocation();
      if (result?.formattedAddress) {
        setDeliveryAddress(result.formattedAddress);
      } else if (result?.approximateLocation) {
        setDeliveryAddress(result.approximateLocation);
      }
    } catch (e) {
      console.error('Consumer GPS detection error:', e);
    }
  };

  const quickActionsList = [
    {
      label: 'Browse Marketplace',
      icon: Store,
      to: '/marketplace',
      description: 'Explore 20+ farm-fresh vegetables and fruits',
      iconBg: 'bg-emerald-100 text-emerald-800'
    },
    {
      label: 'My Orders',
      icon: FileText,
      onClick: () => setActiveTab('orders'),
      description: `Track ${activeOrders.length} active dispatches`,
      iconBg: 'bg-blue-100 text-blue-800'
    },
    {
      label: 'Saved Products',
      icon: Heart,
      onClick: () => setActiveTab('saved'),
      description: `${savedProductIds.length} bookmarked favorites`,
      iconBg: 'bg-rose-100 text-rose-800'
    },
    {
      label: 'Update Location',
      icon: MapPin,
      onClick: () => setShowAddressModal(true),
      description: 'Set morning dispatch doorstep address',
      iconBg: 'bg-amber-100 text-amber-800'
    },
    {
      label: 'My Cart',
      icon: ShoppingBag,
      to: '/cart',
      description: `${totalUniqueItems} unique items ready for checkout`,
      iconBg: 'bg-teal-100 text-teal-800'
    }
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      
      {/* Toast Notification */}
      {addedNotification && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-xl border border-slate-800 text-xs font-bold flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{addedNotification}</span>
        </div>
      )}

      {/* Top Header adhering to Section 7 */}
      <DashboardHeader
        greeting={`Hello, ${consumerName}`}
        roleBadge="🛒 Consumer Portal"
        locationType="Deliver to"
        locationText={deliveryAddress}
        isLocationVerified={true}
      >
        <Button
          to="/marketplace"
          variant="primary"
          size="md"
          leftIcon={Store}
        >
          Browse Marketplace
        </Button>
      </DashboardHeader>

      {/* 4 Core KPI Cards adhering to Section 7 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        <DashboardStatCard
          title="Active Orders"
          value={activeOrders.length || 3}
          subtext="4-6 hr morning transit"
          change="Live Delivery"
          icon={Clock}
          accent="amber"
        />
        <DashboardStatCard
          title="Orders Delivered"
          value={deliveredOrders.length + 16}
          subtext="Past orders completed"
          change="100% Fresh"
          icon={CheckCircle2}
          accent="emerald"
        />
        <DashboardStatCard
          title="Total Saved"
          value="₹2,450"
          subtext="vs Supermarket retail"
          change="35% Saved"
          icon={Sparkles}
          accent="teal"
        />
        <DashboardStatCard
          title="Cart Items"
          value={totalUniqueItems}
          subtext="Fresh produce waiting"
          change={totalUniqueItems > 0 ? 'Ready' : 'Empty'}
          icon={ShoppingBag}
          accent="blue"
        />
      </div>

      {/* Delivery Location Card adhering to Section 7 */}
      <LocationStatusCard
        typeLabel="Delivery Location"
        locationName="Doorstep Drop Location"
        approximateAddress={deliveryAddress}
        isVerified={true}
        source={location?.source || 'Verified Society'}
        onUseCurrentLocation={handleUseCurrentLocation}
        isDetectingGPS={isLocating}
        role="consumer"
      />

      {/* View Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-1">
        {[
          { id: 'overview', label: 'Dashboard Overview' },
          { id: 'orders', label: `My Orders (${consumerOrders.length})` },
          { id: 'saved', label: `Saved Produce (${savedProductIds.length})` },
          { id: 'location', label: 'Delivery Location' }
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === tab.id
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Active Orders Live Tracking Cards (Section 7 requirement: Order #FS1024 Fresh Vegetables ₹840 Out for Delivery) */}
      {(activeTab === 'overview' || activeTab === 'orders') && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Active Orders
              </h3>
              <p className="text-xs text-slate-500">
                Direct farm-to-doorstep early morning transit
              </p>
            </div>
            <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
              Zero Cold Transit Spoilage
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Primary Highlight Active Order #FS1024 */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-50/70 to-teal-50/50 border border-emerald-200/90 space-y-4 relative overflow-hidden">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[11px] font-mono font-bold text-emerald-800 uppercase block">
                    Order #FS1024
                  </span>
                  <h4 className="text-base font-bold text-slate-900">Fresh Vegetables Box</h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Tomatoes, Potatoes, Tender Spinach • ₹840
                  </p>
                </div>
                <StatusBadge status="Out for Delivery" size="sm" />
              </div>

              <div className="flex items-center justify-between text-xs pt-2 border-t border-emerald-200/60">
                <span className="text-slate-600 flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Yamuna Corridor Hub • ETA: 45 mins</span>
                </span>
                <button
                  type="button"
                  onClick={() => setActiveTrackingOrder('FS1024')}
                  className="text-xs font-bold text-emerald-800 hover:text-emerald-900 underline cursor-pointer"
                >
                  Track Order
                </button>
              </div>
            </div>

            {/* Additional active order if present */}
            {activeOrders.filter((o) => o.id !== 'FS1024').slice(0, 1).map((ord) => (
              <div key={ord.id} className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-4">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[11px] font-mono font-bold text-slate-600 uppercase block">
                      Order #{ord.id}
                    </span>
                    <h4 className="text-base font-bold text-slate-900">{ord.product}</h4>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {ord.quantity} {ord.unit} • ₹{ord.amount}
                    </p>
                  </div>
                  <StatusBadge status={ord.status} size="sm" />
                </div>

                <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-200">
                  <span className="text-slate-500">Scheduled: {ord.date}</span>
                  <button
                    type="button"
                    onClick={() => setActiveTrackingOrder(ord.id)}
                    className="text-xs font-bold text-emerald-700 hover:underline cursor-pointer"
                  >
                    Track Order
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Section 7 Requirement: Nearby Fresh Produce */}
      {(activeTab === 'overview') && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-5">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Nearby Fresh Produce
              </h3>
              <p className="text-xs text-slate-500">
                Harvested within 35 km of your delivery location
              </p>
            </div>
            <Link
              to="/marketplace"
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 hover:underline flex items-center gap-1"
            >
              <span>View All Marketplace</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {nearbyProducts.map((prod, idx) => {
              const distance = getProductDistance(prod, idx);
              const isSaved = isProductSaved(prod.id);

              return (
                <div
                  key={prod.id}
                  className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-emerald-300 transition-all flex flex-col justify-between group space-y-3"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                        📍 {distance}
                      </span>
                      <button
                        type="button"
                        onClick={() => toggleSaveProduct(prod.id)}
                        className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                          isSaved
                            ? 'bg-rose-50 border-rose-200 text-rose-600'
                            : 'bg-white border-slate-200 text-slate-400 hover:text-rose-500'
                        }`}
                        title="Save to favorites"
                      >
                        <Heart className="w-3.5 h-3.5 fill-current" />
                      </button>
                    </div>

                    <div>
                      <h4 className="text-sm font-bold text-slate-900 group-hover:text-emerald-800 transition-colors truncate">
                        {prod.name}
                      </h4>
                      <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        <span className="truncate">Near {prod.origin || 'Greater Noida'}</span>
                      </p>
                    </div>

                    <div className="flex items-baseline gap-1">
                      <span className="text-base font-black text-slate-950 font-display">
                        ₹{prod.price}
                      </span>
                      <span className="text-xs text-slate-500">/{prod.unit}</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-200/60 flex items-center gap-2">
                    <Link
                      to={`/product/${prod.id}`}
                      className="flex-1 text-center py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-xs font-bold text-slate-700 transition-colors"
                    >
                      View
                    </Link>
                    <button
                      type="button"
                      onClick={() => handleAddToCart(prod)}
                      className="flex-1 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add to Cart</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Section 7 Requirement: Recommended For You with AI Demand Intelligence */}
      {(activeTab === 'overview') && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-700 mb-0.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                <span>AI Curated Produce</span>
              </div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Recommended For You
              </h3>
              <p className="text-xs text-slate-500">
                Fresh produce selected from active nearby harvests based on demand velocity
              </p>
            </div>
            <Link
              to="/ai-insights"
              className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 hover:underline flex items-center gap-1"
            >
              <span>Explore AI Insights</span>
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {recommendedProducts.map((prod) => (
              <div
                key={prod.id}
                className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-emerald-300 transition-all flex flex-col justify-between space-y-3"
              >
                <div>
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      {prod.isTrendingDemand ? '🔥 High Demand' : 'Fresh Harvest'}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-900 truncate">{prod.name}</h4>
                  <p className="text-[11px] text-slate-500">{prod.origin || 'Western UP'}</p>
                  <p className="text-sm font-black text-slate-950 mt-1">₹{prod.price}/{prod.unit}</p>
                </div>
                <button
                  type="button"
                  onClick={() => handleAddToCart(prod)}
                  className="w-full py-1.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 text-xs font-bold transition-colors cursor-pointer"
                >
                  + Add to Cart
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Saved Products */}
      {(activeTab === 'saved') && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Saved & Favorite Products
              </h3>
              <p className="text-xs text-slate-500">
                Quickly reorder your preferred produce batches
              </p>
            </div>
            <span className="text-xs font-bold text-slate-500">
              {savedProducts.length} items saved
            </span>
          </div>

          {savedProducts.length === 0 ? (
            <div className="text-center py-10 text-xs text-slate-500 space-y-3">
              <Heart className="w-8 h-8 text-slate-300 mx-auto" />
              <p>No products saved to your favorites yet.</p>
              <Button to="/marketplace" variant="outline" size="sm">
                Browse Marketplace
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {savedProducts.map((prod) => (
                <div
                  key={prod.id}
                  className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3"
                >
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">{prod.name}</h4>
                    <p className="text-[11px] text-slate-500">₹{prod.price}/{prod.unit}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleAddToCart(prod)}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700 cursor-pointer"
                    >
                      Add
                    </button>
                    <button
                      type="button"
                      onClick={() => toggleSaveProduct(prod.id)}
                      className="p-1.5 rounded-xl text-rose-500 hover:bg-rose-50 cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Quick Actions adhering to Section 7 */}
      <QuickActions
        title="Quick Actions"
        subtitle="Frequently used consumer actions"
        actions={quickActionsList}
      />

      {/* Modal: Change Delivery Address */}
      {showAddressModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900 font-display">
                Update Delivery Address
              </h3>
              <button
                type="button"
                onClick={() => setShowAddressModal(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-500">
              Enter your Noida / Greater Noida residential society or urban sector.
            </p>

            <input
              type="text"
              placeholder="e.g. Sector 78, Noida, Uttar Pradesh"
              value={newAddressInput}
              onChange={(e) => setNewAddressInput(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs focus:outline-emerald-500"
            />

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowAddressModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                Cancel
              </button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => {
                  if (newAddressInput.trim()) {
                    setDeliveryAddress(newAddressInput.trim());
                  }
                  setShowAddressModal(false);
                }}
              >
                Save Address
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Order Tracking Simulator */}
      {activeTrackingOrder && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-slate-200 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <span className="text-[10px] font-mono text-emerald-700 font-bold block uppercase">
                  Live Dispatch Status
                </span>
                <h3 className="text-base font-bold text-slate-900 font-display">
                  Tracking Order #{activeTrackingOrder}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setActiveTrackingOrder(null)}
                className="text-slate-400 hover:text-slate-600 font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-[10px]">
                  ✓
                </div>
                <div>
                  <h5 className="font-bold text-slate-900">Harvest Plucked & Packed</h5>
                  <p className="text-[11px] text-slate-500">06:00 AM • Dankaur Farm Gate Origin</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-[10px]">
                  ✓
                </div>
                <div>
                  <h5 className="font-bold text-slate-900">Yamuna Expressway EV Transit</h5>
                  <p className="text-[11px] text-slate-500">07:15 AM • Consolidated Hub Staging</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-teal-500 text-white flex items-center justify-center font-bold text-[10px] animate-pulse">
                  ⚡
                </div>
                <div>
                  <h5 className="font-bold text-teal-900">Out for Doorstep Delivery</h5>
                  <p className="text-[11px] text-slate-500">En route to {deliveryAddress}</p>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 text-center">
              <Button
                variant="primary"
                size="sm"
                onClick={() => setActiveTrackingOrder(null)}
                className="w-full justify-center"
              >
                Close Tracking
              </Button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
