import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  ShoppingBag, 
  Store, 
  ArrowRight, 
  MapPin, 
  Search
} from 'lucide-react';
import StatusBadge from '../../components/dashboard/StatusBadge';
import EmptyState from '../../components/dashboard/EmptyState';
import Button from '../../components/Button';
import { useOrders } from '../../context/OrderContext';

const STATUS_FILTERS = [
  'All',
  'Pending',
  'Confirmed',
  'Preparing',
  'In Transit',
  'Delivered',
  'Cancelled'
];

export default function ConsumerOrders() {
  const { orders } = useOrders();
  const [activeFilter, setActiveFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const consumerOrders = orders.filter((o) => o.buyerRole === 'consumer');

  const filteredOrders = consumerOrders.filter((ord) => {
    const matchesFilter = activeFilter === 'All' || ord.status.toLowerCase() === activeFilter.toLowerCase();
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch = !q || 
      ord.id.toLowerCase().includes(q) ||
      (ord.product && ord.product.toLowerCase().includes(q)) ||
      (ord.items && ord.items.some((it) => it.name.toLowerCase().includes(q)));
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
              Purchases & Live Delivery
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold">
              Direct Farm Gate
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-950 font-display tracking-tight">
            My Orders
          </h1>
          <p className="text-slate-500 text-xs sm:text-sm mt-0.5">
            Real-time tracking of fresh produce dispatched from local farmers and FPOs.
          </p>
        </div>

        <Button
          to="/marketplace"
          variant="primary"
          size="sm"
          leftIcon={Store}
        >
          Browse Marketplace
        </Button>
      </div>

      {/* Filter Tabs & Search Input */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex flex-wrap gap-1.5 p-1 rounded-2xl bg-white border border-slate-200 w-full sm:w-auto overflow-x-auto">
          {STATUS_FILTERS.map((filter) => (
            <button
              key={filter}
              type="button"
              onClick={() => setActiveFilter(filter)}
              className={`text-xs px-3.5 py-1.5 rounded-xl font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeFilter === filter
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by Order ID or produce..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 focus:outline-emerald-500"
          />
        </div>
      </div>

      {/* Orders List / Empty State */}
      {filteredOrders.length === 0 ? (
        <EmptyState
          icon={ShoppingBag}
          title="No orders found"
          description="Start exploring fresh produce directly from farmers and FPOs on the marketplace."
          actionLabel="Browse Marketplace"
          actionLink="/marketplace"
        />
      ) : (
        <div className="space-y-4">
          {filteredOrders.map((ord) => (
            <div
              key={ord.id}
              className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-xs hover:shadow-md transition-shadow flex flex-col md:flex-row md:items-center justify-between gap-5"
            >
              <div className="space-y-3 flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-3">
                  <span className="font-mono font-bold text-sm text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-lg border border-emerald-200">
                    #{ord.id}
                  </span>
                  <StatusBadge status={ord.status} size="sm" />
                  <span className="text-xs text-slate-400">
                    Placed: {ord.date || 'Today'}
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-bold text-slate-900 truncate">
                    {ord.product || (ord.items && ord.items.map((i) => i.name).join(', ')) || 'Fresh Farm Produce'}
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {ord.items?.length || 1} produce batch • {ord.deliveryEstimate || 'Today 4-6 hrs delivery'}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600">
                  <span className="flex items-center gap-1 text-slate-500">
                    <MapPin className="w-3.5 h-3.5 text-emerald-700" />
                    <span>{ord.location || ord.buyerLocation?.address || 'Noida'}</span>
                  </span>
                  <span>•</span>
                  <span>Payment: <strong className="text-slate-800">{ord.paymentMethod || 'Cash on Delivery'}</strong></span>
                </div>
              </div>

              <div className="flex sm:flex-col md:items-end justify-between border-t md:border-t-0 pt-4 md:pt-0 border-slate-100 gap-3 flex-shrink-0">
                <div className="text-left sm:text-right">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">Total Paid</span>
                  <span className="text-xl font-black text-slate-950 font-display">
                    ₹{ord.total || ord.amount}
                  </span>
                </div>

                <Link
                  to={`/consumer/orders/${ord.id}`}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shadow-xs"
                >
                  <span>Track Order</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
}
