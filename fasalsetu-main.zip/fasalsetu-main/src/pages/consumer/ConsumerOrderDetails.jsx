import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  ChevronLeft, 
  MapPin, 
  AlertCircle,
  Calendar,
  XCircle
} from 'lucide-react';
import StatusBadge from '../../components/dashboard/StatusBadge';
import Button from '../../components/Button';
import ShipmentStatus from '../../components/logistics/ShipmentStatus';
import { useOrders, ORDER_LIFECYCLE_STEPS } from '../../context/OrderContext';
import { useLogistics } from '../../context/LogisticsContext';

export default function ConsumerOrderDetails() {
  const { orderId } = useParams();
  const { getOrderById, cancelOrder } = useOrders();
  const { getShipmentByOrderId } = useLogistics();

  const order = getOrderById(orderId);
  const shipment = order ? getShipmentByOrderId(order.id) : null;

  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelReason, setCancelReason] = useState('Found alternative produce');
  const [cancelError, setCancelError] = useState(null);

  if (!order) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-4 text-center max-w-md mx-auto space-y-4">
        <AlertCircle className="w-12 h-12 text-slate-400" />
        <h2 className="text-xl font-bold text-slate-900 font-display">Order Not Found</h2>
        <p className="text-xs text-slate-500">
          The requested Order #{orderId} could not be located in our records.
        </p>
        <Button to="/consumer/orders" variant="outline" size="sm">
          Return to My Orders
        </Button>
      </div>
    );
  }

  const isCancellable = order.status === 'Pending' || order.status === 'Confirmed';

  const handleConfirmCancel = () => {
    setCancelError(null);
    const result = cancelOrder(order.id, cancelReason);
    if (result.success) {
      setShowCancelModal(false);
    } else {
      setCancelError(result.error || 'Failed to cancel order.');
    }
  };

  // Determine current lifecycle index for timeline
  const currentStatusIndex = ORDER_LIFECYCLE_STEPS.indexOf(order.status);

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      
      {/* Breadcrumb Navigation */}
      <div className="flex items-center justify-between">
        <Link
          to="/consumer/orders"
          className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-emerald-700 transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Back to All Orders</span>
        </Link>

        <span className="text-xs font-bold text-slate-500 font-mono">
          ID: {order.id}
        </span>
      </div>

      {/* Order Header Card adhering to Section 10 */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
        <div className="space-y-2 z-10">
          <div className="flex flex-wrap items-center gap-2.5">
            <h1 className="text-2xl sm:text-3xl font-black text-slate-950 font-display">
              Order #{order.id}
            </h1>
            <StatusBadge status={order.status} size="md" />
          </div>

          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600">
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>Placed: <strong>{order.date || 'Today'}</strong></span>
            </span>
            <span>•</span>
            <span className="text-slate-600">
              Payment: <strong>{order.paymentMethod || 'Cash on Delivery'}</strong> ({order.paymentStatus || 'Secured'})
            </span>
          </div>
        </div>

        <div className="flex flex-col sm:items-end justify-between gap-2 z-10">
          <span className="text-xs font-bold text-slate-400 uppercase">Grand Total</span>
          <span className="text-3xl font-black text-slate-950 font-display">
            ₹{order.total || order.amount}
          </span>
          {isCancellable && (
            <button
              type="button"
              onClick={() => setShowCancelModal(true)}
              className="text-xs font-bold text-rose-600 hover:text-rose-700 underline cursor-pointer mt-1"
            >
              Cancel Order
            </button>
          )}
        </div>

        {/* Ambient background glow */}
        <div className="absolute right-0 bottom-0 translate-x-10 translate-y-10 w-48 h-48 bg-emerald-100/30 rounded-full blur-2xl pointer-events-none" />
      </div>

      {/* Visual Status Timeline adhering strictly to Section 10 */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs space-y-6">
        <div>
          <h3 className="text-base font-bold text-slate-900 font-display">
            Fulfillment Progress Timeline
          </h3>
          <p className="text-xs text-slate-500">
            Live updates synchronized directly from farmer & aggregation hubs
          </p>
        </div>

        {order.status === 'Cancelled' ? (
          <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs space-y-1">
            <div className="flex items-center gap-2 font-bold">
              <XCircle className="w-4 h-4 text-rose-600" />
              <span>Order Cancelled</span>
            </div>
            <p className="text-rose-700">
              Reason: {order.cancellationReason || 'Cancelled before dispatch'}. Any reserved produce stock has been released.
            </p>
          </div>
        ) : (
          <div className="relative pl-6 sm:pl-8 space-y-6 border-l-2 border-emerald-200 ml-3">
            {ORDER_LIFECYCLE_STEPS.map((step, idx) => {
              const isPast = currentStatusIndex > idx;
              const isCurrent = currentStatusIndex === idx;
              const isFuture = currentStatusIndex < idx;

              // Match timeline log entry if recorded
              const logEntry = (order.timeline || []).find((t) => t.status === step);

              return (
                <div key={step} className="relative">
                  {/* Step Dot */}
                  <div
                    className={`absolute -left-[31px] sm:-left-[39px] top-0.5 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                      isPast
                        ? 'bg-emerald-600 text-white'
                        : isCurrent
                        ? 'bg-emerald-500 text-white ring-4 ring-emerald-100 animate-pulse'
                        : 'bg-slate-100 text-slate-400 border border-slate-200'
                    }`}
                  >
                    {isPast ? '✓' : isCurrent ? '●' : '○'}
                  </div>

                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4
                        className={`text-xs sm:text-sm font-bold ${
                          isCurrent
                            ? 'text-emerald-900 font-black'
                            : isPast
                            ? 'text-slate-900'
                            : 'text-slate-400'
                        }`}
                      >
                        {step === 'Pending' ? 'Order Placed' : step}
                      </h4>

                      {isCurrent && (
                        <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-emerald-100 text-emerald-800">
                          Active Stage
                        </span>
                      )}

                      {logEntry && (
                        <span className="text-[11px] text-slate-400">
                          • {new Date(logEntry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      )}
                    </div>

                    <p className={`text-xs ${isFuture ? 'text-slate-300' : 'text-slate-500'}`}>
                      {step === 'Pending' && 'Order successfully received and sent to local farmer/FPO for confirmation.'}
                      {step === 'Confirmed' && 'Farm producer confirmed harvest availability and scheduled grading.'}
                      {step === 'Preparing' && 'Produce plucked fresh from field, graded for quality, and crated.'}
                      {step === 'Ready for Pickup' && 'Sealed batches staged at collection hub for courier dispatch.'}
                      {step === 'Picked Up' && 'Assigned to hyperlocal EV delivery partner for rapid transit.'}
                      {step === 'In Transit' && (order.deliveryEstimate ? `En route along Yamuna corridor. ${order.deliveryEstimate}` : 'En route to your doorstep location.')}
                      {step === 'Delivered' && 'Delivered fresh directly at your society drop location.'}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Live Hyperlocal Fleet Shipment & Route Tracking */}
      {shipment && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-900 font-display">
                Hyperlocal Delivery Transit
              </h3>
              <p className="text-xs text-slate-500">
                Direct-from-farm consolidated EV transit details
              </p>
            </div>
            <Link
              to="/logistics"
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 hover:underline"
            >
              Logistics Network →
            </Link>
          </div>

          <ShipmentStatus shipment={shipment} />
        </div>
      )}

      {/* Multi-Farmer Fulfillment Items (Section 7 Architecture) */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs space-y-6">
        <div>
          <h3 className="text-base font-bold text-slate-900 font-display">
            Order Produce & Supplier Fulfillment
          </h3>
          <p className="text-xs text-slate-500">
            Batches packaged at verified farm gates
          </p>
        </div>

        {order.fulfillments && order.fulfillments.length > 0 ? (
          <div className="space-y-4">
            {order.fulfillments.map((ful, idx) => (
              <div
                key={idx}
                className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3"
              >
                <div className="flex items-center justify-between pb-2 border-b border-slate-200/60">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 block">
                      Fulfillment Group {String.fromCharCode(65 + idx)}
                    </span>
                    <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                      {ful.supplierName} ({ful.supplierType || 'Producer'})
                    </h4>
                    <p className="text-[11px] text-slate-500">📍 {ful.farmLocation}</p>
                  </div>
                  <StatusBadge status={ful.status || order.status} size="sm" />
                </div>

                <div className="space-y-2 divide-y divide-slate-200/40">
                  {ful.items.map((it, i) => (
                    <div key={i} className="pt-2 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-slate-800">{it.name}</span>
                        <span className="text-slate-500 ml-2">
                          {it.quantity} {it.unit || 'kg'} × ₹{it.price}
                        </span>
                      </div>
                      <span className="font-mono font-bold text-slate-950">
                        ₹{it.subtotal || it.price * it.quantity}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {(order.items || []).map((it, i) => (
              <div key={i} className="py-3 flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-slate-800">{it.name}</span>
                  <p className="text-[11px] text-slate-500">
                    Producer: {it.farmerName || 'Local Producer'} • 📍 {it.farmLocation || 'Western UP'}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-slate-500">{it.quantity} {it.unit || 'kg'} × ₹{it.price}</p>
                  <p className="font-mono font-bold text-slate-950">₹{it.subtotal || it.price * it.quantity}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Cost Summary Breakdown */}
        <div className="pt-4 border-t border-slate-100 space-y-2 text-xs">
          <div className="flex justify-between text-slate-600">
            <span>Items Subtotal</span>
            <span className="font-mono font-bold text-slate-900">₹{order.subtotal || order.amount}</span>
          </div>
          <div className="flex justify-between text-slate-600">
            <span>Delivery Fee</span>
            <span className="font-mono font-bold text-slate-900">
              {order.deliveryFee === 0 ? 'FREE' : `₹${order.deliveryFee || 0}`}
            </span>
          </div>
          {order.savings > 0 && (
            <div className="flex justify-between text-emerald-700 font-semibold bg-emerald-50 p-2 rounded-xl">
              <span>Direct Farm-Gate Savings</span>
              <span className="font-mono font-bold">-₹{order.savings}</span>
            </div>
          )}
          <div className="pt-2 border-t border-slate-200 flex justify-between items-baseline">
            <span className="text-sm font-bold text-slate-900">Total Paid</span>
            <span className="text-xl font-black text-slate-950 font-display">₹{order.total || order.amount}</span>
          </div>
        </div>
      </div>

      {/* Delivery Destination Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs space-y-3">
        <h3 className="text-base font-bold text-slate-900 font-display flex items-center gap-2">
          <MapPin className="w-4 h-4 text-emerald-700" />
          <span>Delivery Destination</span>
        </h3>
        <p className="text-xs text-slate-700 leading-relaxed font-medium">
          {order.buyerLocation?.address || order.location || 'Noida Sector 62, Uttar Pradesh'}
        </p>
        <p className="text-[11px] text-slate-500">
          Estimated: <strong className="text-emerald-800">{order.deliveryEstimate || 'Today 4-6 Hours'}</strong> • Contact: <strong>Direct Courier Protocol</strong>
        </p>
      </div>

      {/* Cancellation Modal Dialog */}
      {showCancelModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center flex-shrink-0">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 font-display">
                  Cancel Order #{order.id}?
                </h3>
                <p className="text-xs text-slate-500">
                  Produce reserved for you will be released back to the farm inventory.
                </p>
              </div>
            </div>

            {cancelError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                {cancelError}
              </div>
            )}

            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700">
                Cancellation Reason:
              </label>
              <select
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-800 focus:outline-emerald-500"
              >
                <option value="Found alternative produce">Found alternative produce</option>
                <option value="Changed delivery address">Changed delivery address</option>
                <option value="Ordered incorrect quantity">Ordered incorrect quantity</option>
                <option value="Emergency cancellation">Emergency cancellation</option>
              </select>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowCancelModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                Keep Order
              </button>
              <button
                type="button"
                onClick={handleConfirmCancel}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 transition-colors cursor-pointer"
              >
                Confirm Cancellation
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
