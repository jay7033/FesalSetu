import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowRight, 
  Sparkles, 
  Sprout, 
  Store, 
  CreditCard, 
  BrainCircuit, 
  Truck, 
  CheckCircle2, 
  ChevronRight, 
  Users, 
  Leaf, 
  Info, 
  Globe2, 
  Building2, 
  ArrowDown,
  Map,
  Boxes,
  Wheat
} from 'lucide-react';
import Button from '../components/Button';
import { 
  STATS_DATA, 
  HOW_IT_WORKS_STEPS, 
  VALUE_PROPOSITIONS,
  PAN_INDIA_NETWORK_ZONES
} from '../data/demoData';

const PAN_INDIA_REGIONS = Object.values(PAN_INDIA_NETWORK_ZONES);

export default function Home() {
  const [selectedRegion, setSelectedRegion] = useState(PAN_INDIA_NETWORK_ZONES.north);
  const stepIcons = [Sprout, BrainCircuit, Store, Truck, CreditCard];


  return (
    <div className="bg-slate-50 relative overflow-hidden">
      
      {/* =========================================================================
          HERO SECTION
          ========================================================================= */}
      <section className="relative pt-12 pb-20 sm:pt-16 sm:pb-28 overflow-hidden bg-gradient-to-b from-white via-slate-50/60 to-slate-50 border-b border-slate-200/70">
        
        {/* Ambient background glows & grid */}
        <div className="absolute inset-0 bg-grid-pattern opacity-60 pointer-events-none" />
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-emerald-100/50 rounded-full blur-3xl pointer-events-none -z-10" />
        <div className="absolute top-1/3 left-10 w-80 h-80 bg-amber-100/40 rounded-full blur-3xl pointer-events-none -z-10" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
            
            {/* Left Column: Hero Text & Actions (7 cols) */}
            <div className="lg:col-span-7 space-y-6 text-left">
              
              {/* National Network Badge */}
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-950/90 border border-emerald-700/60 text-emerald-300 text-xs font-semibold shadow-xs backdrop-blur-sm">
                <Globe2 className="w-3.5 h-3.5 text-emerald-400" />
                <span className="uppercase text-[11px] font-bold tracking-wider">India's Digital Farm-to-Market Network</span>
              </div>

              {/* Main Heading */}
              <h1 className="text-4xl sm:text-5xl xl:text-6xl font-extrabold text-slate-950 tracking-tight leading-[1.1] font-display">
                From the <span className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 bg-clip-text text-transparent">farm</span>. <br />
                Straight to the <span className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 bg-clip-text text-transparent">market</span>.
              </h1>

              {/* Hindi Tagline Sub-header */}
              <p className="text-emerald-800/90 font-serif italic text-base sm:text-lg">
                "फसल से बाज़ार तक, सीधे और स्मार्ट तरीके से।"
              </p>

              {/* Supporting Text */}
              <p className="text-slate-600 text-base sm:text-lg leading-relaxed max-w-2xl font-normal">
                FasalSetu connects farmers, FPOs, consumers and bulk buyers through intelligent marketplace, demand forecasting and smart logistics.
              </p>

              {/* Action Buttons */}
              <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5">
                <Button 
                  to="/marketplace" 
                  variant="primary" 
                  size="lg"
                  rightIcon={ArrowRight}
                >
                  Explore Marketplace
                </Button>

                <Button 
                  to="/how-it-works" 
                  variant="outline" 
                  size="lg"
                >
                  How FasalSetu Works
                </Button>
              </div>

              {/* Trust Indicators */}
              <div className="pt-6 border-t border-slate-200/80 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs text-slate-700 font-medium">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Direct Farmer Access</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>AI-Powered Demand</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Smart Logistics</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Pan-India Network</span>
                </div>
              </div>

            </div>

            {/* Right Column: Visual Interactive Pipeline Card Stack (5 cols) */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md space-y-2.5">
                {/* Node 1: Producer & Origin */}
                <div className="p-3.5 rounded-2xl bg-white/95 border border-slate-200/90 shadow-sm flex items-center justify-between gap-3 hover-lift backdrop-blur-md">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700 shrink-0">
                      <Sprout className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-slate-900">Farmer & FPO</span>
                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 font-bold">VERIFIED</span>
                      </div>
                      <p className="text-[11px] text-slate-500">Harvest Stage • Farm-Gate Pricing</p>
                    </div>
                  </div>
                  <span className="text-xs font-bold font-mono text-emerald-700">Origin</span>
                </div>

                <div className="flex justify-center -my-1">
                  <div className="w-0.5 h-3 bg-emerald-300" />
                </div>

                {/* Node 2: Fresh Produce & Quality */}
                <div className="p-3.5 rounded-2xl bg-white/95 border border-slate-200/90 shadow-sm flex items-center justify-between gap-3 hover-lift backdrop-blur-md">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-700 shrink-0">
                      <Leaf className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-slate-900">Fresh Produce</span>
                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-amber-100 text-amber-800 font-bold">GRADE A</span>
                      </div>
                      <p className="text-[11px] text-slate-500">Quality-checked batches tagged at harvest</p>
                    </div>
                  </div>
                  <span className="text-xs font-bold font-mono text-amber-600">Fresh</span>
                </div>

                <div className="flex justify-center -my-1">
                  <div className="w-0.5 h-3 bg-emerald-400" />
                </div>

                {/* Node 3: AI Matching Engine */}
                <div className="p-3.5 rounded-2xl bg-slate-900 text-white border border-slate-800 shadow-md flex items-center justify-between gap-3 hover-lift">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400 shrink-0">
                      <BrainCircuit className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white">AI Matching</span>
                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-bold">SMART</span>
                      </div>
                      <p className="text-[11px] text-slate-400">Demand forecasting & fair pricing</p>
                    </div>
                  </div>
                  <span className="text-xs font-mono text-emerald-400 font-bold">Matching</span>
                </div>

                <div className="flex justify-center -my-1">
                  <div className="w-0.5 h-3 bg-emerald-400" />
                </div>

                {/* Node 4: Logistics */}
                <div className="p-3.5 rounded-2xl bg-white/95 border border-slate-200/90 shadow-sm flex items-center justify-between gap-3 hover-lift backdrop-blur-md">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-700 shrink-0">
                      <Truck className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-slate-900">Smart Logistics</span>
                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-blue-100 text-blue-800 font-bold">OPTIMIZED</span>
                      </div>
                      <p className="text-[11px] text-slate-500">Farm-gate pickup & consolidated routes</p>
                    </div>
                  </div>
                  <span className="text-xs font-bold font-mono text-blue-600">Transit</span>
                </div>

                <div className="flex justify-center -my-1">
                  <div className="w-0.5 h-3 bg-emerald-400" />
                </div>

                {/* Node 5: Buyer */}
                <div className="p-3.5 rounded-2xl bg-white/95 border border-slate-200/90 shadow-sm flex items-center justify-between gap-3 hover-lift backdrop-blur-md">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-purple-50 border border-purple-200 flex items-center justify-center text-purple-700 shrink-0">
                      <Building2 className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-slate-900">Direct Buyer</span>
                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-purple-100 text-purple-800 font-bold">RETAIL & BULK</span>
                      </div>
                      <p className="text-[11px] text-slate-500">Consumers, Kiranas, HoReCa & Bulk Buyers</p>
                    </div>
                  </div>
                  <span className="text-xs font-bold font-mono text-purple-600">Market</span>
                </div>
              </div>
            </div>

          </div>

        </div>

      </section>


      {/* =========================================================================
          IMPACT & METRICS SECTION
          ========================================================================= */}
      <section className="py-12 sm:py-16 bg-white border-b border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Header & Disclaimer */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-8 pb-4 border-b border-slate-100">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">
                Network Impact
              </span>
              <h2 className="text-2xl font-extrabold text-slate-900 font-display">
                Platform Scope & Model Metrics
              </h2>
            </div>

            {/* Prototype Indicator */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-slate-700 text-xs font-medium self-start sm:self-auto">
              <Info className="w-4 h-4 text-emerald-600 flex-shrink-0" />
              <span>
                <strong className="font-bold text-slate-900">Prototype Metric:</strong> Values reflect test cohort & architectural simulation
              </span>
            </div>
          </div>

          {/* 4 Impact Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {STATS_DATA.map((stat, idx) => {
              const icons = [Users, Store, BrainCircuit, Truck];
              const StatIcon = icons[idx] || Users;

              return (
                <div 
                  key={stat.id}
                  className="bg-slate-50 rounded-2xl p-6 border border-slate-200/90 shadow-xs hover:shadow-md hover:border-emerald-300 transition-all duration-300 relative group overflow-hidden hover-lift"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-white border border-slate-200 flex items-center justify-center group-hover:bg-emerald-50 group-hover:border-emerald-200 transition-colors">
                      <StatIcon className="w-6 h-6 text-emerald-700" />
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-emerald-100/80 text-emerald-800">
                      {stat.change}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <p className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-display">
                      {stat.value}
                    </p>
                    <h3 className="text-sm font-bold text-slate-800">
                      {stat.label}
                    </h3>
                    <p className="text-xs text-slate-500 leading-relaxed pt-1">
                      {stat.subtext}
                    </p>
                  </div>

                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-500 to-teal-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              );
            })}
          </div>

        </div>
      </section>


      {/* =========================================================================
          PAN-INDIA NETWORK SECTION
          "Built for Bharat"
          National farm-to-market network
          ========================================================================= */}
      <section className="py-20 sm:py-28 bg-[#070b14] text-white relative overflow-hidden border-y border-slate-800/80" id="built-for-bharat">
        
        {/* Subtle Ambient Glows */}
        <div className="absolute top-0 left-1/4 -translate-y-1/2 w-[650px] h-[650px] bg-emerald-500/10 rounded-full blur-[140px] pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 translate-y-1/3 w-[550px] h-[550px] bg-blue-600/10 rounded-full blur-[140px] pointer-events-none" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[500px] bg-emerald-500/[0.03] rounded-full blur-[160px] pointer-events-none" />

        {/* Subtle Architectural Grid Pattern */}
        <div 
          className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b14_1px,transparent_1px),linear-gradient(to_bottom,#1e293b14_1px,transparent_1px)] bg-[size:4rem_4rem] pointer-events-none" 
          aria-hidden="true"
        />

        {/* Decorative Connected Network Elements (CSS only) */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-30" aria-hidden="true">
          <div className="absolute top-16 left-[15%] w-2 h-2 rounded-full bg-emerald-400/70 shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
          <div className="absolute top-28 left-[32%] w-1.5 h-1.5 rounded-full bg-teal-400/50" />
          <div className="absolute top-20 right-[25%] w-2 h-2 rounded-full bg-blue-400/60 shadow-[0_0_8px_rgba(96,165,250,0.8)]" />
          <div className="absolute top-48 right-[12%] w-1.5 h-1.5 rounded-full bg-emerald-400/50" />
          <div className="absolute bottom-28 left-[10%] w-1.5 h-1.5 rounded-full bg-emerald-400/40" />
          <div className="absolute bottom-36 right-[16%] w-2 h-2 rounded-full bg-teal-400/50 shadow-[0_0_8px_rgba(45,212,191,0.8)]" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          
          {/* Header */}
          <div className="text-center max-w-3xl mx-auto mb-12 space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-950/80 border border-emerald-700/50 text-emerald-300 text-xs font-semibold shadow-inner backdrop-blur-sm">
              <Globe2 className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span className="tracking-wider uppercase text-[11px] font-bold">Pan-India Agricultural Network</span>
            </div>
            
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-display tracking-tight text-white leading-tight">
              Built for <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-emerald-500 bg-clip-text text-transparent">Bharat</span>
            </h2>

            <p className="text-slate-300 text-base sm:text-lg max-w-2xl mx-auto leading-relaxed">
              From India's farming heartlands to urban markets, FasalSetu connects producers, buyers and intelligent logistics through one digital farm-to-market network.
            </p>

            <div className="inline-flex items-center gap-2 text-xs font-medium text-emerald-400/90 bg-emerald-950/40 px-3.5 py-1 rounded-full border border-emerald-800/40">
              <span>One platform</span>
              <span className="text-emerald-600">•</span>
              <span>Multiple regions</span>
              <span className="text-emerald-600">•</span>
              <span>Connected supply chains</span>
            </div>
          </div>

          {/* Interactive Zone Overview Selector (Section 12) */}
          <div className="max-w-4xl mx-auto mb-12 text-center space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/70 border border-emerald-800/60 text-emerald-400 text-[11px] font-mono font-bold uppercase tracking-wider">
              [ Select a Network Zone ]
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-white font-display">
              Explore India's Agricultural Network
            </h3>
            <p className="text-slate-300 text-xs sm:text-sm max-w-xl mx-auto">
              Choose a region to explore its farm-to-market network and available logistics intelligence.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
              {PAN_INDIA_REGIONS.map((r) => {
                const isSelected = selectedRegion?.id === r.id;
                return (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => {
                      setSelectedRegion(r);
                      document.getElementById('selected-region-panel')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                    }}
                    className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      isSelected
                        ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20 ring-2 ring-emerald-400'
                        : 'bg-slate-900/80 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
                    }`}
                  >
                    <span>{r.icon}</span>
                    <span>{r.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Regional Network Cards (6 Regions) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 max-w-6xl mx-auto mb-10">
            {PAN_INDIA_REGIONS.map((region) => {
              const isSelected = selectedRegion?.id === region.id;
              return (
                <button
                  key={region.id}
                  type="button"
                  onClick={() => {
                    setSelectedRegion(region);
                    document.getElementById('selected-region-panel')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                  }}
                  aria-label={`Explore ${region.name} agricultural network`}
                  className={`group relative rounded-2xl sm:rounded-3xl p-6 border transition-all duration-300 text-left flex flex-col justify-between cursor-pointer w-full focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400 ${
                    isSelected
                      ? 'bg-slate-800/90 border-emerald-500 shadow-xl shadow-emerald-950/40 ring-1 ring-emerald-500/70 -translate-y-1'
                      : 'bg-slate-900/60 border-slate-800/90 hover:bg-slate-800/60 hover:border-emerald-500/50 hover:shadow-lg hover:shadow-emerald-950/30 hover:-translate-y-1 shadow-xs'
                  }`}
                >
                  {/* Top Badges & Emoji */}
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl filter drop-shadow-sm select-none transition-transform group-hover:scale-110">
                          {region.icon}
                        </span>
                        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800/60">
                          {region.badge}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono">
                        {isSelected ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                            Active Zone
                          </span>
                        ) : (
                          <span className="text-[11px] text-slate-500 group-hover:text-emerald-400 transition-colors flex items-center gap-0.5">
                            Explore Network <ChevronRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                          </span>
                        )}
                      </div>
                    </div>

                    <h3 className="text-xl font-bold text-white font-display group-hover:text-emerald-300 transition-colors">
                      {region.name}
                    </h3>

                    <p className="text-xs text-emerald-400/90 font-medium mt-0.5">
                      {Array.isArray(region.states) ? region.states.join(' • ') : region.states}
                    </p>

                    <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                      {region.focus}
                    </p>
                  </div>

                  {/* Bottom Meta & Role */}
                  <div className="mt-5 pt-3.5 border-t border-slate-800 flex items-center justify-between text-[11px]">
                    <span className="text-slate-400 font-medium">
                      Role: <strong className="text-slate-200">{region.role}</strong>
                    </span>
                    <span className="font-mono text-emerald-400/90 text-[10px] uppercase tracking-wider font-semibold flex items-center gap-1 group-hover:underline">
                      <span>Network Corridor</span>
                      <ArrowRight className="w-3 h-3 transition-transform group-hover:translate-x-0.5" />
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Expanded Selected Region Panel with Logistics Corridor Visualization */}
          {selectedRegion && (
            <div 
              id="selected-region-panel"
              className="max-w-5xl mx-auto mb-16 rounded-3xl bg-gradient-to-br from-slate-900/95 via-slate-900/90 to-emerald-950/40 border border-emerald-600/50 shadow-2xl shadow-emerald-950/40 backdrop-blur-xl p-6 sm:p-8 lg:p-10 relative overflow-hidden animate-in fade-in duration-300"
            >
              
              {/* Subtle ambient corner light */}
              <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative">
                
                {/* Left Column: Region Metadata & Context (6 cols) */}
                <div className="lg:col-span-6 space-y-5 text-left">
                  
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-700/60">
                      ZONE: {selectedRegion.badge}
                    </span>
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                      {selectedRegion.role}
                    </span>
                    <span className={`text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border flex items-center gap-1 ${
                      selectedRegion.hasActiveRoutes 
                        ? 'bg-emerald-900/60 text-emerald-300 border-emerald-600/60' 
                        : 'bg-amber-950/60 text-amber-300 border-amber-800/60'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${selectedRegion.hasActiveRoutes ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                      <span>{selectedRegion.statusLabel || 'Network Scope'}</span>
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center gap-3">
                      <span className="text-3xl p-2 rounded-2xl bg-emerald-950/80 border border-emerald-700/50">
                        {selectedRegion.icon}
                      </span>
                      <div>
                        <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
                          {selectedRegion.name}
                        </h3>
                        <p className="text-xs font-mono text-emerald-400 font-bold mt-0.5">
                          {selectedRegion.corridor}
                        </p>
                      </div>
                    </div>

                    <p className="text-sm text-slate-300 mt-3 leading-relaxed">
                      {selectedRegion.description}
                    </p>
                  </div>

                  {/* Highlights Grid */}
                  <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2 text-xs">
                    <div className="flex items-start gap-2">
                      <span className="text-slate-400 font-semibold w-24 shrink-0">States Covered:</span>
                      <span className="text-slate-200 font-medium">
                        {Array.isArray(selectedRegion.states) ? selectedRegion.states.join(' • ') : selectedRegion.states}
                      </span>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="text-slate-400 font-semibold w-24 shrink-0">Agri Focus:</span>
                      <span className="text-slate-200 font-medium">{selectedRegion.focus}</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="text-slate-400 font-semibold w-24 shrink-0">Key Produce:</span>
                      <span className="text-emerald-400 font-medium">{selectedRegion.crops}</span>
                    </div>
                  </div>

                  {/* CTA into Existing Logistics Page with Region Context */}
                  <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                    <Link
                      to={`/logistics?region=${selectedRegion.id}`}
                      className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-xl shadow-emerald-950/60 transition-all hover:scale-[1.02] active:scale-[0.98] group"
                    >
                      <Truck className="w-4 h-4 text-slate-950" />
                      <Map className="w-4 h-4 text-emerald-950" />
                      <span>Explore Logistics Map</span>
                      <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                    </Link>
                    <Link
                      to="/marketplace"
                      className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-700 hover:border-slate-600 bg-slate-800/60 hover:bg-slate-800 text-xs font-bold text-slate-200 transition-colors"
                    >
                      <Map className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Browse Regional Produce</span>
                    </Link>
                  </div>

                  <p className="text-[11px] text-slate-400 italic">
                    * Interactive gateway to FasalSetu's MapLibre logistics engine and corridor dispatch telemetry.
                  </p>

                </div>

                {/* Right Column: Visual Logistics Network Corridor Preview (6 cols) */}
                <div className="lg:col-span-6 bg-slate-950/70 border border-slate-800/90 rounded-3xl p-6 relative overflow-hidden shadow-inner">
                  
                  <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
                    <div className="flex items-center gap-2">
                      <Map className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-300 font-mono">
                        Network Preview
                      </span>
                    </div>
                    <span className="text-[10px] font-mono text-emerald-400 font-semibold bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800/50">
                      Corridor Topology
                    </span>
                  </div>

                  {/* Connected Glowing Corridor Nodes */}
                  <div className="space-y-3 relative py-2">
                    
                    {/* Node 1: Farm Origin */}
                    <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-emerald-500/40 transition-colors">
                      <div className="w-8 h-8 rounded-lg bg-emerald-950 border border-emerald-600/40 flex items-center justify-center text-emerald-400 shrink-0">
                        <Sprout className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white truncate">01. Regional Farm Gate</span>
                          <span className="text-[9px] font-mono text-emerald-400 font-bold uppercase">Origin</span>
                        </div>
                        <p className="text-[10px] text-slate-400 truncate">Harvest batch registered with GPS coordinates</p>
                      </div>
                    </div>

                    <div className="flex justify-center -my-1">
                      <div className="w-0.5 h-3 bg-gradient-to-b from-emerald-500 to-teal-400" />
                    </div>

                    {/* Node 2: FPO Aggregation */}
                    <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-emerald-500/40 transition-colors">
                      <div className="w-8 h-8 rounded-lg bg-teal-950 border border-teal-600/40 flex items-center justify-center text-teal-400 shrink-0">
                        <Boxes className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white truncate">02. FPO Aggregation Node</span>
                          <span className="text-[9px] font-mono text-teal-400 font-bold uppercase">Consolidation</span>
                        </div>
                        <p className="text-[10px] text-slate-400 truncate">Sorting, weight verification & batch clustering</p>
                      </div>
                    </div>

                    <div className="flex justify-center -my-1">
                      <div className="w-0.5 h-3 bg-gradient-to-b from-teal-400 to-blue-500" />
                    </div>

                    {/* Node 3: AI Matching */}
                    <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-blue-500/40 transition-colors">
                      <div className="w-8 h-8 rounded-lg bg-blue-950 border border-blue-600/40 flex items-center justify-center text-blue-400 shrink-0">
                        <BrainCircuit className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white truncate">03. AI Matching Engine</span>
                          <span className="text-[9px] font-mono text-blue-400 font-bold uppercase">Intelligence</span>
                        </div>
                        <p className="text-[10px] text-slate-400 truncate">Predictive demand matching & fair farm-gate pricing</p>
                      </div>
                    </div>

                    <div className="flex justify-center -my-1">
                      <div className="w-0.5 h-3 bg-gradient-to-b from-blue-500 to-amber-500" />
                    </div>

                    {/* Node 4: Logistics Routing */}
                    <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 transition-colors">
                      <div className="w-8 h-8 rounded-lg bg-amber-950 border border-amber-600/40 flex items-center justify-center text-amber-400 shrink-0">
                        <Truck className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white truncate">04. Smart Fleet Dispatch</span>
                          <span className="text-[9px] font-mono text-amber-400 font-bold uppercase">Transit</span>
                        </div>
                        <p className="text-[10px] text-slate-400 truncate">Multi-stop collection optimization along regional corridors</p>
                      </div>
                    </div>

                    <div className="flex justify-center -my-1">
                      <div className="w-0.5 h-3 bg-gradient-to-b from-amber-500 to-purple-500" />
                    </div>

                    {/* Node 5: Buyer Market */}
                    <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-purple-500/40 transition-colors">
                      <div className="w-8 h-8 rounded-lg bg-purple-950 border border-purple-600/40 flex items-center justify-center text-purple-400 shrink-0">
                        <Building2 className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white truncate">05. Direct Buyer Market</span>
                          <span className="text-[9px] font-mono text-purple-400 font-bold uppercase">Destination</span>
                        </div>
                        <p className="text-[10px] text-slate-400 truncate">Retail societies, Kirana stores, HoReCa & bulk buyers</p>
                      </div>
                    </div>

                  </div>

                  {/* Bottom Strip */}
                  <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="font-medium">Model: Farm-to-Fork Direct</span>
                    <span className="font-mono text-emerald-400 font-bold">Zero APMC Brokerage</span>
                  </div>

                </div>

              </div>

            </div>
          )}

          {/* =========================================================================
              HOW THE NETWORK WORKS (MINI 5-STAGE CONNECTED FLOW - Section 11)
              ========================================================================= */}
          <div className="mb-14 max-w-5xl mx-auto">
            <div className="text-center mb-6">
              <span className="text-[11px] font-mono font-bold tracking-widest text-emerald-400 uppercase">
                How The Pan-India Network Operates
              </span>
              <h4 className="text-lg sm:text-xl font-bold text-white font-display mt-1">
                From Farm Gates to Urban Markets Across India
              </h4>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-3 relative">
              {[
                {
                  step: '01',
                  label: 'Producers',
                  title: 'FARMERS',
                  sub: 'Harvest lots & transparent farm-gate rates',
                  icon: Wheat
                },
                {
                  step: '02',
                  label: 'Clusters',
                  title: 'FPO / AGGREGATION',
                  sub: 'Village hubs, quality grading & consolidation',
                  icon: Boxes
                },
                {
                  step: '03',
                  label: 'Engine',
                  title: 'AI DEMAND MATCHING',
                  sub: 'Predictive seasonal volume & rate discovery',
                  icon: BrainCircuit
                },
                {
                  step: '04',
                  label: 'Transit',
                  title: 'SMART ROUTING',
                  sub: 'Multi-stop collection & fleet dispatch',
                  icon: Truck
                },
                {
                  step: '05',
                  label: 'Procurement',
                  title: 'BUYERS',
                  sub: 'Consumers, kirana, HoReCa & bulk portals',
                  icon: Building2
                }
              ].map((stage, idx) => {
                const IconComp = stage.icon;
                return (
                  <div key={stage.label} className="relative">
                    <div className="bg-slate-900/80 border border-slate-800/90 hover:border-emerald-500/60 rounded-2xl p-4 text-center transition-all duration-300 hover:shadow-lg hover:shadow-emerald-950/20 group h-full flex flex-col items-center justify-between">
                      <div className="space-y-2.5 flex flex-col items-center">
                        <div className="w-10 h-10 rounded-xl bg-emerald-950/70 border border-emerald-700/50 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                          <IconComp className="w-5 h-5" />
                        </div>
                        <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-400 font-bold">
                          {stage.step} • {stage.label}
                        </span>
                        <h4 className="text-xs sm:text-sm font-black text-white font-display tracking-tight">
                          {stage.title}
                        </h4>
                        <p className="text-[11px] text-slate-400 leading-snug">
                          {stage.sub}
                        </p>
                      </div>
                    </div>

                    {/* Desktop Connector */}
                    {idx < 4 && (
                      <div className="hidden md:flex absolute top-1/2 -right-3.5 -translate-y-1/2 z-10 w-7 h-7 rounded-full bg-slate-900 border border-emerald-500/50 text-emerald-400 items-center justify-center shadow-md">
                        <ChevronRight className="w-4 h-4 text-emerald-400" />
                      </div>
                    )}

                    {/* Mobile Connector */}
                    {idx < 4 && (
                      <div className="flex md:hidden justify-center my-1.5 text-emerald-400/80">
                        <ArrowDown className="w-4 h-4 animate-bounce" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* National Network Statistics Strip (4 Compact Metrics) */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 max-w-5xl mx-auto mb-10">
            {[
              {
                metric: 'Pan-India Scope',
                label: 'Network Architecture',
                sub: 'Designed for nationwide farm-to-market scale',
                icon: Globe2,
                accent: 'from-emerald-500/20 to-teal-500/5'
              },
              {
                metric: '4 Buyer Types',
                label: 'Direct Procurement',
                sub: 'Consumers, Kirana, HoReCa & Bulk Institutions',
                icon: Building2,
                accent: 'from-blue-500/20 to-indigo-500/5'
              },
              {
                metric: 'AI-Powered Matching',
                label: 'Demand Forecasting',
                sub: 'Predictive seasonal pricing & volume balancing',
                icon: BrainCircuit,
                accent: 'from-purple-500/20 to-pink-500/5'
              },
              {
                metric: 'Smart Logistics',
                label: 'Connected Corridors',
                sub: 'Optimized farm-gate truck collection routes',
                icon: Truck,
                accent: 'from-amber-500/20 to-orange-500/5'
              }
            ].map((stat) => (
              <div
                key={stat.metric}
                className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 sm:p-5 backdrop-blur-md hover:border-slate-700 transition-all text-left flex flex-col justify-between group shadow-xs hover:shadow-md"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className={`p-2 rounded-xl bg-gradient-to-br ${stat.accent} border border-slate-700/60`}>
                    <stat.icon className="w-4 h-4 text-emerald-400" />
                  </div>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-semibold">
                    {stat.label}
                  </span>
                </div>
                <div>
                  <div className="text-base sm:text-lg font-bold text-white font-display tracking-tight">
                    {stat.metric}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                    {stat.sub}
                  </p>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>


      {/* =========================================================================
          HOW IT WORKS (5 CARDS)
          01 Farmers List Produce
          02 Buyers Discover Local Produce
          03 Orders Are Placed Directly
          04 AI Predicts Demand
          05 Smart Logistics Delivers
          ========================================================================= */}
      <section className="py-16 sm:py-24 bg-slate-50 border-b border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
            <span className="text-xs font-bold uppercase tracking-widest text-emerald-600">
              Simple 5-Step Model
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-display">
              How FasalSetu Works
            </h2>
            <p className="text-slate-600 text-base">
              A transparent, technology-driven workflow engineered for rural farmers and urban consumers.
            </p>
          </div>

          {/* 5 Cards Row/Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-5">
            {HOW_IT_WORKS_STEPS.map((step, idx) => {
              const IconComp = stepIcons[idx] || Sprout;

              return (
                <div 
                  key={step.number}
                  className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/90 shadow-xs hover:shadow-lg hover:border-emerald-300 transition-all duration-300 flex flex-col justify-between group hover:-translate-y-1"
                >
                  <div className="space-y-4">
                    {/* Number + Icon */}
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-black font-mono text-emerald-700 group-hover:text-emerald-600 transition-colors">
                        {step.number}
                      </span>
                      <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200/80 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                        <IconComp className="w-5 h-5 text-emerald-700 group-hover:text-white transition-colors" />
                      </div>
                    </div>

                    {/* Title */}
                    <h3 className="text-base font-bold text-slate-900 font-display leading-snug">
                      {step.title}
                    </h3>

                    {/* Description */}
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {step.description}
                    </p>
                  </div>

                  {/* Footer Tag */}
                  <div className="pt-4 mt-4 border-t border-slate-100">
                    <span className="text-[10px] font-semibold text-slate-500 group-hover:text-emerald-700 transition-colors flex items-center gap-1">
                      <span>{step.tag}</span>
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="text-center mt-10">
            <Button 
              to="/how-it-works" 
              variant="outline" 
              size="md"
              rightIcon={ArrowRight}
            >
              Detailed Architecture & Comparison
            </Button>
          </div>

        </div>
      </section>


      {/* =========================================================================
          VALUE PROPOSITION
          FOR FARMERS: "Better Price Realization"
          FOR BUYERS: "Fair & Transparent Prices"
          FOR LOGISTICS: "Smarter Delivery"
          ========================================================================= */}
      <section className="py-16 sm:py-24 bg-white border-b border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
            <span className="text-xs font-bold uppercase tracking-widest text-emerald-600">
              Value Proposition
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-display">
              Why Choose FasalSetu?
            </h2>
            <p className="text-slate-600 text-base">
              A win-win-win model addressing farmers, urban consumers, and hyperlocal logistics fleets.
            </p>
          </div>

          {/* 3 Value Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {VALUE_PROPOSITIONS.map((prop) => (
              <div 
                key={prop.id}
                className="rounded-3xl border border-slate-200/90 p-8 bg-slate-50/70 hover:bg-white hover:shadow-xl hover:border-emerald-300 transition-all duration-300 flex flex-col justify-between space-y-6"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black uppercase tracking-wider text-emerald-700 bg-emerald-100/70 px-3 py-1 rounded-full border border-emerald-200">
                      {prop.target}
                    </span>
                    <span className="text-xl font-extrabold text-slate-900 font-display">
                      {prop.stat}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-2xl font-bold text-slate-900 font-display">
                      {prop.title}
                    </h3>
                    <p className="text-sm font-semibold text-emerald-700 mt-1">
                      {prop.subtitle}
                    </p>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {prop.description}
                  </p>

                  <div className="pt-2 border-t border-slate-200/80 space-y-2.5">
                    {prop.points.map((pt, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-slate-700">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                        <span>{pt}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-4">
                  <Button
                    to="/marketplace"
                    variant="outline"
                    size="sm"
                    className="w-full justify-center"
                    rightIcon={ChevronRight}
                  >
                    Learn More
                  </Button>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>


      {/* =========================================================================
          CALL TO ACTION (CTA)
          "Ready to build a better farm-to-market connection?"
          Buttons: [Explore Marketplace], [Join FasalSetu]
          ========================================================================= */}
      <section className="py-20 sm:py-28 bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-950 text-white relative overflow-hidden border-t border-emerald-900/40">
        
        {/* Background ambient lighting */}
        <div className="absolute inset-0 bg-dot-pattern opacity-10 pointer-events-none" />
        <div className="absolute -bottom-24 right-1/4 w-[500px] h-[500px] bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -top-24 left-1/4 w-[400px] h-[400px] bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative space-y-6">
          
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-900/60 border border-emerald-700/60 text-emerald-300 text-xs font-semibold shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Digital Agricultural Corridor • Farm-to-Fork Network</span>
          </div>

          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold font-display tracking-tight text-white leading-tight">
            Ready to empower India's direct farm economy?
          </h2>

          <p className="text-slate-300 text-base sm:text-lg max-w-2xl mx-auto leading-relaxed font-normal">
            Whether you are a farmer seeking fair farm-gate pricing, an FPO scaling collective supply, or a buyer demanding transparent origin freshness — FasalSetu bridges the gap.
          </p>

          <p className="text-emerald-300/90 font-serif italic text-base">
            "फसल से बाज़ार तक, सीधे और स्मार्ट तरीके से।"
          </p>

          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button
              to="/marketplace"
              variant="primary"
              size="lg"
              className="shadow-xl shadow-emerald-950/50"
              rightIcon={ArrowRight}
            >
              Explore Marketplace
            </Button>

            <Button
              to="/login"
              variant="outline"
              size="lg"
              className="bg-white/5 hover:bg-white/10 text-white border-white/20 backdrop-blur-md"
              leftIcon={Sprout}
            >
              Join FasalSetu
            </Button>
          </div>

          <div className="pt-6 flex flex-wrap items-center justify-center gap-3 sm:gap-6 text-xs text-emerald-300/80 font-medium">
            <span className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Direct Farm-Gate Access</span>
            <span className="text-slate-600 hidden sm:inline">•</span>
            <span className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> AI-Driven Demand & Fair Pricing</span>
            <span className="text-slate-600 hidden sm:inline">•</span>
            <span className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Consolidated Cold-Chain Logistics</span>
          </div>

        </div>
      </section>

    </div>
  );
}
