import React, { useState } from 'react';
import { 
  Sprout, 
  Store, 
  CreditCard, 
  BrainCircuit, 
  Truck, 
  ArrowRight, 
  CheckCircle2, 
  Globe2, 
  TrendingUp, 
  Clock,
  Sparkles,
  Building2,
  Users
} from 'lucide-react';
import Button from '../components/Button';
import { HOW_IT_WORKS_STEPS, VALUE_PROPOSITIONS } from '../data/demoData';

export default function HowItWorks() {
  const [activeRoleTab, setActiveRoleTab] = useState('farmer');
  const stepIcons = [Sprout, BrainCircuit, Store, Truck, CreditCard];

  const ROLE_FLOWS = {
    farmer: {
      role: 'Farmers & FPOs',
      title: 'Direct Market Power & Guaranteed Transparent Realization',
      badge: 'PRODUCER ACCESS',
      icon: Sprout,
      steps: [
        { num: '01', title: 'List Produce at Farm-Gate', desc: 'Specify crop type, variety, harvest timing, quantity, and minimum acceptable rate without middleman pressure.' },
        { num: '02', title: 'AI Price & Demand Guidance', desc: 'Platform algorithms suggest optimal harvest windows and dynamic fair rates based on real-time mandi & urban demand.' },
        { num: '03', title: 'Order Aggregation & Route Matching', desc: 'Orders from local Kiranas, bulk institutions, or retail consumers get combined into scheduled farm-gate collections.' },
        { num: '04', title: 'Direct Farm-Gate Handover & Payout', desc: 'Cold-chain or direct transit pickups happen at the field gate with prompt digital settlements directly into the bank account.' },
      ]
    },
    buyer: {
      role: 'Consumers & Housing Societies',
      title: 'Fresh From Farm to Kitchen in Hours',
      badge: 'RETAIL BUYERS',
      icon: Users,
      steps: [
        { num: '01', title: 'Browse Verified Farm Batches', desc: 'Explore seasonal, organic, and Grade-A harvest lots tagged with exact farmer identity, harvest date, and region.' },
        { num: '02', title: 'Single or Group Order', desc: 'Order individually or participate in society cluster purchases to unlock wholesale rate benefits.' },
        { num: '03', title: 'Consolidated Route Dispatch', desc: 'Hyperlocal milk-run logistics pick up from harvest points and deliver straight to society drop gates.' },
        { num: '04', title: 'Guaranteed Freshness & Origin', desc: 'Enjoy produce harvested hours ago rather than days in multi-tier warehouses, at 15-20% lower cost than modern retail.' },
      ]
    },
    bulk: {
      role: 'Kiranas, HoReCa & Bulk Institutions',
      title: 'Direct B2B Procurement at Scale with Predictable Supply',
      badge: 'INSTITUTIONAL BUYERS',
      icon: Building2,
      steps: [
        { num: '01', title: 'Submit Volume Requests or Pre-Book Harvests', desc: 'Place bulk purchase orders or secure seasonal contracts directly with verified FPO farm collectives.' },
        { num: '02', title: 'AI Demand & Grade Matching', desc: 'The system matches specifications (Grade A/B, sorting standards, moisture levels) with certified regional farmer clusters.' },
        { num: '03', title: 'Fleet Route Optimization', desc: 'Consolidated freight trucks navigate scheduled collection runs, minimizing handling losses and transit time.' },
        { num: '04', title: 'Formal GST Invoicing & Quality Assurance', desc: 'Transparent batch provenance, digital bills, and reliable recurring supply cycles.' },
      ]
    }
  };

  return (
    <div className="bg-slate-50 min-h-screen text-slate-900">
      
      {/* Header / Hero */}
      <section className="relative py-16 sm:py-24 border-b border-slate-200/80 bg-white overflow-hidden">
        <div className="absolute inset-0 bg-dot-pattern opacity-60 pointer-events-none" />
        <div className="absolute -top-24 right-10 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 left-10 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          
          <div className="max-w-3xl mx-auto text-center space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>India's Farm-to-Market Network Architecture</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight font-display">
              How <span className="text-emerald-700">FasalSetu</span> Operates
            </h1>

            <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
              Eliminating multi-tiered intermediaries by connecting verified farmers directly with consumers, local kiranas, and bulk buyers through AI-assisted demand forecasting and consolidated route logistics.
            </p>

            <p className="text-emerald-700 font-serif italic text-base">
              "फसल से बाज़ार तक, सीधे और स्मार्ट तरीके से।"
            </p>

            {/* Quick stats ribbon */}
            <div className="pt-4 flex flex-wrap justify-center items-center gap-4 sm:gap-8 text-xs font-semibold text-slate-600">
              <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200">
                <Globe2 className="w-4 h-4 text-emerald-600" />
                <span>Pan-India Network Vision</span>
              </div>
              <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200">
                <Clock className="w-4 h-4 text-emerald-600" />
                <span>Rapid Farm-Gate Turnaround</span>
              </div>
              <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200">
                <TrendingUp className="w-4 h-4 text-emerald-600" />
                <span>Fair Farm-Gate Price Realization</span>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* The 5-Step Process Section */}
      <section className="py-16 sm:py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-2xl mx-auto mb-14 space-y-2">
          <h2 className="text-xs font-bold uppercase tracking-widest text-emerald-600">
            End-to-End Workflow
          </h2>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
            Five Steps to Direct Agricultural Commerce
          </p>
          <p className="text-slate-600 text-sm">
            From the farmer's harvest lot to the buyer's kitchen or warehouse.
          </p>
        </div>

        {/* Step Cards Stack with visual connector */}
        <div className="space-y-6 lg:space-y-8">
          {HOW_IT_WORKS_STEPS.map((step, index) => {
            const IconComponent = stepIcons[index] || Sprout;

            return (
              <div 
                key={step.number}
                className="bg-white rounded-2xl sm:rounded-3xl border border-slate-200/90 shadow-xs hover:shadow-xl transition-all duration-300 p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 group hover:border-emerald-300 hover-lift relative overflow-hidden"
              >
                {/* Visual Left Accent Line */}
                <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-gradient-to-b from-emerald-500 to-teal-400 opacity-0 group-hover:opacity-100 transition-opacity" />

                {/* Left: Step Number & Icon */}
                <div className="flex items-center gap-5 flex-shrink-0">
                  <div className="w-16 h-16 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center flex-shrink-0 group-hover:bg-emerald-700 group-hover:text-white transition-all duration-300 shadow-xs">
                    <IconComponent className="w-8 h-8 text-emerald-700 group-hover:text-white transition-colors" />
                  </div>
                  <div>
                    <span className="text-3xl sm:text-4xl font-black text-slate-300 font-mono group-hover:text-emerald-600 transition-colors">
                      {step.number}
                    </span>
                    <p className="text-[11px] uppercase font-bold tracking-wider text-emerald-700">
                      {step.role}
                    </p>
                  </div>
                </div>

                {/* Middle: Content */}
                <div className="flex-1 max-w-2xl space-y-1.5">
                  <div className="flex items-center gap-3">
                    <h3 className="text-xl font-bold text-slate-900 font-display group-hover:text-emerald-700 transition-colors">
                      {step.title}
                    </h3>
                    <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                      {step.tag}
                    </span>
                  </div>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    {step.description}
                  </p>
                </div>

                {/* Right: Stage Badge */}
                <div className="w-full md:w-auto flex items-center justify-end border-t md:border-t-0 pt-3 md:pt-0 border-slate-100">
                  <span className="text-xs font-bold text-slate-600 bg-slate-50 px-3.5 py-1.5 rounded-xl border border-slate-200 group-hover:border-emerald-200 group-hover:bg-emerald-50/70 group-hover:text-emerald-800 transition-colors">
                    Stage {index + 1} of 5
                  </span>
                </div>
              </div>
            );
          })}
        </div>

      </section>

      {/* Role-Based Interactive Flow Tabs */}
      <section className="py-16 bg-white border-y border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-10 space-y-2">
            <span className="text-xs font-bold uppercase tracking-widest text-emerald-600">
              Interactive Perspective
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
              See How FasalSetu Works for You
            </h2>
            <p className="text-slate-600 text-sm">
              Select your role to explore the tailored journey and direct benefits.
            </p>
          </div>

          {/* Role Tabs */}
          <div className="flex justify-center mb-10">
            <div className="inline-flex p-1.5 rounded-2xl bg-slate-100 border border-slate-200 gap-1 sm:gap-2">
              {[
                { id: 'farmer', label: 'For Farmers & FPOs', icon: Sprout },
                { id: 'buyer', label: 'For Consumers & Societies', icon: Users },
                { id: 'bulk', label: 'For Bulk Buyers & HoReCa', icon: Building2 },
              ].map(tab => {
                const TabIcon = tab.icon;
                const isActive = activeRoleTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveRoleTab(tab.id)}
                    className={`flex items-center gap-2 px-3.5 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                      isActive 
                        ? 'bg-white text-emerald-700 shadow-sm border border-slate-200/80' 
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                    }`}
                  >
                    <TabIcon className={`w-4 h-4 ${isActive ? 'text-emerald-600' : 'text-slate-500'}`} />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Tab Content Display */}
          {(() => {
            const currentRole = ROLE_FLOWS[activeRoleTab];
            const RoleIcon = currentRole.icon;
            return (
              <div className="bg-slate-50 rounded-3xl p-6 sm:p-10 border border-slate-200/90 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                      <RoleIcon className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="text-[10px] font-extrabold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-mono">
                        {currentRole.badge}
                      </span>
                      <h3 className="text-xl sm:text-2xl font-bold text-slate-900 font-display mt-0.5">
                        {currentRole.title}
                      </h3>
                    </div>
                  </div>
                  <Button to="/login" variant="primary" size="sm" rightIcon={ArrowRight}>
                    Get Started as {currentRole.role.split(' ')[0]}
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 pt-8">
                  {currentRole.steps.map((st) => (
                    <div key={st.num} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs hover:border-emerald-300 transition-colors space-y-2">
                      <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 font-mono font-bold flex items-center justify-center text-xs">
                        {st.num}
                      </div>
                      <h4 className="text-sm font-bold text-slate-900 font-display">
                        {st.title}
                      </h4>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        {st.desc}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}

        </div>
      </section>

      {/* Comparison: Mandi System vs FasalSetu */}
      <section className="py-16 sm:py-20 bg-slate-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-dot-pattern opacity-10 pointer-events-none" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          
          <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
            <span className="text-emerald-400 text-xs font-bold uppercase tracking-wider">
              System Comparison
            </span>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold font-display">
              Traditional Mandi Model vs. FasalSetu Direct Bridge
            </h2>
            <p className="text-slate-400 text-sm sm:text-base">
              Contrast traditional multi-agent wholesale supply chains with our direct, technology-driven model.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            
            {/* Traditional Model */}
            <div className="rounded-3xl bg-slate-800/80 border border-slate-700/80 p-6 sm:p-8 space-y-5 shadow-lg">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-slate-300 font-display">
                  Traditional APMC Mandi Chain
                </h3>
                <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-red-950 text-red-400 border border-red-800/60 font-mono">
                  Fragmented
                </span>
              </div>

              <div className="space-y-3.5 text-xs sm:text-sm text-slate-400">
                <div className="flex items-start gap-2.5">
                  <span className="text-red-400 font-bold text-base">✕</span>
                  <span>4-6 layers of intermediaries (Village Aggregator → Broker → Commission Agent → Wholesaler → Retailer)</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="text-red-400 font-bold text-base">✕</span>
                  <span>Farmer receives only 30% to 45% of final consumer price</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="text-red-400 font-bold text-base">✕</span>
                  <span>Produce sits in transit/storage for 24-48 hours with high spoilage (up to 25%)</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="text-red-400 font-bold text-base">✕</span>
                  <span>Unpredictable distress sales, delayed cash cycles, and zero crop origin transparency</span>
                </div>
              </div>
            </div>

            {/* FasalSetu Model */}
            <div className="rounded-3xl bg-gradient-to-br from-emerald-950/90 to-slate-900 border border-emerald-500/50 p-6 sm:p-8 space-y-5 relative overflow-hidden shadow-xl ring-1 ring-emerald-500/30">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-emerald-300 font-display">
                  FasalSetu Direct Architecture
                </h3>
                <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-emerald-900 text-emerald-300 border border-emerald-600/70 font-mono">
                  Direct & Fair
                </span>
              </div>

              <div className="space-y-3.5 text-xs sm:text-sm text-slate-200">
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <span>Direct link: Farmer / FPO ➔ Consolidated Transit Corridor ➔ Buyer</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <span>Farmer retains 75% to 85% of retail realization with direct digital payouts</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <span>Rapid farm-to-table delivery cycles reducing post-harvest wastage below 5%</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <span>AI demand prediction balances seasonal surpluses and stabilizes fair consumer rates</span>
                </div>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* Stakeholder Value Cards */}
      <section className="py-16 sm:py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-2">
          <h2 className="text-xs font-bold uppercase tracking-widest text-emerald-600">
            Stakeholder Value
          </h2>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
            Empowerment for the Entire Agricultural Ecosystem
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {VALUE_PROPOSITIONS.map((prop) => (
            <div 
              key={prop.id} 
              className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 shadow-xs hover:shadow-xl hover:border-emerald-300 transition-all duration-300 flex flex-col justify-between hover-lift"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 font-mono">
                    {prop.target}
                  </span>
                  <div className="text-right">
                    <span className="text-xl font-extrabold text-slate-900 font-display">
                      {prop.stat}
                    </span>
                    <p className="text-[10px] text-slate-500 font-medium">
                      {prop.statLabel}
                    </p>
                  </div>
                </div>

                <h3 className="text-lg font-bold text-slate-900 font-display">
                  {prop.title}
                </h3>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {prop.subtitle}
                </p>

                <ul className="space-y-2 pt-2 border-t border-slate-100">
                  {prop.points.map((pt, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs text-slate-700">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 flex-shrink-0"></span>
                      <span>{pt}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-6 mt-4 border-t border-slate-100">
                <Button 
                  to="/marketplace" 
                  variant="outline" 
                  size="sm" 
                  className="w-full justify-center"
                  rightIcon={ArrowRight}
                >
                  Explore Marketplace
                </Button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA at Bottom of How It Works */}
      <section className="pb-20 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="bg-gradient-to-br from-emerald-900 to-slate-900 text-white rounded-3xl p-8 sm:p-14 shadow-xl relative overflow-hidden border border-emerald-800/40">
          <div className="relative space-y-5 max-w-xl mx-auto">
            <span className="text-[11px] font-extrabold uppercase tracking-wider px-3 py-1 rounded-full bg-emerald-800/70 text-emerald-300 border border-emerald-600/60 font-mono">
              GET INVOLVED
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold font-display">
              Ready to experience direct agricultural trade?
            </h2>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Explore the live-ready marketplace or register your farm collective, store, or kitchen to participate.
            </p>
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
              <Button to="/marketplace" variant="primary" size="md" rightIcon={ArrowRight}>
                Explore Marketplace
              </Button>
              <Button to="/login" variant="outline" size="md" className="bg-white/5 hover:bg-white/10 text-white border-white/20 backdrop-blur-md">
                Join FasalSetu
              </Button>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
