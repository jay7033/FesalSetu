import React, { useState } from 'react';
import { useOutletContext, Link } from 'react-router-dom';
import { 
  Users, 
  MapPin, 
  Package, 
  Clock, 
  TrendingUp, 
  Scale, 
  PlusCircle, 
  Warehouse, 
  FileText,
  Sparkles,
  Truck
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid
} from 'recharts';
import DashboardHeader from '../../components/dashboard/DashboardHeader';
import DashboardStatCard from '../../components/dashboard/DashboardStatCard';
import StatusBadge from '../../components/dashboard/StatusBadge';
import RecentOrdersTable from '../../components/dashboard/RecentOrdersTable';
import QuickActions from '../../components/dashboard/QuickActions';
import Button from '../../components/Button';
import RouteSummary from '../../components/logistics/RouteSummary';
import PickupSchedule from '../../components/logistics/PickupSchedule';
import { useFPO } from '../../context/FPOContext';
import { useOrders } from '../../context/OrderContext';
import { useAuth } from '../../context/AuthContext';
import { useAI } from '../../context/AIContext';
import { useLogistics } from '../../context/LogisticsContext';

const FPO_WEEKLY_SALES = [
  { day: 'Mon', sales: 74000, volume: '2.8 T' },
  { day: 'Tue', sales: 92000, volume: '3.4 T' },
  { day: 'Wed', sales: 118000, volume: '4.2 T' },
  { day: 'Thu', sales: 86000, volume: '3.1 T' },
  { day: 'Fri', sales: 145000, volume: '5.2 T' },
  { day: 'Sat', sales: 198000, volume: '6.8 T' },
  { day: 'Sun', sales: 127000, volume: '4.5 T' }
];

export default function FPODashboard() {
  const { user } = useAuth();
  const context = useOutletContext();
  const activeTab = context?.activeTab || 'overview';
  const setActiveTab = context?.setActiveTab || (() => {});

  const {
    fpoName,
    registrationNumber,
    totalMembersCount,
    totalFarmLocationsCount,
    activeProduceCount,
    totalSalesFormatted,
    totalProduceFormatted,
    memberFarmers,
    farmLocations,
    aggregatedInventory,
    addMemberFarmer,
    addFarmLocation
  } = useFPO();

  const { orders, updateOrderStatus } = useOrders();
  const { getFPOInsights } = useAI();
  const { routes, pickups, updatePickupStatus } = useLogistics();

  const fpoAiInsights = getFPOInsights(memberFarmers, aggregatedInventory);

  // Modals state
  const [showAddFarmerModal, setShowAddFarmerModal] = useState(false);
  const [showAddLocationModal, setShowAddLocationModal] = useState(false);

  const [newFarmerData, setNewFarmerData] = useState({
    name: '',
    village: 'Jewar',
    district: 'Gautam Buddha Nagar',
    state: 'Uttar Pradesh',
    landSize: '5.0 Acres',
    phone: '',
    crops: 'Wheat, Mustard'
  });

  const [newLocationData, setNewLocationData] = useState({
    name: '',
    district: 'Gautam Buddha Nagar',
    state: 'Uttar Pradesh',
    farmers: 15,
    produce: 'Vegetables & Grains'
  });

  const handleCreateFarmer = (e) => {
    e.preventDefault();
    if (!newFarmerData.name) return;
    addMemberFarmer({
      name: newFarmerData.name,
      village: newFarmerData.village,
      district: newFarmerData.district,
      state: newFarmerData.state,
      landSize: newFarmerData.landSize,
      phone: newFarmerData.phone || '+91 98000 00000',
      products: newFarmerData.crops.split(',').map((c) => c.trim())
    });
    setNewFarmerData({
      name: '',
      village: 'Jewar',
      district: 'Gautam Buddha Nagar',
      state: 'Uttar Pradesh',
      landSize: '5.0 Acres',
      phone: '',
      crops: 'Wheat, Mustard'
    });
    setShowAddFarmerModal(false);
  };

  const handleCreateLocation = (e) => {
    e.preventDefault();
    if (!newLocationData.name) return;
    addFarmLocation({
      name: newLocationData.name,
      district: newLocationData.district,
      state: newLocationData.state,
      farmers: Number(newLocationData.farmers) || 10,
      produce: newLocationData.produce
    });
    setNewLocationData({
      name: '',
      district: 'Gautam Buddha Nagar',
      state: 'Uttar Pradesh',
      farmers: 15,
      produce: 'Vegetables & Grains'
    });
    setShowAddLocationModal(false);
  };

  const quickActionsList = [
    {
      label: '+ Add Farmer',
      icon: PlusCircle,
      onClick: () => setShowAddFarmerModal(true),
      description: 'Onboard a new member farmer to cluster',
      iconBg: 'bg-emerald-100 text-emerald-800'
    },
    {
      label: '+ Add Farm Location',
      icon: MapPin,
      onClick: () => setShowAddLocationModal(true),
      description: 'Register a cooperative aggregation parcel',
      iconBg: 'bg-blue-100 text-blue-800'
    },
    {
      label: '+ Add Produce',
      icon: Package,
      to: '/marketplace',
      description: 'Browse current marketplace listings',
      iconBg: 'bg-amber-100 text-amber-800'
    },
    {
      label: 'View Orders',
      icon: FileText,
      onClick: () => setActiveTab('orders'),
      description: 'Track incoming buyer procurement dispatches',
      iconBg: 'bg-purple-100 text-purple-800'
    },
    {
      label: 'View Inventory',
      icon: Warehouse,
      onClick: () => setActiveTab('inventory'),
      description: 'Review multi-farm aggregated crop stocks',
      iconBg: 'bg-teal-100 text-teal-800'
    },
    {
      label: 'Dispatch & Fleet',
      icon: Truck,
      onClick: () => setActiveTab('logistics'),
      description: 'Review route plans and scheduled truck collections',
      iconBg: 'bg-emerald-100 text-emerald-800'
    }
  ];

  const displayName = user?.entityName || user?.name || fpoName;

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      
      {/* Top Header & Greeting adhering to Section 6 */}
      <DashboardHeader
        greeting={`Welcome, ${displayName}`}
        roleBadge="🏢 FPO Management"
        locationType="Default FPO Location"
        locationText="Dankaur Central Aggregation Center, Gautam Buddha Nagar"
        isLocationVerified={true}
      >
        <Button
          onClick={() => setShowAddFarmerModal(true)}
          variant="outline"
          size="sm"
          leftIcon={PlusCircle}
        >
          + Add Member
        </Button>
        <Button
          onClick={() => setShowAddLocationModal(true)}
          variant="primary"
          size="sm"
          leftIcon={MapPin}
        >
          + Add Farm Location
        </Button>
      </DashboardHeader>

      {/* 6 Core KPI Metrics Cards adhering to Section 6 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4">
        <DashboardStatCard
          title="Member Farmers"
          value={totalMembersCount}
          subtext="Verified producers"
          change="+8 this mo"
          icon={Users}
          accent="emerald"
        />
        <DashboardStatCard
          title="Farm Locations"
          value={totalFarmLocationsCount}
          subtext="Cluster collection yards"
          change="Pan-India"
          icon={MapPin}
          accent="blue"
        />
        <DashboardStatCard
          title="Active Produce"
          value={activeProduceCount}
          subtext="Crop varieties"
          change="In Season"
          icon={Package}
          accent="teal"
        />
        <DashboardStatCard
          title="Pending Orders"
          value={orders.filter((o) => o.status === 'Confirmed' || o.status === 'Preparing').length}
          subtext="Awaiting dispatch"
          change="Priority"
          icon={Clock}
          accent="amber"
        />
        <DashboardStatCard
          title="Total Sales"
          value={totalSalesFormatted}
          subtext="Cumulative cluster GMV"
          change="+28% YoY"
          icon={TrendingUp}
          accent="emerald"
        />
        <DashboardStatCard
          title="Total Produce"
          value={totalProduceFormatted}
          subtext="Aggregated volume"
          change="99.4% Grade-A"
          icon={Scale}
          accent="purple"
        />
      </div>

      {/* View Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-1">
        {[
          { id: 'overview', label: 'Cluster Overview' },
          { id: 'ai-opportunities', label: '🌾 AI Aggregation' },
          { id: 'farmers', label: `Member Farmers (${memberFarmers.length})` },
          { id: 'inventory', label: 'Aggregated Inventory' },
          { id: 'locations', label: `Farm Locations (${farmLocations.length})` },
          { id: 'orders', label: 'Orders & Dispatches' },
          { id: 'sales', label: 'Sales Analytics' }
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === tab.id
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* AI Aggregation Opportunities Section */}
      {(activeTab === 'overview' || activeTab === 'ai-opportunities') && (
        <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 rounded-3xl p-6 sm:p-7 text-white shadow-sm border border-emerald-800/40 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 mb-1">
                <Sparkles className="w-4 h-4" />
                <span>AI AGGREGATION INTELLIGENCE</span>
              </div>
              <h3 className="text-lg font-bold font-display text-white">
                Member Crop Aggregation Opportunities
              </h3>
              <p className="text-xs text-slate-400">
                Comparing regional market demand against aggregated member inventory
              </p>
            </div>

            <span className="text-[11px] font-semibold text-emerald-300 bg-emerald-900/60 border border-emerald-700/60 px-3 py-1 rounded-full self-start sm:self-auto">
              AI-Assisted Forecast
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {fpoAiInsights.map((insight, idx) => (
              <div
                key={idx}
                className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-3 hover:bg-white/10 transition-colors"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="text-base font-bold text-white">{insight.cropName}</h4>
                    <span className="text-[10px] text-slate-400">{insight.primaryDistrict}</span>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                      insight.isDeficit
                        ? 'bg-rose-950 text-rose-300 border-rose-800'
                        : 'bg-emerald-950 text-emerald-300 border-emerald-800'
                    }`}
                  >
                    {insight.priority}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs py-2 border-y border-white/5">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Member Supply</span>
                    <span className="font-mono font-bold text-slate-200">
                      {insight.memberSupplyFormatted}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Forecast Demand</span>
                    <span className="font-mono font-bold text-emerald-400">
                      ~{insight.forecastDemandFormatted}
                    </span>
                  </div>
                </div>

                <p className="text-[11px] text-slate-300 leading-relaxed">
                  {insight.action}
                </p>

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-2 border-t border-white/5">
                  <span>Confidence: {insight.confidenceScore}%</span>
                  <span className="italic">Prototype signal</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 1: Member Farmers Management */}
      {(activeTab === 'overview' || activeTab === 'farmers') && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Member Farmers Roster
              </h3>
              <p className="text-xs text-slate-500">
                Cooperative farmers enrolled under {registrationNumber}
              </p>
            </div>
            <Button
              onClick={() => setShowAddFarmerModal(true)}
              variant="primary"
              size="sm"
              leftIcon={PlusCircle}
            >
              Add Member Farmer
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-100">
                  <th className="pb-2.5 font-bold">Farmer</th>
                  <th className="pb-2.5 font-bold">Location</th>
                  <th className="pb-2.5 font-bold">Land / Acreage</th>
                  <th className="pb-2.5 font-bold">Key Produce</th>
                  <th className="pb-2.5 font-bold">Supplied</th>
                  <th className="pb-2.5 font-bold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {memberFarmers.map((farmer) => (
                  <tr key={farmer.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3">
                      <p className="font-bold text-slate-900">{farmer.name}</p>
                      <p className="text-[10px] text-slate-400">{farmer.id} • {farmer.phone}</p>
                    </td>
                    <td className="py-3 text-slate-600">
                      <p className="font-medium">{farmer.village}</p>
                      <p className="text-[10px] text-slate-400">{farmer.district}, {farmer.state}</p>
                    </td>
                    <td className="py-3 font-semibold text-slate-800">
                      {farmer.landSize}
                    </td>
                    <td className="py-3">
                      <div className="flex flex-wrap gap-1">
                        {farmer.products.map((p, i) => (
                          <span key={i} className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[10px]">
                            {p}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="py-3 font-mono font-bold text-emerald-800">
                      {farmer.totalSupplied}
                    </td>
                    <td className="py-3">
                      <StatusBadge status={farmer.status} size="sm" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Aggregated Inventory */}
      {(activeTab === 'overview' || activeTab === 'inventory') && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                Aggregated Cluster Inventory
              </h3>
              <p className="text-xs text-slate-500">
                Consolidated batch inventory across all 124 member farmers
              </p>
            </div>
            <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
              Live Stock Consolidation
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-100">
                  <th className="pb-2.5 font-bold">Crop / Variety</th>
                  <th className="pb-2.5 font-bold">Total Quantity</th>
                  <th className="pb-2.5 font-bold">Available Stock</th>
                  <th className="pb-2.5 font-bold">Reserved / In Transit</th>
                  <th className="pb-2.5 font-bold">Avg. Price</th>
                  <th className="pb-2.5 font-bold">Member Producers</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {aggregatedInventory.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 font-bold text-slate-900">
                      {item.crop}
                    </td>
                    <td className="py-3 font-mono font-bold text-slate-900">
                      {item.totalQuantity.toLocaleString()} {item.unit}
                    </td>
                    <td className="py-3 font-mono font-bold text-emerald-700">
                      {item.available.toLocaleString()} {item.unit}
                    </td>
                    <td className="py-3 font-mono font-semibold text-amber-700">
                      {item.reserved.toLocaleString()} {item.unit}
                    </td>
                    <td className="py-3 font-mono font-bold text-slate-900">
                      ₹{item.avgPrice}/{item.unit}
                    </td>
                    <td className="py-3 text-slate-600 font-medium">
                      {item.farmersCount} farmers contributing
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Multiple Farm Locations Overview */}
      {(activeTab === 'overview' || activeTab === 'locations') && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                FPO Cluster Farm Locations
              </h3>
              <p className="text-xs text-slate-500">
                Cooperative aggregation centers with protected GPS coordinates
              </p>
            </div>
            <Button
              onClick={() => setShowAddLocationModal(true)}
              variant="outline"
              size="sm"
              leftIcon={MapPin}
            >
              + Register Cluster Hub
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {farmLocations.map((loc) => (
              <div
                key={loc.id}
                className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-emerald-300 transition-colors space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">{loc.name}</h4>
                    <p className="text-xs text-slate-500">{loc.district}, {loc.state}</p>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                    {loc.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-slate-200/60">
                  <div>
                    <span className="text-slate-400 text-[10px] uppercase block font-bold">Producers</span>
                    <span className="font-bold text-slate-800">{loc.farmers} Farmers Attached</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] uppercase block font-bold">Produce Flow</span>
                    <span className="font-bold text-slate-800 truncate block">{loc.produce}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Sales Analytics Section */}
      {(activeTab === 'overview' || activeTab === 'sales') && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-8 bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-slate-900 font-display">
                  Weekly Cluster Sales (Last 7 Days)
                </h3>
                <p className="text-xs text-slate-500">
                  Aggregated volume and gross realization from urban buyer societies
                </p>
              </div>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                Cluster GMV
              </span>
            </div>

            <div className="w-full h-64 sm:h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={FPO_WEEKLY_SALES}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12, fontWeight: 600 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 11 }} tickFormatter={(val) => `₹${val / 1000}k`} />
                  <Tooltip
                    cursor={{ fill: 'rgba(16, 185, 129, 0.08)', radius: 12 }}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const item = payload[0].payload;
                        return (
                          <div className="bg-slate-900 text-white px-3 py-2 rounded-xl text-xs space-y-1">
                            <p className="font-bold text-emerald-400">{item.day} Cluster Sales</p>
                            <p className="text-base font-black">₹{item.sales.toLocaleString('en-IN')}</p>
                            <p className="text-[10px] text-slate-400">{item.volume} dispatched</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey="sales" fill="#059669" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="lg:col-span-4 bg-slate-900 text-white rounded-3xl p-6 sm:p-7 shadow-sm space-y-5 border border-slate-800">
            <div>
              <span className="text-xs font-mono uppercase tracking-wider text-emerald-400 font-bold">
                Cooperative Performance
              </span>
              <h4 className="text-lg font-bold font-display mt-1">Top Revenue Crops</h4>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex justify-between items-center">
                <span>Sharbati Wheat</span>
                <span className="font-mono font-bold text-emerald-300">₹3.8L (45%)</span>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex justify-between items-center">
                <span>Desi Tomatoes</span>
                <span className="font-mono font-bold text-emerald-300">₹2.2L (26%)</span>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex justify-between items-center">
                <span>Kufri Potatoes</span>
                <span className="font-mono font-bold text-emerald-300">₹1.5L (18%)</span>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex justify-between items-center">
                <span>Mustard Seed</span>
                <span className="font-mono font-bold text-emerald-300">₹0.9L (11%)</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 italic">
              100% direct payouts routed to member farmer bank accounts with zero intermediary deductions.
            </p>
          </div>
        </div>
      )}

      {/* Tab: Cluster Logistics & Consolidated Fleet Dispatch */}
      {(activeTab === 'overview' || activeTab === 'logistics') && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900 font-display">
                  Cluster Logistics & Consolidated Dispatch
                </h3>
                <p className="text-xs text-slate-500">
                  Optimized multi-farm collection runs and direct-to-buyer deliveries
                </p>
              </div>
            </div>
            <Link
              to="/logistics"
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 hover:underline inline-flex items-center gap-1"
            >
              Open Logistics Hub →
            </Link>
          </div>

          {/* Active Routes Overview */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
              Active Cooperative Delivery Routes
            </h4>
            {routes && routes.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {routes.slice(0, 2).map((route) => (
                  <RouteSummary key={route.id} route={route} />
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 py-3">No active delivery routes in progress.</p>
            )}
          </div>

          {/* Farm-gate Pickups */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
              Scheduled Member Farm Collections
            </h4>
            {pickups && pickups.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {pickups.slice(0, 3).map((pickup) => (
                  <PickupSchedule
                    key={pickup.id}
                    schedule={pickup}
                    onMarkReady={(id) => updatePickupStatus(id, 'READY')}
                  />
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 py-3">All scheduled pickups up to date.</p>
            )}
          </div>
        </div>
      )}

      {/* Tab 5: Recent Orders */}
      {(activeTab === 'overview' || activeTab === 'orders') && (
        <RecentOrdersTable
          orders={orders}
          title="FPO Cluster Recent Orders"
          subtitle="Consolidated orders routed through FPO aggregation hubs"
          counterpartyLabel="Buyer"
          onStatusChange={updateOrderStatus}
          showActions={true}
          maxItems={6}
        />
      )}

      {/* Quick Actions adhering to Section 6 */}
      <QuickActions
        title="Quick Actions"
        subtitle="Frequently used FPO cluster workflows"
        actions={quickActionsList}
      />

      {/* Modal: Add Member Farmer */}
      {showAddFarmerModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl border border-slate-200 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-slate-900 font-display">
                  Add Member Farmer
                </h3>
                <p className="text-xs text-slate-500">
                  Enrolling producer under {displayName}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowAddFarmerModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateFarmer} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Farmer Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Balram Singh"
                  value={newFarmerData.name}
                  onChange={(e) => setNewFarmerData({ ...newFarmerData, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Village / Tehsil</label>
                  <input
                    type="text"
                    value={newFarmerData.village}
                    onChange={(e) => setNewFarmerData({ ...newFarmerData, village: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">District</label>
                  <input
                    type="text"
                    value={newFarmerData.district}
                    onChange={(e) => setNewFarmerData({ ...newFarmerData, district: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Land Holding Size</label>
                  <input
                    type="text"
                    placeholder="e.g. 6.5 Acres"
                    value={newFarmerData.landSize}
                    onChange={(e) => setNewFarmerData({ ...newFarmerData, landSize: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Mobile Contact</label>
                  <input
                    type="text"
                    placeholder="+91 98765 43210"
                    value={newFarmerData.phone}
                    onChange={(e) => setNewFarmerData({ ...newFarmerData, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Crops Grown (Comma separated)</label>
                <input
                  type="text"
                  placeholder="Wheat, Mustard, Tomato"
                  value={newFarmerData.crops}
                  onChange={(e) => setNewFarmerData({ ...newFarmerData, crops: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-emerald-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddFarmerModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 font-bold hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <Button type="submit" variant="primary" size="sm">
                  Enroll Farmer
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add Farm Location */}
      {showAddLocationModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl border border-slate-200 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-slate-900 font-display">
                  Register FPO Cluster Location
                </h3>
                <p className="text-xs text-slate-500">
                  New aggregation or collection center
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowAddLocationModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateLocation} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Hub Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Jewar South Collection Yard"
                  value={newLocationData.name}
                  onChange={(e) => setNewLocationData({ ...newLocationData, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">District</label>
                  <input
                    type="text"
                    value={newLocationData.district}
                    onChange={(e) => setNewLocationData({ ...newLocationData, district: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">State</label>
                  <input
                    type="text"
                    value={newLocationData.state}
                    onChange={(e) => setNewLocationData({ ...newLocationData, state: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Producers Attached</label>
                  <input
                    type="number"
                    value={newLocationData.farmers}
                    onChange={(e) => setNewLocationData({ ...newLocationData, farmers: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Produce Types</label>
                  <input
                    type="text"
                    placeholder="Vegetables, Mustard, Wheat"
                    value={newLocationData.produce}
                    onChange={(e) => setNewLocationData({ ...newLocationData, produce: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-emerald-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddLocationModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 font-bold hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <Button type="submit" variant="primary" size="sm">
                  Save Cluster Location
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
