import React, { useState, useMemo } from 'react';
import { 
  MapPin, 
  SlidersHorizontal, 
  X, 
  RotateCcw, 
  ShoppingBag,
  Leaf,
  CheckCircle2,
  Navigation,
  Loader2,
  AlertCircle
} from 'lucide-react';

import SearchBar from '../components/SearchBar';
import FilterBar from '../components/FilterBar';
import ProductCard from '../components/ProductCard';
import Button from '../components/Button';
import { useProducts } from '../context/ProductContext';
import { useLocation } from '../context/LocationContext';
import { calculateDistance } from '../utils/distance';

const INITIAL_FILTERS = {
  category: 'All',
  state: 'All',
  location: 'All Locations',
  distance: 'all',
  priceRange: 'all',
  availability: 'all',
  quality: 'All',
  sort: 'recommended'
};

export default function Marketplace() {
  const { products } = useProducts();
  const { 
    buyerLocation, 
    buyerLoading, 
    buyerError, 
    requestBuyerLocation, 
    clearBuyerLocation 
  } = useLocation();

  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState(INITIAL_FILTERS);
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  const handleFilterChange = (key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const handleResetFilters = () => {
    setFilters(INITIAL_FILTERS);
    setSearchQuery('');
  };

  // Filter & Sort Logic
  const filteredProducts = useMemo(() => {
    let result = [...products];

    // 1. Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        (item) =>
          item.name.toLowerCase().includes(q) ||
          item.hindiName?.toLowerCase().includes(q) ||
          item.farmer?.toLowerCase().includes(q) ||
          item.location?.toLowerCase().includes(q) ||
          item.state?.toLowerCase().includes(q) ||
          item.category?.toLowerCase().includes(q)
      );
    }

    // 2. Category filter
    if (filters.category !== 'All') {
      result = result.filter(
        (item) => item.category.toLowerCase() === filters.category.toLowerCase()
      );
    }

    // 3. Indian State filter
    if (filters.state && filters.state !== 'All') {
      result = result.filter(
        (item) => (item.state || '').toLowerCase() === filters.state.toLowerCase()
      );
    }

    // 4. City / Local Region filter
    if (filters.location !== 'All Locations') {
      result = result.filter(
        (item) => (item.location || '').toLowerCase() === filters.location.toLowerCase()
      );
    }

    // 5. Distance filter (when buyer location is known)
    if (filters.distance !== 'all' && buyerLocation) {
      const maxDistance = {
        'within-10': 10,
        'within-25': 25,
        'within-50': 50,
        'within-100': 100
      }[filters.distance];

      if (maxDistance) {
        result = result.filter((item) => {
          if (!item.latitude || !item.longitude) return false;
          const d = calculateDistance(
            buyerLocation.latitude,
            buyerLocation.longitude,
            item.latitude,
            item.longitude
          );
          return d <= maxDistance;
        });
      }
    }

    // 6. Price range
    if (filters.priceRange === 'under-25') {
      result = result.filter((item) => item.price < 25);
    } else if (filters.priceRange === '25-50') {
      result = result.filter((item) => item.price >= 25 && item.price <= 50);
    } else if (filters.priceRange === 'above-50') {
      result = result.filter((item) => item.price > 50);
    }

    // 7. Availability
    if (filters.availability === 'in-stock') {
      result = result.filter((item) => item.quantityAvailable > 50);
    } else if (filters.availability === 'low-stock') {
      result = result.filter((item) => item.quantityAvailable <= 50);
    }

    // 8. Quality / Organic
    if (filters.quality !== 'All') {
      if (filters.quality === 'Organic') {
        result = result.filter((item) => item.organic === true);
      } else {
        result = result.filter(
          (item) => item.quality?.toLowerCase() === filters.quality.toLowerCase()
        );
      }
    }

    // 9. Sorting
    if (filters.sort === 'nearest') {
      if (buyerLocation) {
        result.sort((a, b) => {
          const distA = a.latitude && a.longitude 
            ? calculateDistance(buyerLocation.latitude, buyerLocation.longitude, a.latitude, a.longitude)
            : 99999;
          const distB = b.latitude && b.longitude
            ? calculateDistance(buyerLocation.latitude, buyerLocation.longitude, b.latitude, b.longitude)
            : 99999;
          return distA - distB;
        });
      }
    } else if (filters.sort === 'price-asc') {
      result.sort((a, b) => a.price - b.price);
    } else if (filters.sort === 'price-desc') {
      result.sort((a, b) => b.price - a.price);
    } else if (filters.sort === 'newest') {
      result.sort((a, b) => {
        const aToday = (a.harvestDate || '').toLowerCase().includes('today') ? 1 : 0;
        const bToday = (b.harvestDate || '').toLowerCase().includes('today') ? 1 : 0;
        return bToday - aToday;
      });
    } else if (filters.sort === 'fastest') {
      result.sort((a, b) => {
        const parseKm = (p) => {
          if (buyerLocation && p.latitude && p.longitude) {
            return calculateDistance(buyerLocation.latitude, buyerLocation.longitude, p.latitude, p.longitude);
          }
          const match = (p.distance || '').match(/(\d+)/);
          return match ? parseInt(match[0], 10) : 999;
        };
        return parseKm(a) - parseKm(b);
      });
    }

    return result;
  }, [products, searchQuery, filters, buyerLocation]);

  const activeFilterCount = Object.entries(filters).filter(([key, val]) => {
    if (key === 'category' && val !== 'All') return true;
    if (key === 'state' && val !== 'All') return true;
    if (key === 'location' && val !== 'All Locations') return true;
    if (key === 'distance' && val !== 'all') return true;
    if (key === 'priceRange' && val !== 'all') return true;
    if (key === 'availability' && val !== 'all') return true;
    if (key === 'quality' && val !== 'All') return true;
    if (key === 'sort' && val !== 'recommended') return true;
    return false;
  }).length + (searchQuery ? 1 : 0);

  return (
    <div className="bg-slate-50 min-h-screen pb-24">
      
      {/* =========================================================================
          PAGE HEADER
          ========================================================================= */}
      <section className="bg-white border-b border-slate-200/80 pt-10 pb-8 sm:pt-14 sm:pb-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-pattern opacity-50 pointer-events-none" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            
            <div className="max-w-2xl space-y-3">
              {/* Badges */}
              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold">
                  <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Pan-India Network</span>
                </span>
                <span className="text-xs text-slate-500 font-medium">
                  Hyperlocal Farmer-to-Buyer Marketplace
                </span>
              </div>

              {/* Title */}
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-950 tracking-tight font-display">
                Fresh Produce. Direct from Indian Farms.
              </h1>

              {/* Subtitle */}
              <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
                Discover farm-gate produce from verified farmers and FPOs across India with live proximity calculations.
              </p>

              {/* Buyer Live Location Bar */}
              <div className="pt-2 flex flex-wrap items-center gap-3">
                {buyerLocation ? (
                  <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs font-semibold shadow-xs">
                    <Navigation className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
                    <span>
                      Delivering near: <strong className="text-emerald-800">{buyerLocation.locality || buyerLocation.city || buyerLocation.district || 'Current Location'}, {buyerLocation.state}</strong>
                    </span>
                    <button
                      type="button"
                      onClick={clearBuyerLocation}
                      className="ml-1 p-0.5 rounded-full hover:bg-emerald-200 text-emerald-700"
                      title="Clear location"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={requestBuyerLocation}
                    disabled={buyerLoading}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-xs disabled:opacity-60"
                  >
                    {buyerLoading ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-400" />
                        <span>Detecting live location...</span>
                      </>
                    ) : (
                      <>
                        <Navigation className="w-3.5 h-3.5 text-emerald-400" />
                        <span>📍 Deliver to my location / Find produce near me</span>
                      </>
                    )}
                  </button>
                )}

                {buyerError && (
                  <span className="inline-flex items-center gap-1 text-[11px] text-amber-700 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                    <AlertCircle className="w-3 h-3 flex-shrink-0" />
                    <span>{buyerError}</span>
                  </span>
                )}
              </div>
            </div>

            {/* Live stats summary */}
            <div className="hidden lg:flex flex-col items-end text-right bg-slate-50 border border-slate-200/80 p-4 rounded-2xl">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                Live Farm Batches
              </span>
              <span className="text-2xl font-black text-emerald-700 font-display">
                {products.length} Direct Listings
              </span>
              <span className="text-[11px] text-slate-500">
                0% APMC Brokerage • Pan-India Logistics
              </span>
            </div>

          </div>

          {/* Prominent Search Bar */}
          <div className="mt-8 max-w-3xl">
            <SearchBar
              value={searchQuery}
              onChange={setSearchQuery}
              onClear={() => setSearchQuery('')}
              placeholder="Search tomatoes, potatoes, wheat, Alphonso mangoes, organic turmeric..."
            />
          </div>

        </div>
      </section>

      {/* =========================================================================
          MAIN CONTENT AREA (FILTERS + PRODUCT GRID)
          ========================================================================= */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        
        {/* Mobile Filter Toggle & Quick Bar */}
        <div className="flex lg:hidden items-center justify-between gap-3 mb-6">
          <button
            type="button"
            onClick={() => setMobileFilterOpen(true)}
            className="flex-1 py-3 px-4 rounded-2xl bg-white border border-slate-200 shadow-xs font-bold text-xs text-slate-800 flex items-center justify-center gap-2 hover:bg-slate-50 transition-colors"
          >
            <SlidersHorizontal className="w-4 h-4 text-emerald-600" />
            <span>Filters & Sort</span>
            {activeFilterCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-[10px] flex items-center justify-center font-bold">
                {activeFilterCount}
              </span>
            )}
          </button>

          {activeFilterCount > 0 && (
            <button
              type="button"
              onClick={handleResetFilters}
              className="py-3 px-3.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          )}
        </div>

        {/* Layout Grid: Left Sidebar (Desktop) + Right Products */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Desktop Filter Sidebar (4 cols) */}
          <aside className="hidden lg:block lg:col-span-4 sticky top-24">
            <FilterBar
              filters={filters}
              onFilterChange={handleFilterChange}
              onResetFilters={handleResetFilters}
              totalResults={filteredProducts.length}
              buyerLocation={buyerLocation}
            />

            {/* Pan-India Regional Notice */}
            <div className="mt-4 p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 text-xs text-emerald-900 space-y-1.5">
              <div className="flex items-center gap-1.5 font-bold">
                <Leaf className="w-4 h-4 text-emerald-600" />
                <span>Pan-India Direct Farm Gate</span>
              </div>
              <p className="text-[11px] text-emerald-800/90 leading-relaxed">
                Connect directly with farmers across Maharashtra, Punjab, UP, Karnataka, and more. Distances are calculated dynamically using GPS.
              </p>
            </div>
          </aside>

          {/* Right Product Grid Area (8 cols) */}
          <main className="lg:col-span-8 space-y-6">
            
            {/* Results bar */}
            <div className="flex flex-wrap items-center justify-between text-xs text-slate-500 pb-2 border-b border-slate-200/80 gap-2">
              <span className="font-semibold text-slate-700">
                Showing <strong className="text-slate-950 font-bold">{filteredProducts.length}</strong> farm batches
                {filters.state && filters.state !== 'All' && ` in ${filters.state}`}
                {filters.location !== 'All Locations' && ` (${filters.location})`}
                {filters.category !== 'All' && ` for ${filters.category}`}
                {buyerLocation && filters.distance !== 'all' && ` • ${filters.distance.replace('-', ' ')} km`}
              </span>

              <div className="flex items-center gap-3">
                <span className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-600 text-[11px] font-medium border border-slate-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  {products.filter(p => !p.isDemo).length} Live • {products.filter(p => p.isDemo).length} Sample
                </span>

                {activeFilterCount > 0 && (
                  <button
                    type="button"
                    onClick={handleResetFilters}
                    className="hidden lg:flex items-center gap-1 text-emerald-700 font-semibold hover:underline"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Clear {activeFilterCount} active filter{activeFilterCount > 1 ? 's' : ''}</span>
                  </button>
                )}
              </div>
            </div>

            {/* Empty State */}
            {filteredProducts.length === 0 ? (
              <div className="bg-white rounded-3xl border border-slate-200/90 p-12 text-center space-y-4 my-6 shadow-sm">
                <div className="w-16 h-16 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center mx-auto text-amber-600">
                  <ShoppingBag className="w-8 h-8" />
                </div>

                <div className="space-y-1">
                  <h3 className="text-xl font-bold text-slate-900 font-display">
                    No produce found
                  </h3>
                  <p className="text-slate-500 text-sm max-w-sm mx-auto">
                    Try broadening your distance radius or changing your state filter to discover more farm batches.
                  </p>
                </div>

                <div className="pt-2">
                  <Button
                    onClick={handleResetFilters}
                    variant="primary"
                    size="md"
                    leftIcon={RotateCcw}
                  >
                    Clear Filters
                  </Button>
                </div>
              </div>
            ) : (
              /* Product Grid */
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard 
                    key={product.id} 
                    product={product} 
                    buyerLocation={buyerLocation} 
                  />
                ))}
              </div>
            )}

            {/* Bottom transparency notice */}
            <div className="p-4 rounded-2xl bg-white border border-slate-200/90 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
              <span className="flex items-center gap-1.5 font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span>Zero APMC intermediary margin. Direct bank payout to farmer accounts.</span>
              </span>
              <span className="font-mono text-[10px] text-slate-400">
                FasalSetu Pan-India Engine v3.0
              </span>
            </div>

          </main>

        </div>

      </div>

      {/* =========================================================================
          MOBILE FILTER MODAL / DRAWER
          ========================================================================= */}
      {mobileFilterOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex flex-col justify-end bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div 
            className="fixed inset-0" 
            onClick={() => setMobileFilterOpen(false)} 
          />

          <div className="relative bg-white rounded-t-3xl max-h-[85vh] overflow-y-auto p-5 shadow-2xl z-10 space-y-4">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-5 h-5 text-emerald-600" />
                <h3 className="text-lg font-bold text-slate-900 font-display">
                  Filters & Sorting
                </h3>
              </div>

              <button
                type="button"
                onClick={() => setMobileFilterOpen(false)}
                className="p-2 rounded-xl bg-slate-100 text-slate-600 hover:bg-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <FilterBar
              filters={filters}
              onFilterChange={handleFilterChange}
              onResetFilters={handleResetFilters}
              totalResults={filteredProducts.length}
              buyerLocation={buyerLocation}
              className="shadow-none border-0 p-0"
            />

            <div className="pt-4 border-t border-slate-100 flex items-center gap-3">
              <Button
                variant="outline"
                size="md"
                className="flex-1 justify-center"
                onClick={handleResetFilters}
              >
                Reset
              </Button>
              <Button
                variant="primary"
                size="md"
                className="flex-2 justify-center"
                onClick={() => setMobileFilterOpen(false)}
              >
                Show {filteredProducts.length} Results
              </Button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
