# FasalSetu AI Demand Intelligence & Predictive Agriculture Architecture

## 1. System Overview

FasalSetu's **AI Demand Intelligence Layer** transforms historical transaction velocity, catalog inventory, and coarse geographic clustering into actionable agricultural foresight. The system enables Farmers, FPOs, Consumers, and Bulk Buyers to anticipate market absorption, mitigate post-harvest distress selling, and synchronize farm-gate dispatch with institutional consumption.

```
                           ┌─────────────────────────────────────────┐
                           │            FasalSetu Frontend           │
                           │  (React 19 + Tailwind CSS + Lucide)     │
                           └────────────────────┬────────────────────┘
                                                │
                                    ┌───────────┴───────────┐
                                    │       AI Context      │
                                    │    (src/context/AI)   │
                                    └───────────┬───────────┘
                                                │
                               ┌────────────────┴────────────────┐
                               │        AI Service Layer         │
                               │      (src/services/ai/)         │
                               └────────────────┬────────────────┘
                                                │
                       ┌────────────────────────┴────────────────────────┐
                       │                                                 │
            ┌──────────▼──────────┐                           ┌──────────▼──────────┐
            │  Statistical Engine │                           │   Supabase Forecast │
            │ (Provider Pattern)  │                           │   (demand_forecasts)│
            └──────────┬──────────┘                           └─────────────────────┘
                       │
       ┌───────────────┼───────────────┬───────────────┐
       │               │               │               │
┌──────▼──────┐ ┌──────▼──────┐ ┌──────▼──────┐ ┌──────▼──────┐
│ Historical  │ │ Trend &     │ │ Multi-Factor│ │ Coarse      │
│ Weighted MA │ │ Volatility  │ │ Confidence  │ │ Geographic  │
│ (50/30/20)  │ │ Multiplier  │ │ Scoring     │ │ Aggregation │
└─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘
```

---

## 2. Core Methodologies & Mathematical Formulations

### 📈 1. Historical Weighted Moving Average (WMA)
To accurately reflect both immediate momentum and seasonal stability, the baseline forecast applies normalized historical weights across three temporal horizons:
- **Recent 7-Day Velocity ($D_7$)**: Weight = $0.50$ ($50\%$)
- **Medium-Term 14-Day Velocity ($D_{14}$)**: Weight = $0.30$ ($30\%$)
- **Long-Term 30-Day Velocity ($D_{30}$)**: Weight = $0.20$ ($20\%$)

$$\text{Baseline Forecast} = \frac{D_7 \times 0.50 + \left(\frac{D_{14}}{2}\right) \times 0.30 + \left(\frac{D_{30}}{4.28}\right) \times 0.20}{0.50 + 0.30 + 0.20}$$

### ⚡ 2. Trend & Volatility Adjustment
Demand growth is computed by comparing the most recent 7 days against the preceding 7-day interval ($8\text{--}14$ days prior):

$$\text{Growth \%} = \frac{\text{Recent Demand} - \text{Previous Demand}}{\text{Previous Demand}} \times 100$$

A bounded trend factor ($0.80 \le T \le 1.25$) is applied to dampen wild swings and avoid runaway extrapolation:
- If $\text{Growth \%} > 0$: $T = \min\left(1 + \frac{\text{Growth \%}}{200}, 1.25\right)$
- If $\text{Growth \%} < 0$: $T = \max\left(1 + \frac{\text{Growth \%}}{200}, 0.80\right)$

$$\text{Forecast Quantity} = \text{round}(\text{Baseline Forecast} \times T)$$

---

## 3. Demand Classification & Thresholds

Classification is centralized in `src/services/ai/aiUtils.js` (`DEMAND_THRESHOLDS`):

| Classification | Growth Condition | Volume Threshold | Sample Size Requirement |
| :--- | :--- | :--- | :--- |
| **`HIGH DEMAND`** | $\ge +15.0\%$ | $\ge 1,500\text{ kg}$ | $\ge 3\text{ orders}$ |
| **`RISING DEMAND`** | $\ge +15.0\%$ | $< 1,500\text{ kg}$ | $\ge 3\text{ orders}$ |
| **`STABLE`** | $-10.0\% \le \text{Growth} < +15.0\%$ | Any | $\ge 3\text{ orders}$ |
| **`DECLINING`** | $< -10.0\%$ | $\ge 300\text{ kg}$ | $\ge 3\text{ orders}$ |
| **`LOW DEMAND`** | $< -10.0\%$ | $< 300\text{ kg}$ | $\ge 3\text{ orders}$ |
| **`INSUFFICIENT DATA`** | Any | Any | $< 3\text{ orders}$ |

---

## 4. Surplus vs Shortage Detection Engine

Compares the computed **7-day forecast demand** against **net available supply** (total quantity minus active reservations) across regional producers:

- **Potential Shortage (🔴)**: $\text{Forecast Demand} > \text{Supply} \times 1.15$
- **Potential Surplus (🟡)**: $\text{Supply} > \text{Forecast Demand} \times 1.25$
- **Balanced Supply (🟢)**: Within $15\%\text{--}25\%$ parity
- **Insufficient Data (⚪)**: Sample size $< 3\text{ orders}$

> [!NOTE]
> All UI presentations use probabilistic language (*"Potential Shortage"*, *"Potential Surplus"*) to clearly communicate that projections are advisories rather than statutory market guarantees.

---

## 5. Transparent Confidence Scoring & Explainability

Confidence scores ($0\%\text{--}100\%$) are calculated from empirical data attributes, strictly avoiding arbitrary numbers:

$$\text{Confidence Score} = \text{Base}(30) + S_{\text{sample}} + S_{\text{recency}} + S_{\text{stability}} + S_{\text{diversity}}$$

- **Sample Size ($S_{\text{sample}}$)**:
  - $\ge 20\text{ orders} \rightarrow +30\text{ pts}$
  - $10\text{--}19\text{ orders} \rightarrow +20\text{ pts}$
  - $3\text{--}9\text{ orders} \rightarrow +10\text{ pts}$
  - $< 3\text{ orders} \rightarrow \text{Caps at } 25\%$
- **Data Recency ($S_{\text{recency}}$)**: $\ge 5\text{ orders in last 14 days} \rightarrow +20\text{ pts}$
- **Trend Stability ($S_{\text{stability}}$)**: Volatility bounded $|\text{Growth}| \le 35\% \rightarrow +12\text{ pts}$
- **Buyer Diversity ($S_{\text{diversity}}$)**: Orders spanning $\ge 4\text{ distinct accounts} \rightarrow +8\text{ pts}$

Scores are capped between $15\%$ and $88\%$ (strictly reflecting real-world agricultural variance; no false "99% AI certainty").

### Explainability Checklist ("Why this forecast?")
Every prediction generates human-readable audit drivers:
- *"Robust dataset: 45 historical transactions analyzed"*
- *"Strong recent activity: 12 orders in the last 14 days"*
- *"Supply-to-forecast ratio: 64% coverage against expected demand"*

---

## 6. Location Privacy Architecture

To ensure farmer security and eliminate corporate geofencing/harassment risks:
1. **Public/Consumer AI Payload**: Exposes exclusively coarse regional clusters (`Noida, Uttar Pradesh`, `Pune, Maharashtra`).
2. **Strict Sanitization**: The regional demand service completely omits `latitude`, `longitude`, and `accuracy` fields from output payloads.
3. **Database Layer**: `public_farm_locations` view conceals exact coordinates, enforcing privacy at the PostgreSQL level.

---

## 7. Role-Specific Intelligence Modules

### 🌾 1. Farmer Portal (`/farmer/dashboard`)
- **Widget**: **AI Demand Outlook**
- **Personalized Recommendations**: Evaluates farmer's specific inventory against local district deficits.
- **Suggested Listing Quantity**: Outputs advisory ranges (e.g. `100–150 kg`) without guaranteeing sales.

### 🏢 2. FPO Portal (`/fpo/dashboard`)
- **Widget**: **AI Aggregation Intelligence**
- **Cluster Aggregation**: Sums member supply against regional demand to uncover aggregation deficits (e.g. `550 kg Tomato deficit in Greater Noida`).

### 🚛 3. Bulk Buyer Portal (`/bulk-buyer/dashboard`)
- **Widget**: **AI Procurement Signals**
- **Bulk Sourcing**: Flags multi-tonne surplus clusters ready for commercial procurement with suggested volume bounds.

### 🛒 4. Consumer Portal (`/consumer/dashboard`)
- **Widget**: **AI Curated Produce**
- **Demand Signals**: Highlights trending fresh produce (`🔥 High Demand Fresh Pick`) from morning harvest schedules.

---

## 8. Low-Data & Offline Fallback Strategy

When running in low-transaction or newly initialized demo environments:
- **Sample Size $< 3$**: The system displays `"Early-Stage Marketplace Signal"` and `"Limited data"` badges instead of fabricating misleading predictions.
- **Supabase Disconnection**: The service layer falls back gracefully to in-memory order/product collections without crashing the UI.

---

## 9. Future ML Integration Roadmap (Provider Pattern)

The forecasting service uses an extensible **Provider Pattern**:

```javascript
class StatisticalForecastProvider {
  generateForecasts(orders, products) { ... }
}

class MLForecastProvider {
  async generateForecasts(orders, products) {
    // Future Phase: XGBoost / LightGBM / Neural Prophet
  }
}
```

By swapping providers via `demandForecastService.setProvider(new MLForecastProvider())`, advanced machine learning or neural demand models can be deployed in future phases without altering any React UI components or Context APIs.
