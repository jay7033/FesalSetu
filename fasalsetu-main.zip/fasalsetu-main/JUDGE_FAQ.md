# FasalSetu — Judge FAQ & Anticipated Questions
**SIH 2026 · Problem Statement 26033**  
*Department of Consumer Affairs, Ministry of Consumer Affairs, Food & Public Distribution*

---

## Q1: What makes FasalSetu different from existing agri-marketplaces like eNAM or AgriBazaar?

**Answer:**

FasalSetu is **not just a listing portal** — it is an end-to-end operating system for farm-to-fork supply chains:

| Feature | eNAM / Traditional | FasalSetu |
| :--- | :--- | :--- |
| Market Access | Mandi-centric, requires physical presence | Direct digital access for 4 roles (Farmer, FPO, Consumer, Bulk Buyer) |
| Price Discovery | Auction-based at mandi | Transparent listed pricing with observed price signal analytics |
| Demand Intelligence | None | Statistical demand forecasting with regional gap analysis |
| Logistics | Farmer arranges own transport | Algorithmic route optimization with vehicle capacity constraints |
| FPO Aggregation | Manual coordination | Digital aggregation with member inventory pooling |
| Inventory Protection | None | Atomic reservation/deduction with PostgreSQL row locks |
| Privacy | Location publicly visible | GPS masked — only approximate district shown publicly |

**Key differentiator:** FasalSetu operates as a **cooperative intelligence layer**, not just a marketplace.

---

## Q2: How does FasalSetu benefit the farmer directly?

**Answer:**

1. **Direct Market Access:** Farmers list produce and receive orders directly from consumers and institutional buyers — eliminating 2-3 intermediary layers.
2. **AI Opportunity Scoring:** Each farmer receives a personalized 0-100 Harvest Opportunity Score indicating current market demand for their crops, with actionable listing suggestions.
3. **Price Transparency:** Observed Price Signal analytics show historical vs. recent median prices, helping farmers time their listings.
4. **FPO Aggregation:** Small/marginal farmers can pool inventory through FPO clusters, enabling bulk order fulfillment they couldn't serve individually.
5. **GPS Privacy:** Farmers' exact farm coordinates are **never** exposed to buyers or the public.
6. **Inventory Safety Net:** Atomic reservation prevents overselling — the system mathematically guarantees that accepted orders can be fulfilled.

---

## Q3: How does the AI/demand forecasting work? Is it using real machine learning?

**Answer:**

**Honest disclosure:** For the prototype, FasalSetu uses a **deterministic statistical model**, not a trained neural network:

- **Algorithm:** 3-Tier Weighted Moving Average
  - 50% weight on 7-day trend
  - 30% weight on 14-day trend
  - 20% weight on 30-day trend
- **Regional Adjustment:** A 0.80–1.25 trend multiplier based on regional urbanization, seasonal patterns, and proximity to major consumption centers.
- **Output:** Forecast demand per crop per district, classified as High / Medium / Low / Very Low demand levels.
- **Confidence:** Displayed as "Forecast Confidence" — a composite heuristic based on data recency and regional coverage. This is **not** ML model accuracy.

**Why this approach?**
- No dependency on proprietary ML APIs or expensive GPU inference.
- Deterministic and explainable — every score can be traced to its input factors.
- Production-ready to plug in actual AGMARKNET/eNAM price feeds and real order history.

---

## Q4: How do you prevent overselling? What if two buyers order the same stock?

**Answer:**

FasalSetu implements **atomic inventory reservation** using PostgreSQL transactional RPCs:

```
1. Buyer clicks "Confirm Order"
2. RPC: create_order_transaction() executes
3. SELECT ... FROM products WHERE id = X FOR UPDATE  ← Row-level lock
4. IF quantity_available < requested THEN RAISE EXCEPTION
5. UPDATE products SET quantity_available -= X, reserved_quantity += X
6. INSERT order, order_items, fulfillments, timeline, notifications
7. COMMIT (all-or-nothing)
```

- If two concurrent buyers attempt the same stock, the `FOR UPDATE` lock serializes them — the second buyer gets an "Insufficient stock" error.
- Reserved stock is permanently deducted only when the order reaches `Delivered` status.
- If the order is cancelled, reserved stock is atomically released back to available.

---

## Q5: What happens if the internet goes down during the demo?

**Answer:**

FasalSetu has a **built-in dual-mode architecture**:

1. **If Supabase is configured and online:** Full cloud persistence with RLS, Realtime subscriptions, and atomic RPCs.
2. **If Supabase is unavailable or not configured:** The application seamlessly falls back to a **localStorage-based demo engine** with:
   - Pre-seeded demo accounts for all 4 roles
   - Full order lifecycle management
   - Inventory reservation/release/deduction
   - AI demand intelligence (runs entirely client-side)
   - Route optimization (runs entirely client-side)

**No crash, no error screen, no degraded experience.** The fallback is transparent to the user.

---

## Q6: How does the logistics/route optimization work?

**Answer:**

1. **Input:** Farm pickup points (GPS coordinates of order items), delivery destination, vehicle type + capacity.
2. **Algorithm:** 
   - **Phase 1 — Nearest Neighbor:** Constructs an initial pickup route by greedily selecting the closest unvisited farm.
   - **Phase 2 — 2-Opt Local Search:** Iteratively improves the route by reversing sub-segments to reduce total distance.
3. **Constraints:**
   - Vehicle capacity enforcement (e.g., 500 kg Tata Ace, 2500 kg Medium Truck).
   - Dwell time per stop (loading/unloading).
   - ETA calculation using a 40 km/h prototype baseline.
4. **Visualization:** Interactive MapLibre map with route polylines and stop markers.

**Honest note:** ETAs use a simplified speed model. Production deployment would integrate real-time traffic APIs.

---

## Q7: Is the platform ready for real-world deployment?

**Answer:**

FasalSetu is a **production-architecture prototype**:

| Aspect | Production-Ready? | Notes |
| :--- | :--- | :--- |
| Database schema | ✅ Yes | 15 sequential PostgreSQL migrations |
| RLS security | ✅ Yes | All tables protected |
| Auth system | ✅ Yes | Supabase Auth with JWT |
| Atomic inventory | ✅ Yes | FOR UPDATE locks |
| AI intelligence | ⚠️ Prototype | Needs real market data feeds |
| Route optimization | ⚠️ Prototype | Needs real traffic/mapping APIs |
| Payment gateway | ❌ Not yet | Demo "Cash on Delivery" only |
| Regulatory compliance | ❌ Not yet | Needs APMC/Mandi integration |

**What's needed for production:**
1. Real market data integration (AGMARKNET, eNAM APIs)
2. Payment gateway (Razorpay/UPI)
3. SMS/OTP authentication (Twilio/MSG91)
4. Real-time traffic APIs for logistics
5. APMC compliance for interstate trade

---

## Q8: What is the technology stack?

**Answer:**

| Layer | Technology |
| :--- | :--- |
| Frontend | React 19 + React Router 7 + Tailwind CSS 4 |
| Build | Vite 8 |
| Backend | Supabase (PostgreSQL + Auth + Realtime + Storage) |
| Maps | MapLibre GL (open-source, free) |
| Geocoding | OpenStreetMap Nominatim (free) |
| Charts | Recharts |
| Icons | Lucide React |
| Linting | OxLint |

**No proprietary APIs. No paid services. Fully open-source stack.**

---

## Q9: How does FasalSetu protect farmer privacy?

**Answer:**

FasalSetu follows a **strict approximate-public / precise-private** privacy model:

- **Farmers see:** Their own exact GPS coordinates and registered farm boundaries.
- **Buyers/Public see:** Only approximate location strings like *"Near Nashik, Maharashtra"* or *"Dankaur, Greater Noida"*.
- **Database:** `farm_locations` table is protected by RLS — buyers can only access farm locations for their own active orders.
- **AI Engine:** Internal distance calculations use coordinates for Haversine math, but output results contain only city/district names.
- **No GPS coordinates appear in:** Marketplace cards, product details, search results, AI insights, or logistics displays.

---

## Q10: What are the current limitations you acknowledge?

**Answer:**

We believe in honest engineering disclosure:

1. **AI models are statistical, not ML-trained.** Forecast confidence is a heuristic composite, not model accuracy.
2. **ETAs are simplified.** We use a 40 km/h constant-speed model, not real-time traffic.
3. **Payments are demo-only.** No real payment gateway is integrated.
4. **Demo data is synthetic.** Prices, quantities, and farmer profiles are illustrative.
5. **No APMC/Mandi regulatory integration.** Interstate trade compliance would need APMC exemption certificates.
6. **Single-region prototype.** Currently optimized for Western UP / NCR region. Pan-India scaling needs regional data feeds.

**These are engineering decisions, not limitations** — each one has a clear production upgrade path documented in our architecture.
