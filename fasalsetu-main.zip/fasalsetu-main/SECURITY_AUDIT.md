# FasalSetu — Security Audit Report (Phase 9)
**SIH 2026 · Problem Statement 26033**  
**Audit Date:** September 2026  
**Auditor:** FasalSetu Engineering Team  
**Status:** ✅ PASS — No Critical Vulnerabilities Found

---

## 1. Authentication Architecture

### 1.1 Dual-Mode Auth
FasalSetu implements a resilient dual-mode authentication layer:

| Mode | Trigger | Session Storage | Token Type |
| :--- | :--- | :--- | :--- |
| **Supabase Cloud** | `VITE_SUPABASE_URL` + `VITE_SUPABASE_ANON_KEY` configured and valid | Supabase-managed JWT (`persistSession: true`, `autoRefreshToken: true`) | JWT w/ `auth.uid()` |
| **Demo Fallback** | Supabase not configured or offline | `localStorage` (key: `fasalsetu_auth_v1`) | Local session object |

### 1.2 Role Assignment
- In **Supabase mode**, the user's `role` is sourced from the `profiles.role` column in PostgreSQL — **not** from client input. The `signUp` RPC inserts the role server-side.
- In **Demo mode**, `DEMO_ACCOUNTS` (hardcoded seed data) maps 4 role personas; any user logging in as a role inherits that role's identity. Demo passwords are not real secrets.

### 1.3 Session Lifecycle
- `AuthProvider` subscribes to `onAuthStateChange` for real-time Supabase session events.
- On logout, both `supabase.auth.signOut()` and `localStorage.removeItem(AUTH_STORAGE_KEY)` are called.
- Session restoration on page reload: attempts Supabase `getSession()` first, then falls back to `localStorage` parse.

---

## 2. Role-Based Access Control (RBAC)

### 2.1 Client-Side Route Protection Matrix

| Route Prefix | Allowed Roles | Enforcement Component |
| :--- | :--- | :--- |
| `/farmer/*` | `farmer` | `ProtectedRoute` |
| `/fpo/*` | `fpo` | `ProtectedRoute` |
| `/consumer/*` | `consumer` | `ProtectedRoute` |
| `/bulk-buyer/*` | `bulk_buyer` | `ProtectedRoute` |
| `/marketplace`, `/cart`, `/checkout` | Any (public) | None |
| `/ai-insights`, `/logistics` | Any (public) | None |

### 2.2 ProtectedRoute Behavior
1. **Unauthenticated →** Redirect to `/login?role={targetRole}&redirect={current_path}`.
2. **Wrong role →** Redirect to the user's **own** role dashboard (e.g., a farmer trying `/bulk-buyer/dashboard` goes to `/farmer/dashboard`).
3. **Loading state →** Spinner with "Verifying FasalSetu Credentials..." message.

### 2.3 Server-Side RLS Enforcement (Supabase Mode)
All 21 core tables have `ENABLE ROW LEVEL SECURITY` enabled. Key policies:

| Table | Policy Summary |
| :--- | :--- |
| `profiles` | Users read/update only own profile. Public can read `farmer`/`fpo` names for marketplace display. |
| `farm_locations` | Owners manage own. Buyers see locations only for their active orders. |
| `products` | Anyone reads active products. Sellers manage own. |
| `orders` | Buyers read/insert/update own orders only. |
| `order_items` | Buyers read items of own orders. Sellers read items assigned to them. |
| `order_fulfillments` | Buyers read fulfillments for own orders. Sellers manage own fulfillments. |
| `notifications` | Users manage own notifications only. |
| `saved_products` | Consumers manage own saved products. |
| `inventory_transactions` | Sellers view logs for their products. |

---

## 3. GPS / Location Privacy

### 3.1 Architecture
FasalSetu follows a strict **approximate-public / precise-private** model:

```
Farmer GPS Input → LocationContext (private)
                 ↓
         Exact lat/lng stored only in:
           • farm_locations table (RLS-protected)
           • Internal Haversine calculations
                 ↓
         Public surfaces display ONLY:
           • "Near {City}, {District}, {State}"
           • District-level aggregations
```

### 3.2 Audit Results

| Surface | GPS Exposed? | Verification |
| :--- | :--- | :--- |
| Marketplace product cards | ❌ No | Shows `approximateLocation` string only |
| Product details page | ❌ No | City/district-level labels |
| Farmer profile (public view) | ❌ No | Privacy banner + approximate string |
| Farmer profile (own view) | ✅ Own only | Farmer sees own registered GPS |
| Smart match engine outputs | ❌ No | Returns `matchScore` & `breakdown`, no raw coords |
| Supply-demand gap outputs | ❌ No | Uses district/state aggregation |
| Redistribution plans | ❌ No | Uses city/corridor labels |
| Logistics route outputs | ⚠️ Internal | Route optimization uses coordinates internally for Haversine; public route display shows city names |

### 3.3 Database-Level GPS Protection
- `farm_locations` table is RLS-protected. Buyers can only read farm locations **involved in their active orders**.
- No public database view or API function exposes raw `latitude`/`longitude` columns without authentication.

---

## 4. Secrets & Environment Security

### 4.1 Scanned Files
Full source tree (`src/**`, `scripts/**`, `supabase/**`, root config) scanned for:

| Pattern | Found? | Status |
| :--- | :--- | :--- |
| `service_role` | ❌ None | ✅ PASS |
| `SUPABASE_SERVICE_ROLE` | ❌ None | ✅ PASS |
| Hardcoded API keys | ❌ None | ✅ PASS |
| `.env` in git | ❌ Excluded by `.gitignore` | ✅ PASS |

### 4.2 .gitignore Configuration
```
.env
.env.*
!.env.example
```
- `.env` and all `.env.*` variants are excluded from version control.
- Only `.env.example` (with placeholder values) is tracked.

### 4.3 Client-Side Key Exposure
- `VITE_SUPABASE_ANON_KEY` is intentionally a **public anonymous key** scoped by RLS policies. This is the standard Supabase architecture — the anon key alone cannot bypass row-level security.
- No `service_role` key is used anywhere in the client bundle.

---

## 5. Inventory Atomicity & Financial Integrity

### 5.1 Order Creation (`create_order_transaction` RPC)
- Uses `FOR UPDATE` row locks on products during stock verification.
- Validates: product existence, active status, MOQ compliance, stock availability.
- Atomically: decrements `quantity_available`, increments `reserved_quantity`, creates order + items + fulfillments + timeline + notifications — all within a single PostgreSQL transaction.
- Price is snapshotted from the database at order time (tamper-proof against client manipulation).

### 5.2 Order Delivery (`update_order_status` RPC → `Delivered`)
- Upon `Delivered` transition: `reserved_quantity` is permanently decremented.
- Inventory audit log entry of type `deduct` is recorded.

### 5.3 Order Cancellation (`cancel_order_transaction` RPC)
- Only allowed for `Pending` or `Confirmed` orders (enforced in both SQL and React context).
- Atomically: restores `quantity_available`, decrements `reserved_quantity`, records `release` audit entry.

### 5.4 Client-Side Mirror (Fallback Mode)
`OrderContext.jsx` mirrors the same lifecycle rules:
- `reserveInventory()` on order creation.
- `deductInventory()` on `Delivered` transition.
- `releaseInventory()` on `Cancelled` transition.

### 5.5 Strict State Transition Enforcement
Both SQL RPC and `OrderContext.jsx` enforce the same sequential lifecycle:

```
Pending → Confirmed → Preparing → Ready for Pickup → Picked Up → In Transit → Delivered
                                                                                     ↑ (terminal)
Pending ─┬→ Cancelled
Confirmed ─┘       ↑ (terminal)
```

Invalid jumps (e.g., `Pending → Delivered`) are rejected with descriptive error messages.

---

## 6. AI & Statistical Claims Integrity

### 6.1 Honest Model Labeling
- All AI/statistical models are labeled as **"Prototype Statistical Indicators"**.
- Demand forecasting uses a deterministic Weighted Moving Average formula (50% 7-day + 30% 14-day + 20% 30-day) with a 0.80–1.25 trend multiplier.
- Confidence scores are labeled as **"Forecast Confidence"** (a composite heuristic), **not** as ML model accuracy.

### 6.2 No Fake Claims
- ❌ No "99% accuracy" claims.
- ❌ No "guaranteed income increase" language.
- ❌ No "guaranteed savings" promises.
- ✅ All earnings displays include prototype disclaimers.
- ✅ Commercial PO terms use safe prototype language: *"Applicable statutory requirements will govern the final transaction."*

---

## 7. Summary & Recommendations

### Current Security Posture: **STRONG for Prototype/Hackathon**

| Category | Status | Notes |
| :--- | :--- | :--- |
| Authentication | ✅ | Dual-mode with Supabase JWT + localStorage fallback |
| Authorization (Client) | ✅ | ProtectedRoute enforces role boundaries |
| Authorization (Server) | ✅ | RLS on all 21 tables |
| GPS Privacy | ✅ | No raw coords in public surfaces |
| Secrets Management | ✅ | No service_role keys, .env excluded from git |
| Inventory Integrity | ✅ | Atomic RPC with FOR UPDATE locks |
| AI Honesty | ✅ | No overstated claims, labeled as prototype |
| Console Logging | ✅ | No rogue console.log in production paths |

### Recommendations for Production (Post-Hackathon)
1. Implement CSRF tokens for non-Supabase form submissions.
2. Add rate limiting on the Supabase Edge Function layer.
3. Implement Content Security Policy (CSP) headers.
4. Add server-side input sanitization for user-generated text fields.
5. Consider upgrading from `localStorage` demo mode to a proper offline-first database (e.g., PouchDB).
