# FasalSetu (फसल सेतु) — AI-Powered Hyperlocal Agricultural Marketplace

> *"Connecting Farms. Empowering Farmers."*  
> *"फसल से बाज़ार तक, सीधे और स्मार्ट तरीके से।"*

**FasalSetu** is an agricultural commerce and direct-procurement platform built for the **Smart India Hackathon (SIH)**. It directly connects local producers (Farmers and FPO Collectives) with household Consumers and institutional Bulk Buyers across Noida, Greater Noida, and nationwide Pan-India agricultural belts.

---

## 🏗️ System Architecture

```
                                  FASALSETU
                                      │
                            React 19 + Vite 8
                                      │
                   ┌──────────────────┴──────────────────┐
                   │                                     │
               Contexts                               Services
         (Auth, Products, Orders,             (authService, productService,
          FPO, Buyer, Locations)               orderService, inventoryService)
                   │                                     │
                   └──────────────────┬──────────────────┘
                                      │
                              src/lib/supabase.js
                                      │
                                  Supabase
                                      │
          ┌───────────────────────────┼───────────────────────────┐
          │                           │                           │
        Auth                      PostgreSQL                   Storage
    (4 Roles:                  ├── Profiles             ├── product-images
    Farmer, FPO,               ├── Products             └── avatars
    Consumer, Bulk)            ├── Orders
                               ├── Order Fulfillments
                               ├── Inventory Ledger
                               └── Notifications
```

---

## 🌟 Key Features

1. **4 Role-Protected Portals**:
   - **🌾 Farmer Portal (`/farmer/dashboard`)**: Harvest inventory management, GPS status card, live orders, sequential dispatch controls.
   - **🏢 FPO Collective Portal (`/fpo/dashboard`)**: Member roster, multi-farm aggregation yards, bulk produce batches, sales analytics.
   - **🛒 Consumer Portal (`/consumer/dashboard`)**: Nearby farm produce discovery, 5-step checkout, doorstep delivery tracking, saved favorites.
   - **🚛 Bulk Buyer Portal (`/bulk-buyer/dashboard`)**: Multi-tonne procurement, MOQ validation, prototype PO generation, supplier comparison.

2. **Privacy-First Hyperlocal GPS & Distance Engine**:
   - Live browser GPS with reverse-geocoding via OpenStreetMap Nominatim.
   - Haversine distance calculations and realistic delivery window estimations.
   - **Location Privacy Guarantee**: Exact GPS coordinates (`latitude`, `longitude`, `accuracy`) are strictly masked from public marketplace queries (`public_farm_locations` view).

3. **Atomic Transactional Order Lifecycle**:
   - Sequential 7-stage order lifecycle:
     $$\text{Pending} \rightarrow \text{Confirmed} \rightarrow \text{Preparing} \rightarrow \text{Ready for Pickup} \rightarrow \text{Picked Up} \rightarrow \text{In Transit} \rightarrow \text{Delivered}$$
   - Database-level inventory reservation preventing overselling or negative stock.
   - Atomic cancellation with reserved stock release.

4. **AI Demand Intelligence & Predictive Agriculture (Phase 6)**:
   - **Explainable Statistical Forecasting**: Weighted moving averages (50% 7-day, 30% 14-day, 20% 30-day) with bounded trend multipliers.
   - **Centralized Classification**: `HIGH DEMAND`, `RISING DEMAND`, `STABLE`, `DECLINING`, `LOW DEMAND`, `INSUFFICIENT DATA`.
   - **Surplus & Deficit Engine**: Automated supply-to-forecast ratio analysis flagging potential regional shortages or contract surpluses.
   - **Transparent Confidence Scoring**: Empirical multi-factor confidence rating ($15\%\text{--}88\%$) with human-readable audit drivers.
   - **Dedicated Intelligence Dashboard (`/ai-insights`)**: Recharts trend forecasting, Pan-India coarse demand heatmap, and interactive demand matrix.
   - **Role-Tailored Insights**:
     - Farmer: Suggested listing quantity ranges (e.g. `100–150 kg`).
     - FPO: Member crop aggregation priorities and regional gap analysis.
     - Bulk Buyer: Upcoming demand signals and volume sourcing advisories.
     - Consumer: Trending fresh produce tags based on demand velocity.

5. **Hyperlocal Logistics & Route Optimization (Phase 7)**:
   - **Nearest-Neighbor + 2-Opt Tour Optimization**: Deterministic mathematical routing that untangles corridor crossings, delivering **20%–25% distance reduction** compared to sequential routes.
   - **Transparent Speed & Dwell Model**: 40 km/h blended corridor velocity with realistic dwell allocations (15m pickup, 20m hub, 10m delivery).
   - **Vehicle Capacity & Fleet Pooling**: Standardized profiles (Mini Truck 500kg, Small Truck 1000kg, Medium Truck 2500kg, Large Truck 5000kg) with automated multi-route splitting on excess load.
   - **Consignment Tracking**: Unique `FS-SHP-YYYY-XXXX` shipment numbers with sequential 6-stage lifecycle tracking.
   - **Dedicated Fleet Hub (`/logistics`)**: Interactive MapLibre GL map, 5 fleet KPIs, active route selector, and interactive collection planner.
   - **Multi-Role Integrations**:
     - Farmer: Scheduled farm gate pickups with "Ready for Truck" crating notifications.
     - FPO: Cluster collection runs and vehicle capacity utilization monitors.
     - Bulk Buyer: In-transit consignment manifests and estimated delivery windows.
     - Consumer: Doorstep delivery transit status embedded directly in order tracking.

6. **Multi-Supplier Cart & Fulfillment**:
   - Grouping produce from multiple farmers into a single commercial order with independent supplier fulfillment records.

7. **Real-Time In-App Notification Center**:
   - Instant transaction notifications for order placement, confirmation, dispatch, and delivery.

---

## 🚀 Getting Started

### 1. Prerequisites
- [Node.js](https://nodejs.org/) (v18 or v20+)
- npm or yarn

### 2. Installation
```bash
# Clone repository and navigate to root
cd FasalSetu

# Install dependencies
npm install
```

### 3. Environment Configuration
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

Configure your Supabase credentials in `.env`:
```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-public-key
```

*(Note: If Supabase credentials are not provided, FasalSetu operates in safe local prototype fallback mode using pre-seeded demo accounts.)*

### 4. Run Development Server
```bash
npm run dev
```
Open [http://localhost:5173](http://localhost:5173) in your browser.

---

## 🗄️ Database Migrations (Supabase)

All database schema, constraints, views, and PostgreSQL RPC functions are organized sequentially in [`supabase/migrations/`](file:///supabase/migrations/):

- `001_profiles.sql`: User profiles and role constraints (`farmer`, `fpo`, `consumer`, `bulk_buyer`).
- `002_farmer_fpo_profiles.sql`: Farmer/FPO profiles and member farmer rosters.
- `003_buyer_profiles.sql`: Consumer and bulk buyer business profiles.
- `004_locations.sql`: Farm & buyer locations with `public_farm_locations` privacy view.
- `005_products.sql`: Produce catalog, stock constraints, and `public_products` view.
- `006_orders.sql`: Orders, order items, multi-supplier fulfillments, and order timeline.
- `007_inventory.sql`: Inventory transaction audit ledger.
- `008_notifications.sql`: Transactional in-app notifications.
- `009_saved_products.sql`: Consumer bookmarked produce.
- `010_rls_policies.sql`: Row Level Security policies for all tables.
- `011_functions.sql`: PostgreSQL transactional RPCs (`create_order_transaction`, `update_order_status`, `cancel_order_transaction`).
- `012_storage.sql`: Storage buckets `product-images` and `avatars`.
- `013_demand_forecasts.sql`: AI demand forecasts table, RLS policies, and lookup indexes.
- `014_logistics.sql`: Hyperlocal logistics routes, route stops, shipments tracking, and producer pickup schedules with RLS.
- `015_smart_supply_chain.sql`: Smart matches, regional supply-demand insights, procurement recommendations, and opportunity scores with RLS.
- `seed.sql`: Safe Pan-India prototype records.

For detailed documentation, refer to:
- [`SMART_SUPPLY_CHAIN_ARCHITECTURE.md`](file:///SMART_SUPPLY_CHAIN_ARCHITECTURE.md) — Smart Supply-Chain Intelligence Engine Architecture
- [`LOGISTICS_ARCHITECTURE.md`](file:///LOGISTICS_ARCHITECTURE.md) — Logistics & Route Optimization Architecture
- [`AI_ARCHITECTURE.md`](file:///AI_ARCHITECTURE.md) — AI Demand Intelligence Architecture
- [`SUPABASE_SETUP.md`](file:///SUPABASE_SETUP.md) — Supabase Setup Guide

---

## 🧪 Testing & Verification

```bash
# Run linting (oxlint - 0 errors, 0 warnings)
npm run lint

# Run Phase 4 transaction & fulfillment validation (21/21 passing)
node scripts/verify_phase4.js

# Run Phase 5 Supabase, migrations, RLS & service validation (47/47 passing)
node scripts/verify_phase5.js

# Run Phase 6 AI demand intelligence & predictive agriculture validation (54/54 passing)
node scripts/verify_phase6.js

# Run Phase 7 Hyperlocal logistics & route optimization validation (78/78 passing)
node scripts/verify_phase7.js

# Run Phase 8 Smart supply-chain intelligence validation (63/63 passing)
node scripts/verify_phase8.js

# Build production bundle
npm run build
```

---

## ⚖️ Prototype Commercial Terms

In accordance with responsible prototyping standards, all procurement purchase orders are generated with explicit disclaimer-backed **Prototype Commercial Terms**:
- **Mandi / Market Fees**: To be determined according to applicable rules.
- **Quality / Moisture**: Subject to buyer-supplier agreement and inspection.
- **Logistics / Freight**: As agreed between buyer and supplier.
- **Legal / Tax Terms**: Applicable statutory requirements govern the final transaction.
