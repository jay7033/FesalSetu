# FasalSetu — Presentation Notes
**SIH 2026 · Problem Statement 26033**  
*Department of Consumer Affairs, Ministry of Consumer Affairs, Food & Public Distribution*

---

## 🎯 The 30-Second Elevator Pitch

> "FasalSetu is an AI-powered cooperative marketplace that connects India's 86% small farmers directly to consumers and institutional buyers — eliminating middleman layers, preventing overselling through atomic inventory, and optimizing hyperlocal logistics — all while protecting farmer GPS privacy. Think of it as a complete farm-to-fork operating system, not just a listing portal."

---

## 🎤 The 1-Minute Pitch

> "India's agricultural supply chain has a structural problem: 86% of farmers are small or marginal, lacking direct market access. Multi-tiered middlemen extract 30-60% margins, while farmers plant blindly without demand intelligence.
>
> FasalSetu solves this with four innovations:
>
> **First**, a unified marketplace with dedicated portals for Farmers, FPOs, Consumers, and Bulk Buyers — enabling direct price discovery.
>
> **Second**, an AI demand intelligence engine that uses statistical forecasting to show farmers where demand exists before they harvest, with honest prototype-level confidence indicators.
>
> **Third**, atomic inventory protection using PostgreSQL row-level locks that mathematically prevent overselling — even under concurrent access.
>
> **Fourth**, hyperlocal logistics optimization using 2-Opt heuristic routing that clusters fragmented smallholder pickups into efficient dispatch sequences.
>
> The platform runs on a fully open-source stack, works offline through a built-in fallback engine, and protects farmer privacy by masking GPS coordinates from public view."

---

## 🎙️ The 3-Minute Pitch

### Problem (45 seconds)
- 86% of Indian farmers are small/marginal with <2 hectares
- Multi-layer middlemen extract 30-60% of final consumer price
- Farmers lack demand intelligence — plant blindly, face seasonal gluts
- Logistical fragmentation: small batches, high transport costs, no coordination
- Result: depressed farmgate prices AND inflated retail prices simultaneously

### Solution (90 seconds)
**FasalSetu — "Connecting Farms. Empowering Farmers."**

1. **Direct Multi-Role Market:**
   - 4 dedicated portals: Farmer, FPO, Consumer, Bulk Buyer
   - Role-based authentication with PostgreSQL-backed profiles
   - Cooperative aggregation through FPO member pooling

2. **AI Demand Intelligence:**
   - Statistical demand forecasting (Weighted Moving Average + regional trend multipliers)
   - Farmer Opportunity Scores (0-100) with actionable listing advice
   - Supply-Demand Gap analysis with redistribution recommendations
   - Honestly labeled as "Forecast Confidence" — not overstated ML accuracy

3. **Atomic Inventory & Financial Protection:**
   - PostgreSQL RPC with FOR UPDATE row locks
   - Reserve on order → Deduct on delivery → Release on cancel
   - Mathematically impossible to oversell, even under concurrent access

4. **Hyperlocal Logistics:**
   - Nearest Neighbor + 2-Opt route optimization
   - Vehicle capacity enforcement
   - Interactive MapLibre route visualization

### Technical Strength (30 seconds)
- Full Supabase PostgreSQL backend with 15 sequential migrations
- Row Level Security on all 21 tables
- Dual-mode architecture: works fully offline with localStorage fallback
- Zero proprietary API dependencies — fully open-source stack
- GPS privacy: approximate-public / precise-private model

### Impact (15 seconds)
- Eliminates 2-3 intermediary layers
- Enables small farmers to serve institutional demand through FPO aggregation
- Transparent price discovery replaces opaque mandi auctions
- Privacy-first: farmer locations never exposed publicly

---

## 🎙️ The 5-Minute Full Pitch

*Use the 3-minute structure above, plus:*

### Live Demo Highlights (additional 2 minutes)
Walk through the live application demonstrating:

1. **Landing page** — Bilingual banner, 4 stakeholder pillars, problem statement alignment
2. **Farmer login** — Instant demo credentials, dashboard with AI opportunity score
3. **GPS privacy** — Show farmer's own view vs. public marketplace view
4. **Consumer checkout** — Add to cart, multi-supplier checkout, instant reservation
5. **Inventory proof** — Log back as farmer, show stock decremented immediately
6. **AI insights** — Demand forecast, supply-gap analysis, redistribution recommendations
7. **Logistics** — Optimized pickup route on interactive map
8. **Order lifecycle** — Advance through states, verify delivery deduction

---

## 💡 Innovation Highlights (Key Differentiators to Emphasize)

### 1. Atomic Inventory — Not Just a Feature, a Guarantee
> "Most agri-platforms treat inventory as a number to display. We treat it as a financial contract. Our PostgreSQL FOR UPDATE locks mean that if we show 100 kg available, exactly 100 kg can be ordered — not 101."

### 2. Privacy-Preserving Agriculture
> "We're one of the few agri-platforms that explicitly masks farmer GPS coordinates from buyers. Farmers see their own farm locations; the public sees only 'Near Nashik, Maharashtra.' This is database-enforced through Row Level Security, not just UI hiding."

### 3. Cooperative Intelligence, Not Just a Marketplace
> "FasalSetu doesn't just connect buyers and sellers. It actively tells farmers what to grow, where demand exists, and how to aggregate through FPOs for bulk orders they couldn't serve alone."

### 4. Resilient Dual-Mode Architecture
> "Unlike platforms that crash without internet, FasalSetu seamlessly falls back to a fully functional offline mode. Every feature — ordering, AI, logistics, inventory — works identically. No spinner of death."

### 5. Honest AI
> "We don't claim 99% accuracy or guaranteed income increases. Our statistical model is transparent, deterministic, and labeled clearly as prototype indicators. Every score can be traced back to its exact input factors."

---

## 📊 Impact Metrics (Prototype Indicators)

> **⚠️ Note:** These are illustrative prototype benchmarks based on our model architecture, not verified production statistics.

| Metric | Prototype Indicator |
| :--- | :--- |
| Intermediary Layers Eliminated | 2-3 per transaction |
| Inventory Oversell Prevention | 100% (atomic locks) |
| Route Optimization Improvement | 15-25% distance reduction (2-Opt vs. naive) |
| Farmer GPS Privacy | 100% masked in public surfaces |
| Offline Capability | 100% feature parity in fallback mode |
| Database Security Coverage | 21/21 tables with RLS enabled |

---

## 🚨 Things to NOT Say During Presentation

- ❌ "Our AI has 99% accuracy" — Say: "Our statistical model provides forecast confidence indicators"
- ❌ "Farmers will earn 30% more" — Say: "Direct market access eliminates intermediary margins"
- ❌ "We guarantee delivery in X hours" — Say: "Our prototype ETAs use a 40 km/h baseline model"
- ❌ "GST/Mandi exemptions apply" — Say: "Applicable statutory requirements govern final transactions"
- ❌ "This is production-ready" — Say: "This is a production-architecture prototype with clear upgrade paths"

---

## 🔑 Closing Statement

> "FasalSetu is not just another agri-marketplace. It's a complete cooperative intelligence platform that makes direct farm-to-fork commerce mathematically safe, logistically efficient, and privacy-preserving. We've built it on an entirely open-source stack, it works offline, and every AI claim is honestly labeled. फसल से बाज़ार तक, सीधे और स्मार्ट तरीके से।"
