# FasalSetu — SIH 2026 Live Demo Guide
**Problem Statement 26033** — Department of Consumer Affairs, Ministry of Consumer Affairs, Food & Public Distribution  
**Theme:** Agriculture, FoodTech & Rural Development  
**Tagline:** *Connecting Farms. Empowering Farmers.* (फसल से बाज़ार तक, सीधे और स्मार्ट तरीके से।)

---

## 1. Executive Summary & Problem-Solution Matrix

### The Problem
- **Fragmented Smallholders:** 86% of Indian farmers are small/marginal producers lacking direct market access and bargaining leverage.
- **Intermediary Extraction:** Multi-tiered middleman markups (30–60%) lead to depressed farmgate realizations alongside inflated retail/wholesale prices.
- **Information Asymmetry:** Farmers plant blindly without predictive demand intelligence, causing seasonal gluts, distress sales, and high post-harvest perishability.
- **Logistical Inefficiencies:** High transport costs, empty backhauls, and uncoordinated small-batch dispatches make direct farm-to-buyer fulfillment cost-prohibitive.

### The FasalSetu Solution
FasalSetu is a unified, privacy-preserving AgriTech operating platform providing:
1. **Direct Role-Based Multi-Tier Market Access:** Dedicated portals for Individual Farmers, Farmer Producer Organizations (FPOs), Retail Consumers, and Institutional Bulk Buyers.
2. **AI-Assisted Demand Intelligence:** Statistical demand forecasting (Weighted Moving Average + Regional Trend multipliers) providing localized demand classifications, supply-gap alerts, and farmer opportunity scores.
3. **Smart Matching & Aggregation:** Algorithmic matching balancing distance, volume, quality grade, freshness, and price; enabling FPOs to aggregate fragmented smallholder harvests.
4. **Hyperlocal Logistics & Route Optimization:** Algorithmic pickup routing (Nearest Neighbor + 2-Opt heuristic) with dynamic vehicle capacity constraints and transparent transit tracking.
5. **Atomic Inventory & Financial Safeguards:** PostgreSQL RPC transactions preventing overselling, reserving stock on order, and permanently deducting on delivery.

---

## 2. Pre-Configured Demo Accounts

FasalSetu comes with instant demo credentials pre-wired into the authentication modal for frictionless live demonstration without requiring external SMS OTP gateways.

| Role | Demo Email | Password | Primary Mission in Demo |
| :--- | :--- | :--- | :--- |
| **Farmer** | `farmer@fasalsetu.com` | `demo123` | Shows farm listing, inventory, privacy mask, AI harvest opportunity. |
| **FPO Admin** | `fpo@fasalsetu.com` | `demo123` | Aggregates member supply, clusters dispatches, coordinates logistics. |
| **Consumer** | `consumer@fasalsetu.com` | `demo123` | Browses fresh produce, places multi-item order, tracks delivery. |
| **Bulk Buyer** | `buyer@fasalsetu.com` | `demo123` | Procurement dashboard, smart matching recommendations, commercial PO. |

---

## 3. The 5–8 Minute Judge Presentation Flow

```mermaid
sequenceDiagram
    autonumber
    actor Farmer as Ramesh (Farmer)
    actor Consumer as Priya (Consumer)
    actor FPO as Kisan Vikas FPO
    actor Logistics as FasalSetu Logistics Engine
    
    Note over Farmer: Step 1: Listing & AI Opportunity
    Farmer->>Farmer: Views Opportunity Score (88/100) & Lists 150 kg Tomatoes
    
    Note over Consumer: Step 2: Discovery & Checkout
    Consumer->>Consumer: Discovers Grade-A Tomatoes (Nashik district mask)
    Consumer->>Consumer: Places Order for 30 kg
    Note over Consumer: DB RPC executes: Stock Reserved (120 kg avail / 30 kg res)
    
    Note over FPO: Step 3: Aggregation & Bulk Matching
    FPO->>FPO: Aggregates Ramesh's surplus with 4 member farmers
    
    Note over Logistics: Step 4: Route Optimization
    Logistics->>Logistics: 2-Opt Heuristic builds pickup sequence (4 stops, 82% capacity)
    
    Note over Consumer: Step 5: Lifecycle & Delivery
    Logistics->>Consumer: Moves: Confirmed -> Preparing -> In Transit -> Delivered
    Note over Farmer: DB permanently deducts 30 kg, notifies Farmer & updates balance
```

### Step 1: Platform Overview & Landing (Minute 0:00 – 1:00)
- Navigate to `/` (Home).
- Point out the bilingual banner (*“फसल से बाज़ार तक, सीधे और स्मार्ट तरीके से।”*), the four stakeholder pillars, and the live metrics counters (clearly marked as illustrative prototype benchmarks).
- Show the **SIH 2026 Problem Statement 26033** alignment badge.

### Step 2: Farmer Portal & Privacy Protection (Minute 1:00 – 2:30)
- Click **Login** $\rightarrow$ Click **"Farmer" Quick-Fill** $\rightarrow$ Sign In.
- Directed to `/farmer/dashboard`.
- **Key Features to Highlight to Judges:**
  1. **Produce Inventory:** Show listed items (e.g., Nashik Red Tomatoes).
  2. **GPS Privacy Assurance:** Open `/farmer/locations`. Show that while the farmer sees their registered farm location, the public marketplace sees only: `“Near Nashik, Maharashtra”` (exact latitude/longitude are strictly masked).
  3. **AI Opportunity Score:** Highlight the **88/100 Harvest Opportunity Badge** indicating high regional urban demand for tomatoes with actionable advice.

### Step 3: Consumer Discovery & Atomic Checkout (Minute 2:30 – 4:00)
- Logout and log in as **Consumer** (`consumer@fasalsetu.com`).
- Navigate to `/marketplace`.
- **Key Features to Highlight:**
  1. **Produce Cards:** Show Grade, Harvest Date, Farmer Name, and **Approximate Location**. Note the complete absence of raw GPS coordinates.
  2. **Add to Cart & Checkout:** Add 20 kg of Tomatoes.
  3. Proceed to `/checkout`. Select delivery address and click **Confirm Order**.
  4. Instant feedback confirms the order.
  5. Open `/consumer/orders`. Show order state is currently **Confirmed** with supplier breakdown.

### Step 4: Inventory Proof & Atomic Protection (Minute 4:00 – 4:45)
- Log back in as **Farmer**.
- Open `/farmer/products`.
- Demonstrate that **Available Stock** immediately decreased by 20 kg, while **Reserved Stock** reflects the 20 kg pending fulfillment.
- Emphasize to judges: *“Even under high concurrent access, our PostgreSQL RPC `create_order_transaction` locks rows to mathematically prevent overselling.”*

### Step 5: AI Demand Intelligence & Smart Supply Chain (Minute 4:45 – 6:00)
- Navigate to `/ai-insights`.
- Explain the engine honestly:
  - **Model:** Statistical baseline combining a 3-tier Weighted Moving Average (50% 7-day, 30% 14-day, 20% 30-day) with a 0.80–1.25 trend factor.
  - **Terminology:** Point out that confidence is explicitly labeled as **“Forecast Confidence: 88%”** (a heuristic statistical indicator, not overstated predictive accuracy).
  - Show the **Supply-Demand Gap Analysis** and **Redistribution Recommendations** (e.g., redistributing surplus onions from Nashik to deficit areas in Pune).

### Step 6: Hyperlocal Logistics & Route Optimization (Minute 6:00 – 7:15)
- Navigate to `/logistics`.
- **Key Features to Highlight:**
  1. **Route Engine:** Show the pickup schedule table and interactive MapLibre map.
  2. **2-Opt Optimization:** Demonstrate how multiple farmer farmgates are clustered into an optimized sequence.
  3. **Capacity Validation:** Explain vehicle load limits (e.g., 500 kg Tata Ace) preventing overloaded dispatches.
  4. **Honest ETAs:** Highlight that travel times use a standard prototype 40 km/h baseline + dwell time, labeled as *“Estimated ETA”*.

### Step 7: Order Lifecycle Fulfillment & Wrap-up (Minute 7:15 – 8:00)
- In the logistics or order management dashboard, advance the order state:
  $$\text{Preparing} \longrightarrow \text{Ready for Pickup} \longrightarrow \text{In Transit} \longrightarrow \text{Delivered}$$
- Verify that upon `Delivered`, the reserved inventory is permanently deducted and audit records are finalized.
- Conclude with the SIH value proposition: direct farmer empowerment, transparent price discovery, and cooperative logistics aggregation.

---

## 4. Hybrid Live + Demo Data Architecture & Evaluation Presentation

FasalSetu features a unified **Hybrid Architecture** that blends live database records with verified baseline catalogs:

### 4.1 How to Explain the Architecture to SIH Judges
1. **Never a Toy Mock:** Explain to the jury:
   > *"FasalSetu uses a production-ready Hybrid Data Engine. Live Supabase PostgreSQL records always take precedence. When new farmers register or upload produce, those records immediately integrate with live priority. Pre-seeded baseline catalogs ensure the platform is never empty during demonstration."*
2. **Show the Connection Indicator:**
   - Point out the status pill in the top navigation bar:
     - **Green Dot (`Live Sync`):** Supabase PostgreSQL is actively connected.
     - **Amber Dot (`Demo Sandbox`):** Self-contained resilient local engine.
   - Click the indicator to open the **Data Breakdown Popover**:
     - Displays live farmer listings count vs baseline seed samples.
     - Explains the hybrid data guarantee.
     - Demonstrates architectural maturity and transparent system status.
3. **AI Pipeline Transparency:**
   - On the `/ai-insights` dashboard, highlight the **Hybrid Intelligence Pipeline** banner:
     - Shows exact metrics: e.g. *“Based on X live + Y baseline samples”*.
     - Shows judges that FasalSetu is mathematically transparent about its data inputs.
4. **Zero Risk of Stale Data Interference:**
   - If judges want to test resetting state without losing live work, show the **"Reset Demo Data"** action (accessible in dev mode or via `?demo=true`), which purges only cached mock records while strictly preserving live database records.
